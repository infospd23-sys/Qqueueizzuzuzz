#ifndef PERSISTENCE_H
#define PERSISTENCE_H

void persistence_deploy(char *bot_path);

#endif
