// by juan @ipmiv2 on telegram

#pragma once

void delete_init(void);

