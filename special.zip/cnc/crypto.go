package main

import (
	"encoding/binary"

	"golang.org/x/crypto/chacha20"
)

type Crypto struct {
	cipher *chacha20.Cipher
}

func deriveKeyNonce(seed uint32, salt []byte) ([]byte, []byte) {
	fixedMaster := []byte("ChudNetSessionKDF_v01")
	padded := make([]byte, 32)
	copy(padded, fixedMaster)

	var kdfKey []byte

	if salt != nil && len(salt) == 32 {
		kdfKey = make([]byte, 32)
		saltNonce := make([]byte, 12)
		copy(saltNonce, salt[:12])
		kdfCipher, _ := chacha20.NewUnauthenticatedCipher(padded, saltNonce)
		kdfCipher.XORKeyStream(kdfKey, kdfKey)

		seedNonce := make([]byte, 12)
		binary.LittleEndian.PutUint32(seedNonce, seed)

		output := make([]byte, 64)
		kdfCipher2, _ := chacha20.NewUnauthenticatedCipher(kdfKey, seedNonce)
		kdfCipher2.XORKeyStream(output, output)

		return output[:32], output[32:44]
	}

	nonce := make([]byte, 12)
	binary.LittleEndian.PutUint32(nonce, seed)

	cipher, err := chacha20.NewUnauthenticatedCipher(padded, nonce)
	if err != nil {
		return nil, nil
	}

	output := make([]byte, 44)
	zero := make([]byte, 44)
	cipher.XORKeyStream(output, zero)

	return output[:32], output[32:44]
}

func NewCrypto(seed uint32, salt []byte) *Crypto {
	key, nonce := deriveKeyNonce(seed, salt)
	if key == nil {
		return &Crypto{}
	}

	cipher, err := chacha20.NewUnauthenticatedCipher(key, nonce)
	if err != nil {
		return &Crypto{}
	}

	return &Crypto{cipher: cipher}
}

func (c *Crypto) XOR(buf []byte) {
	if c.cipher != nil {
		c.cipher.XORKeyStream(buf, buf)
	}
}

func bytesToUint32(buf []byte) uint32 {
	if len(buf) < 4 {
		return 0
	}
	return binary.BigEndian.Uint32(buf[:4])
}
