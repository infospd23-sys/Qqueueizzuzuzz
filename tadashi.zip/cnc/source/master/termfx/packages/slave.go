package packages

type Slaves struct {
	Count     int
	UserCount int
	Speedtest string
}
