#pragma once
#include <stdint.h>

void crypto_init(uint32_t seed);
void crypto_set_salt(const uint8_t *salt);
void crypto_xor(uint8_t *buf, int len);
