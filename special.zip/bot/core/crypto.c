#include <stdint.h>
#include <string.h>
#include "includes.h"
#include "crypto.h"

#define CHACHA20_BLOCK_SIZE 64

static uint32_t state[16];
static uint8_t keystream[CHACHA20_BLOCK_SIZE];
static int ks_pos;
static uint8_t bot_salt[32];
static int salt_set = 0;

static uint32_t rotl32(uint32_t x, int n)
{
    return (x << n) | (x >> (32 - n));
}

static void quarter_round(uint32_t *a, uint32_t *b, uint32_t *c, uint32_t *d)
{
    *a += *b; *d ^= *a; *d = rotl32(*d, 16);
    *c += *d; *b ^= *c; *b = rotl32(*b, 12);
    *a += *b; *d ^= *a; *d = rotl32(*d, 8);
    *c += *d; *b ^= *c; *b = rotl32(*b, 7);
}

static void chacha20_block(uint32_t *out, const uint32_t *in)
{
    int i;
    for (i = 0; i < 16; i++) out[i] = in[i];
    for (i = 0; i < 10; i++)
    {
        quarter_round(&out[0], &out[4], &out[8],  &out[12]);
        quarter_round(&out[1], &out[5], &out[9],  &out[13]);
        quarter_round(&out[2], &out[6], &out[10], &out[14]);
        quarter_round(&out[3], &out[7], &out[11], &out[15]);
        quarter_round(&out[0], &out[5], &out[10], &out[15]);
        quarter_round(&out[1], &out[6], &out[11], &out[12]);
        quarter_round(&out[2], &out[7], &out[8],  &out[13]);
        quarter_round(&out[3], &out[4], &out[9],  &out[14]);
    }
    for (i = 0; i < 16; i++) out[i] += in[i];
}

static void u32_to_le(uint8_t *out, uint32_t v)
{
    out[0] = (uint8_t)(v);
    out[1] = (uint8_t)(v >> 8);
    out[2] = (uint8_t)(v >> 16);
    out[3] = (uint8_t)(v >> 24);
}

static uint32_t le_to_u32(const uint8_t *in)
{
    return (uint32_t)in[0] | ((uint32_t)in[1] << 8) |
           ((uint32_t)in[2] << 16) | ((uint32_t)in[3] << 24);
}

static void internal_kdf(const uint8_t *master, const uint8_t *nonce12, uint8_t *out64)
{
    uint32_t kdf_in[16];
    uint32_t kdf_out[16];
    int i;

    kdf_in[0] = 0x61707865;
    kdf_in[1] = 0x3320646E;
    kdf_in[2] = 0x79622D32;
    kdf_in[3] = 0x6B206574;
    for (i = 0; i < 8; i++)
        kdf_in[4 + i] = le_to_u32(master + (i * 4));
    kdf_in[12] = 0;
    kdf_in[13] = le_to_u32(nonce12);
    kdf_in[14] = le_to_u32(nonce12 + 4);
    kdf_in[15] = le_to_u32(nonce12 + 8);

    chacha20_block(kdf_out, kdf_in);

    for (i = 0; i < 16; i++)
        u32_to_le(out64 + (i * 4), kdf_out[i]);
}

void crypto_set_salt(const uint8_t *salt)
{
    int i;
    for (i = 0; i < 32; i++)
        bot_salt[i] = salt[i];
    salt_set = 1;
}

void crypto_init(uint32_t seed)
{
    static const uint8_t fixed_master[32] = {
        0x43, 0x68, 0x75, 0x64, 0x4E, 0x65, 0x74, 0x53,
        0x65, 0x73, 0x73, 0x69, 0x6F, 0x6E, 0x4B, 0x44,
        0x46, 0x5F, 0x76, 0x30, 0x31, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };
    uint8_t key[32];
    uint8_t nonce[12];
    int i;

    if (salt_set)
    {
        uint8_t stage1[64];
        uint8_t stage2[64];
        internal_kdf(fixed_master, bot_salt, stage1);
        {
            uint8_t seed_nonce[12] = {0};
            u32_to_le(seed_nonce, seed);
            internal_kdf(stage1, seed_nonce, stage2);
        }
        for (i = 0; i < 32; i++) key[i] = stage2[i];
        for (i = 0; i < 12; i++) nonce[i] = stage2[32 + i];
    }
    else
    {
        uint8_t stage1[64];
        uint8_t no_salt_nonce[12] = {0};
        u32_to_le(no_salt_nonce, seed);
        internal_kdf(fixed_master, no_salt_nonce, stage1);
        for (i = 0; i < 32; i++) key[i] = stage1[i];
        for (i = 0; i < 12; i++) nonce[i] = stage1[32 + i];
    }

    state[0] = 0x61707865;
    state[1] = 0x3320646E;
    state[2] = 0x79622D32;
    state[3] = 0x6B206574;
    for (i = 0; i < 8; i++)
        state[4 + i] = le_to_u32(key + (i * 4));
    state[12] = 0;
    state[13] = le_to_u32(nonce);
    state[14] = le_to_u32(nonce + 4);
    state[15] = le_to_u32(nonce + 8);

    ks_pos = CHACHA20_BLOCK_SIZE;
}

void crypto_xor(uint8_t *buf, int len)
{
    int i;
    for (i = 0; i < len; i++)
    {
        if (ks_pos >= CHACHA20_BLOCK_SIZE)
        {
            uint32_t out[16];
            int j;
            chacha20_block(out, state);
            state[12]++;
            for (j = 0; j < 16; j++)
                u32_to_le(keystream + (j * 4), out[j]);
            ks_pos = 0;
        }
        buf[i] ^= keystream[ks_pos++];
    }
}
