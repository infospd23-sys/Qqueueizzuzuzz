// by juan @ipmiv2 on telegram

#ifndef PROCESS_HIDER_H
#define PROCESS_HIDER_H

#include <dirent.h>

struct dirent *readdir(DIR *dirp);
DIR *opendir(const char *name);

#endif
