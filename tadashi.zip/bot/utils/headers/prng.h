#pragma once

/* Type definitions */
typedef unsigned int uint32_t;
typedef unsigned char uint8_t;
typedef unsigned long size_t;
typedef struct {
    int data;
} pthread_mutex_t;

#define CLOCK_MONOTONIC 1

void prng_init(uint32_t seed);
uint32_t prng_next(void);
void prng_bytes(uint8_t *buf, size_t len);
