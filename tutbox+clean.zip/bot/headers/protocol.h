// by juan @ipmiv2 on telegram

#pragma once

#include <stdint.h>
#include "config.h"

// DNS Header Structure
struct dnshdr {
    uint16_t id;
    uint16_t opts;
    uint16_t qdcount;
    uint16_t ancount;
    uint16_t nscount;
    uint16_t arcount;
};

// DNS Question Structure
struct dns_question {
    uint16_t qtype;
    uint16_t qclass;
};

// DNS Resource Structure
struct dns_resource {
    uint16_t type;
    uint16_t _class;
    uint32_t ttl;
    uint16_t data_len;
} __attribute__((packed));

// GRE Header Structure
struct grehdr {
    uint16_t opts;
    uint16_t protocol;
};

// DNS Protocol Constants
#define PROTO_DNS_QTYPE_A      1
#define PROTO_DNS_QCLASS_IP    1

// TCP Protocol Constants
#define PROTO_TCP_OPT_NOP      1
#define PROTO_TCP_OPT_MSS      2
#define PROTO_TCP_OPT_WSS      3
#define PROTO_TCP_OPT_SACK     4
#define PROTO_TCP_OPT_TSVAL    8

// GRE Protocol Constants
#define PROTO_GRE_TRANS_ETH    0x6558
