module cnc

go 1.21.0

require (
	github.com/mattn/go-shellwords v1.0.13
	github.com/mattn/go-sqlite3 v1.14.24
)
