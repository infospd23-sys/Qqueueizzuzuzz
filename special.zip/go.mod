module cnc

go 1.26.4

require (
	github.com/mattn/go-shellwords v1.0.13
	github.com/mattn/go-sqlite3 v1.14.47
	golang.org/x/crypto v0.53.0
	golang.org/x/term v0.44.0
)

require golang.org/x/sys v0.46.0 // indirect
