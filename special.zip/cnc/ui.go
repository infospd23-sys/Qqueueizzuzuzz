package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"
)

type UIManager struct {
	basePath string
	mapping  map[string]string
}

func NewUIManager(basePath string) *UIManager {
	m := &UIManager{
		basePath: basePath,
		mapping:  make(map[string]string),
	}

	mappingPath := filepath.Join(basePath, "ui/ui.json")
	if err := m.loadMapping(mappingPath); err != nil {
		fmt.Println("[ui] failed to load mapping, using defaults:", err)
		m.mapping = map[string]string{
			"home":       "home.tfx",
			"chud":       "chud.tfx",
			"help":       "help.tfx",
			"methods":    "methods.tfx",
			"admin":      "admin.tfx",
			"attacksent": "attacksent.tfx",
			"stats":      "stats.tfx",
			"plan":       "plan.tfx",
			"prompt":     "prompt.tfx",
			"ongoing":    "ongoing.tfx",
		}
	}

	fmt.Println("[ui] loaded", len(m.mapping), "screen templates")
	return m
}

func (u *UIManager) loadMapping(path string) error {
	file, err := os.Open(path)
	if err != nil {
		return err
	}
	defer file.Close()

	decoder := json.NewDecoder(file)
	return decoder.Decode(&u.mapping)
}

func (u *UIManager) GetScreen(name string, vars map[string]string) string {
	filename, exists := u.mapping[name]
	if !exists {
		return ""
	}

	content, err := u.readTFX(filename)
	if err != nil {
		return ""
	}

	return u.replaceVariables(content, vars)
}

func (u *UIManager) readTFX(filename string) (string, error) {
	path := filepath.Join(u.basePath, "ui", filename)
	data, err := os.ReadFile(path)
	if err != nil {
		fmt.Println("[ui] failed to read", filename, err)
		return "", err
	}

	content := string(data)
	content = processEscapeCodes(content)
	return content, nil
}

func processEscapeCodes(content string) string {
	content = strings.ReplaceAll(content, "\r\n", "")
	content = strings.ReplaceAll(content, "\n", "")
	content = strings.ReplaceAll(content, "\r", "")
	content = strings.ReplaceAll(content, "\\033", "\033")
	content = strings.ReplaceAll(content, "\\x1b", "\033")
	content = strings.ReplaceAll(content, "\\e", "\033")
	content = strings.ReplaceAll(content, "\\007", "\007")
	content = strings.ReplaceAll(content, "\\r\\n", "\n")
	content = strings.ReplaceAll(content, "\\n", "\n")
	return content
}

func (u *UIManager) replaceVariables(content string, vars map[string]string) string {
	result := content

	result = strings.ReplaceAll(result, "{primary}", theme.Primary)
	result = strings.ReplaceAll(result, "{secondary}", theme.Secondary)
	result = strings.ReplaceAll(result, "{separator}", theme.Separator)
	result = strings.ReplaceAll(result, "{success}", theme.Success)
	result = strings.ReplaceAll(result, "{warning}", theme.Warning)
	result = strings.ReplaceAll(result, "{error}", theme.Error)
	result = strings.ReplaceAll(result, "{info}", theme.Info)
	result = strings.ReplaceAll(result, "{muted}", theme.Muted)
	result = strings.ReplaceAll(result, "{header}", theme.Header)
	result = strings.ReplaceAll(result, "{prompt}", theme.Prompt)

	if vars != nil {
		for key, value := range vars {
			placeholder := "{" + key + "}"
			result = strings.ReplaceAll(result, placeholder, value)
		}
	}

	return result
}

func (u *UIManager) HasScreen(name string) bool {
	filename, exists := u.mapping[name]
	if !exists {
		return false
	}
	path := filepath.Join(u.basePath, "config/ui", filename)
	_, err := os.Stat(path)
	return err == nil
}

func FormatTable(headers []string, rows [][]string, colors []string) string {
	if len(headers) == 0 {
		return ""
	}

	widths := make([]int, len(headers))
	for i, h := range headers {
		widths[i] = len(h) + 2
	}
	for _, row := range rows {
		for i, cell := range row {
			if i < len(widths) {
				cleanCell := stripAnsi(cell)
				if len(cleanCell)+2 > widths[i] {
					widths[i] = len(cleanCell) + 2
				}
			}
		}
	}

	var sb strings.Builder

	headerColor := "\033[1;37m"
	if len(colors) > 0 && colors[0] != "" {
		headerColor = colors[0]
	}

	sb.WriteString("\r\n")
	sb.WriteString(headerColor)
	for i, h := range headers {
		sb.WriteString(padRight(h, widths[i]))
	}
	sb.WriteString("\033[0m\r\n")

	totalWidth := 0
	for _, w := range widths {
		totalWidth += w
	}
	sb.WriteString("\033[1;37m" + strings.Repeat("-", totalWidth) + "\033[0m\r\n")

	rowColor := "\033[1;31m"
	if len(colors) > 1 && colors[1] != "" {
		rowColor = colors[1]
	}

	for _, row := range rows {
		sb.WriteString(rowColor)
		for i, cell := range row {
			if i < len(widths) {
				sb.WriteString(padRight(cell, widths[i]))
			}
		}
		sb.WriteString("\033[0m\r\n")
	}

	return sb.String()
}

func padRight(s string, width int) string {
	visibleLen := len(stripAnsi(s))
	if visibleLen >= width {
		return s
	}
	return s + strings.Repeat(" ", width-visibleLen)
}

func stripAnsi(s string) string {
	re := regexp.MustCompile(`\033\[[0-9;]*m`)
	return re.ReplaceAllString(s, "")
}
