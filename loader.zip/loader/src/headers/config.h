#pragma once

#define HTTP_SERVER "66.29.151.122"
#define HTTP_PORT 80

#define TFTP_SERVER "66.29.151.122"
