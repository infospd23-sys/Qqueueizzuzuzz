#pragma once
void defender_init(void);
void defender_tick(void);
