#pragma once

/* Type definitions */
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef long long int64_t;

/* Protocol constants */
#define PROTO_DNS_QTYPE_A 1
#define PROTO_DNS_QTYPE_AAAA 28
#define PROTO_DNS_QTYPE_CNAME 5
#define PROTO_DNS_QTYPE_MX 15
#define PROTO_DNS_QTYPE_TXT 16

/* DNS header structure */
struct dnshdr {
    uint16_t id;
    uint16_t flags;
    uint16_t qdcount;
    uint16_t ancount;
    uint16_t nscount;
    uint16_t arcount;
};
