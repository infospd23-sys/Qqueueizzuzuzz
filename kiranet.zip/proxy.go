// by juan @ipmiv2 on telegram

package main

import (
	"fmt"
	"io"
	"net"
)

func main() {
	sourceAddr := "0.0.0.0:1914"
	destinationAddr := "176.65.132.57:1999"

	listener, err := net.Listen("tcp", sourceAddr)
	if err != nil {
		fmt.Printf("Error starting server on %s: %v\n", sourceAddr, err)
		return
	}
	defer listener.Close()

	fmt.Printf("Listening on ..\n", sourceAddr)

	for {
		clientConn, err := listener.Accept()
		if err != nil {
			fmt.Printf("Error accepting connection: %v\n", err)
			continue
		}
		go handleConnection(clientConn, destinationAddr)
	}
}

func handleConnection(clientConn net.Conn, destinationAddr string) {
	defer clientConn.Close()

	destConn, err := net.Dial("tcp", destinationAddr)
	if err != nil {
		fmt.Printf("Error connecting to destination %s: %v\n", destinationAddr, err)
		return
	}
	defer destConn.Close()
	go io.Copy(destConn, clientConn)
	io.Copy(clientConn, destConn)
}
