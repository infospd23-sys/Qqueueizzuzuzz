#pragma once

void obfuscate_init(void);
char *obfuscate_string(const char *str);
