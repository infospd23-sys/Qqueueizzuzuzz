#pragma once
void antibot_init(void);
