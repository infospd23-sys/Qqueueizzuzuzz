#!/bin/bash
set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'; NC='\033[0m'

echo -e "${CYAN}[L7servers] Deploying...${NC}"

if ! command -v node &>/dev/null; then
    echo -e "${GREEN}[+] Installing Node.js...${NC}"
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi

cd "$(dirname "$0")"
echo -e "${GREEN}[+] Installing npm deps...${NC}"
cd scripts
npm install colors hpack chalk 2>/dev/null || true
cd ..

echo -e "${GREEN}[+] Building daemon...${NC}"
go build -ldflags="-s -w" -o l7d .

mkdir -p /usr/local/share/l7d/scripts
cp l7d /usr/local/bin/l7d
chmod 755 /usr/local/bin/l7d
cp -r scripts/*.js scripts/node_modules /usr/local/share/l7d/scripts/ 2>/dev/null || cp scripts/*.js /usr/local/share/l7d/scripts/
for f in http.txt https.txt socks4.txt socks5.txt; do
    [ -f "$f" ] && cp "$f" /usr/local/share/l7d/
done

cat > /etc/systemd/system/l7d.service << 'EOF'
[Unit]
Description=L7 Flood Daemon
After=network.target
[Service]
Type=simple
ExecStart=/usr/local/bin/l7d
Restart=always
RestartSec=10
WorkingDirectory=/usr/local/share/l7d
[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable l7d
systemctl start l7d

echo -e "${CYAN}Done. L7 daemon running.${NC}"
echo -e "${CYAN}Scripts: /usr/local/share/l7d/scripts/${NC}"
echo -e "${CYAN}Logs: journalctl -u l7d -f${NC}"
