package user

func Init() {

}
