package user

import (
	"advanced-telnet-cnc/source/config"
	"advanced-telnet-cnc/source/master/command"
	"advanced-telnet-cnc/source/master/flood"
	sessions "advanced-telnet-cnc/source/master/session"
	"advanced-telnet-cnc/source/master/termfx"
	"fmt"
	"sort"
)

func init() {
	command.Make(&command.Command{
		Aliases:     []string{"methods"},
		Description: "Lists all available attack methods.",
		Executor: func(args []string, fx *termfx.TermFX, session *sessions.Session) error {
			session.Print(fmt.Sprintf("%s┌──────────────────────────────────────────────────────────┐\r\n", config.Cyan))
			session.Print(fmt.Sprintf("%s│                     AVAILABLE METHODS                    │\r\n", config.Cyan))
			session.Print(fmt.Sprintf("%s├──────────────────────┬───────────────────────────────────┤\r\n", config.Cyan))
			session.Print(fmt.Sprintf("%s│ Name                 │ Description                       │\r\n", config.Cyan))
			session.Print(fmt.Sprintf("%s├──────────────────────┼───────────────────────────────────┤\r\n", config.Cyan))

			var keys []string
			for k := range flood.Methods {
				keys = append(keys, k)
			}
			sort.Strings(keys)

			for _, key := range keys {
				method := flood.Methods[key]
				session.Print(fmt.Sprintf("%s│ %-20s │ %-33s │\r\n", config.Cyan, method.Name, method.Description))
			}

			session.Print(fmt.Sprintf("%s└──────────────────────┴───────────────────────────────────┘\r\n", config.Cyan))
			return nil
		},
	})
}
