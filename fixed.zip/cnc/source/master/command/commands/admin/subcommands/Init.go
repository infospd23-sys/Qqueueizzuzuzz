package subcommands

func Init() {

}
