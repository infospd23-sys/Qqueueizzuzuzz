ulimit -n 999999; ulimit -u999999; zmap -p 7000 -i eno1 -o- -q | ./scanip 7000
