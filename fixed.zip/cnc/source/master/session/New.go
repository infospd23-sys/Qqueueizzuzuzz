package sessions

import (
	"crypto/rand"
	"encoding/binary"
)

func New(session *Session) *Session {
	buf := make([]byte, 8)
	for {
		if _, err := rand.Read(buf); err != nil {
			return nil
		}

		id := int(binary.BigEndian.Uint64(buf))
		
		sessionMutex.Lock()
		if _, ok := sessionsMap[id]; !ok {
			session.ID = id
			sessionsMap[id] = session
			sessionMutex.Unlock()
			return session
		}
		sessionMutex.Unlock()
	}
}
