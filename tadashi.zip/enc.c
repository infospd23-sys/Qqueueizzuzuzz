#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

/* Chacha20 Implementation */

static inline void u32t8le(uint32_t v, uint8_t p[4]) {
    p[0] = v & 0xff;
    p[1] = (v >> 8) & 0xff;
    p[2] = (v >> 16) & 0xff;
    p[3] = (v >> 24) & 0xff;
}

static inline uint32_t u8t32le(uint8_t p[4]) {
    uint32_t value = p[3];
    value = (value << 8) | p[2];
    value = (value << 8) | p[1];
    value = (value << 8) | p[0];
    return value;
}

static inline uint32_t rotl32(uint32_t x, int n) {
    return x << n | (x >> (-n & 31));
}

static void chacha20_quarterround(uint32_t *x, int a, int b, int c, int d) {
    x[a] += x[b]; x[d] = rotl32(x[d] ^ x[a], 16);
    x[c] += x[d]; x[b] = rotl32(x[b] ^ x[c], 12);
    x[a] += x[b]; x[d] = rotl32(x[d] ^ x[a],  8);
    x[c] += x[d]; x[b] = rotl32(x[b] ^ x[c],  7);
}

static void chacha20_serialize(uint32_t in[16], uint8_t output[64]) {
    for (int i = 0; i < 16; i++) {
        u32t8le(in[i], output + (i << 2));
    }
}

static void chacha20_block(uint32_t in[16], uint8_t out[64], int num_rounds) {
    uint32_t x[16];
    memcpy(x, in, sizeof(uint32_t) * 16);

    for (int i = num_rounds; i > 0; i -= 2) {
        chacha20_quarterround(x, 0, 4,  8, 12);
        chacha20_quarterround(x, 1, 5,  9, 13);
        chacha20_quarterround(x, 2, 6, 10, 14);
        chacha20_quarterround(x, 3, 7, 11, 15);
        chacha20_quarterround(x, 0, 5, 10, 15);
        chacha20_quarterround(x, 1, 6, 11, 12);
        chacha20_quarterround(x, 2, 7,  8, 13);
        chacha20_quarterround(x, 3, 4,  9, 14);
    }

    for (int i = 0; i < 16; i++) {
        x[i] += in[i];
    }

    chacha20_serialize(x, out);
}

static void chacha20_init_state(uint32_t s[16], uint8_t key[32], uint32_t counter, uint8_t nonce[12]) {
    s[0] = 0x61707865;
    s[1] = 0x3320646e;
    s[2] = 0x79622d32;
    s[3] = 0x6b206574;

    for (int i = 0; i < 8; i++) {
        s[4 + i] = u8t32le(key + i * 4);
    }

    s[12] = counter;

    for (int i = 0; i < 3; i++) {
        s[13 + i] = u8t32le(nonce + i * 4);
    }
}

void chacha20_xor(uint8_t key[32], uint32_t counter, uint8_t nonce[12], uint8_t *in, uint8_t *out, int inlen) {
    uint32_t s[16];
    uint8_t block[64];

    chacha20_init_state(s, key, counter, nonce);

    for (int i = 0; i < inlen; i += 64) {
        chacha20_block(s, block, 20);
        s[12]++;

        for (int j = i; j < i + 64; j++) {
            if (j >= inlen) break;
            out[j] = in[j] ^ block[j - i];
        }
    }
}

/* Tool Logic */

static uint8_t key[] = {
    0x16, 0x1e, 0x19, 0x1b,
    0x11, 0x1f, 0x00, 0x1d,
    0x04, 0x1c, 0x0e, 0x08,
    0x0b, 0x1a, 0x12, 0x07,
    0x05, 0x09, 0x0d, 0x0f,
    0x06, 0x0a, 0x15, 0x01,
    0x0c, 0x14, 0x1f, 0x17,
    0x02, 0x03, 0x13, 0x18};

static uint8_t nonce[] = {
    0x1e, 0x00, 0x4a, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

int parse_hex(const char *input, uint8_t *output) {
    int len = 0;
    while (*input) {
        if (*input == '\\' && *(input + 1) == 'x') {
            char hex[3] = {*(input + 2), *(input + 3), '\0'};
            output[len++] = (uint8_t)strtol(hex, NULL, 16);
            input += 4;
        } else {
            input++;
        }
    }
    return len;
}

int main(int argc, char **argv) {
    if (argc < 3) {
        printf("Usage: %s <string> <enc/dec>\n", argv[0]);
        return 1;
    }

    char *input = argv[1];
    char *mode = argv[2];

    if (strcmp(mode, "enc") == 0) {
        int len = strlen(input);
        uint8_t *out = malloc(len);
        chacha20_xor(key, 1, nonce, (uint8_t *)input, out, len);
        
        printf("Encrypted: ");
        for (int i = 0; i < len; i++) {
            printf("\\x%02X", out[i]);
        }
        printf("\n");
        free(out);
    } else if (strcmp(mode, "dec") == 0) {
        uint8_t *hex_data = malloc(strlen(input));
        int len = parse_hex(input, hex_data);
        uint8_t *out = malloc(len + 1);
        chacha20_xor(key, 1, nonce, hex_data, out, len);
        out[len] = '\0';
        
        printf("Decrypted: %s\n", out);
        free(hex_data);
        free(out);
    } else {
        printf("Unknown mode: %s\n", mode);
        return 1;
    }

    return 0;
}
