package main

import (
	"encoding/json"
	"fmt"
	"os"
)

type Theme struct {
	Primary   string `json:"primary"`
	Secondary string `json:"secondary"`
	Separator string `json:"separator"`
	Success   string `json:"success"`
	Warning   string `json:"warning"`
	Error     string `json:"error"`
	Info      string `json:"info"`
	Muted     string `json:"muted"`
	Header    string `json:"header"`
	Prompt    string `json:"prompt"`
}

func defaultTheme() *Theme {
	return &Theme{
		Primary:   "1;31",
		Secondary: "1;37",
		Separator: "0;31",
		Success:   "1;32",
		Warning:   "1;33",
		Error:     "1;31",
		Info:      "1;33",
		Muted:     "0;90",
		Header:    "1;31",
		Prompt:    "0;97",
	}
}

func LoadTheme(path string) *Theme {
	t := defaultTheme()

	file, err := os.Open(path)
	if err != nil {
		fmt.Println("[theme] failed to open, using defaults:", err)
		return t
	}
	defer file.Close()

	if err := json.NewDecoder(file).Decode(t); err != nil {
		fmt.Println("[theme] decode error, using defaults:", err)
		return defaultTheme()
	}

	fmt.Println("[theme] loaded from", path)
	return t
}

func (t *Theme) C(color, text string) string {
	return fmt.Sprintf("\033[%sm%s\033[0m", color, text)
}

func (t *Theme) Label(text string) string {
	return fmt.Sprintf("\033[%sm%s\033[0m", t.Primary, text)
}

func (t *Theme) Value(text string) string {
	return fmt.Sprintf("\033[%sm%s\033[0m", t.Secondary, text)
}

func (t *Theme) Sep() string {
	return fmt.Sprintf("\033[%sm:\033[0m", t.Separator)
}

func (t *Theme) LabelValue(label, value string) string {
	return fmt.Sprintf("\033[%sm%s \033[%sm:\033[0m \033[%sm%s\033[0m",
		t.Primary, label, t.Separator, t.Secondary, value)
}

func (t *Theme) Succ(text string) string {
	return fmt.Sprintf("\033[%sm%s\033[0m", t.Success, text)
}

func (t *Theme) Warn(text string) string {
	return fmt.Sprintf("\033[%sm%s\033[0m", t.Warning, text)
}

func (t *Theme) Err(text string) string {
	return fmt.Sprintf("\033[%sm%s\033[0m", t.Error, text)
}

func (t *Theme) Inf(text string) string {
	return fmt.Sprintf("\033[%sm%s\033[0m", t.Info, text)
}

func (t *Theme) Hint(text string) string {
	return fmt.Sprintf("\033[%sm%s\033[0m", t.Muted, text)
}

func (t *Theme) Head(text string) string {
	return fmt.Sprintf("\033[%sm%s\033[0m", t.Header, text)
}

func (t *Theme) ErrorMsg(desc string) string {
	return fmt.Sprintf("\033[%smError \033[%sm:\033[0m \033[%sm%s\033[0m",
		t.Error, t.Separator, t.Primary, desc)
}

func (t *Theme) SuccessMsg(desc string) string {
	return fmt.Sprintf("\033[%sm%s\033[0m", t.Success, desc)
}

func (t *Theme) WarningMsg(msgType, desc string) string {
	return fmt.Sprintf("\033[%sm%s \033[%sm:\033[0m \033[%sm%s\033[0m",
		t.Warning, msgType, t.Separator, t.Primary, desc)
}

func (t *Theme) UsageMsg(cmd, args string) string {
	return fmt.Sprintf("\033[%smUsage \033[%sm:\033[0m \033[%sm%s \033[%sm%s\033[0m",
		t.Warning, t.Separator, t.Primary, cmd, t.Secondary, args)
}

func (t *Theme) InfoMsg(msgType, desc string) string {
	return fmt.Sprintf("\033[%sm%s \033[%sm:\033[0m \033[%sm%s\033[0m",
		t.Info, msgType, t.Separator, t.Primary, desc)
}
