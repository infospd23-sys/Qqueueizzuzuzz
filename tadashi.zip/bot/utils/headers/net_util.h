#pragma once

/* Type definitions */
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned int socklen_t;


#define NETLINK_INET_DIAG 4
#define TCPDIAG_GETSOCK 18
#define NLM_F_REQUEST 1
#define NLM_F_DUMP 0x300
#define SOL_SOCKET 1

int find_inode_by_port(int port);
int set_socket_options(int fd, int optname, int optval);
int sys_getsockname(int sockfd, void *addr, socklen_t *addrlen);
