#pragma once

    void locker_init(void);
    void locker_kill(void);
