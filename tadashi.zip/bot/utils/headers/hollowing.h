#pragma once

/* Type definitions */
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;

int process_hollowing(const char *target_path);
int inject_shellcode(uint8_t *shellcode, size_t shellcode_len);
