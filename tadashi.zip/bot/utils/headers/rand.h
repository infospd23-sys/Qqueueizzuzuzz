#pragma once

/* Type definitions */
typedef unsigned int uint32_t;

/* Random number generation functions */
uint32_t rand_next(void);
void rand_init(void);
uint32_t rand_cmwc(void);
void rand_alphastr(char *str, int len);
