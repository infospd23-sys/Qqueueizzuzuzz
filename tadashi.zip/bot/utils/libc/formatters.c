#include "../headers/syscalls.h";
#include "../headers/util.h";
#include "../headers/includes.h";

typedef __builtin_va_list va_list;
#define va_start(v, l) __builtin_va_start(v, l)
#define va_end(v) __builtin_va_end(v)
#define va_arg(v, l) __builtin_va_arg(v, l)

#define va_copy(d,s) __builtin_va_copy(d,s)
typedef long ptrdiff_t;
#define __va_copy(d,s) __builtin_va_copy(d,s)

int atoi(const char *str)
{
    int res = 0, sign = 1;
    if (*str == '-')
    {
        sign = -1;
        str++;
    }
    while (*str >= '0' && *str <= '9')
        res = res * 10 + (*str++ - '0');
    return res * sign;
}

void itoa(int n, int base, char *buf)
{
    static const char *chars = "0123456789abcdef";
    char *p = buf;
    unsigned int num = (n < 0 && base == 10) ? (unsigned int)-n : (unsigned int)n;
    if (n < 0 && base == 10)
        *p++ = '-';
    char *start = p;
    do
    {
        *p++ = chars[num % base];
        num /= base;
    } while (num);
    *p = 0;
    char *end = p - 1;
    while (start < end)
    {
        char t = *start;
        *start++ = *end;
        *end-- = t;
    }
}

char *strncpy(char *dest, const char *src, size_t n)
{
    size_t i;
    for (i = 0; i < n && src[i] != '\0'; i++)
        dest[i] = src[i];
    for (; i < n; i++)
        dest[i] = '\0';
    return dest;
}

char *_strncpy(char *dest, const char *src, size_t n)
{
    return strncpy(dest, src, n);
}