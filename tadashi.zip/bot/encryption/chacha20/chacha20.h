#ifndef __CHACHA20_H
#define __CHACHA20_H

#include <stddef.h>

typedef unsigned int uint32_t;
typedef unsigned char uint8_t;

void chacha20_xor(uint8_t *key, uint32_t counter, uint8_t *nonce, char *input, char *output, int inputlen);

#endif
