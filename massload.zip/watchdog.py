import subprocess
import time
import os

DIR = "/root/massload"
SCREEN = "massloader"

def screen_exists():
    result = subprocess.run(
        ["screen", "-ls"],
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        text=True
    )
    return f".{SCREEN}" in result.stdout

def massloader_running():
    result = subprocess.run(
        ["pgrep", "-af", "massloader.go"],
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        text=True
    )

    return bool(result.stdout.strip())

def start():
    print("Starting massloader...")

    subprocess.Popen(
        [
            "screen",
            "-dmS",
            SCREEN,
            "bash",
            "-c",
            f"cd {DIR} && sh run.sh"
        ]
    )

while True:
    if not screen_exists():
        print("Screen not found -> starting")
        start()

    elif not massloader_running():
        print("massloader.go stopped -> restarting screen")

        subprocess.run(
            ["screen", "-S", SCREEN, "-X", "quit"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        time.sleep(2)
        start()

    time.sleep(10)