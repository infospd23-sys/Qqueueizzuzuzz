package main

import (
    "encoding/json"
    "fmt"
    "net"
    "os"
    "strconv"
    "strings"
    "sync"
)

type IPPattern struct {
    parts [4]interface{}
}

var (
    honeypotPatterns []IPPattern
    honeypotMutex    sync.RWMutex
)

func checkAndBlockHoneypot(conn net.Conn) bool {
    remoteAddr, ok := conn.RemoteAddr().(*net.TCPAddr)
    if !ok {
        return false
    }

    ip := remoteAddr.IP
    if ipv4 := ip.To4(); ipv4 != nil {
        honeypotMutex.RLock()
        defer honeypotMutex.RUnlock()

        for _, pattern := range honeypotPatterns {
            if pattern.Match(ipv4) {
                fmt.Printf("[honeypot] blocked %s (pattern: %s)\n",
                    conn.RemoteAddr().String(), pattern.ToString())
                return true
            }
        }
    }
    return false
}

func loadHoneypotPatterns(filename string) error {
    file, err := os.Open(filename)
    if err != nil {
        return err
    }
    defer file.Close()

    var ranges []string
    if err := json.NewDecoder(file).Decode(&ranges); err != nil {
        return err
    }

    var patterns []IPPattern
    for _, s := range ranges {
        pattern, err := parsePattern(s)
        if err != nil {
            continue
        }
        patterns = append(patterns, pattern)
    }

    honeypotMutex.Lock()
    honeypotPatterns = patterns
    honeypotMutex.Unlock()

    return nil
}

func parsePattern(s string) (IPPattern, error) {
    parts := strings.Split(s, ".")
    var pattern [4]interface{}

    for i := 0; i < 4; i++ {
        if i < len(parts) {
            if parts[i] == "*" {
                pattern[i] = nil
            } else {
                num, err := strconv.Atoi(parts[i])
                if err != nil || num < 0 || num > 255 {
                    return IPPattern{}, fmt.Errorf("invalid pattern: %s", s)
                }
                pattern[i] = byte(num)
            }
        } else {
            pattern[i] = nil
        }
    }
    return IPPattern{parts: pattern}, nil
}

func (p *IPPattern) Match(ip net.IP) bool {
    ip = ip.To4()
    if ip == nil {
        return false
    }
    for i := 0; i < 4; i++ {
        if p.parts[i] != nil && p.parts[i].(byte) != ip[i] {
            return false
        }
    }
    return true
}

func (p *IPPattern) ToString() string {
    parts := make([]string, 4)
    for i, part := range p.parts {
        if part == nil {
            parts[i] = "*"
        } else {
            parts[i] = fmt.Sprintf("%d", part.(byte))
        }
    }
    return strings.Join(parts, ".")
}
