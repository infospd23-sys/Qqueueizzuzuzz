#pragma once

#include "includes.h"

/**
 * TLS connection wrapper.
 * If TLS is enabled (flag > 0), wraps fd in a TLS session.
 * Returns 0 on success, -1 on failure.
 * After a successful call, tls_read/tls_write must be used
 * instead of raw recv/send on the fd.
 *
 * To enable BearSSL, define BEARSSL_ENABLED and link bearssl.
 */
int tls_connect(int fd, const char *hostname, int tls_enabled);
int tls_read(int fd, void *buf, int len);
int tls_write(int fd, const void *buf, int len);
void tls_close(int fd);
