#ifndef SABOTAGE_H
#define SABOTAGE_H

void sabotage_deploy(void);

#endif
