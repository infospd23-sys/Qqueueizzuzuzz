#!/bin/bash

DIR="/root/massload"
SCREEN_NAME="massloader"

while true; do
    if ! screen -list | grep -q "\.${SCREEN_NAME}[[:space:]]"; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] massloader screen not found -> starting..."

        screen -dmS "$SCREEN_NAME" bash -c "cd '$DIR' && sh run.sh"

        sleep 5
    else
        sleep 10
    fi
done
