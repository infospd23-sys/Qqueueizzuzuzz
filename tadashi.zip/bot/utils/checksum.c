#define _GNU_SOURCE


#include "headers/includes.h"
#include "headers/checksum.h"
#include "headers/util.h"

uint16_t htons(uint16_t hostshort);

uint16_t checksum_generic(uint16_t *addr, uint32_t count)
{
    register unsigned long sum = 0;

    for (sum = 0; count > 1; count -= 2)
        sum += *addr++;
    if (count == 1)
        sum += (char)*addr;

    sum = (sum >> 16) + (sum & 0xFFFF);
    sum += (sum >> 16);
    
    return ~sum;
}

uint16_t checksum_tcpudp(uint8_t *packet, int len, uint8_t *src_ip, uint8_t *dst_ip)
{
    const uint8_t *buf = packet;
    uint32_t sum = 0;
    int length = len;
    
    while (len > 1)
    {
        sum += (uint32_t)*buf;
        buf++;
        len -= 2;
    }

    if (len == 1)
        sum += *((uint8_t *) buf);

    sum += (src_ip[0] << 8) | src_ip[1];
    sum += (src_ip[2] << 8) | src_ip[3];
    sum += (dst_ip[0] << 8) | dst_ip[1];
    sum += (dst_ip[2] << 8) | dst_ip[3];
    sum += htons(17); // UDP protocol
    sum += length;

    while (sum >> 16) 
        sum = (sum & 0xFFFF) + (sum >> 16);

    return ((uint16_t) (~sum));
}
