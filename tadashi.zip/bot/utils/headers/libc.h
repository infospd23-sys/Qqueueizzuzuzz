#pragma once

/* Type definitions */
#ifndef _TYPES_H
#define _TYPES_H
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef long long int64_t;
typedef unsigned long size_t;
typedef unsigned int socklen_t;
typedef long time_t;
#endif

//FORMATTERS
int atoi(const char *str);
void itoa(int n, int base, char *buf);
char *strncpy(char *dest, const char *src, size_t n);
char *_strncpy(char *dest, const char *src, size_t n);

//PRINTS
int printf(const char *format, ...);
int sys_sprintf(char *str, const char *format, ...);
int vsnprintf(char *str, size_t size, const char *format, __builtin_va_list ap);
int snprintf(char *str, size_t size, const char *format, ...);
int sprintf(char *str, const char *format, ...);
void sys_printf(const char *fmt, ...);

//NETWORK
int sys_socket(int d, int t, int p);
int sys_connect(int fd, const void *addr, socklen_t addrlen);
int sys_fcntl(int fd, int cmd, int arg);
int sys_sendto(int fd, const void *buf, size_t len, int flags, const void *dest_addr, socklen_t addrlen);
int sys_poll(void *fds, uint32_t nfds, int timeout);
int sys_getsockopt(int sockfd, int level, int optname, void *optval, socklen_t *optlen);
int sys_getsockname(int sockfd, void *addr, socklen_t *addrlen);
int sys_setsockopt(int sockfd, int level, int optname, const void *optval, socklen_t optlen);
int sys_bind(int fd, const void *addr, socklen_t addrlen);
int sys_listen(int fd, int backlog);
int sys_accept(int fd, void *addr, socklen_t *addrlen);
int sys_shutdown(int fd, int how);
int sys_getpeername(int sockfd, void *addr, socklen_t *addrlen);
int sys_recvfrom(int sockfd, void *buf, size_t len, int flags, void *src_addr, socklen_t *addrlen);
uint32_t CONVERT_ADDR(uint32_t addr);

uint32_t ntohl(uint32_t netlong);
uint32_t htonl(uint32_t hostlong);

