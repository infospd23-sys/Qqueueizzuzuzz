int puts(const char*);main(){puts("Hello, World!");}
