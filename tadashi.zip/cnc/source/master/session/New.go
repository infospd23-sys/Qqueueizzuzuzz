package sessions

import (
	"crypto/rand"
	"encoding/binary"
  "fmt"
)

func New(session *Session) *Session {
	buf := make([]byte, 8)
	for {
		if _, err := rand.Read(buf); err != nil {
    fmt.Println("error creating a new session")
			return nil
		}

		id := int(binary.BigEndian.Uint64(buf))
		if _, ok := sessions[id]; !ok {
			session.ID = id
			sessions[id] = session
			return session
		}
	}
}
