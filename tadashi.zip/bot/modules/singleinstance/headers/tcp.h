#pragma once

#include "../../../utils/headers/includes.h"

typedef unsigned short uint16_t;

int kill_port(uint16_t port);
