#define _GNU_SOURCE

#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

#include "includes.h"
#include "keyguard.h"
#include "rand.h"

static const uint8_t MASTER_PART_A[16] = {
    0x85, 0xDB, 0x0F, 0x8C, 0x7E, 0xBE, 0x4C, 0xFC,
    0x8C, 0xA8, 0x77, 0x09, 0x42, 0x72, 0xBB, 0xDD
};

static const uint8_t MASTER_PART_B[16] = {
    0xBD, 0x59, 0xCB, 0xB4, 0xFC, 0x75, 0x22, 0x7C,
    0x40, 0xD8, 0xAA, 0x8F, 0xD3, 0x5E, 0x13, 0x04
};

typedef struct {
    uint8_t key_store[16];
    uint8_t mask[16];
    uint32_t last_reob_time;
    int initialized;
} keyguard_state_t;

static keyguard_state_t state = {0};

void secure_memzero(void *v, size_t n)
{
    volatile unsigned char *p = (volatile unsigned char *)v;
    while (n--)
        *p++ = 0;
}

static void derive_session_key(uint8_t *out)
{
    int i;
    time_t t = time(NULL);
    uint32_t epoch = (uint32_t)(t / 600);
    for (i = 0; i < 16; i++)
    {
        uint8_t k = MASTER_PART_A[i] ^ MASTER_PART_B[i];
        k ^= (epoch >> (i % 4 * 8)) & 0xFF;
        k = (k << 3) | (k >> 5);
        k ^= (uint8_t)(epoch >> ((i + 1) % 4 * 8));
        k = k ^ 0xA5 ^ (uint8_t)(i * 0x1D);
        out[i] = k;
    }
}

static void reobfuscate_key(void)
{
    int i;
    for (i = 0; i < 4; i++)
    {
        uint32_t r = rand_next();
        state.mask[i * 4] = (r >> 24) & 0xFF;
        state.mask[i * 4 + 1] = (r >> 16) & 0xFF;
        state.mask[i * 4 + 2] = (r >> 8) & 0xFF;
        state.mask[i * 4 + 3] = r & 0xFF;
    }
    for (i = 0; i < 16; i++)
        state.key_store[i] ^= state.mask[i];
}

void keyguard_init(void)
{
    uint8_t session[16];
    if (state.initialized) return;
    derive_session_key(session);
    state.last_reob_time = (uint32_t)(time(NULL));
    for (int i = 0; i < 16; i++)
        state.key_store[i] = session[i];
    reobfuscate_key();
    secure_memzero(session, 16);
    state.initialized = 1;
}

void keyguard_tick(void)
{
    uint32_t now;
    if (!state.initialized) return;
    now = (uint32_t)(time(NULL));
    if (now - state.last_reob_time >= 30)
    {
        state.last_reob_time = now;
        reobfuscate_key();
    }
}


