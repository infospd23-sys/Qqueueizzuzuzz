#ifndef L4_H
#define L4_H

#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>

extern int g_yield_interval;
extern int g_thread_count;

typedef struct { char ip[64]; int port; int sec; } target_t;

__attribute__((unused)) static void sleep_ms(int ms) {
    struct timespec ts = {ms/1000, (ms%1000)*1000000L};
    nanosleep(&ts, NULL);
}

__attribute__((unused)) static void cpu_yield(void) {
    struct timespec ts = {0, 50000L};
    nanosleep(&ts, NULL);
}

__attribute__((unused)) static void cpu_yield_batch(int *cnt, int every) {
    if (++(*cnt) >= every) { *cnt = 0; cpu_yield(); }
}

static int resolve_target(target_t *t, const char *host) {
    struct hostent *he = gethostbyname(host);
    if (!he) return -1;
    inet_ntop(AF_INET, he->h_addr, t->ip, sizeof(t->ip));
    return 0;
}

#endif
