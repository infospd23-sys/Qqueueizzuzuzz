#pragma once

#define HTTP_SERVER "45.156.87.125"
#define HTTP_PORT 80

#define TFTP_SERVER "45.156.87.125"
