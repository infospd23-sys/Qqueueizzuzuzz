#pragma once

void speed_test_init(void);
int speed_test_run(uint32_t duration);
