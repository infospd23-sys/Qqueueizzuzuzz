echo -e "=== CNC BUILDING... ==="
go build server.go

echo -e "=== MAKE ARCH: Login SSH, Run command 'payload' ==="