#include "headers/includes.h"
#include "headers/rand.h"
#include "headers/util.h"
#include "headers/crypto.h"
#include "headers/protocols.h"
#include "headers/resolver.h"
#include "../encryption/chacha20_table.h"

/* ── TLS 1.3 State & Logic ───────────────────────────────────────── */

// Hand-crafted TLS 1.3 ClientHello with all required extensions for QUIC
size_t protocols_tls13_ch(uint8_t *buf, uint8_t *dcid, size_t dcid_len) {
    size_t i = 0;
    uint8_t *len_ptr;

    buf[i++] = 0x01; // ClientHello
    len_ptr = &buf[i]; i += 3; // Length placeholder

    buf[i++] = 0x03; buf[i++] = 0x03; // Version 1.2
    rand_str((char *)&buf[i], 32); i += 32; // Random
    buf[i++] = 0x00; // Session ID
    
    // Cipher Suites: TLS_AES_128_GCM_SHA256, TLS_AES_256_GCM_SHA384
    buf[i++] = 0x00; buf[i++] = 0x04;
    buf[i++] = 0x13; buf[i++] = 0x01;
    buf[i++] = 0x13; buf[i++] = 0x02;
    
    buf[i++] = 0x01; buf[i++] = 0x00; // Compression

    // Extensions
    uint8_t *ext_len_ptr = &buf[i]; i += 2;
    
    // Server Name
    buf[i++] = 0x00; buf[i++] = 0x00; // SNI
    buf[i++] = 0x00; buf[i++] = 0x05; // Len
    buf[i++] = 0x00; buf[i++] = 0x03; // List Len
    buf[i++] = 0x00; // Type: Hostname
    buf[i++] = 0x00; buf[i++] = 0x00; // Hostname Len (Stub)

    // Supported Versions
    buf[i++] = 0x00; buf[i++] = 0x2b; 
    buf[i++] = 0x00; buf[i++] = 0x03;
    buf[i++] = 0x02; buf[i++] = 0x03; buf[i++] = 0x04; // TLS 1.3

    // QUIC Transport Params
    buf[i++] = 0x00; buf[i++] = 0x39;
    buf[i++] = 0x00; buf[i++] = 0x08;
    buf[i++] = 0x00; buf[i++] = 0x06; // Param: initial_max_data
    buf[i++] = 0x04; buf[i++] = 0x80; buf[i++] = 0x08; buf[i++] = 0x00; buf[i++] = 0x00;

    // Fix lengths
    size_t ext_len = i - ((size_t)ext_len_ptr + 2);
    ext_len_ptr[0] = (ext_len >> 8) & 0xFF;
    ext_len_ptr[1] = ext_len & 0xFF;

    size_t total_len = i - 4;
    len_ptr[0] = (total_len >> 16) & 0xFF;
    len_ptr[1] = (total_len >> 8) & 0xFF;
    len_ptr[2] = total_len & 0xFF;

    return i;
}

/* ── HTTP/2 Engine (Zero-Library) ────────────────────────────────── */

/* ── Minimal HTTP/2 Preamble ────────────────────────────────────── */
size_t protocols_generate_h2_preamble(uint8_t *buf) {
    memcpy(buf, enc[H2_PREAMBLE].string, enc[H2_PREAMBLE].len);
    return enc[H2_PREAMBLE].len;
}

size_t protocols_h2_pack_headers(uint8_t *buf, const char *host, const char *path, const char *method) {
    size_t i = 0;
    
    // Static HPACK Indexing for common headers
    if (strcmp(method, enc[METHOD_GET].string) == 0) buf[i++] = 0x82;
    else if (strcmp(method, enc[METHOD_POST].string) == 0) buf[i++] = 0x83;
    
    buf[i++] = 0x87; // :scheme: https
    
    // :authority (Literal header field with incremental indexing)
    buf[i++] = 0x41; 
    buf[i++] = strlen(host);
    memcpy(&buf[i], host, strlen(host)); i += strlen(host);
    
    // :path
    if (strcmp(path, "/") == 0) buf[i++] = 0x84;
    else {
        buf[i++] = 0x44;
        buf[i++] = strlen(path);
        memcpy(&buf[i], path, strlen(path)); i += strlen(path);
    }
    
    // User-Agent (Literal)
    char *ua = enc[UA_TADASHI].string;
    buf[i++] = 0x50; // user-agent
    buf[i++] = enc[UA_TADASHI].len;
    memcpy(&buf[i], ua, enc[UA_TADASHI].len); i += enc[UA_TADASHI].len;

    return i;
}

int protocols_build_headers_frame(unsigned char *buf, int streamID,
                                const char *host, const char *path) {
    unsigned char hpack[1024];
    unsigned char *p = hpack;

    /* :method: GET (Index 2) */
    *p++ = 0x82;
    /* :scheme: https (Index 7) */
    *p++ = 0x87;
    
    /* :authority: host (Index 1) */
    *p++ = 0x01;
    size_t hl = strlen((char *)host);
    *p++ = (unsigned char)hl;
    memcpy(p, (void *)host, hl); p += hl;

    /* :path (Index 4) */
    if (strcmp((char *)path, "/") == 0) {
        *p++ = 0x84; /* :path: / */
    } else {
        *p++ = 0x04; /* :path literal with index 4 */
        size_t pl = strlen((char *)path);
        *p++ = (unsigned char)pl;
        memcpy(p, (void *)path, pl); p += pl;
    }

    /* user-agent (Index 58) -> 0x0F 0x2B */
    *p++ = 0x0F; *p++ = 0x2B;
    char *ua = enc[USER_AGENT_CHROME].string;
    size_t ual = enc[USER_AGENT_CHROME].len;
    *p++ = (unsigned char)ual;
    memcpy(p, (void *)ua, ual); p += ual;

    /* accept: */
    *p++ = 0x0F; *p++ = 0x04; /* accept index 19 -> 0x0F, index extension 19-15=4 */
    *p++ = enc[ACCEPT_ALL].len;
    memcpy(p, enc[ACCEPT_ALL].string, enc[ACCEPT_ALL].len); p += enc[ACCEPT_ALL].len;

    int hlen = (int)(p - hpack);
    int plen = hlen + 5;
    buf[0] = (plen >> 16) & 0xFF; buf[1] = (plen >>  8) & 0xFF; buf[2] =  plen & 0xFF;
    buf[3] = 0x01; buf[4] = 0x25; /* HEADERS + END_STREAM + END_HEADERS + PRIORITY */
    buf[5] = (streamID >> 24) & 0xFF; buf[6] = (streamID >> 16) & 0xFF;
    buf[7] = (streamID >>  8) & 0xFF; buf[8] =  streamID & 0xFF;
    
    unsigned char priorityDataChrome[5] = {0x80,0x00,0x00,0x00,0xFF};
    memcpy(buf + 9, (void *)priorityDataChrome, 5);
    memcpy(buf + 9 + 5, hpack, (size_t)hlen);
    return 9 + 5 + hlen;
}

size_t protocols_h2_frame(uint8_t *buf, uint8_t type, uint8_t flags, uint32_t stream_id, const uint8_t *payload, size_t len) {
    size_t i = 0;
    buf[i++] = (len >> 16) & 0xFF;
    buf[i++] = (len >> 8) & 0xFF;
    buf[i++] = len & 0xFF;
    buf[i++] = type;
    buf[i++] = flags;
    buf[i++] = (stream_id >> 24) & 0x7F;
    buf[i++] = (stream_id >> 16) & 0xFF;
    buf[i++] = (stream_id >> 8) & 0xFF;
    buf[i++] = stream_id & 0xFF;
    memcpy(&buf[i], payload, len);
    return i + len;
}

/* ── HTTP/3 / QPACK Minimal ──────────────────────────────────────── */

/* ── Chrome H2 Fingerprints ── */
static const uint8_t H2_CHROME_SETTINGS[] = {
    0x00,0x00,0x18, 0x04, 0x00, 0x00,0x00,0x00,0x00,
    0x00,0x01, 0x00,0x01,0x00,0x00,
    0x00,0x02, 0x00,0x00,0x00,0x00,
    0x00,0x04, 0x00,0x60,0x00,0x00,
    0x00,0x06, 0x00,0x04,0x00,0x00,
    0x00,0x00,0x04, 0x08, 0x00, 0x00,0x00,0x00,0x00,
    0x00,0xEF,0x00,0x01
};
static const uint8_t H2_CHROME_ACK[]  = { 0x00,0x00,0x00, 0x04, 0x01, 0x00,0x00,0x00,0x00 };
static const uint8_t H2_CHROME_PRIORITY[] = {0x00,0x00,0x05, 0x02, 0x00, 0x00,0x00,0x00,0x03, 0x80,0x00,0x00,0x00,0xFF};

size_t protocols_h2_chrome_settings(uint8_t *buf) {
    memcpy(buf, H2_CHROME_SETTINGS, sizeof(H2_CHROME_SETTINGS));
    return sizeof(H2_CHROME_SETTINGS);
}

size_t protocols_h2_chrome_ack(uint8_t *buf) {
    memcpy(buf, H2_CHROME_ACK, sizeof(H2_CHROME_ACK));
    return sizeof(H2_CHROME_ACK);
}

size_t protocols_h2_chrome_priority(uint8_t *buf) {
    memcpy(buf, H2_CHROME_PRIORITY, sizeof(H2_CHROME_PRIORITY));
    return sizeof(H2_CHROME_PRIORITY);
}

size_t protocols_h3_request(uint8_t *buf, const char *host, const char *path, const char *method) {
    size_t i = 0;
    
    // QPACK Instruction: Set Dynamic Table Capacity (0)
    buf[i++] = 0x00; 
    
    // Literal headers without name reference (Minimal QPACK)
    // :method
    buf[i++] = 0x50; buf[i++] = strlen(method);
    memcpy(&buf[i], method, strlen(method)); i += strlen(method);
    
    // :scheme
    buf[i++] = 0x50; buf[i++] = enc[HTTPS_SCHEME].len; memcpy(&buf[i], enc[HTTPS_SCHEME].string, enc[HTTPS_SCHEME].len); i += enc[HTTPS_SCHEME].len;
    
    // :authority
    buf[i++] = 0x50; buf[i++] = strlen(host);
    memcpy(&buf[i], host, strlen(host)); i += strlen(host);
    
    // :path
    buf[i++] = 0x50; buf[i++] = strlen((char *)path);
    memcpy(&buf[i], (void *)path, strlen((char *)path)); i += strlen((char *)path);

    return i;
}

/* ── WolfSSL TLS 1.2/1.3 bootstrap ───────────────────────────────── */

WOLFSSL_CTX *protocols_wolfssl_init_client_ctx(void) {
    WOLFSSL_CTX *ctx;

    wolfSSL_Init();

    ctx = wolfSSL_CTX_new(wolfTLS_client_method());
    if (ctx == NULL)
        return NULL;

    /* Flood mode does not validate cert chains, but still needs real TLS crypto. */
    wolfSSL_CTX_set_verify(ctx, WOLFSSL_VERIFY_NONE, NULL);
    wolfSSL_CTX_set_cipher_list(ctx, enc[CIPHER_LIST].string);

    return ctx;
}

int protocols_wolfssl_configure_client(WOLFSSL *ssl, const char *sni, const char *alpn_list) {
    if (ssl == NULL)
        return WOLFSSL_FAILURE;

    if (sni != NULL && sni[0] != '\0') {
        if (wolfSSL_UseSNI(ssl, WOLFSSL_SNI_HOST_NAME, (const void *)sni,
                (unsigned short)strlen(sni)) != WOLFSSL_SUCCESS) {
            return WOLFSSL_FAILURE;
        }
    }

    if (alpn_list != NULL && alpn_list[0] != '\0') {
        if (wolfSSL_UseALPN(ssl, (char *)alpn_list,
                (unsigned int)strlen(alpn_list),
                WOLFSSL_ALPN_FAILED_ON_MISMATCH) != WOLFSSL_SUCCESS) {
            return WOLFSSL_FAILURE;
        }
    }

    return WOLFSSL_SUCCESS;
}
