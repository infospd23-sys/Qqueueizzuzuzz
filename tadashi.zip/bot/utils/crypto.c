#include "../modules/debug.h"
#include "headers/crypto.h"
#include "../encryption/chacha20/chacha20.h"

/* ── SHA-256 Implementation ───────────────────────────────────────── */
#define ROR(x, n) (((x) >> (n)) | ((x) << (32 - (n))))
#define Ch(x, y, z)  ((x & y) ^ (~x & z))
#define Maj(x, y, z) ((x & y) ^ (x & z) ^ (y & z))
#define Sigma0(x) (ROR(x, 2) ^ ROR(x, 13) ^ ROR(x, 22))
#define Sigma1(x) (ROR(x, 6) ^ ROR(x, 11) ^ ROR(x, 25))
#define sigma0(x) (ROR(x, 7) ^ ROR(x, 18) ^ ((x) >> 3))
#define sigma1(x) (ROR(x, 17) ^ ROR(x, 19) ^ ((x) >> 10))

static const uint32_t K[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
};

static void transform(sha256_ctx_t *ctx) {
    uint32_t a, b, c, d, e, f, g, h, t1, t2, m[64];
    int i;

    for (i = 0; i < 16; i++) {
        m[i] = (ctx->buffer[i * 4] << 24) | (ctx->buffer[i * 4 + 1] << 16) | (ctx->buffer[i * 4 + 2] << 8) | (ctx->buffer[i * 4 + 3]);
    }
    for (; i < 64; i++) {
        m[i] = sigma1(m[i - 2]) + m[i - 7] + sigma0(m[i - 15]) + m[i - 16];
    }

    a = ctx->state[0]; b = ctx->state[1]; c = ctx->state[2]; d = ctx->state[3];
    e = ctx->state[4]; f = ctx->state[5]; g = ctx->state[6]; h = ctx->state[7];

    for (i = 0; i < 64; i++) {
        t1 = h + Sigma1(e) + Ch(e, f, g) + K[i] + m[i];
        t2 = Sigma0(a) + Maj(a, b, c);
        h = g; g = f; f = e;
        e = d + t1;
        d = c; c = b; b = a;
        a = t1 + t2;
    }

    ctx->state[0] += a; ctx->state[1] += b; ctx->state[2] += c; ctx->state[3] += d;
    ctx->state[4] += e; ctx->state[5] += f; ctx->state[6] += g; ctx->state[7] += h;
}

void sha256_init(sha256_ctx_t *ctx) {
    ctx->state[0] = 0x6a09e667; ctx->state[1] = 0xbb67ae85; ctx->state[2] = 0x3c6ef372; ctx->state[3] = 0xa54ff53a;
    ctx->state[4] = 0x510e527f; ctx->state[5] = 0x9b05688c; ctx->state[6] = 0x1f83d9ab; ctx->state[7] = 0x5be0cd19;
    ctx->bitlen = 0;
}

void sha256_update(sha256_ctx_t *ctx, const uint8_t *data, size_t len) {
    for (size_t i = 0; i < len; i++) {
        ctx->buffer[ctx->bitlen % 64] = data[i];
        ctx->bitlen += 8;
        if (ctx->bitlen % 512 == 0) transform(ctx);
    }
}

void sha256_final(sha256_ctx_t *ctx, uint8_t *hash) {
    uint64_t bitlen = ctx->bitlen;
    sha256_update(ctx, (uint8_t *)"\x80", 1);
    while (ctx->bitlen % 512 != 448) sha256_update(ctx, (uint8_t *)"\x00", 1);
    for (int i = 7; i >= 0; i--) sha256_update(ctx, (uint8_t *)((uint8_t *)&bitlen + i), 1);

    for (int i = 0; i < 8; i++) {
        hash[i * 4] = (ctx->state[i] >> 24) & 0xff;
        hash[i * 4 + 1] = (ctx->state[i] >> 16) & 0xff;
        hash[i * 4 + 2] = (ctx->state[i] >> 8) & 0xff;
        hash[i * 4 + 3] = (ctx->state[i] & 0xff);
    }
}

/* ── HMAC-SHA256 ─────────────────────────────────────────────────── */
void hmac_sha256_init(hmac_sha256_ctx_t *ctx, const uint8_t *key, size_t key_len) {
    uint8_t k[64] = {0};
    uint8_t i_key_pad[64], o_key_pad[64];

    if (key_len > 64) {
        sha256_init(&ctx->inner);
        sha256_update(&ctx->inner, key, key_len);
        sha256_final(&ctx->inner, k);
    } else {
        memcpy(k, key, key_len);
    }

    for (int i = 0; i < 64; i++) {
        i_key_pad[i] = k[i] ^ 0x36;
        o_key_pad[i] = k[i] ^ 0x5c;
    }

    sha256_init(&ctx->inner);
    sha256_update(&ctx->inner, i_key_pad, 64);

    sha256_init(&ctx->outer);
    sha256_update(&ctx->outer, o_key_pad, 64);

    ctx->initialized = 1;
}

void hmac_sha256_update(hmac_sha256_ctx_t *ctx, const uint8_t *data, size_t len) {
    if (!ctx->initialized) return;
    sha256_update(&ctx->inner, data, len);
}

void hmac_sha256_final(hmac_sha256_ctx_t *ctx, uint8_t *hash) {
    uint8_t inner_hash[32];
    
    if (!ctx->initialized) return;
    
    sha256_final(&ctx->inner, inner_hash);
    sha256_update(&ctx->outer, inner_hash, 32);
    sha256_final(&ctx->outer, hash);
    
    ctx->initialized = 0;
}

void hmac_sha256(const uint8_t *key, size_t key_len, const uint8_t *data, size_t data_len, uint8_t *mac) {
    hmac_sha256_ctx_t ctx;
    hmac_sha256_init(&ctx, key, key_len);
    hmac_sha256_update(&ctx, data, data_len);
    hmac_sha256_final(&ctx, mac);
}

/* ── ChaCha20-Poly1305 (RFC 8439) ─────────────────────────────────── */
static uint32_t load32_le(const uint8_t *p) {
    return ((uint32_t)p[0])       |
           ((uint32_t)p[1] << 8)  |
           ((uint32_t)p[2] << 16) |
           ((uint32_t)p[3] << 24);
}

static uint64_t load64_le(const uint8_t *p) {
    return ((uint64_t)p[0])        |
           ((uint64_t)p[1] << 8)   |
           ((uint64_t)p[2] << 16)  |
           ((uint64_t)p[3] << 24)  |
           ((uint64_t)p[4] << 32)  |
           ((uint64_t)p[5] << 40)  |
           ((uint64_t)p[6] << 48)  |
           ((uint64_t)p[7] << 56);
}

static void store32_le(uint8_t *p, uint32_t v) {
    p[0] = (uint8_t)(v);
    p[1] = (uint8_t)(v >> 8);
    p[2] = (uint8_t)(v >> 16);
    p[3] = (uint8_t)(v >> 24);
}

static void store64_le(uint8_t *p, uint64_t v) {
    p[0] = (uint8_t)(v);
    p[1] = (uint8_t)(v >> 8);
    p[2] = (uint8_t)(v >> 16);
    p[3] = (uint8_t)(v >> 24);
    p[4] = (uint8_t)(v >> 32);
    p[5] = (uint8_t)(v >> 40);
    p[6] = (uint8_t)(v >> 48);
    p[7] = (uint8_t)(v >> 56);
}

static void poly1305_auth(const uint8_t *key, const uint8_t *in, size_t len, uint8_t *mac) {
    uint32_t t0, t1, t2, t3;
    uint32_t r0, r1, r2, r3, r4;
    uint32_t s1, s2, s3, s4;
    uint32_t h0, h1, h2, h3, h4;
    uint32_t f0, f1, f2, f3;
    uint64_t d0, d1, d2, d3, d4;
    uint32_t c;
    uint8_t mp[16];

    t0 = load32_le(key + 0);
    t1 = load32_le(key + 4);
    t2 = load32_le(key + 8);
    t3 = load32_le(key + 12);

    r0 = ( t0                    ) & 0x3ffffff;
    r1 = ((t0 >> 26) | (t1 << 6 )) & 0x3ffff03;
    r2 = ((t1 >> 20) | (t2 << 12)) & 0x3ffc0ff;
    r3 = ((t2 >> 14) | (t3 << 18)) & 0x3f03fff;
    r4 = ((t3 >> 8)             ) & 0x00fffff;

    s1 = r1 * 5;
    s2 = r2 * 5;
    s3 = r3 * 5;
    s4 = r4 * 5;

    h0 = h1 = h2 = h3 = h4 = 0;

    while (len >= 16) {
        t0 = load32_le(in + 0);
        t1 = load32_le(in + 4);
        t2 = load32_le(in + 8);
        t3 = load32_le(in + 12);

        h0 += ( t0                    ) & 0x3ffffff;
        h1 += ((t0 >> 26) | (t1 << 6 )) & 0x3ffffff;
        h2 += ((t1 >> 20) | (t2 << 12)) & 0x3ffffff;
        h3 += ((t2 >> 14) | (t3 << 18)) & 0x3ffffff;
        h4 += ((t3 >> 8)             ) | (1 << 24);

        d0 = ((uint64_t)h0 * r0) + ((uint64_t)h1 * s4) + ((uint64_t)h2 * s3) + ((uint64_t)h3 * s2) + ((uint64_t)h4 * s1);
        d1 = ((uint64_t)h0 * r1) + ((uint64_t)h1 * r0) + ((uint64_t)h2 * s4) + ((uint64_t)h3 * s3) + ((uint64_t)h4 * s2);
        d2 = ((uint64_t)h0 * r2) + ((uint64_t)h1 * r1) + ((uint64_t)h2 * r0) + ((uint64_t)h3 * s4) + ((uint64_t)h4 * s3);
        d3 = ((uint64_t)h0 * r3) + ((uint64_t)h1 * r2) + ((uint64_t)h2 * r1) + ((uint64_t)h3 * r0) + ((uint64_t)h4 * s4);
        d4 = ((uint64_t)h0 * r4) + ((uint64_t)h1 * r3) + ((uint64_t)h2 * r2) + ((uint64_t)h3 * r1) + ((uint64_t)h4 * r0);

        c = (uint32_t)(d0 >> 26); h0 = (uint32_t)d0 & 0x3ffffff; d1 += c;
        c = (uint32_t)(d1 >> 26); h1 = (uint32_t)d1 & 0x3ffffff; d2 += c;
        c = (uint32_t)(d2 >> 26); h2 = (uint32_t)d2 & 0x3ffffff; d3 += c;
        c = (uint32_t)(d3 >> 26); h3 = (uint32_t)d3 & 0x3ffffff; d4 += c;
        c = (uint32_t)(d4 >> 26); h4 = (uint32_t)d4 & 0x3ffffff;
        h0 += c * 5;
        c = h0 >> 26; h0 &= 0x3ffffff; h1 += c;

        in += 16;
        len -= 16;
    }

    if (len > 0) {
        memset(mp, 0, sizeof(mp));
        memcpy(mp, in, len);
        mp[len] = 1;

        t0 = load32_le(mp + 0);
        t1 = load32_le(mp + 4);
        t2 = load32_le(mp + 8);
        t3 = load32_le(mp + 12);

        h0 += ( t0                    ) & 0x3ffffff;
        h1 += ((t0 >> 26) | (t1 << 6 )) & 0x3ffffff;
        h2 += ((t1 >> 20) | (t2 << 12)) & 0x3ffffff;
        h3 += ((t2 >> 14) | (t3 << 18)) & 0x3ffffff;
        h4 += ((t3 >> 8)             );

        d0 = ((uint64_t)h0 * r0) + ((uint64_t)h1 * s4) + ((uint64_t)h2 * s3) + ((uint64_t)h3 * s2) + ((uint64_t)h4 * s1);
        d1 = ((uint64_t)h0 * r1) + ((uint64_t)h1 * r0) + ((uint64_t)h2 * s4) + ((uint64_t)h3 * s3) + ((uint64_t)h4 * s2);
        d2 = ((uint64_t)h0 * r2) + ((uint64_t)h1 * r1) + ((uint64_t)h2 * r0) + ((uint64_t)h3 * s4) + ((uint64_t)h4 * s3);
        d3 = ((uint64_t)h0 * r3) + ((uint64_t)h1 * r2) + ((uint64_t)h2 * r1) + ((uint64_t)h3 * r0) + ((uint64_t)h4 * s4);
        d4 = ((uint64_t)h0 * r4) + ((uint64_t)h1 * r3) + ((uint64_t)h2 * r2) + ((uint64_t)h3 * r1) + ((uint64_t)h4 * r0);

        c = (uint32_t)(d0 >> 26); h0 = (uint32_t)d0 & 0x3ffffff; d1 += c;
        c = (uint32_t)(d1 >> 26); h1 = (uint32_t)d1 & 0x3ffffff; d2 += c;
        c = (uint32_t)(d2 >> 26); h2 = (uint32_t)d2 & 0x3ffffff; d3 += c;
        c = (uint32_t)(d3 >> 26); h3 = (uint32_t)d3 & 0x3ffffff; d4 += c;
        c = (uint32_t)(d4 >> 26); h4 = (uint32_t)d4 & 0x3ffffff;
        h0 += c * 5;
        c = h0 >> 26; h0 &= 0x3ffffff; h1 += c;
    }

    c = h1 >> 26; h1 &= 0x3ffffff; h2 += c;
    c = h2 >> 26; h2 &= 0x3ffffff; h3 += c;
    c = h3 >> 26; h3 &= 0x3ffffff; h4 += c;
    c = h4 >> 26; h4 &= 0x3ffffff; h0 += c * 5;
    c = h0 >> 26; h0 &= 0x3ffffff; h1 += c;

    t0 = h0 + 5;
    c = t0 >> 26; t0 &= 0x3ffffff;
    t1 = h1 + c; c = t1 >> 26; t1 &= 0x3ffffff;
    t2 = h2 + c; c = t2 >> 26; t2 &= 0x3ffffff;
    t3 = h3 + c; c = t3 >> 26; t3 &= 0x3ffffff;
    c = (h4 + c) >> 26;

    if (c != 0) {
        h0 = t0; h1 = t1; h2 = t2; h3 = t3; h4 = (h4 + (t3 >> 26)) & 0x3ffffff;
    }

    h0 = h0 | (h1 << 26);
    h1 = (h1 >> 6) | (h2 << 20);
    h2 = (h2 >> 12) | (h3 << 14);
    h3 = (h3 >> 18) | (h4 << 8);

    t0 = load32_le(key + 16);
    t1 = load32_le(key + 20);
    t2 = load32_le(key + 24);
    t3 = load32_le(key + 28);

    f0 = h0 + t0;
    f1 = h1 + t1 + (f0 < h0);
    f2 = h2 + t2 + (f1 < h1);
    f3 = h3 + t3 + (f2 < h2);

    store32_le(mac + 0, f0);
    store32_le(mac + 4, f1);
    store32_le(mac + 8, f2);
    store32_le(mac + 12, f3);
}

static void poly1305_update_padded(uint8_t *buf, size_t *off, const uint8_t *src, size_t len) {
    if (len > 0) {
        memcpy(buf + *off, src, len);
        *off += len;
        if (len % 16 != 0) {
            size_t pad = 16 - (len % 16);
            memset(buf + *off, 0, pad);
            *off += pad;
        }
    }
}

static int crypto_memcmp(const uint8_t *a, const uint8_t *b, size_t n) {
    uint8_t v = 0;
    for (size_t i = 0; i < n; i++) v |= (uint8_t)(a[i] ^ b[i]);
    return v;
}

static int chacha20_poly1305_tag(const uint8_t *key, const uint8_t *nonce, const uint8_t *ad, size_t ad_len,
                                 const uint8_t *ciphertext, size_t ct_len, uint8_t *tag) {
    uint8_t block0[64];
    uint8_t one_time_key[32];
    uint8_t lenbuf[16];
    uint8_t *mac_input;
    size_t mac_len = 0;
    uint8_t key_local[32];
    uint8_t nonce_local[12];

    memcpy(key_local, key, sizeof(key_local));
    memcpy(nonce_local, nonce, sizeof(nonce_local));

    memset(block0, 0, sizeof(block0));
    chacha20_xor(key_local, 0, nonce_local, (char *)block0, (char *)block0, 64);
    memcpy(one_time_key, block0, sizeof(one_time_key));

    mac_len = ((ad_len + 15) & ~(size_t)15) + ((ct_len + 15) & ~(size_t)15) + 16;
    mac_input = malloc(mac_len);
    if (mac_input == NULL) {
        memset(tag, 0, 16);
        return 0;
    }

    size_t off = 0;
    poly1305_update_padded(mac_input, &off, ad, ad_len);
    poly1305_update_padded(mac_input, &off, ciphertext, ct_len);
    store64_le(lenbuf + 0, (uint64_t)ad_len);
    store64_le(lenbuf + 8, (uint64_t)ct_len);
    memcpy(mac_input + off, lenbuf, sizeof(lenbuf));
    off += sizeof(lenbuf);

    poly1305_auth(one_time_key, mac_input, off, tag);
    free(mac_input);
    return 1;
}

void chacha20_poly1305_encrypt(const uint8_t *key, const uint8_t *nonce, const uint8_t *ad, size_t ad_len, const uint8_t *in, size_t in_len, uint8_t *out, uint8_t *tag) {
    uint8_t key_local[32];
    uint8_t nonce_local[12];

    memcpy(key_local, key, sizeof(key_local));
    memcpy(nonce_local, nonce, sizeof(nonce_local));

    chacha20_xor(key_local, 1, nonce_local, (char *)in, (char *)out, (int)in_len);
    if (!chacha20_poly1305_tag(key, nonce, ad, ad_len, out, in_len, tag))
        memset(tag, 0, 16);
}

int chacha20_poly1305_decrypt(const uint8_t *key, const uint8_t *nonce, const uint8_t *ad, size_t ad_len, const uint8_t *in, size_t in_len, uint8_t *out, const uint8_t *tag) {
    uint8_t calc_tag[16];
    uint8_t key_local[32];
    uint8_t nonce_local[12];

    if (!chacha20_poly1305_tag(key, nonce, ad, ad_len, in, in_len, calc_tag)) {
        memset(out, 0, in_len);
        return 0;
    }
    if (crypto_memcmp(calc_tag, tag, sizeof(calc_tag)) != 0) {
        memset(out, 0, in_len);
        return 0;
    }

    memcpy(key_local, key, sizeof(key_local));
    memcpy(nonce_local, nonce, sizeof(nonce_local));
    chacha20_xor(key_local, 1, nonce_local, (char *)in, (char *)out, (int)in_len);
    return 1;
}
