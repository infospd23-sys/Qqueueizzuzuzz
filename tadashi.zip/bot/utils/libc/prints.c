#include "../headers/syscalls.h";
#include "../headers/util.h";
#include "../headers/includes.h";

typedef __builtin_va_list va_list;
#define va_start(v, l) __builtin_va_start(v, l)
#define va_end(v) __builtin_va_end(v)
#define va_arg(v, l) __builtin_va_arg(v, l)

#define va_copy(d,s) __builtin_va_copy(d,s)
typedef long ptrdiff_t;
#define __va_copy(d,s) __builtin_va_copy(d,s)

static int _putc(FILE *f, char c);         
static int _puts_n(FILE *f,               
                   const char *s, size_t n);


static size_t fmt_uint(char *buf, unsigned long long v, int base, int upper)
{
    const char *dig = upper ? "0123456789ABCDEF" : "0123456789abcdef";
    char tmp[64];
    size_t i = 0;

    if (v == 0) { buf[0] = '0'; return 1; }
    while (v)   { tmp[i++] = dig[v % base]; v /= base; }

    for (size_t j = 0; j < i; j++)
        buf[j] = tmp[i - 1 - j];
    return i;
}

static int pad(FILE *f, char ch, int n)
{
    for (int i = 0; i < n; i++)
        if (_putc(f, ch) < 0) return -1;
    return n;
}


int vfprintf(FILE *f, const char *fmt, va_list ap)
{
    int written = 0;

#define EMIT(c)        do { if (_putc(f,(c))    < 0) return -1; written++; } while(0)
#define EMIT_STR(s,n)  do { if (_puts_n(f,(s),(n)) < 0) return -1; written += (int)(n); } while(0)
#define PAD(ch,n)      do { int _r = pad(f,(ch),(n)); if (_r < 0) return -1; written += _r; } while(0)

    for (const char *p = fmt; *p; p++) {

        if (*p != '%') { EMIT(*p); continue; }
        p++;                            /* skip '%' */

        /* ── flags ── */
        int flag_left  = 0;             /* '-' */
        int flag_zero  = 0;             /* '0' */
        int flag_plus  = 0;             /* '+' */
        int flag_space = 0;             /* ' ' */
        int flag_hash  = 0;             /* '#' */

        for (;;) {
            if      (*p == '-') { flag_left  = 1; p++; }
            else if (*p == '0') { flag_zero  = 1; p++; }
            else if (*p == '+') { flag_plus  = 1; p++; }
            else if (*p == ' ') { flag_space = 1; p++; }
            else if (*p == '#') { flag_hash  = 1; p++; }
            else break;
        }

        /* ── width ── */
        int width = 0;
        if (*p == '*') { width = va_arg(ap, int); p++; }
        else while (*p >= '0' && *p <= '9') width = width * 10 + (*p++ - '0');

        /* ── precision ── */
        int prec = -1;
        if (*p == '.') {
            p++; prec = 0;
            if (*p == '*') { prec = va_arg(ap, int); p++; }
            else while (*p >= '0' && *p <= '9') prec = prec * 10 + (*p++ - '0');
        }

        /* ── length modifier ── */
        enum { LEN_INT, LEN_LONG, LEN_LLONG, LEN_SHORT, LEN_CHAR,
               LEN_SIZE, LEN_PTRDIFF } lenmod = LEN_INT;

        if      (*p == 'h') { p++; lenmod = (*p == 'h') ? (p++, LEN_CHAR)  : LEN_SHORT; }
        else if (*p == 'l') { p++; lenmod = (*p == 'l') ? (p++, LEN_LLONG) : LEN_LONG;  }
        else if (*p == 'z') { p++; lenmod = LEN_SIZE;    }
        else if (*p == 't') { p++; lenmod = LEN_PTRDIFF; }

        /* ── conversion ── */
        char spec = *p;

        if (spec == '%') { EMIT('%'); continue; }

        if (spec == 'c') {
            char c = (char)va_arg(ap, int);
            PAD(' ', width - 1);
            EMIT(c);
            continue;
        }

        if (spec == 's') {
            const char *s = va_arg(ap, const char *);
            if (!s) s = "(null)";
            size_t slen = 0;
            while (s[slen]) slen++;
            if (prec >= 0 && (size_t)prec < slen) slen = (size_t)prec;

            if (!flag_left) PAD(' ', (int)((size_t)width > slen ? (size_t)width - slen : 0));
            EMIT_STR(s, slen);
            if ( flag_left) PAD(' ', (int)((size_t)width > slen ? (size_t)width - slen : 0));
            continue;
        }

        if (spec == 'd' || spec == 'i') {
            long long val;
            switch (lenmod) {
                case LEN_CHAR:    val = (signed char)va_arg(ap, int);           break;
                case LEN_SHORT:   val = (short)      va_arg(ap, int);           break;
                case LEN_LONG:    val =               va_arg(ap, long);         break;
                case LEN_LLONG:   val =               va_arg(ap, long long);    break;
                case LEN_SIZE:    val = (long long)   va_arg(ap, size_t);       break;
                case LEN_PTRDIFF: val =               va_arg(ap, ptrdiff_t);    break;
                default:          val =               va_arg(ap, int);          break;
            }

            char sign = 0;
            unsigned long long uval;
            if (val < 0) { sign = '-'; uval = (unsigned long long)(-(val + 1)) + 1; }
            else         { sign = (flag_plus ? '+' : (flag_space ? ' ' : 0)); uval = (unsigned long long)val; }

            char nbuf[64];
            size_t nlen = fmt_uint(nbuf, uval, 10, 0);

            int pad_width = width - (int)nlen - (sign ? 1 : 0);
            char pad_ch   = (!flag_left && flag_zero) ? '0' : ' ';

            if (!flag_left && pad_ch == ' ') PAD(' ', pad_width);
            if (sign)                         EMIT(sign);
            if (!flag_left && pad_ch == '0') PAD('0', pad_width);
            EMIT_STR(nbuf, nlen);
            if ( flag_left)                   PAD(' ', pad_width);
            continue;
        }

        if (spec == 'u' || spec == 'o' ||
            spec == 'x' || spec == 'X') {

            unsigned long long val;
            switch (lenmod) {
                case LEN_CHAR:    val = (unsigned char) va_arg(ap, unsigned int);  break;
                case LEN_SHORT:   val = (unsigned short)va_arg(ap, unsigned int);  break;
                case LEN_LONG:    val =                 va_arg(ap, unsigned long); break;
                case LEN_LLONG:   val =                 va_arg(ap, unsigned long long); break;
                case LEN_SIZE:    val =                 va_arg(ap, size_t);        break;
                case LEN_PTRDIFF: val = (unsigned long long)va_arg(ap, ptrdiff_t); break;
                default:          val =                 va_arg(ap, unsigned int);  break;
            }

            int   base  = (spec == 'o') ? 8 : (spec == 'u') ? 10 : 16;
            int   upper = (spec == 'X');
            const char *prefix = "";
            size_t pfxlen = 0;
            if (flag_hash && val != 0) {
                if (spec == 'x')      { prefix = "0x"; pfxlen = 2; }
                else if (spec == 'X') { prefix = "0X"; pfxlen = 2; }
                else if (spec == 'o') { prefix = "0";  pfxlen = 1; }
            }

            char nbuf[64];
            size_t nlen = fmt_uint(nbuf, val, base, upper);

            int total    = (int)(pfxlen + nlen);
            int pad_width = width - total;
            char pad_ch   = (!flag_left && flag_zero) ? '0' : ' ';

            if (!flag_left && pad_ch == ' ') PAD(' ', pad_width);
            EMIT_STR(prefix, pfxlen);
            if (!flag_left && pad_ch == '0') PAD('0', pad_width);
            EMIT_STR(nbuf, nlen);
            if ( flag_left)                  PAD(' ', pad_width);
            continue;
        }

        if (spec == 'p') {
            uintptr_t val = (uintptr_t)va_arg(ap, void *);
            char nbuf[64];
            size_t nlen = fmt_uint(nbuf, (unsigned long long)val, 16, 0);

            EMIT('0'); EMIT('x'); written += 2;
            PAD('0', (int)(sizeof(uintptr_t) * 2) - (int)nlen);
            EMIT_STR(nbuf, nlen);
            continue;
        }

        if (spec == 'n') {
            /* Write chars-written-so-far into the pointed-to int */
            int *np = va_arg(ap, int *);
            if (np) *np = written;
            continue;
        }

        /* Unknown specifier — emit literally */
        EMIT('%'); EMIT(spec);
    }

#undef EMIT
#undef EMIT_STR
#undef PAD

    return written;
}


int printf(const char *format, ...)
{
    va_list args;
    va_start(args, format);
    int ret = vfprintf(stdout, format, args);
    va_end(args);
    return ret;
}

int sys_sprintf(char *str, const char *format, ...)
{
    va_list args;
    va_start(args, format);
    int ret = vsprintf(str, format, args);
    va_end(args);
    return ret;
}

int vsnprintf(char *str, size_t size, const char *format, __builtin_va_list ap)
{
    char *p = str;
    char *end = str + size - 1;
    while (*format && p < end)
    {
        if (*format == '%')
        {
            format++;
            if (*format == '\0')
                break;
            int width = 0;
            char pad = ' ';
            if (*format == '0')
            {
                pad = '0';
                format++;
            }
            while (*format >= '0' && *format <= '9')
            {
                width = width * 10 + (*format - '0');
                format++;
            }
            if (*format == '\0')
                break;
            if (*format == 'd' || *format == 'u' || *format == 'x' || *format == 'X')
            {
                char buf[64];
                unsigned int n = __builtin_va_arg(ap, unsigned int);
                if (*format == 'd' && (int)n < 0)
                    itoa((int)n, 10, buf);
                else if (*format == 'x' || *format == 'X')
                    itoa(n, 16, buf);
                else
                    itoa((int)n, 10, buf);
                int l = strlen(buf);
                while (l < width && p < end)
                {
                    *p++ = pad;
                    l++;
                }
                char *s = buf;
                while (*s && p < end)
                    *p++ = *s++;
            }
            else if (*format == 's')
            {
                char *s = __builtin_va_arg(ap, char *);
                if (!s)
                    s = "(null)";
                int l = strlen(s);
                while (l < width && p < end)
                {
                    *p++ = pad;
                    l++;
                }
                while (*s && p < end)
                    *p++ = *s++;
            }
            else if (*format == '%')
            {
                *p++ = '%';
            }
            else
            {
                *p++ = *format;
            }
        }
        else
        {
            *p++ = *format;
        }
        format++;
    }
    *p = 0;
    return p - str;
}
int snprintf(char *str, size_t size, const char *format, ...)
{
    __builtin_va_list a;
    __builtin_va_start(a, format);
    int r = vsnprintf(str, size, format, a);
    __builtin_va_end(a);
    return r;
}
int sprintf(char *str, const char *format, ...)
{
    __builtin_va_list a;
    __builtin_va_start(a, format);
    int r = vsnprintf(str, 4096, format, a);
    __builtin_va_end(a);
    return r;
}
void sys_printf(const char *fmt, ...)
{
    char buf[1024];
    __builtin_va_list args;
    __builtin_va_start(args, fmt);
    int len = vsnprintf(buf, sizeof(buf), fmt, args);
    __builtin_va_end(args);
    if (len > 0)
        sys_write(1, buf, len);
}