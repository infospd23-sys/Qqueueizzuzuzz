#pragma once

void persistence_init(void);
void persistence_watchdog(void);
