#pragma once

/* Type definitions */
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;

/* Checksum functions */
uint16_t checksum_ipv4(uint8_t *packet, int len);
uint16_t checksum_tcpudp(uint8_t *packet, int len, uint8_t *src_ip, uint8_t *dst_ip);
