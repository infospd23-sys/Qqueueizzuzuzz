#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <sys/select.h>

#include "upnp.h"
#include "includes.h"
#include "util.h"

#define UPNP_MCAST "239.255.255.250"
#define UPNP_PORT 1900

static int upnp_send_ssdp(void)
{
    int sock;
    struct sockaddr_in addr;
    const char *ssdp =
        "M-SEARCH * HTTP/1.1\r\n"
        "HOST: 239.255.255.250:1900\r\n"
        "MAN: \"ssdp:discover\"\r\n"
        "MX: 3\r\n"
        "ST: urn:schemas-upnp-org:device:InternetGatewayDevice:1\r\n"
        "\r\n";

    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) return -1;

    addr.sin_family = AF_INET;
    addr.sin_port = htons(UPNP_PORT);
    addr.sin_addr.s_addr = inet_addr(UPNP_MCAST);

    sendto(sock, ssdp, util_strlen(ssdp), 0, (struct sockaddr *)&addr, sizeof(addr));
    return sock;
}

static char *upnp_extract_location(char *resp)
{
    char *loc = util_strstr(resp, "LOCATION:");
    if (!loc) loc = util_strstr(resp, "Location:");
    if (!loc) return NULL;
    loc = strchr(loc, ':') + 1;
    while (*loc == ' ' || *loc == '\t') loc++;
    {
        char *end = loc;
        while (*end && *end != '\r' && *end != '\n') end++;
        *end = 0;
    }
    return loc;
}

static int upnp_parse_url(char *url, char *host, int hsize, int *port, char *path, int psize)
{
    char *p;
    if (util_strncmp(url, "http://", 7)) return -1;
    p = url + 7;
    {
        char *slash = strchr(p, '/');
        char *colon = strchr(p, ':');
        if (colon && colon < slash)
        {
            int hl = colon - p;
            if (hl >= hsize) hl = hsize - 1;
            util_memcpy(host, p, hl);
            host[hl] = 0;
            *port = util_atoi(colon + 1, 10);
        }
        else if (slash)
        {
            int hl = slash - p;
            if (hl >= hsize) hl = hsize - 1;
            util_memcpy(host, p, hl);
            host[hl] = 0;
            *port = 80;
        }
        else
        {
            return -1;
        }
        if (slash)
        {
            int pl = util_strlen(slash);
            if (pl >= psize) pl = psize - 1;
            util_memcpy(path, slash, pl);
            path[pl] = 0;
        }
    }
    return 0;
}

static int upnp_http_get(char *host, int port, char *path, char *out, int max)
{
    int fd;
    struct sockaddr_in addr;
    char req[1024];
    int n;

    fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return -1;

    addr.sin_family = AF_INET;
    addr.sin_port = htons((uint16_t)port);
    addr.sin_addr.s_addr = inet_addr(host);

    if (addr.sin_addr.s_addr == INADDR_NONE)
    {
        struct hostent *hp = gethostbyname(host);
        if (!hp) { close(fd); return -1; }
        addr.sin_addr.s_addr = *(uint32_t *)hp->h_addr_list[0];
    }

    n = snprintf(req, sizeof(req),
        "GET %s HTTP/1.1\r\nHost: %s:%d\r\nConnection: close\r\n\r\n",
        path, host, port);

    if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0)
    {
        close(fd);
        return -1;
    }

    send(fd, req, n, MSG_NOSIGNAL);
    n = recv(fd, out, max - 1, 0);
    close(fd);
    if (n > 0) out[n] = 0;
    return n;
}

static int upnp_add_port_mapping(char *ctrl_url, char *host, int port,
                                  int ext_port, int int_port, char *desc)
{
    char soap[2048];
    char path[512];
    int ctrl_port;
    int fd;
    struct sockaddr_in addr;
    int n;

    if (upnp_parse_url(ctrl_url, host, 256, &ctrl_port, path, sizeof(path)) < 0)
        return -1;

    n = snprintf(soap, sizeof(soap),
        "<?xml version=\"1.0\"?>\r\n"
        "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" "
        "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">\r\n"
        "<s:Body>\r\n"
        "<u:AddPortMapping xmlns:u=\"urn:schemas-upnp-org:service:WANIPConnection:1\">\r\n"
        "<NewRemoteHost></NewRemoteHost>\r\n"
        "<NewExternalPort>%d</NewExternalPort>\r\n"
        "<NewProtocol>TCP</NewProtocol>\r\n"
        "<NewInternalPort>%d</NewInternalPort>\r\n"
        "<NewInternalClient>%s</NewInternalClient>\r\n"
        "<NewEnabled>1</NewEnabled>\r\n"
        "<NewPortMappingDescription>%s</NewPortMappingDescription>\r\n"
        "<NewLeaseDuration>0</NewLeaseDuration>\r\n"
        "</u:AddPortMapping>\r\n"
        "</s:Body>\r\n"
        "</s:Envelope>\r\n",
        ext_port, int_port, host, desc);

    fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return -1;

    addr.sin_family = AF_INET;
    addr.sin_port = htons((uint16_t)ctrl_port);
    addr.sin_addr.s_addr = inet_addr(host);

    {
        char post_hdr[512];
        int ph;
        ph = snprintf(post_hdr, sizeof(post_hdr),
            "POST %s HTTP/1.1\r\n"
            "Host: %s:%d\r\n"
            "Content-Type: text/xml; charset=\"utf-8\"\r\n"
            "SOAPAction: \"urn:schemas-upnp-org:service:WANIPConnection:1#AddPortMapping\"\r\n"
            "Content-Length: %d\r\n"
            "Connection: close\r\n"
            "\r\n",
            path, host, ctrl_port, n);

        if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0)
        {
            close(fd);
            return -1;
        }
        send(fd, post_hdr, ph, MSG_NOSIGNAL);
        send(fd, soap, n, MSG_NOSIGNAL);
    }
    close(fd);
    return 0;
}

int upnp_port_forward(int proxy_port)
{
    int sock;
    char buf[4096];
    char host_ip[32] = {0};
    int n;
    fd_set fds;
    struct timeval tv;
    int i;

    /* get our local IP */
    {
        int s = socket(AF_INET, SOCK_DGRAM, 0);
        struct sockaddr_in r;
        r.sin_family = AF_INET;
        r.sin_port = htons(80);
        r.sin_addr.s_addr = inet_addr("8.8.8.8");
        connect(s, (struct sockaddr *)&r, sizeof(r));
        {
            struct sockaddr_in l;
            socklen_t ll = sizeof(l);
            getsockname(s, (struct sockaddr *)&l, &ll);
            util_strcpy(host_ip, inet_ntoa(l.sin_addr));
        }
        close(s);
    }

    sock = upnp_send_ssdp();
    if (sock < 0) return -1;

    for (i = 0; i < 5; i++)
    {
        FD_ZERO(&fds);
        FD_SET(sock, &fds);
        tv.tv_sec = 1;
        tv.tv_usec = 0;

        if (select(sock + 1, &fds, NULL, NULL, &tv) <= 0)
            continue;

        n = recv(sock, buf, sizeof(buf) - 1, 0);
        if (n <= 0) continue;
        buf[n] = 0;

        {
            char *loc = upnp_extract_location(buf);
            if (loc)
            {
                char igd_host[256];
                int igd_port;
                char igd_path[512];
                char xml_resp[4096];

                if (upnp_parse_url(loc, igd_host, sizeof(igd_host), &igd_port, igd_path, sizeof(igd_path)) == 0)
                {
                    n = upnp_http_get(igd_host, igd_port, igd_path, xml_resp, sizeof(xml_resp));
                    if (n > 0)
                    {
                        char *ctrl = util_strstr(xml_resp, "<controlURL>");
                        if (ctrl)
                        {
                            ctrl += 12;
                            {
                                char *end = strchr(ctrl, '<');
                                if (end) *end = 0;
                            }
                            {
                                char ctrl_full[512];
                                char *slash = strrchr(igd_path, '/');
                                if (slash) *slash = 0;
                                snprintf(ctrl_full, sizeof(ctrl_full), "http://%s:%d%s/%s", igd_host, igd_port, igd_path, ctrl);
                                upnp_add_port_mapping(ctrl_full, host_ip, igd_port, proxy_port, proxy_port, "ChudNet");
                            }
                        }
                    }
                }
                close(sock);
                return 0;
            }
        }
    }

    close(sock);
    return -2;
}
