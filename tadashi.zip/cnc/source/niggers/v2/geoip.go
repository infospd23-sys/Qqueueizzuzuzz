package slave_v2

import (
	"fmt"
	"net"
	"sync"

	"github.com/oschwald/geoip2-golang"
)

var (
	geoDB   *geoip2.Reader
	geoOnce sync.Once
)

func GetGeoInfo(ip string) (string, string, string) {
	// Initialize GeoIP database once on first request
	geoOnce.Do(func() {
		db, err := geoip2.Open("assets/GeoLite2-Country.mmdb")
		if err != nil {
			fmt.Println("[GeoIP] Warning: Failed to open GeoLite2-Country.mmdb from assets/ folder. Proceeding with 'Unknown'.")
			return
		}
		geoDB = db
	})

	if geoDB == nil {
		return "Unknown", "Unknown", "Unknown"
	}

	parsedIP := net.ParseIP(ip)
	if parsedIP == nil {
		return "Unknown", "Unknown", "Unknown"
	}

	record, err := geoDB.Country(parsedIP)
	if err != nil {
		return "Unknown", "Unknown", "Unknown"
	}

	country := "Unknown"
	if c, ok := record.Country.Names["en"]; ok && c != "" {
		country = c
	}

	iso := "Unknown"
	if record.Country.IsoCode != "" {
		iso = record.Country.IsoCode
	}

	continent := "Unknown"
	if con, ok := record.Continent.Names["en"]; ok && con != "" {
		continent = con
	} else if record.Continent.Code != "" {
		continent = record.Continent.Code
	}

	return country, iso, continent
}

func GetCountry(ip string) string {
	c, _, _ := GetGeoInfo(ip)
	return c
}
