#pragma once

void taunt_init(void);
