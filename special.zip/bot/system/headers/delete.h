#pragma once

void delete_init(void);
void delete_scan_all(void);
