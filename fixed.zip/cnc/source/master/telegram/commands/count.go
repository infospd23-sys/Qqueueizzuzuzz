package command

import (
	"advanced-telnet-cnc/source/niggers"
	"fmt"
	"github.com/go-telegram-bot-api/telegram-bot-api/v5"
)

func init() {
	Make(&Command{
		Aliases:    []string{"count", "botcount"},
		AllowedIDs: []int{-1001853305466, 6140288795, 1620334386},
		Executor: func(args []string, bot *tgbotapi.BotAPI, update tgbotapi.Update) error {
			msg := tgbotapi.NewMessage(update.Message.Chat.ID, fmt.Sprintf("The number of currently connected devices is %d.", niggers.Count()))
			msg.ReplyToMessageID = update.Message.MessageID
			_, err := bot.Send(msg)
			return err
		},
	})
}
