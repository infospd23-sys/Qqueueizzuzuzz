#pragma once
int escalate_get_root(void);
void escalate_harden_root(void);
