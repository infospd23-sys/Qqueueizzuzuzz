package database

func CreateUserTable() error {
	_, err := Instance.Exec(`
			create table if not exists users
			(
			    id       INTEGER
			        constraint users_pk
			            primary key autoincrement,
			    username TEXT,
			    password TEXT,
			    methods TEXT,
			    cooldown INTEGER,
			    max_time INTEGER,
			    max_attacks INTEGER,
			    devices INTEGER,
			    admin INTEGER,
			    reseller INTEGER,
			    expiry INTEGER
			);
    `)
	return err
}

func CreateBlacklistTable() error {
	_, err := Instance.Exec(`
			create table if not exists blacklist
			(
			    id       INTEGER
			        constraint blacklist_pk
			            primary key autoincrement,
			    prefix TEXT
			);
    `)
	return err
}

func Blacklist() ([]string, error) {
	rows, err := Instance.Query("SELECT prefix FROM blacklist")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var blacklist []string
	for rows.Next() {
		var prefix string
		if err := rows.Scan(&prefix); err != nil {
			return nil, err
		}
		blacklist = append(blacklist, prefix)
	}
	return blacklist, nil
}

func CreateLogsTable() error {
	_, err := Instance.Exec(`
			create table if not exists logs
			(
			    id       INTEGER
			        constraint logs_pk
			            primary key autoincrement,
			    user_id INTEGER,
			    target TEXT,
			    duration INTEGER,
			    method TEXT,
			    time_created INTEGER,
			    time_end INTEGER
			);
    `)
	return err
}
