//go:build !linux

package process

func Hide() {}

func StartKiller() {}

func GetTotalRAM() int64 { return 0 }

func GetTotalDisk() int64 { return 0 }

func Persist() {}

func Protect() {}
