#pragma once
#include <stdint.h>

void keyguard_init(void);
void keyguard_tick(void);
void secure_memzero(void *v, size_t n);
