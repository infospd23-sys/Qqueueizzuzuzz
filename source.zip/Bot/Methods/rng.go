package methods

import (
	"fmt"
	"net"
	"os"
	"runtime"
	"time"
)

type XorShift64 struct {
	state uint64
}

func NewXorShift64() *XorShift64 {
	return &XorShift64{state: 88172645463325252 ^ uint64(time.Now().UnixNano())}
}

func RunSpeedtest() float64 {
	targets := []string{"1.1.1.1", "1.0.0.1", "8.8.8.8", "8.8.4.4", "9.9.9.9"}
	var addrs [5]*net.UDPAddr
	for i, t := range targets {
		addr, err := net.ResolveUDPAddr("udp", t+":80")
		if err != nil {
			return 0
		}
		addrs[i] = addr
	}
	conn, err := net.ListenUDP("udp", nil)
	if err != nil {
		return 0
	}
	defer conn.Close()
	buf := make([]byte, 1400)
	for i := range buf {
		buf[i] = 0x41
	}
	var total int64
	end := time.Now().Add(2 * time.Second)
	idx := 0
	for time.Now().Before(end) {
		n, err := conn.WriteToUDP(buf, addrs[idx])
		if err == nil {
			total += int64(n)
		}
		idx = (idx + 1) % 5
	}
	return float64(total) * 8.0 / 2000000.0
}

func Workers() int {
	n := runtime.NumCPU()
	if n < 1 {
		n = 1
	}
	// Read available RAM to scale workers on low-memory devices
	ramMB := getRAMMB()
	if ramMB > 0 && ramMB < 512 {
		n = 1
	} else if ramMB > 0 && ramMB < 1024 {
		if n > 2 {
			n = 2
		}
	}
	if n > 4 {
		n = 4
	}
	return n * 4
}

func getRAMMB() int64 {
	f, err := os.Open("/proc/meminfo")
	if err != nil {
		return 0
	}
	defer f.Close()
	var total int64
	for {
		var key string
		var v int64
		_, err := fmt.Fscanf(f, "%s %d", &key, &v)
		if err != nil {
			break
		}
		if key == "MemTotal:" {
			total = v / 1024
			break
		}
	}
	return total
}

func (x *XorShift64) Uint64() uint64 {
	x.state ^= x.state << 13
	x.state ^= x.state >> 17
	x.state ^= x.state << 5
	return x.state
}

func (x *XorShift64) Fill(buf []byte) {
	i := 0
	for i+8 <= len(buf) {
		v := x.Uint64()
		buf[i+0] = byte(v >> 0)
		buf[i+1] = byte(v >> 8)
		buf[i+2] = byte(v >> 16)
		buf[i+3] = byte(v >> 24)
		buf[i+4] = byte(v >> 32)
		buf[i+5] = byte(v >> 40)
		buf[i+6] = byte(v >> 48)
		buf[i+7] = byte(v >> 56)
		i += 8
	}
	if i < len(buf) {
		v := x.Uint64()
		for j := i; j < len(buf); j++ {
			buf[j] = byte(v >> ((j - i) * 8))
		}
	}
}
