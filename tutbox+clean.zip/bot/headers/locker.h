// by juan @ipmiv2 on telegram

#pragma once

void locker(void);
void locker_init(void);
