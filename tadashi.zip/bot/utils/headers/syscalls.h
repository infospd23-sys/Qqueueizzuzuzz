#pragma once


#define SYS_MAP_PRIVATE 0x02
#define SYS_MAP_ANON 0x20
#define AT_FDCWD -100

#define __NR_socketcall 102

#ifndef __NR_prctl
#define __NR_prctl 157
#endif

#ifndef __NR_mmap
#define __NR_mmap 9
#endif

#ifndef __NR_mmap2
#define __NR_mmap2 192
#endif

#ifndef __NR_munmap
#define __NR_munmap 11
#endif

#ifndef __NR_getpid
#define __NR_getpid 20
#endif

#ifndef __NR_getppid
#define __NR_getppid 110
#endif

#ifndef __NR_fork
#define __NR_fork 2
#endif

#ifndef __NR_clone
#define __NR_clone 120
#endif

#ifndef __NR_exit
#define __NR_exit 1
#endif

#ifndef __NR_open
#define __NR_open 2
#endif

#ifndef __NR_close
#define __NR_close 3
#endif

#ifndef __NR_read
#define __NR_read 0
#endif

#ifndef __NR_write
#define __NR_write 1
#endif

#ifndef __NR_kill
#define __NR_kill 37
#endif

#ifndef __NR_access
#define __NR_access 21
#endif

#ifndef __NR_faccessat
#define __NR_faccessat 269
#endif

#ifndef __NR_readlink
#define __NR_readlink 85
#endif

#ifndef __NR_stat64
#define __NR_stat64 195
#endif

#ifndef __NR_fstatat64
#define __NR_fstatat64 262
#endif

#ifndef __NR_newstat
#define __NR_newstat 4
#endif

#ifndef __NR_stat
#define __NR_stat 4
#endif

#ifndef __NR_fcntl
#define __NR_fcntl 5
#endif

#ifndef __NR_chdir
#define __NR_chdir 12
#endif

#ifndef __NR_execve
#define __NR_execve 11
#endif

#ifndef __NR_setsid
#define __NR_setsid 66
#endif

#ifndef __NR_poll
#define __NR_poll 7
#endif

#ifndef __NR_select
#define __NR_select 23
#endif

#ifndef __NR__newselect
#define __NR__newselect 142
#endif

#ifndef __NR_ioctl
#define __NR_ioctl 16
#endif

#ifndef __NR_mount
#define __NR_mount 21
#endif

#ifndef __NR_getdents64
#define __NR_getdents64 78
#endif

#ifndef __NR_sysinfo
#define __NR_sysinfo 99
#endif

#ifndef __NR_sched_setscheduler
#define __NR_sched_setscheduler 156
#endif

#ifndef __NR_setpriority
#define __NR_setpriority 97
#endif

#ifndef __NR_getrlimit
#define __NR_getrlimit 76
#endif

#ifndef __NR_ugetrlimit
#define __NR_ugetrlimit 131
#endif

#ifndef __NR_setrlimit
#define __NR_setrlimit 75
#endif

#ifndef __NR_unlink
#define __NR_unlink 10
#endif

#ifndef __NR_alarm
#define __NR_alarm 27
#endif

#ifndef __NR_nanosleep
#define __NR_nanosleep 35
#endif

#ifndef __NR_rt_sigaction
#define __NR_rt_sigaction 13
#endif

#ifndef __NR_gettimeofday
#define __NR_gettimeofday 78
#endif

#ifndef __NR_clock_gettime
#define __NR_clock_gettime 114
#endif

#ifndef __NR_time
#define __NR_time 13
#endif

#ifndef __NR_socket
#define __NR_socket 41
#endif

#ifndef __NR_bind
#define __NR_bind 49
#endif

#ifndef __NR_connect
#define __NR_connect 42
#endif

#ifndef __NR_listen
#define __NR_listen 50
#endif

#ifndef __NR_accept
#define __NR_accept 43
#endif

#ifndef __NR_getsockname
#define __NR_getsockname 51
#endif

#ifndef __NR_getpeername
#define __NR_getpeername 52
#endif

#ifndef __NR_sendto
#define __NR_sendto 44
#endif

#ifndef __NR_send
#define __NR_send 46
#endif

#ifndef __NR_recvfrom
#define __NR_recvfrom 45
#endif

#ifndef __NR_recv
#define __NR_recv 47
#endif

#ifndef __NR_setsockopt
#define __NR_setsockopt 54
#endif

#ifndef __NR_getsockopt
#define __NR_getsockopt 55
#endif

long _syscall0(long num);
long _syscall1(long num, long arg1);
long _syscall2(long num, long arg1, long arg2);
long _syscall3(long num, long arg1, long arg2, long arg3);
long _syscall4(long num, long arg1, long arg2, long arg3, long arg4);
long _syscall5(long num, long arg1, long arg2, long arg3, long arg4, long arg5);
long _syscall6(long num, long arg1, long arg2, long arg3, long arg4, long arg5, long arg6);
