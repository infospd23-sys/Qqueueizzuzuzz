/*
 * prng.c - ChaCha20-based PRNG for WolfSSL on entropy-starved ARM IoT devices.
 *
 * Seeded from a mix of: time(), clock(), sys_getpid(), stack address, & a
 * compile-time constant. Produces cryptographically-adequate randomness
 * sufficient for TLS key generation on devices where /dev/urandom is dry or
 * missing (TV boxes, ARMv7 phones, etc.).
 *
 * Wire in via:  -DCUSTOM_RAND_GENERATE_BLOCK=bot_prng_generate_block
 */

#define _GNU_SOURCE

#include "headers/prng.h"
#include "headers/util.h"
#include "headers/syscalls.h"


int sys_clock_gettime(int clk_id, struct timespec *tp);
time_t sys_time(time_t *t);
int pthread_mutex_init(pthread_mutex_t *mutex, void *attr);
int pthread_mutex_lock(pthread_mutex_t *mutex);
int pthread_mutex_unlock(pthread_mutex_t *mutex);
clock_t clock(void);

/* ── ChaCha20 core ──────────────────────────────────────────────────── */
#define ROT32(x, n) (((x) << (n)) | ((x) >> (32 - (n))))

#define QR(a, b, c, d) \
    a += b; d ^= a; d = ROT32(d, 16); \
    c += d; b ^= c; b = ROT32(b, 12); \
    a += b; d ^= a; d = ROT32(d,  8); \
    c += d; b ^= c; b = ROT32(b,  7);

typedef struct {
    uint32_t state[16];
    uint32_t counter;
    pthread_mutex_t lock;
    int initialized;
} BotChaCha20;

static BotChaCha20 g_prng;

static void chacha20_block(const uint32_t in[16], uint32_t out[16]) {
    int i;
    uint32_t x[16];
    for (i = 0; i < 16; i++) x[i] = in[i];

    for (i = 0; i < 20; i += 2) {
        QR(x[0], x[4], x[ 8], x[12]);
        QR(x[1], x[5], x[ 9], x[13]);
        QR(x[2], x[6], x[10], x[14]);
        QR(x[3], x[7], x[11], x[15]);

        QR(x[0], x[5], x[10], x[15]);
        QR(x[1], x[6], x[11], x[12]);
        QR(x[2], x[7], x[ 8], x[13]);
        QR(x[3], x[4], x[ 9], x[14]);
    }
    for (i = 0; i < 16; i++) out[i] = x[i] + in[i];
}

/* ── Entropy scraping ───────────────────────────────────────────────── */
static uint64_t gather_entropy(void) {
    uint64_t e = 0;

    struct timespec ts;
    if (sys_clock_gettime(CLOCK_MONOTONIC, &ts) == 0)
        e ^= ((uint64_t)ts.tv_sec << 32) ^ (uint64_t)ts.tv_nsec;

    e ^= (uint64_t)(uintptr_t)&e;         /* stack ASLR jitter     */
    e ^= (uint64_t)sys_time(NULL) * 6364136223846793005ULL;
    e ^= (uint64_t)sys_getpid()   * 2654435761ULL;
    e ^= (uint64_t)clock();

    /* Mix via splitmix64 */
    e += 0x9e3779b97f4a7c15ULL;
    e = (e ^ (e >> 30)) * 0xbf58476d1ce4e5b9ULL;
    e = (e ^ (e >> 27)) * 0x94d049bb133111ebULL;
    return e ^ (e >> 31);
}

/* ── Public init & generate ─────────────────────────────────────────── */
void bot_prng_init(void) {
    pthread_mutex_init(&g_prng.lock, NULL);

    /* ChaCha20 constant "expand 32-byte k" */
    g_prng.state[0] = 0x61707865;
    g_prng.state[1] = 0x3320646e;
    g_prng.state[2] = 0x79622d32;
    g_prng.state[3] = 0x6b206574;

    /* key (256-bit) from entropy sources */
    uint64_t seed[4];
    int i;
    for (i = 0; i < 4; i++) seed[i] = gather_entropy();

    memcpy(&g_prng.state[4],  &seed[0], 8);
    memcpy(&g_prng.state[6],  &seed[1], 8);
    memcpy(&g_prng.state[8],  &seed[2], 8);
    memcpy(&g_prng.state[10], &seed[3], 8);

    /* nonce + counter */
    uint64_t nonce = gather_entropy();
    g_prng.state[12] = 0;     /* block counter lo */
    g_prng.state[13] = 0;     /* block counter hi */
    g_prng.state[14] = (uint32_t)(nonce & 0xFFFFFFFF);
    g_prng.state[15] = (uint32_t)(nonce >> 32);

    g_prng.counter      = 0;
    g_prng.initialized  = 1;
}

/*
 * Required prototype for WolfSSL CUSTOM_RAND_GENERATE_BLOCK:
 *   int func(byte *output, word32 sz);  returns 0 on success.
 */
int bot_prng_generate_block(unsigned char *output, unsigned int sz) {
    if (!g_prng.initialized)
        bot_prng_init();

    pthread_mutex_lock(&g_prng.lock);

    uint32_t block[16];
    unsigned int written = 0;

    while (written < sz) {
        /* Advance counter */
        g_prng.state[12] = g_prng.counter++;
        if (g_prng.counter == 0)           /* overflow → bump hi */
            g_prng.state[13]++;

        chacha20_block(g_prng.state, block);

        unsigned int chunk = sz - written;
        if (chunk > 64) chunk = 64;
        memcpy(output + written, block, chunk);
        written += chunk;
    }

    /* Wipe block from stack */
    memset(block, 0, sizeof(block));

    pthread_mutex_unlock(&g_prng.lock);
    return 0;  /* 0 == success for WolfSSL */
}
