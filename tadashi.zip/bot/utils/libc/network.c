#include "../headers/syscalls.h";
#include "../headers/util.h";
#include "../headers/includes.h";

typedef __builtin_va_list va_list;
#define va_start(v, l) __builtin_va_start(v, l)
#define va_end(v) __builtin_va_end(v)
#define va_arg(v, l) __builtin_va_arg(v, l)

#define va_copy(d,s) __builtin_va_copy(d,s)
typedef long ptrdiff_t;
#define __va_copy(d,s) __builtin_va_copy(d,s)

uint32_t ntohl(uint32_t netlong)
{
    return ((netlong & 0xFF) << 24) |
           ((netlong & 0xFF00) << 8) |
           ((netlong & 0xFF0000) >> 8) |
           ((netlong & 0xFF000000) >> 24);
}

uint32_t htonl(uint32_t hostlong)
{
    return ntohl(hostlong);
}

int setsockopt(int sockfd, int level, int optname, const void *optval, socklen_t optlen)
{
    return _syscall5(__NR_setsockopt, sockfd, level, optname, (long)optval, (long)optlen);
}

uint32_t CONVERT_ADDR(uint32_t addr)
{
    return addr;
}
