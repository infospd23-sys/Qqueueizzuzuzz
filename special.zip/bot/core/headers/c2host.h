#pragma once

void c2_init_host(void);
char *c2_get_host(void);
