#pragma once


#ifndef _TYPES_H
#define _TYPES_H
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef long long int64_t;
typedef unsigned long size_t;
typedef unsigned int socklen_t;
typedef long time_t;
#endif

typedef unsigned int nfds_t;
typedef struct {
    uint32_t fds_bits;
} fd_set;
typedef struct {
    int fd;
    short events;
    short revents;
} pollfd;
typedef struct timeval {
    long tv_sec;
    long tv_usec;
} timeval;
typedef struct {
    long tv_sec;
    long tv_nsec;
} timespec;

struct sysinfo {
    long uptime;
    unsigned long loads[3];
    unsigned long totalram;
    unsigned long freeram;
    unsigned long sharedram;
    unsigned long bufferram;
    unsigned long totalswap;
    unsigned long freeswap;
    unsigned short procs;
    unsigned short pad;
    unsigned long totalhigh;
    unsigned long freehigh;
    unsigned int mem_unit;
};

/* Missing syscalls */
int sys_sysinfo(struct sysinfo *info);
int sys_select(int nfds, fd_set *readfds, fd_set *writefds, fd_set *exceptfds, struct timeval *timeout);
int sys_bind(int fd, const void *addr, socklen_t addrlen);
int sys_getsockname(int fd, void *addr, socklen_t *addrlen);
int sys_gettimeofday(struct timeval *tv, void *tz);
int sys_poll(void *fds, nfds_t nfds, int timeout);
long _syscall6(long number, long arg1, long arg2, long arg3, long arg4, long arg5, long arg6);
int sys_readlink(char *path, char *buf, size_t bufsiz);
int sys_sleep(int seconds);

/* Forward declarations */
struct resolved;
void free_entries(struct resolved *entries);

