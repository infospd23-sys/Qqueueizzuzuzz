#include "../headers/syscalls.h";
#include "../headers/util.h";
#include "../headers/includes.h";

typedef __builtin_va_list va_list;
#define va_start(v, l) __builtin_va_start(v, l)
#define va_end(v) __builtin_va_end(v)
#define va_arg(v, l) __builtin_va_arg(v, l)

#define va_copy(d,s) __builtin_va_copy(d,s)
typedef long ptrdiff_t;
#define __va_copy(d,s) __builtin_va_copy(d,s)


char *strncpy(char *dest, const char *src, size_t n)
{
    size_t i;
    for (i = 0; i < n && src[i] != '\0'; i++)
        dest[i] = src[i];
    for (; i < n; i++)
        dest[i] = '\0';
    return dest;
}

char *_strncpy(char *dest, const char *src, size_t n)
{
    return strncpy(dest, src, n);
}