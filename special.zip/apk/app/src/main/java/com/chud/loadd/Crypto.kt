package com.chud.loadd

import java.nio.ByteBuffer
import java.nio.ByteOrder

class Crypto(seed: Long) {
    private val state = IntArray(16)
    private val keystream = ByteArray(64)
    private var ksPos = 64
    private var counter = 0

    init {
        val seedInt = (seed and 0xFFFFFFFFL).toInt()
        val (key, nonce) = deriveKeyNonce(seedInt)

        state[0] = 0x61707865.toInt()
        state[1] = 0x3320646E.toInt()
        state[2] = 0x79622D32.toInt()
        state[3] = 0x6B206574.toInt()

        for (i in 0..7) {
            state[4 + i] = leBytesToInt(key, i * 4)
        }
        state[12] = 0

        for (i in 0..2) {
            state[13 + i] = leBytesToInt(nonce, i * 4)
        }
    }

    fun xor(buf: ByteArray) {
        for (i in buf.indices) {
            if (ksPos >= 64) {
                generateKeystream()
                ksPos = 0
            }
            buf[i] = (buf[i].toInt() xor (keystream[ksPos].toInt() and 0xFF)).toByte()
            ksPos++
        }
    }

    fun xor(buf: ByteArray, offset: Int, len: Int) {
        for (i in offset until offset + len) {
            if (ksPos >= 64) {
                generateKeystream()
                ksPos = 0
            }
            buf[i] = (buf[i].toInt() xor (keystream[ksPos].toInt() and 0xFF)).toByte()
            ksPos++
        }
    }

    private fun generateKeystream() {
        val working = IntArray(16)
        for (i in 0..15) working[i] = state[i]
        working[12] = counter
        counter++

        for (round in 0 until 10) {
            quarterRound(working, 0, 4, 8, 12)
            quarterRound(working, 1, 5, 9, 13)
            quarterRound(working, 2, 6, 10, 14)
            quarterRound(working, 3, 7, 11, 15)
            quarterRound(working, 0, 5, 10, 15)
            quarterRound(working, 1, 6, 11, 12)
            quarterRound(working, 2, 7, 8, 13)
            quarterRound(working, 3, 4, 9, 14)
        }

        for (i in 0..15) {
            val v = (working[i] + state[i])
            intToLeBytes(v, keystream, i * 4)
        }
    }

    companion object {
        private const val MASTER_KEY = "ChudNetSessionKDF_v01\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000"

        private fun rotl32(x: Int, n: Int): Int = (x shl n) or (x ushr (32 - n))

        private fun quarterRound(state: IntArray, a: Int, b: Int, c: Int, d: Int) {
            var na = state[a]; var nb = state[b]; var nc = state[c]; var nd = state[d]
            na += nb; nd = nd xor na; nd = rotl32(nd, 16)
            nc += nd; nb = nb xor nc; nb = rotl32(nb, 12)
            na += nb; nd = nd xor na; nd = rotl32(nd, 8)
            nc += nd; nb = nb xor nc; nb = rotl32(nb, 7)
            state[a] = na; state[b] = nb; state[c] = nc; state[d] = nd
        }

        private fun chacha20Block(output: IntArray, input: IntArray) {
            for (i in 0..15) output[i] = input[i]
            for (round in 0 until 10) {
                quarterRound(output, 0, 4, 8, 12)
                quarterRound(output, 1, 5, 9, 13)
                quarterRound(output, 2, 6, 10, 14)
                quarterRound(output, 3, 7, 11, 15)
                quarterRound(output, 0, 5, 10, 15)
                quarterRound(output, 1, 6, 11, 12)
                quarterRound(output, 2, 7, 8, 13)
                quarterRound(output, 3, 4, 9, 14)
            }
            for (i in 0..15) output[i] = output[i] + input[i]
        }

        private fun leBytesToInt(b: ByteArray, offset: Int): Int {
            return (b[offset].toInt() and 0xFF) or
                   ((b[offset + 1].toInt() and 0xFF) shl 8) or
                   ((b[offset + 2].toInt() and 0xFF) shl 16) or
                   ((b[offset + 3].toInt() and 0xFF) shl 24)
        }

        private fun intToLeBytes(v: Int, out: ByteArray, offset: Int) {
            out[offset] = (v and 0xFF).toByte()
            out[offset + 1] = ((v ushr 8) and 0xFF).toByte()
            out[offset + 2] = ((v ushr 16) and 0xFF).toByte()
            out[offset + 3] = ((v ushr 24) and 0xFF).toByte()
        }

        private fun deriveKeyNonce(seed: Int): Pair<ByteArray, ByteArray> {
            val masterKeyBytes = MASTER_KEY.toByteArray(Charsets.UTF_8)
            val paddedKey = ByteArray(32)
            System.arraycopy(masterKeyBytes, 0, paddedKey, 0, minOf(masterKeyBytes.size, 32))

            val kdfNonce = ByteArray(12)
            intToLeBytes(seed, kdfNonce, 0)

            val kdfInput = IntArray(16)
            kdfInput[0] = 0x61707865.toInt()
            kdfInput[1] = 0x3320646E.toInt()
            kdfInput[2] = 0x79622D32.toInt()
            kdfInput[3] = 0x6B206574.toInt()
            for (i in 0..7) kdfInput[4 + i] = leBytesToInt(paddedKey, i * 4)
            kdfInput[12] = 0
            kdfInput[13] = seed
            kdfInput[14] = 0
            kdfInput[15] = 0

            val kdfOutput = IntArray(16)
            chacha20Block(kdfOutput, kdfInput)

            val key = ByteArray(32)
            for (i in 0..7) intToLeBytes(kdfOutput[i], key, i * 4)

            val nonce = ByteArray(12)
            for (i in 0..2) intToLeBytes(kdfOutput[8 + i], nonce, i * 4)

            return Pair(key, nonce)
        }

        fun bytesToUint32(buf: ByteArray): Long =
            ByteBuffer.wrap(buf).order(ByteOrder.BIG_ENDIAN).int.toLong() and 0xFFFFFFFFL

        fun uint32ToBytes(v: Long): ByteArray =
            ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putInt(v.toInt()).array()

        fun uint16ToBytes(v: Int): ByteArray =
            ByteBuffer.allocate(2).order(ByteOrder.BIG_ENDIAN).putShort(v.toShort()).array()

        fun bytesToUint16(buf: ByteArray): Int =
            ByteBuffer.wrap(buf).order(ByteOrder.BIG_ENDIAN).short.toInt() and 0xFFFF
    }
}
