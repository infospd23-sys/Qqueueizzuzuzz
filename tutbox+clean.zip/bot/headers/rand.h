// by juan @ipmiv2 on telegram

#pragma once

#include <stdint.h>

// Constant for the random number generator
#define PHI 0x9e3779b9

// Function prototypes
void rand_init(void);
uint32_t rand_next(void);
void rand_str(char *str, int len);
void rand_alpha_str(uint8_t *str, int len);
void rand_alphastr(uint8_t *str, int len);
uint32_t rand_next_range(uint32_t min, uint32_t max);
