#pragma once
#include <stdint.h>

void relay_handle(int fd_serv, char *target_host, uint16_t target_port);
