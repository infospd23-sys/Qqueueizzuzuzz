#include "headers/net_util.h"
#include "headers/util.h"
#include "headers/syscalls.h"

int sys_getsockname(int sockfd, void *addr, socklen_t *addrlen);
int sys_setsockopt(int sockfd, int level, int optname, const void *optval, socklen_t optlen);

int find_inode_by_port(int port) {
    // Simplified implementation - just return 0 for now
    // Full netlink implementation would require complex structures
    return 0;
}

int get_socket_info(int fd, struct sockaddr_in *addr) {
    socklen_t len = sizeof(struct sockaddr_in);
    return sys_getsockname(fd, (struct sockaddr *)addr, &len);
}

int set_socket_options(int fd, int optname, int optval) {
    return sys_setsockopt(fd, SOL_SOCKET, optname, &optval, sizeof(optval));
}
