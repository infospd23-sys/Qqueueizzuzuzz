#pragma once


/* Network headers */
struct iphdr {
    uint8_t ihl:4;
    uint8_t version:4;
    uint8_t tos;
    uint16_t tot_len;
    uint16_t id;
    uint16_t frag_off;
    uint8_t ttl;
    uint8_t protocol;
    uint16_t check;
    uint32_t saddr;
    uint32_t daddr;
};

struct udphdr {
    uint16_t source;
    uint16_t dest;
    uint16_t len;
    uint16_t check;
};

struct grehdr {
    uint16_t flags;
    uint16_t protocol;
};

/* System call wrappers */
#define sys_sendto(fd, buf, len, flags, addr, addrlen) sendto(fd, buf, len, flags, addr, addrlen)
#define sys_usleep(usec) usleep(usec)
