#pragma once

#ifdef DEBUG
#include "utils/headers/util.h"
#include "encryption/chacha20_table.h"
#define debug(fmt, ...) do { \
    printf(fmt, ##__VA_ARGS__); \
} while (0)
#endif

#ifndef DEBUG
#define debug(...)
#endif
