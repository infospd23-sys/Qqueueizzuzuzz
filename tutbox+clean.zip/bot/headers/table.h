// by juan @ipmiv2 on telegram

#pragma once

typedef struct {
    char *str;
    int len;
} table_t;

// Declare the variable as extern
extern table_t *table;
