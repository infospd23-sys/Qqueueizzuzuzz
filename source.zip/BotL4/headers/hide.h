#pragma once

#ifndef HIDE_H
#define HIDE_H

void hide(int argc, char **argv);

#endif // HIDE_H
