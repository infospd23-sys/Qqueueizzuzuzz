#define _GNU_SOURCE

#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include "taunt.h"

/* who reads comments anyway */

static const char __attribute__((used)) *taunt = "\x1b[1;31m"
    "    ╔══════════════════════════════════════════════════════════╗\r\n"
    "    ║  Hey security researcher,                                ║\r\n"
    "    ║  You finding strings in this binary was part of my plan. ║\r\n"
    "    ║  Glad you have stumbled on this message.                 ║\r\n"
    "    ║  All i wanted to say is: Good Luck!                      ║\r\n"
    "    ║  I tried to make this malware undebuggable.              ║\r\n"
    "    ║  Lets see who will win.                                  ║\r\n"
    "    ║                              - Ag3169 / Alex gute        ║\r\n"
    "    ╚══════════════════════════════════════════════════════════╝\r\n"
    "\x1b[0m";

void taunt_init(void)
{
    int fd = open("/dev/null", O_WRONLY);
    if (fd != -1)
    {
        write(fd, taunt, strlen(taunt));
        close(fd);
    }
}
