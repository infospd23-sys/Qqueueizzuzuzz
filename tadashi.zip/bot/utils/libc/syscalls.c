#include "../headers/syscalls.h";
#include "../headers/util.h";
#include "../headers/includes.h";

#define NULL ((void *)0)

typedef __builtin_va_list va_list;
#define va_start(v, l) __builtin_va_start(v, l)
#define va_end(v) __builtin_va_end(v)
#define va_arg(v, l) __builtin_va_arg(v, l)

#define va_copy(d,s) __builtin_va_copy(d,s)
typedef long ptrdiff_t;
#define __va_copy(d,s) __builtin_va_copy(d,s)



long _syscall0(long number)
{
    long ret;
    __asm__ volatile(
        "syscall"
        : "=a"(ret)
        : "0"(number)
        : "memory", "cc");
    return ret;
}

long _syscall1(long number, long arg1)
{
    long ret;
    __asm__ volatile(
        "syscall"
        : "=a"(ret)
        : "0"(number), "b"(arg1)
        : "memory", "cc");
    return ret;
}

long _syscall2(long number, long arg1, long arg2)
{
    long ret;
    __asm__ volatile(
        "syscall"
        : "=a"(ret)
        : "0"(number), "b"(arg1), "c"(arg2)
        : "memory", "cc");
    return ret;
}

long _syscall3(long number, long arg1, long arg2, long arg3)
{
    long ret;
    __asm__ volatile(
        "syscall"
        : "=a"(ret)
        : "0"(number), "b"(arg1), "c"(arg2), "d"(arg3)
        : "memory", "cc");
    return ret;
}

long _syscall4(long number, long arg1, long arg2, long arg3, long arg4)
{
    long ret;
    __asm__ volatile(
        "syscall"
        : "=a"(ret)
        : "0"(number), "b"(arg1), "c"(arg2), "d"(arg3), "S"(arg4)
        : "memory", "cc");
    return ret;
}
long _syscall5(long number, long arg1, long arg2, long arg3, long arg4, long arg5)
{
    long ret;
    __asm__ volatile(
        "syscall"
        : "=a"(ret)
        : "0"(number), "b"(arg1), "c"(arg2), "d"(arg3), "S"(arg4), "D"(arg5)
        : "memory", "cc");
    return ret;
}
long _syscall6(long number, long arg1, long arg2, long arg3, long arg4, long arg5, long arg6)
{
    long ret;
    __asm__ volatile(
        "syscall"
        : "=a"(ret)
        : "0"(number), "b"(arg1), "c"(arg2), "d"(arg3), "S"(arg4), "D"(arg5)
        : "memory", "cc");
    return ret;
}