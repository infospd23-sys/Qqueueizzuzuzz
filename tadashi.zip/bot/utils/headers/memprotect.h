#pragma once

/* Type definitions */
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;

int make_memory_executable(void *addr, size_t size);
int make_memory_writable(void *addr, size_t size);
int protect_memory(void *addr, size_t size, int prot);
