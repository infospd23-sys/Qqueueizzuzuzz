#pragma once

#include "../headers/includes.h"
#include "../headers/util.h"
#include "../headers/rand.h"

// Attack-related function declarations
void flood_attack_init(void);
void flood_attack_cleanup(void);
int flood_attack_start(char *target, int port, int duration);
int flood_attack_stop(void);
