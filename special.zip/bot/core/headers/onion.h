#pragma once

#include "includes.h"
#include "util.h"

void onion_init(void);
char *onion_get_host(void);
int onion_enabled_check(void);
int onion_connect(int *out_fd, char *onion_host, uint16_t onion_port);
