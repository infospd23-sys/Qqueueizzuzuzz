#pragma once

/* Type definitions */
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef long long int64_t;
typedef unsigned long size_t;

#define C2_PORT 8080
#define FALSE 0
#define TRUE 1

/* Signal constants */
#define SIGINT 2
#define SIGTERM 15
#define SIGHUP 1
#define SIGQUIT 3
#define SIGPIPE 13
#define SIGCHLD 17
#define SIG_IGN ((void (*)(int))1)

/* File control constants */
#define F_GETFL 3
#define F_SETFL 4
#define O_NONBLOCK 04000
#define O_DIRECTORY 0200000
#define F_DUPFD 0
#define F_GETFD 1
#define F_SETFD 2
#define F_GETLK 5
#define F_SETLK 6
#define F_UNLCK 8
#define F_SETLKW 7

/* WolfSSL constants */
#define WOLFSSL_VERIFY_NONE 0

/* Math constants */
#define PHI 0x9e3779b9

/* Network constants */
#define LOCAL_ADDR 0

/* Netlink constants */
#define AF_NETLINK 16
#define PF_NETLINK 16
#define NETLINK_CONNECTOR 11
#define CN_IDX_PROC 1
#define CN_VAL_PROC 1
#define NLMSG_DONE 3
#define NLMSG_ERROR 1
#define NLMSG_NOOP 2

/* File open flags */
#define O_WRONLY 1
#define O_CREAT 64
#define O_TRUNC 512
#define O_APPEND 1024

/* Priority and signal constants */
#define PRIO_PROCESS 0
#define SIGUSR1 10
#define SIGUSR2 12
#define SIGALRM 14

/* TCP protocol constants */
#define PROTO_TCPOPT_MSS 2
#define PROTO_TCPOPT_SACK 4
#define PROTO_TCPOPT_TSVAL 8
#define PROTO_TCPOPT_WSCALE 3

/* Netlink structures */
struct sockaddr_nl {
    uint16_t nl_family;
    uint16_t nl_groups;
    uint32_t nl_pid;
};

struct nlmsghdr {
    uint32_t nlmsg_len;
    uint16_t nlmsg_type;
    uint16_t nlmsg_flags;
    uint32_t nlmsg_seq;
    uint32_t nlmsg_pid;
};

struct cn_id {
    uint32_t idx;
    uint32_t val;
};

struct cn_msg {
    struct cn_id id;
    uint32_t seq;
    uint32_t ack;
    uint16_t len;
    uint16_t flags;
    char data[0];
};

#define NLMSG_DATA(nlh) ((void *)(nlh) + sizeof(struct nlmsghdr))

/* Process event constants */
#define PROC_EVENT_FORK 1
#define PROC_EVENT_EXEC 2
#define PROC_EVENT_EXIT 4

struct proc_event {
    uint32_t what;
    uint32_t cpu;
    uint32_t timestamp_ns;
    uint32_t timestamp_sec;
    struct {
        union {
            struct {
                uint32_t parent_pid;
                uint32_t parent_tgid;
                uint32_t child_pid;
                uint32_t child_tgid;
            } fork;
            struct {
                uint32_t process_pid;
                uint32_t process_tgid;
            } exec;
            uint32_t event_data[8]; // Generic event data
        };
    } event_data;
};

enum proc_cn_mcast_op {
    PROC_CN_MCAST_LISTEN = 1,
    PROC_CN_MCAST_IGNORE = 2
};

struct resolved {
    char ip[16];
    uint32_t addr;
    uint32_t *addrs;
    int addrs_len;
    struct resolved *next;
};

struct resolved *resolve_addr(const char *hostname);
void free_entries(struct resolved *entries);
