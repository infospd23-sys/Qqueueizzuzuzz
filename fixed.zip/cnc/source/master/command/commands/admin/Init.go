package admin

func Init() {

}
