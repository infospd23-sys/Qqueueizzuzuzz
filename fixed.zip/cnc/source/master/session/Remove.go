package sessions

func (session *Session) Remove() {
	sessionMutex.Lock()
	defer sessionMutex.Unlock()
	delete(sessionsMap, session.ID)
}
