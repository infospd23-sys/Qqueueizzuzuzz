#pragma once

/* Type definitions - no libc dependencies */
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef long long int64_t;
typedef unsigned long size_t;

/* wolfSSL structures */
typedef struct {
    int fd;
    void *ctx;
    const char *alpn_src;
    char selected_alpn[16];
    char sni[256];
    int last_error;
    int handshake_done;
    uint16_t negotiated_version;
} WOLFSSL;

typedef struct {
    int verify_mode;
    const char *cipher_list;
} WOLFSSL_CTX;

typedef struct {
    struct {
        unsigned char major;
        unsigned char minor;
    } version;
    unsigned char side;
    unsigned char downgrade;
} WOLFSSL_METHOD;

/* wolfSSL constants */
#define WOLFSSL_SUCCESS 1
#define WOLFSSL_FAILURE -1
#define WOLFSSL_ERROR_NONE 0
#define WOLFSSL_ERROR_WANT_READ 2
#define WOLFSSL_ERROR_WANT_WRITE 3
#define WOLFSSL_SNI_HOST_NAME 0
#define WOLFSSL_VERIFY_NONE 0
#define WOLFSSL_ALPN_FAILED_ON_MISMATCH 0
#define WOLFSSL_ALPN_CONTINUE_ON_MISMATCH 1

/* -------------------------------------------------------------------------
 * Protocol implementations
 * ------------------------------------------------------------------------- */

/* TLS 1.3 / QUIC */
size_t protocols_tls13_ch(uint8_t *buf, uint8_t *dcid, size_t dcid_len);

/* HTTP/2 */
size_t protocols_generate_h2_preamble(uint8_t *buf);
size_t protocols_h2_pack_headers(uint8_t *buf, const char *host, const char *path, const char *method);
size_t protocols_h2_frame(uint8_t *buf, uint8_t type, uint8_t flags, uint32_t stream_id, const uint8_t *payload, size_t len);
int protocols_build_headers_frame(unsigned char *buf, int streamID, const char *host, const char *path);

/* ── Socket syscall wrappers (no glibc) ── */
int sys_send(int sockfd, void *buf, size_t len, int flags);
int sys_recv(int sockfd, void *buf, size_t len, int flags);

/* ── WolfSSL TLS helpers ── */
WOLFSSL_CTX *protocols_wolfssl_init_client_ctx(void);
int protocols_wolfssl_configure_client(WOLFSSL *ssl, const char *sni, const char *alpn_list);
int wolfSSL_Init(void);
void wolfSSL_Cleanup(void);
WOLFSSL_METHOD *wolfTLS_client_method(void);
WOLFSSL_METHOD *wolfTLSv23_client_method(void);
WOLFSSL_CTX *wolfSSL_CTX_new(WOLFSSL_METHOD *method);
void wolfSSL_CTX_free(WOLFSSL_CTX *ctx);
int wolfSSL_CTX_set_cipher_list(WOLFSSL_CTX *ctx, const char *list);
void wolfSSL_CTX_set_verify(WOLFSSL_CTX *ctx, int mode, void *cb);
WOLFSSL *wolfSSL_new(WOLFSSL_CTX *ctx);
void wolfSSL_free(WOLFSSL *ssl);
int wolfSSL_set_fd(WOLFSSL *ssl, int fd);
int wolfSSL_connect(WOLFSSL *ssl);
int wolfSSL_write(WOLFSSL *ssl, const void *data, int sz);
int wolfSSL_read(WOLFSSL *ssl, void *data, int sz);
int wolfSSL_get_error(WOLFSSL *ssl, int ret);
int wolfSSL_shutdown(WOLFSSL *ssl);
int wolfSSL_UseALPN(WOLFSSL *ssl, char *protocol_name_list, unsigned int protocol_name_listSz, unsigned char options);
int wolfSSL_ALPN_GetProtocol(WOLFSSL *ssl, char **protocol_name, unsigned short *size);
int wolfSSL_UseSNI(WOLFSSL *ssl, unsigned char type, const void *data, unsigned short size);
int wolfSSL_set_quic_transport_version(WOLFSSL *ssl, int version);

/* Additional wolfSSL functions needed for DNS over TLS */
int wolfSSL_CTX_SetMinVersion(WOLFSSL_CTX* ctx, int version);
char* wolfSSL_ERR_error_string(unsigned long errNumber, char* data);
const char* wolfSSL_get_cipher(WOLFSSL* ssl);
int wolfSSL_peek(WOLFSSL *ssl, void *data, int sz);

/* Additional protocols */
size_t protocols_h2_chrome_settings(uint8_t *buf);
size_t protocols_h2_chrome_ack(uint8_t *buf);
size_t protocols_h2_chrome_priority(uint8_t *buf);

/* HTTP/3 */
size_t protocols_h3_request(uint8_t *buf, const char *host, const char *path, const char *method);
