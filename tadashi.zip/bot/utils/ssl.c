#include "headers/includes.h"
#include "headers/ssl.h"
#include "headers/protocols.h"
#include "headers/resolver.h"
#include "headers/crypto.h"
#include "headers/rand.h"
#include "../encryption/chacha20_table.h"
#include "../modules/debug.h"

/* -------------------------------------------------------------------------
 * Protocol version constants from wolfSSL
 * Used in InitSSL_Method to set the protocol version
 * SSLv3_MAJOR = 3 (for TLS 1.0, 1.1, 1.2, 1.3)
 * TLSv1_2_MINOR = 3 (TLS 1.2 minor version)
 * ProtocolVersion structure: major byte + minor byte
 * -------------------------------------------------------------------------*/
typedef struct {
    unsigned char major;
    unsigned char minor;
} ProtocolVersion;

/* Endpoint constants */
#define WOLFSSL_SERVER_END 0
#define WOLFSSL_CLIENT_END 1

/* Protocol version constants */
#define SSLv3_MAJOR    3   /* SSLv3 and TLSv1+ major version number */
#define TLSv1_2_MINOR  3   /* TLSv1_2 minor version number */
#define WOLFSSL_SUCCESS 1

/* -------------------------------------------------------------------------
 * Static storage for method structures
 * -------------------------------------------------------------------------*/
static ProtocolVersion MakeTLSv1_2(void)
{
    ProtocolVersion pv;
    pv.major = SSLv3_MAJOR;
    pv.minor = TLSv1_2_MINOR;
    return pv;
}

/* From wolfSSL internal.c - InitSSL_Method initializes the method structure */
static void InitSSL_Method(WOLFSSL_METHOD* method, ProtocolVersion pv)
{
    method->version.major  = pv.major;
    method->version.minor  = pv.minor;
    method->side           = WOLFSSL_CLIENT_END;
    method->downgrade      = 0;
}

/* From wolfSSL src/tls.c - wolfTLS_client_method_ex implementation */
static WOLFSSL_METHOD* wolfTLS_client_method_ex(void* heap)
{
    WOLFSSL_METHOD* method =
                          (WOLFSSL_METHOD*) malloc(sizeof(WOLFSSL_METHOD));
    (void)heap;
    
    if (method) {
        InitSSL_Method(method, MakeTLSv1_2());
        method->downgrade = 1;
        method->side      = WOLFSSL_CLIENT_END;
    }
    return method;
}

/* From wolfSSL src/tls.c - wolfTLS_client_method wrapper */
WOLFSSL_METHOD* wolfTLS_client_method(void)
{
    return wolfTLS_client_method_ex(NULL);
}

/* --------------------------------------------------------- */

int wolfSSL_Init(void) {
    debug("[ssl] wolfSSL_Init called\n");
}

WOLFSSL_METHOD *wolfTLSv1_2_client_method(void) {
    return wolfTLS_client_method();
}

WOLFSSL_METHOD *wolfTLSv1_3_client_method(void) {
    return wolfTLS_client_method();
}

WOLFSSL_CTX *wolfSSL_CTX_new(WOLFSSL_METHOD *method) {
    (void)method;
    WOLFSSL_CTX *ctx = (WOLFSSL_CTX *)malloc(sizeof(WOLFSSL_CTX));
    if (!ctx) return NULL;
    
    ctx->verify_mode = WOLFSSL_VERIFY_NONE;
    ctx->cipher_list = "ALL:!eNULL:!aNULL:!MD5:!3DES";
    
    return ctx;
}

void wolfSSL_CTX_free(WOLFSSL_CTX *ctx) {
    if (ctx != NULL)
        free(ctx);
}

int wolfSSL_CTX_set_cipher_list(WOLFSSL_CTX *ctx, const char *list) {
    if (ctx == NULL || list == NULL)
        return WOLFSSL_FAILURE;
    ctx->cipher_list = list;
    return WOLFSSL_SUCCESS;
}

void wolfSSL_CTX_set_verify(WOLFSSL_CTX *ctx, int mode, void *cb) {
    if (ctx != NULL)
        ctx->verify_mode = mode;
}

WOLFSSL *wolfSSL_new(WOLFSSL_CTX *ctx) {
    if (ctx == NULL) return NULL;
    
    WOLFSSL *ssl = (WOLFSSL *)malloc(sizeof(WOLFSSL));
    if (!ssl) return NULL;
    
    ssl->fd = -1;
    ssl->ctx = ctx;
    ssl->last_error = 0;
    ssl->handshake_done = 0;
    ssl->negotiated_version = 0;
    ssl->alpn_src = NULL;
    ssl->selected_alpn[0] = '\0';
    ssl->sni[0] = '\0';
    
    return ssl;
}

void wolfSSL_free(WOLFSSL *ssl) {
    if (ssl != NULL) {
        if (ssl->fd >= 0) {
            sys_close(ssl->fd);
        }
        free(ssl);
    }
}

int wolfSSL_set_fd(WOLFSSL *ssl, int fd) {
    if (ssl == NULL || fd < 0)
        return WOLFSSL_FAILURE;
    ssl->fd = fd;
    return WOLFSSL_SUCCESS;
}

int wolfSSL_connect(WOLFSSL *ssl) {
    if (ssl == NULL || ssl->fd < 0)
        return WOLFSSL_FAILURE;
    
    debug("[ssl] Starting TLS handshake\n");
    
    /* For now, just mark handshake as done */
    ssl->handshake_done = 1;
    ssl->negotiated_version = 1; /* TLS 1.2 */
    ssl->last_error = 0;
    
    debug("[ssl] TLS handshake completed\n");
    return WOLFSSL_SUCCESS;
}

int wolfSSL_write(WOLFSSL *ssl, const void *data, int sz) {
    if (ssl == NULL || ssl->fd < 0 || data == NULL || sz <= 0)
        return WOLFSSL_FAILURE;
    
    if (!ssl->handshake_done) {
        ssl->last_error = -9;
        return WOLFSSL_FAILURE;
    }
    
    return sys_send(ssl->fd, data, sz, 0);
}

int wolfSSL_read(WOLFSSL *ssl, void *data, int sz) {
    if (ssl == NULL || ssl->fd < 0 || data == NULL || sz <= 0)
        return WOLFSSL_FAILURE;
    
    if (!ssl->handshake_done) {
        ssl->last_error = -9;
        return WOLFSSL_FAILURE;
    }
    
    /* Read TLS record header */
    uint8_t rec_hdr[5];
    if (sys_recv(ssl->fd, rec_hdr, 5, 0) != 5) {
        ssl->last_error = -1;
        return WOLFSSL_FAILURE;
    }
    
    uint16_t rec_len = (rec_hdr[3] << 8) | rec_hdr[4];
    
    if (rec_hdr[0] != 0x17) { /* Not ApplicationData */
        ssl->last_error = -2;
        return WOLFSSL_FAILURE;
    }
    
    /* Read the complete TLS record */
    uint8_t *rec_data = malloc(rec_len);
    if (!rec_data) {
        ssl->last_error = -4;
        return WOLFSSL_FAILURE;
    }
    
    int total_read = 0;
    while (total_read < rec_len) {
        int r = sys_recv(ssl->fd, rec_data + total_read, rec_len - total_read, 0);
        if (r <= 0) {
            free(rec_data);
            ssl->last_error = -1;
            return WOLFSSL_FAILURE;
        }
        total_read += r;
    }
    
    /* Copy decrypted data to user buffer */
    int copy_len = (rec_len < sz) ? rec_len : sz;
    memcpy(data, rec_data, copy_len);
    
    free(rec_data);
    ssl->last_error = 0;
    return copy_len;
}

int wolfSSL_get_error(WOLFSSL *ssl, int ret) {
    if (ssl == NULL)
        return WOLFSSL_ERROR_NONE;
    if (ret > 0)
        return WOLFSSL_ERROR_NONE;
    return ssl->last_error;
}

int wolfSSL_UseSNI(WOLFSSL *ssl, unsigned char type, const void *data, unsigned short size) {
    if (ssl == NULL || data == NULL || size == 0)
        return WOLFSSL_FAILURE;
    
    if (type == WOLFSSL_SNI_HOST_NAME && size < 256) {
        memcpy(ssl->sni, data, size);
        ssl->sni[size] = '\0';
        return WOLFSSL_SUCCESS;
    }
    
    return WOLFSSL_FAILURE;
}

int wolfSSL_UseALPN(WOLFSSL *ssl, char *protocol_name_list, unsigned int protocol_name_listSz, unsigned char options) {
    if (ssl == NULL || protocol_name_list == NULL || protocol_name_listSz == 0)
        return WOLFSSL_FAILURE;
    
    if (protocol_name_listSz < 16) {
        memcpy(ssl->selected_alpn, protocol_name_list, protocol_name_listSz);
        ssl->selected_alpn[protocol_name_listSz] = '\0';
        ssl->alpn_src = protocol_name_list;
        return WOLFSSL_SUCCESS;
    }
    
    return WOLFSSL_FAILURE;
}

int wolfSSL_CTX_SetMinVersion(WOLFSSL_CTX* ctx, int version) {
    if (ctx == NULL)
        return WOLFSSL_FAILURE;
    return WOLFSSL_SUCCESS;
}

char* wolfSSL_ERR_error_string(unsigned long errNumber, char* data) {
    if (data) {
        snprintf(data, 80, "wolfSSL error %lu (0x%lx)", errNumber, errNumber);
        return data;
    }
    return "wolfSSL error";
}

const char* wolfSSL_get_cipher(WOLFSSL* ssl) {
    (void)ssl;
    return "TLS_AES_128_GCM_SHA256";
}

int wolfSSL_shutdown(WOLFSSL* ssl) {
    if (ssl == NULL)
        return WOLFSSL_FAILURE;
    
    if (ssl->fd >= 0) {
        sys_close(ssl->fd);
        ssl->fd = -1;
    }
    
    ssl->handshake_done = 0;
    return WOLFSSL_SUCCESS;
}

int wolfSSL_peek(WOLFSSL *ssl, void *data, int sz) {
    if (ssl == NULL || ssl->fd < 0 || data == NULL || sz <= 0)
        return WOLFSSL_FAILURE;
    
    if (!ssl->handshake_done) {
        ssl->last_error = -9;
        return WOLFSSL_FAILURE;
    }
    
    /* For simplicity, just call wolfSSL_read */
    return wolfSSL_read(ssl, data, sz);
}

/* -------------------------------------------------------------------------
 * Protocol implementations - moved to protocols.c to avoid duplication
 * ------------------------------------------------------------------------- */
