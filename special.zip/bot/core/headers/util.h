#pragma once
#include "includes.h"
int util_strlen(const char *);
BOOL util_strncmp(const char *, const char *, int);
BOOL util_strcmp(const char *, const char *);
int util_strcpy(char *, const char *);
void util_memcpy(void *, const void *, int);
void util_memmove(void *, const void *, int);
void util_zero(void *, int);
int util_atoi(const char *, int);
char *util_itoa(int, int, char *);
char *util_strstr(char *, const char *);
int util_stristr(const char *, int, const char *);
ipv4_t util_local_addr(void);
char *util_fdgets(char *, int, int);
static inline int util_isupper(char c)
{
    return (c >= 'A' && c <= 'Z');
}
static inline int util_isalpha(char c)
{
    return ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'));
}
static inline int util_isspace(char c)
{
    return (c == ' ' || c == '\t' || c == '\n' || c == '\12');
}
static inline int util_isdigit(char c)
{
    return (c >= '0' && c <= '9');
}

