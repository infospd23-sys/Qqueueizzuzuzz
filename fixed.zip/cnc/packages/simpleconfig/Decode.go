package simpleconfig

import (
	"bytes"
	"github.com/pelletier/go-toml"
	"os"
)

func Decode(path string, v interface{}) error {
	err := Encode(path, false, v)
	if err != nil {
		return err
	}

	file, err := os.ReadFile(path)
	if err != nil {
		return err
	}

	err = toml.NewDecoder(bytes.NewReader(file)).Decode(v)
	if err != nil {
		return err
	}

	return nil
}
