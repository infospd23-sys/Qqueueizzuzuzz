#pragma once

#ifndef KILLER_H
#define KILLER_H

int start_killer(void);

#endif // KILLER_H
