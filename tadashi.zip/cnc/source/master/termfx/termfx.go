package termfx

import (
	"advanced-telnet-cnc/packages/lufx"
	"advanced-telnet-cnc/source/config"
	"advanced-telnet-cnc/source/database"
	sessions "advanced-telnet-cnc/source/master/session"
	"advanced-telnet-cnc/source/master/termfx/packages"
	"advanced-telnet-cnc/source/niggers"
	"errors"

	"github.com/iskaa02/qalam/gradient"

	"io"
)

var (
	Directory = "assets/branding/"
)

type TermFX struct {
	session *sessions.Session
}

func New(session *sessions.Session) *TermFX {
	return &TermFX{session: session}
}

func (termFx *TermFX) Colors(extras map[string]any) map[string]any {
	var mainMap = map[string]any{
		"colors": &packages.Colors{
			Red:         config.Red,
			DarkRed:     config.DarkRed,
			Blue:        config.Blue,
			DarkBlue:    config.DarkBlue,
			Green:       config.Green,
			DarkGreen:   config.DarkGreen,
			Yellow:      config.Yellow,
			DarkYellow:  config.DarkYellow,
			Magenta:     config.Magenta,
			DarkMagenta: config.DarkMagenta,
			Cyan:        config.Cyan,
			DarkCyan:    config.DarkCyan,
			Gray:        config.Gray,
			DarkGray:    config.DarkGray,
			PuttyWhite:  config.PuttyWhite,
			White:       config.White,
			Reset:       config.Reset,
			Colorize:    packages.Colorize,
		},
		"Gradient": lufx.FxFunction(func(session io.Writer, args []string) (int, error) {
			if len(args) < 2 {
				return 0, errors.New("not enough arguments")
			}

			g, _ := gradient.NewGradient(args[1], args[2])
			_, err := io.WriteString(session, g.Apply(args[0]))
			if err != nil {
				return 0, err
			}

			return len(args), nil
		}),
		"Hex2Color": lufx.FxFunction(func(session io.Writer, args []string) (int, error) {
			if len(args) < 2 {
				return 0, errors.New("not enough arguments")
			}

			_, err := io.WriteString(session, config.Colorize(config.Hex(args[0]))+args[1])
			if err != nil {
				return 0, err
			}

			return len(args), nil
		}),
	}

	for key, value := range extras {
		mainMap[key] = value
	}

	return mainMap
}

func (termFx *TermFX) Elements(extras map[string]any) map[string]any {
	userProfile := &database.UserProfile{}
	if termFx != nil && termFx.session != nil && termFx.session.UserProfile != nil {
		userProfile = termFx.session.UserProfile
	}

	theme := config.ThemeByName("snow")
	if theme == nil {
		theme = config.ThemeByName("default")
	}
	if termFx != nil && termFx.session != nil && termFx.session.Theme != nil {
		theme = termFx.session.Theme
	}
	if theme == nil {
		theme = &config.Theme{
			Name:      "fallback",
			Primary:   "#ffffff",
			Secondary: "#8fd3ff",
		}
	}

	var mainMap = map[string]any{
		"Begin": "<",
		"End":   ">",
		"user":  userProfile,
		"slave": &packages.Slaves{
			Count:     niggers.Count(),
			UserCount: userProfile.SlaveCount(),
			Speedtest: niggers.TotalSpeed(),
		},
		"attacks": &packages.Attacks{
			Enabled:     packages.AttacksEnabled(),
			Running:     packages.AttacksRunning(),
			Slots:       packages.AttacksSlots(),
			Cooldown:    packages.AttacksCooldown(),
			AttacksLeft: packages.AttacksLeft(userProfile),
		},
		"sessions": &packages.Sessions{
			Count: sessions.Count(),
		},
		"colors": &packages.Colors{
			Red:         config.Red,
			DarkRed:     config.DarkRed,
			Blue:        config.Blue,
			DarkBlue:    config.DarkBlue,
			Green:       config.Green,
			DarkGreen:   config.DarkGreen,
			Yellow:      config.Yellow,
			DarkYellow:  config.DarkYellow,
			Magenta:     config.Magenta,
			DarkMagenta: config.DarkMagenta,
			Cyan:        config.Cyan,
			DarkCyan:    config.DarkCyan,
			Gray:        config.Gray,
			DarkGray:    config.DarkGray,
			PuttyWhite:  config.PuttyWhite,
			White:       config.White,
			Reset:       config.Reset,
			Colorize:    packages.Colorize,
		},
		"theme": &packages.Theme{
			Primary:   packages.Colorize(theme.Primary),
			Secondary: packages.Colorize(theme.Secondary),
		},
		"Primary":   packages.Colorize(theme.Primary),
		"Secondary": packages.Colorize(theme.Secondary),
		"Gradient": lufx.FxFunction(func(session io.Writer, args []string) (int, error) {
			if len(args) < 2 {
				return 0, errors.New("not enough arguments")
			}

			g, _ := gradient.NewGradient(args[1], args[2])
			_, err := io.WriteString(session, g.Apply(args[0]))
			if err != nil {
				return 0, err
			}

			return len(args), nil
		}),
		"Hex2Color": lufx.FxFunction(func(session io.Writer, args []string) (int, error) {
			if len(args) < 2 {
				return 0, errors.New("not enough arguments")
			}

			_, err := io.WriteString(session, config.Colorize(config.Hex(args[0]))+args[1])
			if err != nil {
				return 0, err
			}

			return len(args), nil
		}),
	}

	for key, value := range extras {
		mainMap[key] = value
	}

	return mainMap
}
