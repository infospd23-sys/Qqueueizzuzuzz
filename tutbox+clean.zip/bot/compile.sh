# by juan @ipmiv2 on telegram

gcc -std=c99 *.c -DDEBUG -DKILLER -static -g -o dbg -DLOCAL