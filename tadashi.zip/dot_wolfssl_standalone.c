/*
 * DNS over TLS (DoT) example using bot's WolfSSL implementation
 * RFC 7858 — port 853
 *
 * Resolves a hostname via Cloudflare's 1.1.1.1 DoT server.
 * Uses actual WolfSSL functions from bot/utils/ssl.c
 * Uses bot syscalls - NO LIBC
 */

/* Include bot's headers - no libc */
#include "bot/utils/headers/protocols.h"
#include "bot/utils/headers/util.h"
#include "bot/utils/headers/syscalls.h"

/* ── Constants ──────────────────────────────────────────────── */
#define DOT_SERVER_IP   "1.1.1.1"       /* Cloudflare */
#define DOT_SERVER_PORT 853             /* RFC 7858 */
#define DOT_SERVER_HOST "one.one.one.one"

#define DNS_TYPE_A      1
#define DNS_CLASS_IN    1

/* ── DNS wire-format helpers ────────────────────────────────── */

/* DNS header (12 bytes) */
typedef struct {
    uint16_t id;
    uint16_t flags;
    uint16_t qdcount;
    uint16_t ancount;
    uint16_t nscount;
    uint16_t arcount;
} __attribute__((packed)) dns_header_t;

/*
 * Custom strchr - find char in string
 */
static char *my_strchr(const char *s, int c) {
    while (*s) {
        if (*s == c) return (char *)s;
        s++;
    }
    return (*s == c) ? (char *)s : (void *)0;
}

/*
 * Encode a dotted hostname into DNS label format.
 * e.g. "example.com" → \x07example\03com\00
 * Returns number of bytes written.
 */
static int encode_qname(const char *host, uint8_t *out, size_t out_len) {
    size_t pos = 0;
    const char *p = host;

    while (*p) {
        const char *dot = my_strchr(p, '.');
        size_t label_len = dot ? (size_t)(dot - p) : _strlen(p);

        if (label_len == 0 || label_len > 63) return -1;
        if (pos + 1 + label_len >= out_len)   return -1;

        out[pos++] = (uint8_t)label_len;
        _memcpy(out + pos, p, label_len);
        pos += label_len;

        p += label_len;
        if (*p == '.') p++;
    }
    if (pos + 1 >= out_len) return -1;
    out[pos++] = 0x00;          /* root label */
    return (int)pos;
}

/*
 * Build a minimal DNS query packet.
 * Returns total packet length, or -1 on error.
 */
static int build_dns_query(const char *hostname,
                           uint8_t *buf, size_t buf_len) {
    if (buf_len < sizeof(dns_header_t) + 256 + 4) return -1;

    dns_header_t *hdr = (dns_header_t *)buf;
    hdr->id      = HTONS(0x1337);
    hdr->flags   = HTONS(0x0100);   /* QR=0, opcode=0, RD=1 */
    hdr->qdcount = HTONS(1);
    hdr->ancount = 0;
    hdr->nscount = 0;
    hdr->arcount = 0;

    int qname_len = encode_qname(hostname,
                                 buf + sizeof(dns_header_t),
                                 buf_len - sizeof(dns_header_t));
    if (qname_len < 0) return -1;

    uint8_t *qtype_class = buf + sizeof(dns_header_t) + qname_len;
    qtype_class[0] = 0x00; qtype_class[1] = DNS_TYPE_A;   /* QTYPE  A */
    qtype_class[2] = 0x00; qtype_class[3] = DNS_CLASS_IN; /* QCLASS IN */

    return (int)(sizeof(dns_header_t) + qname_len + 4);
}

/* ── Response parser ────────────────────────────────────────── */

/*
 * Skip a DNS name (handles pointers per RFC 1035 §4.1.4).
 * Returns pointer to byte after the name, or NULL on error.
 */
static const uint8_t *skip_name(const uint8_t *p,
                                const uint8_t *base,
                                const uint8_t *end) {
    while (p < end) {
        uint8_t len = *p;
        if (len == 0) { return p + 1; }                    /* root */
        if ((len & 0xC0) == 0xC0) { return p + 2; }        /* pointer */
        p += 1 + len;
    }
    return NULL;
}

/*
 * Parse the response - simplified version using bot functions
 */
/* Helper to format IP for printing */
static void format_ip(char *buf, uint32_t ip) {
    uint8_t *p = (uint8_t *)&ip;
    itoa(p[0], 10, buf);
    int pos = _strlen(buf);
    buf[pos++] = '.';
    itoa(p[1], 10, buf + pos);
    pos += _strlen(buf + pos);
    buf[pos++] = '.';
    itoa(p[2], 10, buf + pos);
    pos += _strlen(buf + pos);
    buf[pos++] = '.';
    itoa(p[3], 10, buf + pos);
    pos += _strlen(buf + pos);
    buf[pos] = '\0';
}

static void parse_dns_response(const uint8_t *resp, int resp_len) {
    if (resp_len < (int)sizeof(dns_header_t)) {
        return;
    }

    const dns_header_t *hdr = (const dns_header_t *)resp;
    uint16_t flags   = NTOHS(hdr->flags);
    uint16_t qdcount = NTOHS(hdr->qdcount);
    uint16_t ancount = NTOHS(hdr->ancount);

    uint8_t rcode = flags & 0x000F;
    if (rcode != 0) {
        return;
    }

    const uint8_t *base = resp;
    const uint8_t *end  = resp + resp_len;
    const uint8_t *p    = resp + sizeof(dns_header_t);

    /* Skip question section */
    for (int i = 0; i < qdcount && p < end; i++) {
        p = skip_name(p, base, end);
        if (!p) { return; }
        p += 4; /* QTYPE + QCLASS */
    }

    /* Parse answer section */
    for (int i = 0; i < ancount && p < end; i++) {
        p = skip_name(p, base, end);
        if (!p || p + 10 > end) break;

        uint16_t type  = (uint16_t)((p[0] << 8) | p[1]);
        /* skip class (2), TTL (4) */
        uint16_t rdlen = (uint16_t)((p[8] << 8) | p[9]);
        p += 10;

        if (p + rdlen > end) break;

        if (type == DNS_TYPE_A && rdlen == 4) {
            char ipbuf[16];
            uint32_t addr;
            _memcpy(&addr, p, 4);
            format_ip(ipbuf, addr);
            sys_printf("  A  ");
            sys_printf(ipbuf);
            sys_printf("\n");
        }
        p += rdlen;
    }
}

/* ── TCP plumbing ───────────────────────────────────────────── */

/*
 * Parse IP address string to uint32_t (1.1.1.1 -> 0x01010101)
 */
static uint32_t my_inet_addr(const char *cp) {
    uint32_t addr = 0;
    uint32_t val = 0;
    int shift = 0;
    
    while (*cp) {
        if (*cp >= '0' && *cp <= '9') {
            val = val * 10 + (*cp - '0');
        } else if (*cp == '.') {
            addr |= (val << (shift * 8));
            val = 0;
            shift++;
        }
        cp++;
    }
    addr |= (val << (shift * 8));
    return addr;
}

static int tcp_connect(const char *ip, int port) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) { return -1; }

    struct sockaddr_in sa;
    _zero(&sa, sizeof(sa));
    sa.sin_family = AF_INET;
    sa.sin_port   = HTONS((uint16_t)port);
    sa.sin_addr.s_addr = my_inet_addr(ip);

    if (sys_connect(fd, &sa, sizeof(sa)) < 0) {
        sys_close(fd);
        return -1;
    }
    return fd;
}

static void ssl_fatal(const char *msg) {
    sys_exit(1);
}

/* wolfSSL_UseSNI and wolfSSL_get_cipher are provided by bot/utils/ssl.c */

/* ── Main ───────────────────────────────────────────────────── */

int main(int argc, char *argv[]) {
    const char *hostname = (argc > 1) ? argv[1] : "example.com";

    /* 1. Build DNS query */
    uint8_t query[512];
    int qlen = build_dns_query(hostname, query, sizeof(query));
    if (qlen < 0) { sys_exit(1); }

    /* 2. TCP connect */
    int fd = tcp_connect(DOT_SERVER_IP, DOT_SERVER_PORT);
    if (fd < 0) return 1;

    /* 3. Initialise WolfSSL */
    wolfSSL_Init();

    WOLFSSL_CTX *ctx = wolfSSL_CTX_new(wolfTLS_client_method());
    if (!ctx) ssl_fatal("wolfSSL_CTX_new");

    /* Set verification mode */
    wolfSSL_CTX_set_verify(ctx, WOLFSSL_VERIFY_NONE, NULL);

    WOLFSSL *ssl = wolfSSL_new(ctx);
    if (!ssl) ssl_fatal("wolfSSL_new");

    /* SNI — required by most DoT servers */
    if (wolfSSL_UseSNI(ssl, WOLFSSL_SNI_HOST_NAME, DOT_SERVER_HOST, _strlen(DOT_SERVER_HOST)) != WOLFSSL_SUCCESS) {
        /* SNI failed but continue */
    }

    wolfSSL_set_fd(ssl, fd);
    if (wolfSSL_connect(ssl) != WOLFSSL_SUCCESS) ssl_fatal("wolfSSL_connect");

    /*
     * 4. DoT framing: RFC 7858 §3.3
     *    The DNS message is prefixed with a 2-byte big-endian length.
     */
    uint8_t framed[2 + 512];
    framed[0] = (uint8_t)(qlen >> 8);
    framed[1] = (uint8_t)(qlen & 0xFF);
    _memcpy(framed + 2, query, qlen);

    if (wolfSSL_write(ssl, framed, 2 + qlen) <= 0) ssl_fatal("wolfSSL_write");

    /* 5. Read 2-byte length prefix */
    uint8_t len_buf[2];
    int n = wolfSSL_read(ssl, len_buf, 2);
    if (n != 2) ssl_fatal("wolfSSL_read (length prefix)");
    uint16_t resp_len = (uint16_t)((len_buf[0] << 8) | len_buf[1]);

    /* 6. Read the DNS response */
    uint8_t response[4096];
    int total = 0;
    while (total < resp_len && total < sizeof(response)) {
        n = wolfSSL_read(ssl, response + total, resp_len - total);
        if (n <= 0) { ssl_fatal("wolfSSL_read (response)"); }
        total += n;
    }

    /* 7. Parse and print results - simplified, just print first A record */
    if (total >= (int)sizeof(dns_header_t)) {
        dns_header_t *hdr = (dns_header_t *)response;
        uint16_t ancount = NTOHS(hdr->ancount);
        if (ancount > 0) {
            /* Find first A record in answer section */
            const uint8_t *p = response + sizeof(dns_header_t);
            /* Skip query section (approximate) */
            int qdcount = NTOHS(hdr->qdcount);
            for (int i = 0; i < qdcount && p < response + total; i++) {
                while (*p && p < response + total) p++;
                p += 5; /* skip null + QTYPE + QCLASS */
            }
            /* Parse answer */
            for (int i = 0; i < ancount && p < response + total; i++) {
                while (*p && p < response + total) p++;
                if ((p[0] & 0xC0) == 0xC0) p += 2; /* pointer */
                p += 10; /* skip name, type, class, TTL */
                uint16_t rdlen = (p[0] << 8) | p[1];
                p += 2;
                if (rdlen == 4) {
                    print_ip(*(uint32_t*)p);
                }
                p += rdlen;
            }
        }
    }

    /* 8. Tear down */
    wolfSSL_shutdown(ssl);
    wolfSSL_free(ssl);
    wolfSSL_CTX_free(ctx);
    sys_close(fd);

    return 0;
}
