package encryption

import (
	"fmt"
)

var tableKey = `someoffdeeznuts`

func xorCrypt(input, key string) (output string) {
	for i := 0; i < len(input); i++ {
		output += string(input[i] ^ key[i%len(key)])
	}

	return output
}

func byteToInt(b byte) int {
	return int(b)
}

func Crypt(input string) {
	encryptedString := xorCrypt(input, tableKey)
	fmt.Printf("XOR'ing %d bytes: ", len(encryptedString))
	for _, b := range encryptedString {
		fmt.Printf("\\x%02X", b)
	}
	fmt.Println()
}
