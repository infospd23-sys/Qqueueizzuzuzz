#pragma once

#include "protocols.h"

int wolfSSL_Init(void);
void wolfSSL_Cleanup(void);
WOLFSSL *wolfSSL_new(WOLFSSL_CTX *ctx);
int wolfSSL_connect(WOLFSSL *ssl);
int wolfSSL_read(WOLFSSL *ssl, void *buf, int sz);
int wolfSSL_write(WOLFSSL *ssl, const void *buf, int sz);
