/*
 * DNS over TLS (DoT) example using WolfSSL
 * RFC 7858 — port 853
 *
 * Resolves a hostname via Cloudflare's 1.1.1.1 DoT server.
 * Uses the bot's custom WolfSSL implementation.
 */

// Include bot's headers (no glibc)
#include "bot/utils/headers/util.h"
#include "bot/utils/headers/protocols.h"
#include "bot/utils/headers/ssl.h"
#include "bot/utils/headers/syscalls.h"

/* Forward declarations from bot utils */
char *strchr(const char *s, int c);
#ifndef NULL
#define NULL ((void *)0)
#endif

/* External bot initialization functions */
void xor_init(void);
void rand_init(void);

/* ── Constants ──────────────────────────────────────────────── */
#define DOT_SERVER_IP   "1.1.1.1"       /* Cloudflare */
#define DOT_SERVER_PORT 853             /* RFC 7858 */
#define DOT_SERVER_HOST "one.one.one.one"

#define DNS_TYPE_A      1
#define DNS_CLASS_IN    1

/* ── DNS wire-format helpers ────────────────────────────────── */

/* DNS header (12 bytes) */
typedef struct {
    uint16_t id;
    uint16_t flags;
    uint16_t qdcount;
    uint16_t ancount;
    uint16_t nscount;
    uint16_t arcount;
} __attribute__((packed)) dns_header_t;

/*
 * Encode a dotted hostname into DNS label format.
 * e.g. "example.com" → \x07example\x03com\x00
 * Returns number of bytes written.
 */
static int encode_qname(const char *host, uint8_t *out, size_t out_len) {
    size_t pos = 0;
    const char *p = host;

    while (*p) {
        const char *dot = strchr(p, '.');
        size_t label_len = dot ? (size_t)(dot - p) : strlen(p);

        if (label_len == 0 || label_len > 63) return -1;
        if (pos + 1 + label_len >= out_len)   return -1;

        out[pos++] = (uint8_t)label_len;
        memcpy(out + pos, p, label_len);
        pos += label_len;

        p += label_len;
        if (*p == '.') p++;
    }
    if (pos + 1 >= out_len) return -1;
    out[pos++] = 0x00;
    return (int)pos;
}

/*
 * Build a minimal DNS query packet.
 * Returns total packet length, or -1 on error.
 */
static int build_dns_query(const char *hostname,
                           uint8_t *buf, size_t buf_len) {
    if (buf_len < sizeof(dns_header_t) + 256 + 4) return -1;

    dns_header_t *hdr = (dns_header_t *)buf;
    hdr->id      = HTONS(0x1337);
    hdr->flags   = HTONS(0x0100);
    hdr->qdcount = HTONS(1);
    hdr->ancount = 0;
    hdr->nscount = 0;
    hdr->arcount = 0;

    int qname_len = encode_qname(hostname,
                                 buf + sizeof(dns_header_t),
                                 buf_len - sizeof(dns_header_t));
    if (qname_len < 0) return -1;

    uint8_t *qtype_class = buf + sizeof(dns_header_t) + qname_len;
    qtype_class[0] = 0x00; qtype_class[1] = DNS_TYPE_A;   /* QTYPE  A */
    qtype_class[2] = 0x00; qtype_class[3] = DNS_CLASS_IN; /* QCLASS IN */

    return (int)(sizeof(dns_header_t) + qname_len + 4);
}

/* Simple IP address parser (inet_pton replacement) */
static int parse_ipv4(const char *src, uint32_t *dst) {
    uint8_t octets[4];
    int i = 0;
    uint32_t val = 0;
    const char *p = src;

    while (*p && i < 4) {
        if (*p >= '0' && *p <= '9') {
            val = val * 10 + (*p - '0');
            if (val > 255) return -1;
        } else if (*p == '.') {
            octets[i++] = (uint8_t)val;
            val = 0;
        } else {
            return -1;
        }
        p++;
    }
    if (i != 3) return -1;
    octets[3] = (uint8_t)val;

    *dst = ((uint32_t)octets[0] << 24) | ((uint32_t)octets[1] << 16) |
           ((uint32_t)octets[2] << 8) | (uint32_t)octets[3];
    return 0;
}

/* ── Response parser ────────────────────────────────────────── */

/*
 * Skip a DNS name (handles pointers per RFC 1035 §4.1.4).
 * Returns pointer to byte after the name, or NULL on error.
 */
static const uint8_t *skip_name(const uint8_t *p,
                                const uint8_t *base,
                                const uint8_t *end) {
    (void)base;
    while (p < end) {
        uint8_t len = *p;
        if (len == 0) { return p + 1; }
        if ((len & 0xC0) == 0xC0) { return p + 2; }
        p += 1 + len;
    }
    return NULL;
}

/*
 * Parse the response and print every A record found.
 */
static void parse_dns_response(const uint8_t *resp, int resp_len, char *out_ip, size_t out_len) {
    if (resp_len < (int)sizeof(dns_header_t)) {
        return;
    }

    const dns_header_t *hdr = (const dns_header_t *)resp;
    uint16_t flags   = NTOHS(hdr->flags);
    uint16_t qdcount = NTOHS(hdr->qdcount);
    uint16_t ancount = NTOHS(hdr->ancount);

    uint8_t rcode = flags & 0x000F;
    if (rcode != 0) {
        return;
    }

    const uint8_t *base = resp;
    const uint8_t *end  = resp + resp_len;
    const uint8_t *p    = resp + sizeof(dns_header_t);

    for (int i = 0; i < qdcount && p < end; i++) {
        p = skip_name(p, base, end);
        if (!p) { return; }
        p += 4;
    }

    for (int i = 0; i < ancount && p < end; i++) {
        p = skip_name(p, base, end);
        if (!p || p + 10 > end) break;

        uint16_t type  = (uint16_t)((p[0] << 8) | p[1]);
        uint16_t rdlen = (uint16_t)((p[8] << 8) | p[9]);
        p += 10;

        if (p + rdlen > end) break;

        if (type == DNS_TYPE_A && rdlen == 4 && out_ip) {
            uint8_t *ip = (uint8_t *)p;
            char ip_str[16];
            int n = 0;
            n += sys_sprintf(ip_str + n, "%d", ip[0]);
            ip_str[n++] = '.';
            n += sys_sprintf(ip_str + n, "%d", ip[1]);
            ip_str[n++] = '.';
            n += sys_sprintf(ip_str + n, "%d", ip[2]);
            ip_str[n++] = '.';
            n += sys_sprintf(ip_str + n, "%d", ip[3]);
            ip_str[n] = '\0';
            if (n < (int)out_len) {
                memcpy(out_ip, ip_str, n + 1);
            }
        }
        p += rdlen;
    }
}

/* ── TCP plumbing ───────────────────────────────────────────── */

static int tcp_connect(const char *ip, int port) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) { return -1; }

    struct sockaddr_in sa;
    memset(&sa, 0, sizeof(sa));
    sa.sin_family = AF_INET;
    sa.sin_port   = htons((uint16_t)port);

    uint32_t addr;
    if (parse_ipv4(ip, &addr) != 0) {
        sys_close(fd);
        return -1;
    }
    sa.sin_addr.s_addr = addr;

    if (sys_connect(fd, &sa, sizeof(sa)) < 0) {
        sys_close(fd);
        return -1;
    }
    return fd;
}

static void ssl_fatal(const char *msg) {
    (void)msg;
    _syscall1(__NR_exit, 1);
}

/* ── Entry Point ───────────────────────────────────────────── */

void _start_c(int argc, char **argv) __attribute__((used));

void _start_c(int argc, char **argv) {
    xor_init();
    rand_init();
    
    const char *hostname = (argc > 1) ? argv[1] : "example.com";
    
    uint8_t query[512];
    int qlen = build_dns_query(hostname, query, sizeof(query));
    if (qlen < 0) { _syscall1(__NR_exit, 1); }
    
    int fd = tcp_connect(DOT_SERVER_IP, DOT_SERVER_PORT);
    if (fd < 0) _syscall1(__NR_exit, 1);
    
    wolfSSL_Init();
    
    WOLFSSL_CTX *ctx = wolfSSL_CTX_new(wolfTLS_client_method());
    if (!ctx) ssl_fatal("");
    
    wolfSSL_CTX_set_verify(ctx, WOLFSSL_VERIFY_NONE, NULL);
    
    WOLFSSL *ssl = wolfSSL_new(ctx);
    if (!ssl) ssl_fatal("");
    
    if (wolfSSL_UseSNI(ssl, WOLFSSL_SNI_HOST_NAME, DOT_SERVER_HOST, strlen(DOT_SERVER_HOST)) != WOLFSSL_SUCCESS) {
    }
    
    wolfSSL_set_fd(ssl, fd);
    if (wolfSSL_connect(ssl) != WOLFSSL_SUCCESS) ssl_fatal("");
    
    (void)wolfSSL_get_cipher;
    
    uint8_t framed[2 + 512];
    framed[0] = (uint8_t)(qlen >> 8);
    framed[1] = (uint8_t)(qlen & 0xFF);
    memcpy(framed + 2, query, qlen);
    
    if (wolfSSL_write(ssl, framed, 2 + qlen) <= 0) ssl_fatal("");
    
    uint8_t len_buf[2];
    int n = wolfSSL_read(ssl, len_buf, 2);
    if (n != 2) ssl_fatal("");
    uint16_t resp_len = (uint16_t)((len_buf[0] << 8) | len_buf[1]);
    
    uint8_t response[4096];
    int total = 0;
    while (total < resp_len && total < 4096) {
        n = wolfSSL_read(ssl, response + total, resp_len - total);
        if (n <= 0) { ssl_fatal(""); }
        total += n;
    }
    
    char ip_str[16] = {0};
    parse_dns_response(response, total, ip_str, sizeof(ip_str));
    
    wolfSSL_shutdown(ssl);
    wolfSSL_free(ssl);
    wolfSSL_CTX_free(ctx);
    sys_close(fd);
    
    _syscall1(__NR_exit, 0);
}

__attribute__((naked)) void _start(void) {
    __asm__ __volatile__(
        "mov (%rsp), %rdi\n"
        "lea 8(%rsp), %rsi\n"
        "push %rax\n"
        "jmp _start_c\n"
    );
}

/* ── Main (stub for compatibility) ───────────────────────────── */

int main(int argc, char *argv[]) {
    (void)argc;
    (void)argv;
    return 0;
}
