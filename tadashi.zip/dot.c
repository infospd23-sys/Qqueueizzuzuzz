/*
 * DNS over TLS (DoT) in C — using wolfSSL
 * RFC 7858 — port 853
 *
 * Resolves a hostname via Cloudflare's 1.1.1.1 DoT server.
 *
 * Install wolfSSL (Debian/Ubuntu):
 *   sudo apt install libwolfssl-dev
 *
 *   — or build from source with certificate verification enabled:
 *   ./configure --enable-opensslextra && make && sudo make install
 *
 * Build:
 *   gcc dns_over_tls_wolf.c -o dns_over_tls_wolf -lwolfssl
 *
 * Usage:
 *   ./dns_over_tls_wolf [hostname]
 *   ./dns_over_tls_wolf example.com
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

/* Enable wolfSSL extensions before including headers */
#define HAVE_SNI

/* wolfSSL — drop-in compatible with OpenSSL API surface */
#include <wolfssl/ssl.h>

/* ── Constants ──────────────────────────────────────────────── */
#define DOT_SERVER_IP   "1.1.1.1"
#define DOT_SERVER_PORT 853
#define DOT_SERVER_HOST "one.one.one.one"

#define DNS_TYPE_A   1
#define DNS_CLASS_IN 1

/* ── DNS wire-format helpers ────────────────────────────────── */

typedef struct {
    uint16_t id;
    uint16_t flags;
    uint16_t qdcount;
    uint16_t ancount;
    uint16_t nscount;
    uint16_t arcount;
} __attribute__((packed)) dns_header_t;

static int encode_qname(const char *host, uint8_t *out, size_t out_len) {
    size_t pos = 0;
    const char *p = host;

    while (*p) {
        const char *dot = strchr(p, '.');
        size_t label_len = dot ? (size_t)(dot - p) : strlen(p);

        if (label_len == 0 || label_len > 63)    return -1;
        if (pos + 1 + label_len >= out_len)       return -1;

        out[pos++] = (uint8_t)label_len;
        memcpy(out + pos, p, label_len);
        pos += label_len;

        p += label_len;
        if (*p == '.') p++;
    }
    if (pos + 1 >= out_len) return -1;
    out[pos++] = 0x00;
    return (int)pos;
}

static int build_dns_query(const char *hostname,
                           uint8_t *buf, size_t buf_len) {
    if (buf_len < sizeof(dns_header_t) + 256 + 4) return -1;

    dns_header_t *hdr = (dns_header_t *)buf;
    hdr->id      = htons(0x1337);
    hdr->flags   = htons(0x0100);   /* RD=1 */
    hdr->qdcount = htons(1);
    hdr->ancount = hdr->nscount = hdr->arcount = 0;

    int qname_len = encode_qname(hostname,
                                 buf + sizeof(dns_header_t),
                                 buf_len - sizeof(dns_header_t));
    if (qname_len < 0) return -1;

    uint8_t *qt = buf + sizeof(dns_header_t) + qname_len;
    qt[0] = 0x00; qt[1] = DNS_TYPE_A;
    qt[2] = 0x00; qt[3] = DNS_CLASS_IN;

    return (int)(sizeof(dns_header_t) + qname_len + 4);
}

/* ── Response parser ────────────────────────────────────────── */

static const uint8_t *skip_name(const uint8_t *p,
                                const uint8_t *end) {
    while (p < end) {
        uint8_t len = *p;
        if (len == 0)               return p + 1;   /* root  */
        if ((len & 0xC0) == 0xC0)  return p + 2;   /* ptr   */
        p += 1 + len;
    }
    return NULL;
}

static void parse_dns_response(const uint8_t *resp, int resp_len) {
    if (resp_len < (int)sizeof(dns_header_t)) {
        fprintf(stderr, "Response too short\n");
        return;
    }

    const dns_header_t *hdr = (const dns_header_t *)resp;
    uint16_t flags   = ntohs(hdr->flags);
    uint16_t qdcount = ntohs(hdr->qdcount);
    uint16_t ancount = ntohs(hdr->ancount);

    if (flags & 0x000F) {
        fprintf(stderr, "DNS rcode=%u\n", flags & 0x000F);
        return;
    }
    printf("Answer count: %u\n", ancount);

    const uint8_t *end = resp + resp_len;
    const uint8_t *p   = resp + sizeof(dns_header_t);

    for (int i = 0; i < qdcount && p && p < end; i++) {
        p = skip_name(p, end);
        if (p) p += 4;
    }

    for (int i = 0; i < ancount && p && p < end; i++) {
        p = skip_name(p, end);
        if (!p || p + 10 > end) break;

        uint16_t type  = (uint16_t)((p[0] << 8) | p[1]);
        uint16_t rdlen = (uint16_t)((p[8] << 8) | p[9]);
        p += 10;

        if (p + rdlen > end) break;

        if (type == DNS_TYPE_A && rdlen == 4) {
            struct in_addr addr;
            memcpy(&addr, p, 4);
            printf("  A  %s\n", inet_ntoa(addr));
        }
        p += rdlen;
    }
}

/* ── TCP helper ─────────────────────────────────────────────── */

static int tcp_connect(const char *ip, int port) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) { perror("socket"); return -1; }

    struct sockaddr_in sa = {0};
    sa.sin_family = AF_INET;
    sa.sin_port   = htons((uint16_t)port);
    inet_pton(AF_INET, ip, &sa.sin_addr);

    if (connect(fd, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
        perror("connect"); close(fd); return -1;
    }
    return fd;
}

/* ── Main ───────────────────────────────────────────────────── */

int main(int argc, char *argv[]) {
    const char *hostname = (argc > 1) ? argv[1] : "example.com";
    printf("Resolving \"%s\" via DoT (%s:%d) with wolfSSL …\n\n",
           hostname, DOT_SERVER_IP, DOT_SERVER_PORT);

    /* 1. Build DNS query */
    uint8_t query[512];
    int qlen = build_dns_query(hostname, query, sizeof(query));
    if (qlen < 0) { fprintf(stderr, "Failed to build query\n"); return 1; }

    /* 2. TCP connect */
    int fd = tcp_connect(DOT_SERVER_IP, DOT_SERVER_PORT);
    if (fd < 0) return 1;

    /* 3. Initialise wolfSSL
     *
     * wolfSSL_Init() is the equivalent of SSL_library_init().
     * wolfTLSv1_3_client_method() locks us to TLS 1.3;
     * use wolfSSLv23_client_method() to allow TLS 1.2 fallback.
     */
    if (wolfSSL_Init() != WOLFSSL_SUCCESS) {
        fprintf(stderr, "wolfSSL_Init failed\n");
        return 1;
    }

    WOLFSSL_CTX *ctx = wolfSSL_CTX_new(wolfTLSv1_2_client_method());
    if (!ctx) { fprintf(stderr, "wolfSSL_CTX_new failed\n"); return 1; }

    /*
     * Certificate verification.
     *
     * Option A — system CA bundle (most Linux distros):
     *   wolfSSL_CTX_load_verify_locations(ctx, "/etc/ssl/certs/ca-certificates.crt", NULL);
     *
     * Option B — directory of hashed PEM certs:
     *   wolfSSL_CTX_load_verify_locations(ctx, NULL, "/etc/ssl/certs");
     *
     * Option C — disable verification (NOT for production):
     *   wolfSSL_CTX_set_verify(ctx, WOLFSSL_VERIFY_NONE, NULL);
     */
    if (wolfSSL_CTX_load_verify_locations(ctx,
            "/etc/ssl/certs/ca-certificates.crt", NULL) != WOLFSSL_SUCCESS) {
        /* Fallback: try the cert directory */
        if (wolfSSL_CTX_load_verify_locations(ctx,
                NULL, "/etc/ssl/certs") != WOLFSSL_SUCCESS) {
            fprintf(stderr, "Warning: could not load CA bundle — "
                            "cert verification may fail\n");
        }
    }
    wolfSSL_CTX_set_verify(ctx, WOLFSSL_VERIFY_PEER, NULL);

    /* 4. Create a wolfSSL session and attach to our TCP socket */
    WOLFSSL *ssl = wolfSSL_new(ctx);
    if (!ssl) { fprintf(stderr, "wolfSSL_new failed\n"); return 1; }

    wolfSSL_set_fd(ssl, fd);

    /* SNI — required by most DoT servers */
    wolfSSL_UseSNI(ssl, 0, DOT_SERVER_HOST, (uint16_t)strlen(DOT_SERVER_HOST));

    /* 5. TLS handshake */
    if (wolfSSL_connect(ssl) != WOLFSSL_SUCCESS) {
        int err = wolfSSL_get_error(ssl, 0);
        char err_buf[80];
        wolfSSL_ERR_error_string(err, err_buf);
        fprintf(stderr, "wolfSSL_connect error: %s\n", err_buf);
        wolfSSL_free(ssl);
        wolfSSL_CTX_free(ctx);
        close(fd);
        return 1;
    }

    printf("TLS connected. Cipher: %s\n\n",
           wolfSSL_get_cipher(ssl));

    /*
     * 6. DoT framing (RFC 7858 §3.3):
     *    2-byte big-endian length prefix before the DNS message.
     */
    uint8_t framed[2 + sizeof(query)];
    framed[0] = (uint8_t)(qlen >> 8);
    framed[1] = (uint8_t)(qlen & 0xFF);
    memcpy(framed + 2, query, qlen);

    if (wolfSSL_write(ssl, framed, 2 + qlen) <= 0) {
        fprintf(stderr, "wolfSSL_write failed\n");
        return 1;
    }

    /* 7. Read 2-byte length prefix */
    uint8_t len_buf[2];
    if (wolfSSL_read(ssl, len_buf, 2) != 2) {
        fprintf(stderr, "wolfSSL_read (length) failed\n");
        return 1;
    }
    uint16_t resp_len = (uint16_t)((len_buf[0] << 8) | len_buf[1]);

    /* 8. Read DNS response */
    uint8_t response[65536];
    int total = 0;
    while (total < resp_len) {
        int n = wolfSSL_read(ssl, response + total, resp_len - total);
        if (n <= 0) {
            int err = wolfSSL_get_error(ssl, n);
            char err_buf[80];
            wolfSSL_ERR_error_string(err, err_buf);
            fprintf(stderr, "wolfSSL_read error: %s\n", err_buf);
            return 1;
        }
        total += n;
    }

    /* 9. Parse and print */
    parse_dns_response(response, total);

    /* 10. Clean up */
    wolfSSL_shutdown(ssl);
    wolfSSL_free(ssl);
    wolfSSL_CTX_free(ctx);
    wolfSSL_Cleanup();
    close(fd);

    return 0;
}