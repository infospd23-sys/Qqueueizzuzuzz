void _start(void) {
    register long rax __asm__("rax") = 1;  // sys_write
    register long rdi __asm__("rdi") = 1;  // stdout
    register const char *rsi __asm__("rsi") = "Hello, World!\n";
    register long rdx __asm__("rdx") = 14; // length
    __asm__ volatile ("syscall" : : "r"(rax), "r"(rdi), "r"(rsi), "r"(rdx));

    rax = 60; // sys_exit
    rdi = 0;
    __asm__ volatile ("syscall" : : "r"(rax), "r"(rdi));
}
