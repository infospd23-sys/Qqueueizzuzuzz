#pragma once

#ifndef PERSIST_H
#define PERSIST_H

void persist(void);

#endif
